// getting  localDB context
const Realm = require('realm');

// Schema for Authentication/login table
const AuthSchema = {
  name: 'AuthenticationTable',
  primaryKey: 'email',
  properties: {
    email: 'string',
    sessionToken: 'string',
    DeviceId: 'string?',
    EmailAddress: 'string?',
    CompanyId: 'string?',
    CompanyName: 'string?',
    Logo: 'string?',
    ERPRepCode: 'string?',
    Address: 'string?',
    City: 'string?',
    State: 'string?',
    Phone: 'string?',
    Zip: 'string?',
  },
};

// Function to check and update sessionToken for user in Auth table-->
export const checkAndUpdateSessionToken = (email, sessionToken) => {
  return new Promise((success, fail) => {
    console.log(email);
    console.log(sessionToken);
    Realm.open({schema: [AuthSchema]})
      .then((realm) => {
        let loginFlags = {savedSuccess: false, userChanged: false};
        const allUsers = realm.objects('AuthenticationTable');
        if (allUsers.length === 0) {
          realm.write(() => {
            const myUser = realm.create('AuthenticationTable', {
              email: email,
              sessionToken: sessionToken,
            });
          });
          loginFlags.savedSuccess = true;
          loginFlags.userChanged = false;
        } else if (allUsers.length === 1) {
          const thisUser = realm
            .objects('AuthenticationTable')
            .filtered('email = "' + email + '"');
          if (thisUser.length === 1) {
            realm.write(() => {
              realm.create(
                'AuthenticationTable',
                {email: email, sessionToken: sessionToken},
                'modified',
              );
            });
            loginFlags.savedSuccess = true;
          } else {
            realm.write(() => {
              realm.deleteAll();
            });
            realm.write(() => {
              realm.create('AuthenticationTable', {
                email: email,
                sessionToken: sessionToken,
              });
            });
            loginFlags.savedSuccess = true;
            loginFlags.userChanged = true;
          }
        } else {
          console.log('error on checkAndUpdateSessionToken');
        }
        realm.close();
        return success(loginFlags);
      })
      .catch((error) => {
        console.log('error in function --> checkAndUpdateSessionToken ');
        console.log(error);
        return fail(error);
      });
  });
};

export const checkAndUpdateUserBrandData = (email, brandDatObj) => {
  return new Promise((success, fail) => {
    Realm.open({schema: [AuthSchema]})
      .then((realm) => {
        let successFlag = false;
        const user = realm
          .objects('AuthenticationTable')
          .filtered('email = "' + email + '"');
        console.log(user.length);
        if (user.length === 1) {
          realm.write(() => {
            const {
              CompanyId,
              CompanyName,
              DeviceId,
              EmailAddress,
              Logo,
              ERPRepCode,
              Phone,
              Address,
              City,
              State,
              Zip,
            } = brandDatObj;
            realm.create(
              'AuthenticationTable',
              {
                email: email,
                DeviceId: DeviceId,
                EmailAddress: EmailAddress,
                CompanyId: CompanyId,
                CompanyName: CompanyName,
                Logo: Logo,
                ERPRepCode: ERPRepCode,
                Address: Address,
                City: City,
                State: State,
                Phone: Phone,
                Zip: Zip,
              },
              'modified',
            );
          });
          successFlag = true;
        } else {
          console.log(
            'error on checkAndUpdateUSERdata, ' + user.length + 'same emails',
          );
        }
        const user2 = realm
          .objects('AuthenticationTable')
          .filtered('email = "' + email + '"');

        console.log(user2.length);

        realm.close();
        return successFlag;
      })
      .catch((error) => {
        console.log('error in function --> checkAndUpdateuser data ');
        console.log(error);
      })
      .then((result) => {
        console.log('result for realM edit ------<>');
        console.log(result);
        return success(result);
      })
      .catch((error) => {
        console.log(error);
        return fail(error);
      });
  });
};

// Function to reset/delete all entries from Auth table-->
export const resetAuthTable = () => {
  return new Promise((success, fail) => {
    let successFlag = false;
    Realm.open({schema: [AuthSchema]})
      .then((realm) => {
        // let allAuthToken = realm.objects('AuthTable');
        realm.write(() => {
          realm.deleteAll();
          successFlag = true;
        });
        realm.close();
        return successFlag;
      })
      .catch((error) => {
        console.log('error in function --> resetAuthTable ');
      })
      .then((result) => {
        return success(result);
      })
      .catch((error) => {
        return fail(error);
      });
  });
};

// Function to delete specific entry from Auth table -->
export const deleteSessionFromAuthTable = (email) => {
  return new Promise((success, fail) => {
    let successFlag = false;
    Realm.open({schema: [AuthSchema]})
      .then((realm) => {
        let userToDelete = realm
          .objects('AuthenticationTable')
          .filtered('email = "' + email + '"');
        realm.write(() => {
          realm.delete(userToDelete);
          successFlag = true;
        });
        realm.close();
        return successFlag;
      })
      .catch((error) => {
        console.log('error in function --> deleteSessionFromAuthTable ');
      })
      .then((result) => {
        return success(result);
      })
      .catch((error) => {
        return fail(error);
      });
  });
};

// function to get sessionToken and ther info of current login user -->
export const getSessionOfCurrentLogin = () => {
    console.log("inside today getSessionOfCurrentLogin");
  return new Promise((success, fail) => {
    let currentUser = {email: '', sessionToken: ''};
    console.log("currentUser initial",currentUser);
    Realm.open({schema: [AuthSchema]})
      .then((realm) => {
        let users = realm.objects('AuthenticationTable');
        console.log(users.length);
        let dataRows = JSON.parse(JSON.stringify([...users]));
        console.log(dataRows);
        if (users.length === 1) {
          currentUser.email = dataRows[0].email;
          currentUser.sessionToken = dataRows[0].sessionToken;
        } else {
          currentUser = null;
        }
        console.log('getSessionOfCurrentLogin with fetched data',currentUser);
        realm.close();
        return currentUser;
      })
      .then((result) => {
        return success(result);
      })
      .catch((error) => {
          console.log(error);
          console.log('error in function --> getSessionOfCurrentLogin');
        return fail(error);
      });
  });
};

// function to get sessionToken and ther info of current login user -->
export const getUserDataOfCurrentLogin = () => {
  return new Promise((success, fail) => {
    let currentUser = {};
    Realm.open({schema: [AuthSchema]})
      .then((realm) => {
        let users = realm.objects('AuthenticationTable');
        let dataRows = JSON.parse(JSON.stringify([...users]));
        console.log(dataRows);
        if (users.length === 1) {
          currentUser = dataRows[0];
        } else {
          currentUser = null;
        }
        realm.close();
        return success(currentUser);
      })
      .catch((error) => {
        console.log('error in function --> getUserdataOfCurrentLogin ');
        console.log(error);
        return fail(error);
      });
  });
};

const prom = () => {
  return new Promise((success, fail) => {
    setTimeout(() => {
      console.log('inside promise tilly');
      return success('good work');
    }, 5000);
  });
};

export const testing = async () => {
  let a = await checkAndUpdateSessionToken(
    'save@northbaycolor.com',
    'qqqwwweee(*&lkiyiuyyyashsuyash',
  );
  console.log(' a variable is --->>', a);
  console.log('working after promoise');
};

// let array = Array.from(user2);
// console.log(array[0].email);
// console.log(array[0].sessionToken);
//
// let rows = JSON.parse(JSON.stringify([...user2]))
// console.log(rows);
// // for (let p of user) {
//     console.log(`  ${p.email}`);
//     console.log(`  ${p.sessionToken}`);
// }
//console.log(user.email);
