// getting localDB context
const Realm = require('realm');

//Schema for Items list
const ItemSchema = {
  name: 'ItemTable',
  primaryKey: 'Id',
  properties: {
    AvailableQty: 'int',
    CompanyId: 'string',
    CreatedBy: 'string',
    CreatedDate: 'string',
    Description1: 'string',
    HasBarcode: 'bool',
    HasMSDS: 'bool',
    HasPresentation: 'bool',
    Id: 'string',
    ItemNo: 'string',
    LastSoldDate: 'string?',
    ListPrice: 'double',
      ImageData:'string?'
  },
};

export const saveItemsToRealm = (itemList) => {
  return new Promise((success, fail) => {
    let successFlag = false;

    Realm.open({schema: [ItemSchema]})
      .then((realm) => {
        for (let obj = 0; obj < itemList.length; obj++) {
          realm.write(() => {
            const {
              AvailableQty,
              CompanyId,
              CreatedBy,
              CreatedDate,
              Description1,
              HasBarcode,
              HasMSDS,
              HasPresentation,
              Id,
              ItemNo,
              LastSoldDate,
              ListPrice,
                ImageData
            } = itemList[obj];
            realm.create('ItemTable', {
              AvailableQty: AvailableQty,
              CompanyId: CompanyId,
              CreatedBy: CreatedBy,
              CreatedDate: CreatedDate,
              Description1: Description1,
              HasBarcode: HasBarcode,
              HasMSDS: HasMSDS,
              HasPresentation: HasPresentation,
              Id: Id,
              ItemNo: ItemNo,
              LastSoldDate: LastSoldDate,
              ListPrice: ListPrice,
                ImageData:ImageData
            });
          });
        }
        successFlag = true;
        realm.close();
        return successFlag;
      })
      .catch((error) => {
        console.log('error in function --> saveItemsToRealm');
        console.log(error);
      })
      .then((result) => {
        return success(result);
      })
      .catch((error) => {
        return fail(error);
      });
  });
};

export const getItemsListFromRealm = (offset) => {
  return new Promise((success, fail) => {
    let itemList = [];
    Realm.open({schema: [ItemSchema]})
      .then((realm) => {
        let items = realm.objects('ItemTable');
        let endLimit = offset + 20;

        if (items.length < endLimit) {
          endLimit = items.length;
        }

        for (let i = offset; i < endLimit; i++) {
          itemList.push(items[i]);
        }

        console.log('offset is ' + offset + ' end is ' + endLimit);
        console.log('Items list--->>><<>>', itemList);

        let itemsRows = JSON.parse(JSON.stringify([...itemList]));

        console.log(itemsRows);
        realm.close();
        itemList = itemsRows;
        return itemList;
      })
      .catch((error) => {
        console.log('error in function --> getItemsListFromRealm');
        console.log(error);
      })
      .then((result) => {
        return success(result);
      })
      .catch((error) => {
        return fail(error);
      });
  });
};

export const resetItemTable = () => {
  return new Promise((success, fail) => {
    let successFlag = false;
    Realm.open({schema: [ItemSchema]})
      .then((realm) => {
        realm.write(() => {
          realm.deleteAll();
          successFlag = true;
        });
        realm.close();
        return success(successFlag);
      })
      .catch((error) => {
        console.log('error on delete Items bulk');
        return fail(error);
      });
  });
};
