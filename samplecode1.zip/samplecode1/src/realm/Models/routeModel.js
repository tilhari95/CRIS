// getting  localDB context
const Realm = require('realm');

const RouteSchema = {
    name: 'RouteTable',
    primaryKey: 'Id',
    properties: {
        Id: 'string',
        CompanyId: 'string?',
        RouteName: 'string?',
        Description: 'string?',
        LastServiced: 'string?',
        NextService: 'string?',
        Every: 'string?',
        Frequency: 'int?',
        CreatedDate: 'string?',
        Sequence: 'int',
    },
};


export const updateRouteInRealM = (updatedObj) => {
    return new Promise((success, fail) => {
        Realm.open({schema: [RouteSchema]})
            .then((realm) => {
                const thisRoute = realm
                    .objects('RouteTable')
                    .filtered('Id = "' + updatedObj.Id + '"');
                if (thisRoute.length === 1) {
                    realm.write(() => {
                        realm.create(
                            'RouteTable',
                            {
                                Id: updatedObj.Id, RouteName: updatedObj.RouteName, Description: updatedObj.Description,
                                Every: updatedObj.Every, Frequency: parseInt(updatedObj.Frequency)
                            },
                            'modified',
                        );
                    });
                }
            })
            .then((result) => {
                return success(result);
            })
            .catch((error) => {
                console.log('error in function --> route item updating ');
                console.log(error);
                return fail(error);
            })
    });
};

export const getRouteListFromRealM = (offset) => {
    return new Promise((success, fail) => {
       // let routesList = [];
        Realm.open({schema: [RouteSchema]})
            .then((realm) => {
                let routes = realm.objects('RouteTable');
                let sortedRoutes = routes.sorted('Sequence');
                 //let endLimit= offset+50;
                // if(users.length <endLimit){
                //     endLimit=users.length;
                // }
                // for(let i=offset; i<endLimit; i++){
                //     customerList.push(users[i]);
                // }
               // console.log("offset is " +offset + "end is " + endLimit);
                //console.log("shorted customer list--->>><<>>", customerList)
                let routesRows = JSON.parse(JSON.stringify([...sortedRoutes]));

                //console.log(routesRows);
                realm.close();
          //      routesList = routesRows;
                return routesRows;
            })
            .catch((error) => {
                console.log('error in function --> route fetching ');
                console.log(error);
            })
            .then((result) => {
                return success(result);
            })
            .catch((error) => {
                return fail(error);
            });
    });
};

export const saveRouteToRealM = (routeList) => {
    return new Promise((success, fail) => {
        let successFlag = false;
        Realm.open({schema: [RouteSchema]})
            .then((realm) => {
                for (let obj = 0; obj < routeList.length; obj++) {
                    realm.write(() => {
                        const {
                            Id,
                            CompanyId,
                            RouteName,
                            Description,
                            LastServiced,
                            NextService,
                            Every,
                            Frequency,
                            CreatedDate,
                            Sequence,
                        } = routeList[obj];
                        realm.create(
                            'RouteTable',
                            {
                                Id: Id,
                                CompanyId: CompanyId,
                                RouteName: RouteName,
                                Description: Description,
                                LastServiced: LastServiced,
                                NextService: NextService,
                                Every: Every,
                                Frequency: Frequency,
                                CreatedDate: CreatedDate,
                                Sequence : Sequence,
                            },
                        );
                    });
                }
                successFlag = true;
                realm.close();
                return successFlag;

            })
            .catch((error) => {
                console.log('error in function --> route saving ');
                console.log(error);
            })
            .then((result) => {
                return success(result);
            })
            .catch((error) => {
                return fail(error);
            });
    });
};



export const resetRouteTable = () => {
    return new Promise((success, fail) => {
        let successFlag = false;
        Realm.open({schema: [RouteSchema]})
            .then((realm) => {
                realm.write(() => {
                    realm.deleteAll();
                    successFlag = true;
                });
                realm.close();
                return success(successFlag);
            })
            .catch((error) => {
                console.log('error on delete route bulk');
                return fail(error);
            });
    });
};
