// getting  localDB context
const Realm = require('realm');

// Schema for prospect table
const ProspectSchema = {
    name: 'ProspectTable',
    primaryKey: 'Id',
    properties: {
        Id: 'string',
        CompanyId: 'string?',
        CompanyName: 'string?',
        Address: 'string?',
        City: 'string?',
        State: 'string?',
        Zip: 'string?',
        Phone: 'string?',
        EmailAddress: 'string?',
        EstimatedAnnualSales: 'double?',
        CreatedOn: 'string?',
        CurrentStage:'string?',
        DecisionMaker: 'string?',
        Stage: 'string?',
        RepId:'string?',
        ApproachProcessList:'string?',
    },
};

export const getProspectListFromRealM = (offset) => {
    return new Promise((success, fail) => {
        let prospectList = [];
        Realm.open({schema: [ProspectSchema]})
            .then((realm) => {
                let users = realm.objects('ProspectTable');
                let endLimit= offset+50;
                if(users.length <endLimit){
                    endLimit=users.length;
                }
                for(let i=offset; i<endLimit; i++){
                    prospectList.push(users[i]);
                }
                console.log("offset is " +offset + "end is " + endLimit);
                console.log("shorted customer list--->>><<>>", prospectList)
                let ProspectRows = JSON.parse(JSON.stringify([...prospectList]));

                console.log(ProspectRows);
                realm.close();
                prospectList = ProspectRows;
                return prospectList;
            })
            .catch((error) => {
                console.log('error in function --> get prospect list from db ');
                console.log(error);
            })
            .then((result) => {
                return success(result);
            })
            .catch((error) => {
                return fail(error);
            });
    });
};

export const saveProspectToRealM = (prospectList) => {
    return new Promise((success, fail) => {
        let successFlag = false;
        Realm.open({schema: [ProspectSchema]})
            .then((realm) => {
                for (let obj = 0; obj < prospectList.length; obj++) {
                    realm.write(() => {
                        const {
                            Id,
                            CompanyId,
                            CompanyName,
                            Address,
                            City,
                            State,
                            Zip,
                            Phone,
                            EmailAddress,
                            EstimatedAnnualSales,
                            CreatedOn,
                            CurrentStage,
                            DecisionMaker,
                            Stage,
                            RepId,
                            ApproachProcessList
                        } = prospectList[obj];
                        realm.create(
                            'ProspectTable',
                            {
                                Id : Id,
                                CompanyId: CompanyId,
                                CompanyName: CompanyName,
                                Address: Address,
                                City: City,
                                State: State,
                                Zip: Zip,
                                Phone: Phone,
                                EmailAddress: EmailAddress,
                                EstimatedAnnualSales: EstimatedAnnualSales,
                                CreatedOn: CreatedOn,
                                CurrentStage: CurrentStage,
                                DecisionMaker: DecisionMaker,
                                Stage:Stage,
                                RepId:RepId,
                                ApproachProcessList:ApproachProcessList
                            },
                        );
                    });
                }
                successFlag = true;
                realm.close();
                return successFlag;

            })
            .catch((error) => {
                console.log('error in function --> save prospect list ');
                console.log(error);
            })
            .then((result) => {
                return success(result);
            })
            .catch((error) => {
                return fail(error);
            });
    });
};



export const resetProspectTable = () => {
    return new Promise((success, fail) => {
        let successFlag = false;
        Realm.open({schema: [ProspectSchema]})
            .then((realm) => {
                realm.write(() => {
                    realm.deleteAll();
                    successFlag = true;
                });
                realm.close();
                return success(successFlag);
            })
            .catch((error) => {
                console.log('error on delete prospect bulk');
                return fail(error);
            });
    });
};
export const updateProspectInRealM = (updatedObj) => {
    return new Promise((success, fail) => {
        Realm.open({schema: [ProspectSchema]})
            .then((realm) => {
                const thisRoute = realm
                    .objects('ProspectTable')
                    .filtered('Id = "' + updatedObj.Id + '"');
                if (thisRoute.length === 1) {
                    realm.write(() => {
                        realm.create(
                            'ProspectTable',
                            {
                                Id: updatedObj.Id,
                                CompanyName: updatedObj.CompanyName,
                                Address: updatedObj.Address,
                                City: updatedObj.City,
                                State: updatedObj.State,
                                Zip: updatedObj.Zip,
                                Phone: updatedObj.Phone,
                                EmailAddress: updatedObj.EmailAddress,
                                EstimatedAnnualSales: parseFloat(updatedObj.EstimatedAnnualSales),
                                CurrentStage:updatedObj.CurrentStage,
                                Stage:updatedObj.Stage,
                                DecisionMaker:updatedObj.DecisionMaker ,
                                ApproachProcessList:updatedObj.ApproachProcessList
                            },
                            'modified',
                        );
                    });
                }else{
                    console.log('this prospect not in local db after search prospect update');
                }
            })
            .then((result) => {
                return success(result);
            })
            .catch((error) => {
                console.log('error in function --> route item updating ');
                console.log(error);
                return fail(error);
            })
    });
};
