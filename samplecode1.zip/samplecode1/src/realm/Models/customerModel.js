// getting  localDB context
const Realm = require('realm');

// Schema for Authentication/login table
const CustomerSchema = {
  name: 'CustomerTable',
  primaryKey: 'CustomerId',
  properties: {
    CustomerId: 'string',
    CustomerName: 'string?',
    Address1: 'string?',
    Address2: 'string?',
    City: 'string?',
    State: 'string?',
    PostalCode: 'string?',
    Phone1: 'string?',
    EmailAddress: 'string?',
    CreditLimit: 'double?',
    LastSaleAmount: 'double?',
    LastSaleDate: 'string?',
    Longitude:  'string?',
    Latitude:  'string?',
  },
};

export const getCustomersListFromRealM = (offset) => {
  return new Promise((success, fail) => {
    let customerList = [];
    Realm.open({schema: [CustomerSchema]})
      .then((realm) => {
        let users = realm.objects('CustomerTable');
        let endLimit= offset+50;
        if(users.length <endLimit){
            endLimit=users.length;
        }
        for(let i=offset; i<endLimit; i++){
            customerList.push(users[i]);
        }
          console.log("offset is " +offset + "end is " + endLimit);
          console.log("shorted customer list--->>><<>>", customerList)
        let CustomerRows = JSON.parse(JSON.stringify([...customerList]));

        console.log(CustomerRows);
        realm.close();
        customerList = CustomerRows;
        return customerList;
      })
      .catch((error) => {
        console.log('error in function --> getUserdataOfCurrentLogin ');
        console.log(error);
      })
      .then((result) => {
        return success(result);
      })
      .catch((error) => {
        return fail(error);
      });
  });
};

export const saveCustomersToRealM = (customerList) => {
  return new Promise((success, fail) => {
    let successFlag = false;
    Realm.open({schema: [CustomerSchema]})
      .then((realm) => {
        for (let obj = 0; obj < customerList.length; obj++) {
          realm.write(() => {
            const {
              CustomerId,
              CustomerName,
              Address1,
              Address2,
              City,
              State,
              PostalCode,
              Phone1,
              EmailAddress,
              CreditLimit,
              LastSaleAmount,
              LastSaleDate,
                Latitude,
                Longitude
            } = customerList[obj];
            realm.create(
              'CustomerTable',
              {
                CustomerId: CustomerId,
                CustomerName: CustomerName,
                Address1: Address1,
                Address2: Address2,
                City: City,
                State: State,
                PostalCode: PostalCode,
                Phone1: Phone1,
                EmailAddress: EmailAddress,
                CreditLimit: CreditLimit,
                LastSaleAmount: LastSaleAmount,
                LastSaleDate: LastSaleDate,
                  Latitude: Latitude,
                  Longitude: Longitude
              },
            );
          });
        }
          successFlag = true;
          realm.close();
          return successFlag;

      })
      .catch((error) => {
        console.log('error in function --> getUserdataOfCurrentLogin ');
        console.log(error);
      })
      .then((result) => {
        return success(result);
      })
      .catch((error) => {
        return fail(error);
      });
  });
};



export const resetCustomerTable = () => {
    return new Promise((success, fail) => {
        let successFlag = false;
        Realm.open({schema: [CustomerSchema]})
            .then((realm) => {
                realm.write(() => {
                    realm.deleteAll();
                    successFlag = true;
                });
                realm.close();
                return success(successFlag);
            })
            .catch((error) => {
                console.log('error on delete customer bulk');
                return fail(error);
            });
    });
};
