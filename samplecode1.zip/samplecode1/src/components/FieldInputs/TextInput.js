import React from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {Input} from 'react-native-elements';


const TextInput = (
    {
        onFocus,
        placeholder,
        leftIconType,
        leftIconSize=25,
        leftIconColor='black',
        rightIconType,
        rightIconSize=25,
        rightIconColor='black',
        onChangeText,
        errorMessage,
        errorStyle,
        secureTextEntry=false,
        containerStyle,
        inputContainerStyle,
        rightIconOnPress,
        keyboardType='default',
        value,
        multiline=false,
        numberOfLines,
        inputStyle,
        returnKeyType='done',
        disabled=false
    }
) => {
    return(
        <Input placeholder={placeholder}
            leftIcon={
                <Icon
                    name={leftIconType}
                    size={leftIconSize}
                    color={leftIconColor}
                />
            }
            rightIcon={
                <Icon
                    name={rightIconType}
                    size={rightIconSize}
                    color={rightIconColor}
                    onPress={rightIconOnPress}
                />
            }
            onFocus={onFocus}
            onChangeText={onChangeText}
            secureTextEntry={secureTextEntry}
            errorMessage={errorMessage}
            errorStyle={errorStyle}
            containerStyle={containerStyle}
            inputContainerStyle={inputContainerStyle}
            keyboardType={keyboardType}
            returnKeyType={returnKeyType}
            value={value}
            inputStyle={inputStyle}
            multiline={multiline}
            numberOfLines={numberOfLines}
               disabled={disabled}

        />
    );
};

export default TextInput;
