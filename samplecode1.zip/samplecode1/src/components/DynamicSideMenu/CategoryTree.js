import React from 'react';
import {FlatList} from 'react-native';
import CategoryTreeItem from './CategoryTreeItem';

// recursive component for rendering dynamic side menu tree -->
const CategoryTree = ({categories, ...props}) => {
  const renderRow = (category) => <CategoryTreeItem category={category.item} />;

  return (
    <FlatList
      data={categories.filter(
          category =>
            category.IsActive === true
      )}
      renderItem={renderRow}
      keyExtractor={(item) => String(item.MenuID)}
      {...props}
    />
  );
};

export default CategoryTree;
