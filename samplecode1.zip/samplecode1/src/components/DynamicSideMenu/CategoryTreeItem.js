import React, {useState, useEffect} from 'react';
import {UIManager, Platform, StyleSheet, LayoutAnimation} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import CardTemplate from '../GenericTemplate/CardTemplate';
import {Text} from 'react-native-elements';
import CategoryTree from './CategoryTree';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {
  APP_BLUE_COLOR,
  BLACK_COLOR,
  GREY_ICON_COLOR,
  HEADER_FONT_WEIGHT,
} from '../../resources/constants/themeConstant';
import {
  SPACING_15,
  SPACING_5,
  TEXT_SIZE_15,
  SMALL_ICON_SIZE,
} from '../../resources/constants/dimensions';
import {validateRequiredField} from "../../utils/validators";
import Toast from 'react-native-simple-toast';

const CategoryTreeItem = ({category}) => {
  const [expanded, setExpanded] = useState(false);
  const navigation = useNavigation();

  useEffect(() => {
    if (Platform.OS === 'android') {
      // eslint-disable-next-line no-unused-expressions
      UIManager.setLayoutAnimationEnabledExperimental &&
        UIManager.setLayoutAnimationEnabledExperimental(true);
    }
  }, []);

  useEffect(() => {
    LayoutAnimation.easeInEaseOut();
  });

  // side menu click functionality -->
  const onRowPress = () => {
    // if no child items for sub menus open the corresponding page
    if (category.children_data.length === 0) {
      console.log('navigate here  -->');
      console.log(category.NavURL);
      if(validateRequiredField(category.NavURL)){
        navigation.navigate(category.NavURL);
      }else{
        Toast.showWithGravity('No Page found.', Toast.SHORT, Toast.CENTER);
      }
      //TODO as per server response
      // navigation.navigate(NAVIGATION_TO_CATEGORY_PRODUCT_LIST_SCREEN, {
      //     //title: category.name,
      //     //id: category.id,
      // });
    } else {
      // else expand the card for submenu
      setExpanded((prevState) => !prevState);
    }
  };

  // recursive call to render child-objects to generate sub-menu hierarchy
  const renderChildren = () => {
    if (expanded) {
      return (
        <CategoryTree
          navigation={navigation}
          categories={category.children_data}
        />
      );
    }
    return null;
  };

  return (
    <>
      <CardTemplate
        type="clear"
        onPress={onRowPress}
        style={styles.card(category.level)}>
        <Text
          style={[
            category.level % 2 === 0
              ? {color: APP_BLUE_COLOR}
              : {color: BLACK_COLOR},
            {fontSize: TEXT_SIZE_15, fontWeight: HEADER_FONT_WEIGHT},
          ]}
        >
          {category.MenuName}
        </Text>
        {category.children_data.length > 0 ? (
          <Icon
            name={expanded ? 'arrow-drop-up' : 'arrow-drop-down'}
            color={GREY_ICON_COLOR}
            size={SMALL_ICON_SIZE}
            onPress={() => setExpanded((prevState) => !prevState)}
          />
        ) : (
          <Icon
            name={'arrow-right'}
            color={GREY_ICON_COLOR}
            size={SMALL_ICON_SIZE}
          />
        )}
      </CardTemplate>
      {renderChildren()}
    </>
  );
};

const styles = StyleSheet.create({
  card: (level) => ({
    paddingStart: level > 1 ? (level - 1) * SPACING_15 : SPACING_5,
    paddingEnd: 16,
    paddingVertical: 20,
    marginBottom: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: GREY_ICON_COLOR,
    overflow: 'hidden',
    borderRadius: 0,
  }),
});

export default CategoryTreeItem;
