import {StyleSheet, View, LayoutAnimation} from 'react-native';
import {connect} from 'react-redux';
import React, {useEffect, useState} from 'react';
import FastImage from 'react-native-fast-image';
import {mcni360_blue_icon} from '../../resources/images';
// import AppAsyncStorage from '../../api/helper/AppAsyncStorage';
// import {USER_BRAND_DATA} from '../../resources/constants/asyncKeys';
import {Icon, Text} from 'react-native-elements';
//import {setUserDataFromAsync} from '../../store/ProductPage/productPageAction';
import {
  SPACING_10,
  TEXT_SIZE_15,
} from '../../resources/constants/dimensions';
import {
  FIELD_BORDER_WIDTH,
  HEADER_FONT_WEIGHT,
  INPUT_FIELD_BORDER_COLOR,
} from '../../resources/constants/themeConstant';
const CustomerHeader = ({
  navigation,
  headerBackButton = false,
  headerNavigator = false,
  sideMenuOpen = false,
  headerStyle = {},
  onSideMenuPress,
}) => {
  const [comapanyName, setCompanyName] = useState('');
  const [logoFile, setlogoFile] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phoneNo, setPhoneNo] = useState('');
  const [displayContactBool, setDisplayContactBool] = useState(true);

  useEffect(() => {
    LayoutAnimation.easeInEaseOut();
  });

  return (
    <View style={[styles.headerStyle, headerStyle]}>
      {headerNavigator ? (
        !headerBackButton ? (
          <View
            style={[
              styles.headerViewsStyle,
              {width: '20%', paddingLeft: 5, alignItems: 'flex-start'},
            ]}>
            <Icon
              name={!sideMenuOpen ? 'menu' : 'close'}
              type="MaterialCommunityIcons"
              color="black"
              onPress={onSideMenuPress}
              size={30}
            />
          </View>
        ) : (
          <View
            style={[
              styles.headerViewsStyle,
              {width: '20%', paddingLeft: 5, alignItems: 'flex-start'},
            ]}>
            <Icon
              name="arrow-back"
              type="MaterialIcons"
              color="black"
              onPress={() => navigation.pop()}
              size={40}
            />
          </View>
        )
      ) : (
        <View style={[styles.headerViewsStyle, {width: '20%'}]}></View>
      )}
      <View
        style={[styles.headerViewsStyle, {width: '60%', alignItems: 'center'}]}>
        <FastImage
          style={styles.headerLogoStyle}
          source={mcni360_blue_icon}
          resizeMode="stretch"
        />
      </View>
      <View
        style={[
          styles.headerViewsStyle,
          styles.headerRightContentStyle,
          {width: '20%'},
        ]}>
        {/*<Text h4 h4Style={styles.userDataStyle}>{firstName} {lastName}</Text>*/}
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  headerStyle: {
    width: '100%',
    flexDirection: 'row',
    height: '8%',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: INPUT_FIELD_BORDER_COLOR,
  },
  userDataStyle: {
    textAlign: 'right',
    // alignContent:'',
    fontWeight: HEADER_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
  },
  headerViewsStyle: {
    // height:HEADER_HEIGHT,
  },
  headerLogoStyle: {
    width: 60,
    height: 60,
  },
  headerRightContentStyle: {
    justifyContent: 'center',
    alignItems: 'flex-end',
    paddingRight: SPACING_10,
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    //   brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    //  userBrandDataFromAsync: reduxStore.productPage.userBrandDataFromAsync
  };
};
export default connect(mapStateToProps, {
  //setUserDataFromAsync
})(CustomerHeader);
