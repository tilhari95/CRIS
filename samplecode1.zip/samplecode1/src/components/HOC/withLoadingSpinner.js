import React, {Fragment, useState} from 'react';
import {
  StyleSheet,
  ActivityIndicator,
} from 'react-native';
import {Overlay} from 'react-native-elements';
import {
  GENERIC_BACKGROUND_COLOR,
  LOADER_COLOR,
  MODAL_BACKDROP_OPACITY,
} from '../../resources/constants/themeConstant';
const withLoadingSpinner = (bool) => (WrappedComponent) => (props) => {
  const [loadingSpinnerVisibility, setLoadingSpinnerVisibility] = useState(
    false,
  );
  const propsWithSpinnerProps = {
    ...props,
    setLoadingSpinnerVisibility: (boolean) => setLoadingSpinnerVisibility(boolean),
  };
  return (
    <Fragment>
      <WrappedComponent {...propsWithSpinnerProps} />
      <Overlay
        backdropStyle={styles.overlay}
        isVisible={loadingSpinnerVisibility}
        overlayStyle={styles.overlayLoaderStyle}>
        <ActivityIndicator size="large" color={LOADER_COLOR} />
      </Overlay>
    </Fragment>
  );
};

const styles = StyleSheet.create({
  overlay: {
    backgroundColor: GENERIC_BACKGROUND_COLOR,
    opacity: 0.8,
  },
  overlayLoaderStyle: {
    width: 0,
    height: 0,
    padding: 0,
    backgroundColor: GENERIC_BACKGROUND_COLOR,
    opacity: MODAL_BACKDROP_OPACITY,
  },
});

export default withLoadingSpinner;
