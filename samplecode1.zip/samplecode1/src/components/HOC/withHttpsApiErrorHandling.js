import React, {Fragment, useState} from 'react';
import {StyleSheet, View} from 'react-native';
import {Overlay, Text} from 'react-native-elements';
import {
  GENERIC_BACKGROUND_COLOR,
  MODAL_BACKDROP_OPACITY,
} from '../../resources/constants/themeConstant';
import GenericButton from '../Buttons/GenericButton';
import {
  FIELD_BORDER_WIDTH,
  HEADER_FONT_WEIGHT,
  INPUT_FIELD_BORDER_COLOR,
} from '../../resources/constants/themeConstant';
import {
  MODAL_CONTAINER_WIDTH,
  SPACING_30,
  TEXT_SIZE_15,
} from '../../resources/constants/dimensions';
import {getModalErrorText} from '../../utils/errorHandlers';
import {OKAY} from '../../resources/constants/stringConstants';
import {SESSION_EXPIRED_MSG, INTERNAL_SERVER_MSG} from '../../resources/constants/storeConstants';
import {onAutoLogout} from '../../utils/LogoutHandlers';

const withHttpsApiErrorHandling = () => (WrappedComponent) => (props) => {
  const [errorDialogProps, setErrorDialogProps] = useState({
    visibility: false,
    errorMessage: '',
  });
  let {navigation} = props;

  // controller for error dialog overlay -->
  const showHttpsApiErrorDialog = (httpsErrorObj) => {
    let errorText = getModalErrorText(httpsErrorObj);
    setErrorDialogProps({
      ...errorDialogProps,
      errorMessage: errorText,
      visibility: true,
    });
  };

  const showHttpsApiErrorToast = () => {
    //TODO AS PER CLIENT REQUIREMENT IN FUTURE
    alert('error toast');
  };

  // function for error dialog button press -->
  const errorDialogButtonPress = () => {
    let logoutOnError = false;
    if (errorDialogProps.errorMessage === SESSION_EXPIRED_MSG || errorDialogProps.errorMessage === INTERNAL_SERVER_MSG) {
      logoutOnError = true;
    }
    setErrorDialogProps({
      ...errorDialogProps,
      errorMessage: '',
      visibility: false,
    });
    if (logoutOnError === true) {
      console.log('handle logout here');
      onAutoLogout(navigation);
    }
  };

  // update current props with api error handling functions:
  const propsWithErrorHandling = {
    ...props,
    showHttpsApiErrorDialog: showHttpsApiErrorDialog,
    showHttpsApiErrorToast: showHttpsApiErrorToast,
  };

  return (
    <Fragment>
      <WrappedComponent {...propsWithErrorHandling} />
      <Overlay
        backdropStyle={styles.overlay}
        isVisible={errorDialogProps.visibility}
        overlayStyle={styles.overlayModalStyle}>
        <View>
          <Text h3 h3Style={styles.modalErrorStyle}>
            {errorDialogProps.errorMessage}
          </Text>
          <GenericButton
            title={OKAY}
            onPress={errorDialogButtonPress}></GenericButton>
        </View>
      </Overlay>
    </Fragment>
  );
};

const styles = StyleSheet.create({
  overlay: {
    backgroundColor: GENERIC_BACKGROUND_COLOR,
    opacity: MODAL_BACKDROP_OPACITY,
  },
  overlayModalStyle: {
    borderWidth: FIELD_BORDER_WIDTH,
    borderColor: INPUT_FIELD_BORDER_COLOR,
    width: MODAL_CONTAINER_WIDTH,
  },
  modalErrorStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'center',
    //color:ERROR_COLOR,
    marginBottom: SPACING_30,
  },
});

export default withHttpsApiErrorHandling;
