import React, {useContext} from 'react';
import {View, StyleSheet} from 'react-native';
import TouchReceptor from '../TouchReceptor/TouchReceptor';

const OUTLINE = 'outline';

const CardTemplate = ({type, style, onPress, disabled, children}) => {
  const ViewGroup = onPress ? TouchReceptor : React.Fragment;

  return (
    <ViewGroup {...(onPress && {onPress, disabled})}>
      <View style={StyleSheet.flatten([styles.container(type), style])}>
        {children}
      </View>
    </ViewGroup>
  );
};

const styles = {
  container: (type) => ({
    borderWidth: type === OUTLINE ? 1 : 0,
    borderRadius: 1,
  }),
};

export default CardTemplate;
