import React from 'react';
import {View, Text, Image} from 'react-native';
import {ListItem, Avatar} from 'react-native-elements';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {parseCustomerDate} from '../../utils/date';
import {validateRequiredField, roundToTwo} from "../../utils/validators";
import {defaultBase64Icon} from "../../resources/images/defaultImage";


const ItemCardTemplate = ({item}) => {
  let imgString='';
  if (validateRequiredField(item.ImageData)){
    imgString = 'data:image/png;base64,' + item.ImageData;
  }else{
    imgString= defaultBase64Icon;
  }
    return(
        <View style={{flex: 1}}>
        <ListItem bottomDivider containerStyle={{flex: 1}}>
          <Avatar source={{uri: imgString}}/>
          <ListItem.Content>
            <View style={{flex: 2, flexDirection: 'row'}}>
              <Text style={{flex: 1}}>{item.ItemNo}</Text>
              <Text style={{textAlign: 'right'}}>List Price</Text>
              {item.ListPrice ?
               <Text style={{textAlign: 'right', fontWeight: 'bold'}}>
                 : ${roundToTwo(item.ListPrice)}
               </Text>
              : null}
              {item.Price ?
               <Text style={{textAlign: 'right', fontWeight: 'bold'}}>
                 : ${roundToTwo(item.Price)}
               </Text>
              : null}
            </View>
            {item.Description1 ? <Text>{item.Description1}</Text> : null}
            {item.Description ? <Text>{item.Description}</Text> : null}

            <View style={{flex: 2, flexDirection: 'row'}}>
              <View style={{flex: 1, flexDirection: 'row'}}>
                {item.HasBarcode ? (
                  <Icon
                    name="barcode"
                    type="font-awesome"
                    color="black"
                    size={20}
                    style={{marginTop: 10, marginRight: 10}}
                  />
                ) : null}
                {item.HasPresentation ? (
                  <Icon
                    name="alpha-m-circle-outline"
                    type="font-awesome"
                    color="black"
                    size={20}
                    style={{marginTop: 10, marginRight: 10}}
                  />
                ) : null}

                {item.HasMSDS ? (
                  <Icon
                    name="presentation"
                    type="MaterialCommunityIcons"
                    color="black"
                    size={20}
                    style={{marginTop: 10, marginRight: 10}}
                  />
                ) : null}
              </View>
              <View style={{flex: 1}}>
                {/*{item.AvailableQty ? <Text>Avail: {item.AvailableQty}</Text>: null}*/}
                {item.Quantity ?  <Text>Avail: {item.Quantity}</Text>: null}
                <Text>Last Sold: {parseCustomerDate(item.LastSoldDate)}</Text>
              </View>
            </View>
          </ListItem.Content>
        </ListItem>
      </View>
    )
}

export default ItemCardTemplate;
