import React, {useEffect, useState} from 'react';
import {
    View,
    SafeAreaView,
    StatusBar,
    StyleSheet,
    ActivityIndicator, ScrollView, Platform
} from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import {Overlay,} from 'react-native-elements';
import {
    GENERIC_BACKGROUND_COLOR,
    LOADER_COLOR, MODAL_BACKDROP_OPACITY,
} from '../../resources/constants/themeConstant';
const GenericTemplate = ({
  /**
   * Main content of the view
   */
  children,
  /**
   * Sticky footer that need to be shown below main content`
   */
  footer,
  /**
   * container style
   */
  style = {},
  overlayLoaderVisibility = false,
  keyboardAwareView=true,
  keyboardTapPersist = 'never'
}) => {
    const [loaderVisibility, setLoaderVisibility] =useState(false);

    useEffect(()=>{
        //debugger;
        setLoaderVisibility(overlayLoaderVisibility);

    },[overlayLoaderVisibility])
  return (
    <>
      <StatusBar barStyle="dark-content" backgroundColor={GENERIC_BACKGROUND_COLOR} />
      <SafeAreaView style={styles.container}>
      {
          (keyboardAwareView && Platform.OS == 'android')?
                <ScrollView keyboardShouldPersistTaps={keyboardTapPersist} contentContainerStyle={style} bounces={false}>

                  {children}

                </ScrollView>
          :
            (keyboardAwareView && Platform.OS == 'ios')?
                <KeyboardAwareScrollView keyboardShouldPersistTaps={keyboardTapPersist} enableOnAndroid contentContainerStyle={style} bounces={false}>

                        {children}

                </KeyboardAwareScrollView>
            :

                <View style={style}>
                    <View>
                        {children}
                    </View>
                </View>
      }
        <Overlay
          backdropStyle={styles.overlay}
          isVisible={loaderVisibility}
          overlayStyle={styles.overlayLoaderStyle}
            >
          <ActivityIndicator size="large" color={LOADER_COLOR} />
        </Overlay>
      </SafeAreaView>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: GENERIC_BACKGROUND_COLOR,
  },
  overlay:{
    backgroundColor: GENERIC_BACKGROUND_COLOR,
    opacity: 0.8
  },
  overlayLoaderStyle:{
      width:0,height:0,
      padding:0,
      backgroundColor: GENERIC_BACKGROUND_COLOR,
      opacity: MODAL_BACKDROP_OPACITY
  }
});




export default GenericTemplate;
