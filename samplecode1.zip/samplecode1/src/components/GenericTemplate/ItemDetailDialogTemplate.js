import React, {useEffect, useState} from 'react';
import {
  Text,
  View,
  StyleSheet,
  FlatList,
  TouchableWithoutFeedback,
  Switch,
} from 'react-native';
import {
  SearchBar,
  ListItem,
  Avatar,
  Overlay,
  Button,
  Input,
} from 'react-native-elements';
import {TextInput} from 'react-native-gesture-handler';
import {set} from 'react-native-reanimated';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  BLACK_COLOR,
  COLORS,
  GENERIC_BACKGROUND_COLOR,
} from '../../resources/constants/themeConstant';
import {connect} from 'react-redux';
import withHttpsApiErrorHandling from '../HOC/withHttpsApiErrorHandling';
import withLoadingSpinner from '../HOC/withLoadingSpinner';
import {
  addOrderLineApiReqAction,
  resetAddOrderLineApiResponseAction,
  resetAddOrderLineApiErrAction,
  resetAddOrderLineHttpErrAction,
  addItemToCartAction,
  setOrderIdAction,
  setOrderNoAction,
  setSequenceAction,
} from '../../store/OrderLine/orderLineAction';
import Toast from 'react-native-simple-toast';
import {
  validateFloat,
  validateRequiredField,
  isInt,
  isFloat,
  roundToTwo,
  generateRandomNumer,
} from '../../utils/validators';
import {EMAIL_ENTERED} from '../../resources/constants/storeConstants';
import {useFocusEffect} from '@react-navigation/core';

const ItemDetailDialogTemplate = ({
  overlayVisible,
  itemDetail,
  onCancelPress,
  onAddPress,
  addOrderLineApiReqAction: _addOrderLineApiReqAction,
  resetAddOrderLineApiResponseAction: _resetAddOrderLineApiResponseAction,
  resetAddOrderLineApiErrAction: _resetAddOrderLineApiErrAction,
  resetAddOrderLineHttpErrAction: _resetAddOrderLineHttpErrAction,
  addOrderLineResponse,
  addOrderLineApiErr,
  addOrderLineHttpErr,
  brandSuccessResponse,
  selectedCustomer,
  setLoadingSpinnerVisibility,
  showHttpsApiErrorDialog,
  addItemToCartAction: _addItemToCartAction,
  addedItemsList,
  setOrderIdAction: _setOrderIdAction,
  setOrderNoAction: _setOrderNoAction,
  setSequenceAction: _setSequenceAction,
  orderNo,
  sequence,
}) => {
  // let [count, setCount] = useState(1);
  const [quantity, setQuantity] = useState(1);
  const [price, setPrice] = useState(null);
  const [note, setNote] = useState('');
  const [totalPrice, setTotalPrice] = useState(null);

  useEffect(() => {
    if (itemDetail.ListPrice != null) {
      setTotalPrice(itemDetail.ListPrice);
      setPrice(itemDetail.ListPrice);
    }
  }, [itemDetail.ListPrice]);

  useEffect(() => {
    if (validateRequiredField(quantity)) {
      updateTotalPriceCount();
    }
  }, [quantity]);

  useEffect(() => {
    if (validateRequiredField(price)) {
      updateTotalPriceCount();
    }
  }, [price]);

  const updateTotalPriceCount = () => {
    let p = 0;
    let q = 0;

    if (validateInputField(quantity) && isInt(quantity)) {
      q = quantity;
    } else {
      q = 1;
    }

    if (validateInputField(price) && (isInt(price) || isFloat(price))) {
      p = price;
    } else {
      p = itemDetail.ListPrice;
    }

    setTotalPrice(p * q);
  };

  const resetState = () => {
    setQuantity(1);
    setPrice(null);
    setNote('');
    setTotalPrice(null);
  };

  useFocusEffect(() => {
    if (validateRequiredField(addOrderLineResponse)) {
      console.log('Orderline called');

      setLoadingSpinnerVisibility(false);
      itemDetail.ListPrice = price;
      itemDetail.OrderQty = quantity;
      itemDetail.Notes = note;
      itemDetail.OrderId = addOrderLineResponse.Item1; // Item1 is OrderId
      itemDetail.OrderLineId = addOrderLineResponse.Item2; // Item2 is OrderLineId
      itemDetail.OrderNo = addOrderLineResponse.Item3; // Item3 is OrderNo
      _setOrderIdAction(addOrderLineResponse.Item1);
      _addItemToCartAction(itemDetail);
      _setOrderNoAction(addOrderLineResponse.Item3);
      _resetAddOrderLineApiResponseAction();
      resetState();
      onAddPress();
    }
  }, [addOrderLineResponse]);

  useEffect(() => {
    if (addOrderLineApiErr != null) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(addOrderLineApiErr);
      _resetAddOrderLineApiErrAction(addOrderLineApiErr);
    }
  }, [addOrderLineApiErr]);

  useEffect(() => {
    if (addOrderLineHttpErr != null) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(addOrderLineHttpErr);
      _resetAddOrderLineHttpErrAction();
    }
  }, [addOrderLineHttpErr]);

  const getOrderNo = () => {
    if (validateRequiredField(orderNo)) {
      return orderNo;
    } else {
      return null;
    }
  };

  const getSequenceNo = () => {
    const val = sequence;
    _setSequenceAction(++sequence);
    return val;
  };

  const onAddBtnClicked = () => {
    if (validateInputField()) {
      setLoadingSpinnerVisibility(true);
      _addOrderLineApiReqAction(
        '00000000-0000-0000-0000-000000000000',
        getOrderNo(),
        getSequenceNo(),
        itemDetail.Id,
        itemDetail.ItemNo,
        itemDetail.Description1,
        itemDetail.Description2,
        price,
        quantity,
        itemDetail.TaxFlag == 'Y' ? true : false,
        note,
        1,
        brandSuccessResponse.CompanyId,
        itemDetail.BarCode,
        itemDetail.UOMKey,
        brandSuccessResponse.DeviceId,
        selectedCustomer.CustomerNo,
        selectedCustomer.CustomerId,
        brandSuccessResponse.ERPRepCode
      );
    }
  };

  const validateInputField = () => {
    if (!isInt(quantity)) {
      // Toast.show('Enter Valid Quantity.', Toast.SHORT);
      return false;
    }

    if (!(isFloat(price) || isInt(price))) {
      // Toast.show('Enter Valid Price.', Toast.SHORT);
      return false;
    }
    return true;
  };

  const onQuantityChange = (text) => {
    setQuantity(text);
  };

  const onPriceChange = (text) => {
    setPrice(text);
  };

  return (
    <Overlay isVisible={overlayVisible} overlayStyle={{width: '90%'}}>
      <View>
        <ListItem>
          <Avatar
            source={{
              uri:
                'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
            }}
          />
          <ListItem.Content>
            <View style={{flexDirection: 'row', width: '100%'}}>
              <Text style={{flex: 1}}>{itemDetail.ItemNo}</Text>
              <Text style={{fontWeight: 'bold'}}>
                Total: ${roundToTwo(totalPrice)}
              </Text>
            </View>
            <Text>{itemDetail.Description1}</Text>
            <View style={{flexDirection: 'row', height: 30}}>
              <View style={{flex: 1, flexDirection: 'row'}}>
                {itemDetail.HasBarcode ? (
                  <Icon
                    name="barcode"
                    type="font-awesome"
                    color="black"
                    size={20}
                    style={{marginTop: 10, marginRight: 10}}
                  />
                ) : null}
                {itemDetail.HasPresentation ? (
                  <Icon
                    name="alpha-m-circle-outline"
                    type="font-awesome"
                    color="black"
                    size={20}
                    style={{marginTop: 10, marginRight: 10}}
                  />
                ) : null}

                {itemDetail.HasMSDS ? (
                  <Icon
                    name="presentation"
                    type="MaterialCommunityIcons"
                    color="black"
                    size={20}
                    style={{marginTop: 10, marginRight: 10}}
                  />
                ) : null}
              </View>
              <View style={{flex: 1}}>
                <Text>Avail: {itemDetail.AvailableQty}</Text>
                <Text>
                  Last Sold:{' '}
                  {itemDetail.LastSoldDate ? itemDetail.LastSoldDate : 'NA'}{' '}
                </Text>
              </View>
            </View>

            <View style={{flexDirection: 'row'}}>
              <View>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'center',
                    marginTop: 10,
                  }}>
                  <Text style={{alignSelf: 'center'}}>Quantity:{'  '} </Text>
                  <TextInput
                    placeholder="Count"
                    style={{
                      borderBottomWidth: 1,
                      width: 50,
                    }}
                    keyboardType={'numeric'}
                    value={quantity + ''}
                    onChangeText={onQuantityChange}
                  />
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    marginTop: 10,
                  }}>
                  <Text style={{alignSelf: 'center'}}>Price:{'  '} </Text>
                  <TextInput
                    placeholder="Price"
                    style={{
                      borderBottomWidth: 1,
                      width: 50,
                    }}
                    keyboardType={'numeric'}
                    value={price + ''}
                    onChangeText={onPriceChange}
                  />
                </View>
              </View>
              <View
                style={{
                  marginTop: 10,
                  justifyContent: 'flex-end',
                  flexDirection: 'row',
                  flex: 1,
                }}>
                <View>
                  <Text style={{alignSelf: 'center'}}>Note</Text>
                  <Icon
                    name="clipboard-text-outline"
                    type="MaterialCommunityIcons"
                    color="black"
                    size={20}
                    style={{alignSelf: 'center'}}
                  />
                </View>
                <View style={{marginStart: 10}}>
                  <Text style={{alignSelf: 'center'}}>Confirm</Text>
                  <Icon
                    name="camera-outline"
                    type="MaterialCommunityIcons"
                    color="black"
                    size={20}
                    style={{alignSelf: 'center'}}
                  />
                </View>
              </View>
            </View>

            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'center',
                marginTop: 10,
              }}>
              <Text style={{alignSelf: 'center'}}>Note:{'  '} </Text>
              <TextInput
                placeholder="Write a note"
                style={{
                  borderBottomWidth: 1,
                  flex: 1,
                }}
                multiline={true}
                value={note}
                onChangeText={(text) => setNote(text)}
              />
            </View>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'center',
                marginTop: 10,
              }}>
              <Text style={{alignSelf: 'center'}}>Tax:</Text>
              <Switch
                value={true}
                style={styles.checkBoxStyle}
                trackColor={{true: COLORS.grayDark}}
                // thumbColor={true ? '#f5dd4b' : '#f4f3f4'}
              />
            </View>

            <View style={styles.footer}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'flex-end',
                  flex: 1,
                }}>
                <Button
                  title="Cancel"
                  type="solid"
                  buttonStyle={styles.button}
                  onPress={() => {
                    // setCount(1);
                    _resetAddOrderLineApiResponseAction();
                    resetState();
                    onCancelPress();
                  }}
                />
                <Button
                  title="Add"
                  type="solid"
                  onPress={onAddBtnClicked}
                  buttonStyle={[styles.button, {marginStart: 10}]}
                />
              </View>
            </View>
          </ListItem.Content>
        </ListItem>
      </View>
    </Overlay>
  );
};

const styles = StyleSheet.create({
  checkBoxStyle: {
    marginStart: 20,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    width: 100,
    backgroundColor: COLORS.pink,
  },
  footer: {
    height: 40,
    flexDirection: 'row',
    margin: 10,
    width: '100%',
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    addOrderLineResponse: reduxStore.orderLine.addOrderLineResponse,
    addOrderLineApiErr: reduxStore.orderLine.addOrderLineApiErr,
    addOrderLineHttpErr: reduxStore.orderLine.addOrderLineHttpErr,
    selectedCustomer: reduxStore.customer.selectedCustomer,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    addedItemsList: reduxStore.orderLine.addedItemsList,
    orderNo: reduxStore.orderLine.orderNo,
    sequence: reduxStore.orderLine.sequence,
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      addOrderLineApiReqAction,
      resetAddOrderLineApiResponseAction,
      resetAddOrderLineApiErrAction,
      resetAddOrderLineHttpErrAction,
      addItemToCartAction,
      setOrderIdAction,
      setOrderNoAction,
      setSequenceAction,
    })(ItemDetailDialogTemplate),
  ),
);
