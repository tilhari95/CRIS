import {StyleSheet, View} from 'react-native';
import React, {useEffect, useState} from 'react';

import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {Text} from 'react-native-elements';
import {
    HEIGHT_MAX_130, SPACING_10, SPACING_5, TEXT_SIZE_10, TEXT_SIZE_12,
    TEXT_SIZE_15, TEXT_SIZE_18, TEXT_SIZE_8,
} from '../../resources/constants/dimensions';
import {
    APP_BLUE_COLOR,
    BOLD_FONT_WEIGHT,
    HEADER_FONT_WEIGHT, INPUT_FIELD_BORDER_COLOR, PRODUCT_NAME_COLOR,
} from '../../resources/constants/themeConstant';
import {parseCustomerDate} from "../../utils/date";
import GenericButton from "../Buttons/GenericButton";
import Toast from "react-native-simple-toast";
import {roundToTwo} from "../../utils/validators";
// import {parseSpiffDate} from '../../utils/date';
// import {roundToTwo} from '../../utils/cartHelpers';
const ProspectListTemplate =({
                                 itemData,onEditPress
                             }) => {
    let parsedDateInFormat = parseCustomerDate(itemData.CreatedOn);
    //let formattedAmount = roundToTwo(itemData.Amount);

    return(
        <View style={styles.viewStyle}>
            <View style={{width:'15%',  alignItems:'center'}}>
                <Icon
                    //type='MaterialCommunityIcons'
                    size={40}
                    name='account'
                    color={'black'}
                />
            </View>
            <View style={{width:'55%',}}>
                <Text h4 h4Style={[styles.itemDescriptionStyle, {fontSize: TEXT_SIZE_12, fontWeight: BOLD_FONT_WEIGHT, }]}>{itemData.CompanyName}</Text>
                <Text h4 h4Style={styles.itemDescriptionStyle}>{itemData.Address}</Text>
                <Text h4 h4Style={styles.itemDescriptionStyle}>{itemData.Phone}</Text>
                <Text h4 h4Style={[styles.itemDescriptionStyle, {color: PRODUCT_NAME_COLOR, fontSize: TEXT_SIZE_8}]}>Stage: {itemData.Stage}</Text>

            </View>
            <View style={{width:'30%',}}>
                <View>
                    <GenericButton
                        //  title="Edit"
                        //titleStyle={{fontSize:10}}
                        containerStyle={{alignItems:'flex-end', }}
                        icon={'edit'}
                        size={12}
                        iconType={'MaterialIcons'}
                        iconColor={APP_BLUE_COLOR}
                        type={'clear'}
                        onPress={onEditPress}
                        // onPress={() => {setAddModalVisibility(true)}}
                    />
                </View>
                <Text h4 h4Style={[styles.itemDescriptionStyle, {textAlign: 'right', color: PRODUCT_NAME_COLOR}]}>Est$: {roundToTwo(itemData.EstimatedAnnualSales)}</Text>
                <Text h4 h4Style={[styles.itemDescriptionStyle, {textAlign: 'right', color: PRODUCT_NAME_COLOR}]}>{parsedDateInFormat}</Text>
            </View>
        </View>

    );
}
const styles = StyleSheet.create({
    viewStyle: {
        width: "100%",
        flexDirection: "row",
        maxHeight: HEIGHT_MAX_130,
        alignItems: 'center',
        borderBottomWidth: 1,
        borderColor: INPUT_FIELD_BORDER_COLOR,
        paddingLeft: SPACING_5,
        paddingRight: SPACING_5,
        paddingBottom: SPACING_5,
        paddingTop: SPACING_5
    },
    itemDescriptionStyle: {
        fontWeight: HEADER_FONT_WEIGHT,
        fontSize: TEXT_SIZE_8,
    },
});

export default ProspectListTemplate;
