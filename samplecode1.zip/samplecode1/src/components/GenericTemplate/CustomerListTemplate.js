import {StyleSheet, View} from 'react-native';
import React, {useEffect, useState} from 'react';

import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {Text} from 'react-native-elements';
import {
    HEIGHT_MAX_130, SPACING_10, SPACING_5, TEXT_SIZE_10, TEXT_SIZE_12,
    TEXT_SIZE_15, TEXT_SIZE_18,
} from '../../resources/constants/dimensions';
import {
    BOLD_FONT_WEIGHT,
    HEADER_FONT_WEIGHT, INPUT_FIELD_BORDER_COLOR, PRODUCT_NAME_COLOR,
} from '../../resources/constants/themeConstant';
import {roundToTwo} from "../../utils/validators";
// import {parseSpiffDate} from '../../utils/date';
// import {roundToTwo} from '../../utils/cartHelpers';
const CustomerListTemplate =({
                               itemData,
                           }) => {
    //let parsedDateInFormat = parseSpiffDate(itemData.SpiffCreationDate);
    //let formattedAmount = roundToTwo(itemData.Amount);
    return(
        <View style={styles.viewStyle}>
            <View style={{width:'15%',  alignItems:'center'}}>
                <Icon
                    //type='MaterialCommunityIcons'
                    size={40}
                    name='account'
                    color={'black'}
                />
            </View>
            <View style={{width:'60%',}}>
                <Text h4 h4Style={[styles.itemDescriptionStyle, {fontSize: TEXT_SIZE_12, fontWeight: BOLD_FONT_WEIGHT, }]}>{itemData.CustomerName}</Text>
                <Text h4 h4Style={styles.itemDescriptionStyle}>{itemData.Address1}</Text>
                <Text h4 h4Style={styles.itemDescriptionStyle}>{itemData.Phone1}</Text>
            </View>
            <View style={{width:'25%',}}>
                <Text h4 h4Style={[styles.itemDescriptionStyle, {textAlign: 'right', color: PRODUCT_NAME_COLOR}]}>${roundToTwo(itemData.LastSaleAmount)}</Text>
                <Text h4 h4Style={[styles.itemDescriptionStyle, {textAlign: 'right', color: PRODUCT_NAME_COLOR}]}>{itemData.LastSaleDate}</Text>
            </View>
        </View>

    );
}
const styles = StyleSheet.create({
    viewStyle: {
        width: "100%",
        flexDirection: "row",
        maxHeight: HEIGHT_MAX_130,
        alignItems: 'center',
        borderBottomWidth: 1,
        borderColor: INPUT_FIELD_BORDER_COLOR,
        paddingLeft: SPACING_5,
        paddingRight: SPACING_5,
        paddingBottom: SPACING_5,
        paddingTop: SPACING_5
    },
    itemDescriptionStyle: {
        fontWeight: HEADER_FONT_WEIGHT,
        fontSize: TEXT_SIZE_10,
    },
});

export default CustomerListTemplate;
