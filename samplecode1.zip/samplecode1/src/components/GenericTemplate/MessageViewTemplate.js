import {StyleSheet, View} from 'react-native';
import React from 'react';
import {Icon, Text} from 'react-native-elements';
import {
    HEIGHT_100, HEIGHT_110, SPACING_10, SPACING_15, SPACING_5, TEXT_SIZE_10,
    TEXT_SIZE_15,
    WIDTH_100, WIDTH_80,
} from '../../resources/constants/dimensions';
import {
    BOLD_FONT_WEIGHT, FIELD_BORDER_RADIUS,
    HEADER_FONT_WEIGHT, MOBILE_MSG_BG_COLOR, PRODUCT_NAME_COLOR, SERVER_MSG_BG_COLOR,
} from '../../resources/constants/themeConstant';
import {SERVER_FLAG} from '../../resources/constants/storeConstants';
import {AT, MOBILE_SEND, SERVER_SEND} from '../../resources/constants/stringConstants';
const MessageViewTemplate =({
messageData,
}) => {
    return(
    <View style={styles.mainViewStyle}>
    {
    (messageData.MessageSource === SERVER_FLAG) ?
        <View style={{ alignItems:'flex-start'}}>
            <View style={styles.replyFromServerStyle}>
                <Text style={{...styles.messageTextStyle, color: 'white'}}>{messageData.MessageText}</Text>
            </View>
            <Text style={styles.dateAndTimeStyle}>{SERVER_SEND} {messageData.SenderName} {AT} {messageData.DateInfo}</Text>
        </View>
            :
        <View style={{ alignItems:'flex-end'}}>
            <View style={styles.sendFromDeviceStyle}>
                <Text style={styles.messageTextStyle}>{messageData.MessageText}</Text>
            </View>
            <Text style={{...styles.dateAndTimeStyle, textAlign: 'right'}}>{MOBILE_SEND} {messageData.DateInfo}</Text>
        </View>
    }
    </View>)
}
const styles = StyleSheet.create({
    mainViewStyle:{
        marginBottom:SPACING_15,
        width:'100%'
    },
    messageTextStyle:{
        fontWeight:'500',
        fontSize:TEXT_SIZE_15
    },
    dateAndTimeStyle:{
        fontSize:TEXT_SIZE_10,
        color:PRODUCT_NAME_COLOR
    },
    replyFromServerStyle:{
        maxWidth:"80%",
        padding: SPACING_5,
        backgroundColor:SERVER_MSG_BG_COLOR,
        borderRadius: FIELD_BORDER_RADIUS,
    },
    sendFromDeviceStyle:{
        maxWidth:"80%",
        padding: SPACING_5,
        backgroundColor:MOBILE_MSG_BG_COLOR,
        borderRadius: FIELD_BORDER_RADIUS,
    },
    itemDescriptionStyle:{
        fontWeight:HEADER_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
    },
    itemValueStyle:{
        color:PRODUCT_NAME_COLOR,
        textAlign:'left',
        width:'50%',
        fontWeight:BOLD_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
    },
    viewElementsStyle:{
        justifyContent:'center',
        alignItems: 'flex-start',
        // height:HEADER_HEIGHT,
    },
    imageStyle:{
        width:WIDTH_100,
        height:HEIGHT_100,
    },
    buttonStyle:{
        width:"50%",
        paddingRight: SPACING_5}
});

export default MessageViewTemplate;
