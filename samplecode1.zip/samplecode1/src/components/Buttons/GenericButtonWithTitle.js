import React from 'react';
import { Icon } from 'react-native-elements';
import { Button, Text } from 'react-native-elements';
import { StyleSheet, View } from 'react-native';
import { COLORS } from '../../resources/constants/themeConstant';

const GenericButtonWithTitle = (
    {
        title,
        type="solid",
        iconType="material-community",
        onPress,
        color='transparent',
        size,
        icon,
        loading=false,
        iconColor= COLORS.black,
        titleStyle,
        containerStyle,
        buttonStyle,
        disabled=false,
        label,
        labelColor = COLORS.black,
        componentStyle,
        labelStyle
    }
) => {
    return (
       <View style = {[styles.container, {componentStyle}]}>
            <Button
                title={title}
                type={type}
                onPress={onPress}
                color={color}
                icon={
                    <Icon
                        name={icon}
                        type={iconType}
                        size={size}
                        color={iconColor}
                    />
            }
            loading={loading}
            titleStyle={titleStyle}
            containerStyle={containerStyle}
            buttonStyle={buttonStyle}
            disabled={disabled}
        />
        <Text style={labelStyle} numberOfLines={1} ellipsizeMode= 'tail' >{label}</Text>
       </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: COLORS.white,
        borderRadius: 10,
        padding: 5,
        width: 70,
        height: 70,
        marginRight:10
    }
});

export default GenericButtonWithTitle;
