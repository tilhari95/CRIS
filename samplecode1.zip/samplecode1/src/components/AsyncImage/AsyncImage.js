
import React, { Component } from 'react';
import { StyleSheet, View } from 'react-native';
import FastImage from 'react-native-fast-image';

import imageplaceholder from '../../resources/images/imageplaceholder.png';
import {
  WIDTH_80,
} from '../../resources/constants/dimensions';

class AsyncImage extends Component {
  static servePlaceHolderImageComponent(imgStyle) {
    return <FastImage source={imageplaceholder} style={[styles.placeHolderImage, imgStyle]} />
  }

  constructor(props) {
    super(props);

    this.state = {
      isImageLoadComplete: false,
      dimensions: null,
      showLoadedImage: false,
      stateImageStyle: {}
    };
  }

  beginLoadingAsyncImage(isAsynImgLoaded) {
    //debugger;
    const {
      targetURL,
      allowDynamicSizing = true,
      customSize,
      resizeMode = FastImage.resizeMode.contain,
      imageStyle
    } = this.props;

    const imageFetchData = {
      uri: targetURL,
      priority: FastImage.priority.normal,
    };
   // console.log('inside AsyncDebug ------------>  ' + targetURL );

    return (
      <FastImage
          source={{uri: this.props.targetURL}}
          style={this.state.stateImageStyle}
          resizeMode={this.props.resizeMode}
          onLoadStart={(dimensions) => {
              if (this.state.isImageLoadComplete) {
                this.setState({
                  isImageLoadComplete: false,
                  dimensions: dimensions.nativeEvent,
                  stateImageStyle: {display:'none'}
                });
              }
            }}
          onLoad={(dimensions) => {
            if (!this.state.isImageLoadComplete) {
              this.setState({
                isImageLoadComplete: true,
                dimensions: dimensions.nativeEvent,
                stateImageStyle: this.props.imageStyle
              });
            }
      }}/>
    );
  }

  render() {
    const isAsynImgLoaded = this.state.isImageLoadComplete;
     if (this.props.targetURL) {
       return <View>
         {(!isAsynImgLoaded)?AsyncImage.servePlaceHolderImageComponent(this.props.imageStyle):null }
         {this.beginLoadingAsyncImage()}
       </View>;
     }
     else
       return <View>{AsyncImage.servePlaceHolderImageComponent()}</View>
    }
}

const styles = StyleSheet.create({
  placeHolderImage: { width: WIDTH_80, height: WIDTH_80, resizeMode: 'contain' },
  bodyImage: { width: '100%' },
});

export default AsyncImage;
