import {resetAuthTable} from '../realm/Models/loginModel';
import {ROUTE_AUTH} from '../resources/constants/navigationConstants';
import {useNavigation} from '@react-navigation/native';
import {SET_LOGIN_INITIAL_STATE} from '../resources/constants/storeConstants';
import store from '../store/store';
import AppAsyncStorage from "../api/helper/AppAsyncStorage";
import {AUTO_LOGGED_OUT} from "../resources/constants/asyncKeys";
import {NO, YES} from "../resources/constants/stringConstants";
import {resetAppData} from "../services/onAuthService";

export const onLogoutPressHandler = async (navigation) => {
    let appAsyncResetSuccess = await resetAppData(true);
      if (appAsyncResetSuccess === true) {
        await  AppAsyncStorage.setValue(AUTO_LOGGED_OUT, NO);
        await store.dispatch({type: SET_LOGIN_INITIAL_STATE, payload: ''});
        setTimeout(() => {
          navigation.replace(ROUTE_AUTH);
        }, 500);
      }
};

export const onAutoLogout =  async (navigation) => {
    await AppAsyncStorage.setValue(AUTO_LOGGED_OUT, YES);
    // const navigation = useNavigation();
    try {
        await store.dispatch({type: SET_LOGIN_INITIAL_STATE, payload: ''});
        setTimeout(() => {
            navigation.replace(ROUTE_AUTH);
        }, 500);
    } catch (error){
        console.log('error on auto-logout' + error);
    }
    ;
}
