import {
    ERROR_401,
    EXCEPTION_ISSUE,
    INTERNAL_SERVER_MSG, LOGOUT, LOGOUT_ON_SESSION_INVALID,
    OOPS_WRONG, PDF_ERROR, PDF_LOAD_FAIL,
    REQUEST_ERROR,
    REQUEST_ISSUE, RESET_PRODUCT_PAGE_REDUCER_ON_LOGOUT,
    RESET_PRODUCT_PAGE_REDUCER_STATE, RESET_SPIFF_REDUCER_STATE,
    RESPONSE_ISSUE,
    SESSION_EXPIRED_MSG,
    SET_CART_REDUX_INITIAL_STATE, SET_INTERMEDDIATE_PAGE_INITIAL_STATE,
    SET_LOGIN_INITIAL_STATE, SET_LOGIN_INITIAL_STATE_ON_LOGOUT,
    SET_LOGOUT_REDUX_INITIAL_STATE,
    UNEXPECTED_ERROR,
} from '../resources/constants/storeConstants';
import AppAsyncStorage from '../api/helper/AppAsyncStorage';
import {PRODUCT_LIST, SESSION_TOKEN, USER_BRAND_DATA} from '../resources/constants/asyncKeys';
// import store from '../store';
// import {ROUTE_AUTH} from '../resources/constants/navRouteKeys';


// error text for http API handling
export const getModalErrorText = (errorObj) =>{
    let errorText='ERROR!!';
    if(errorObj.errorType === REQUEST_ISSUE){
        errorText = REQUEST_ERROR;
    }
    else if(errorObj.errorType === RESPONSE_ISSUE){
        if(errorObj.ErrorStatus === ERROR_401)
            errorText = SESSION_EXPIRED_MSG;
        else
            errorText = INTERNAL_SERVER_MSG;
    }
    else if(errorObj.errorType === EXCEPTION_ISSUE){
        errorText = OOPS_WRONG;
    }
    else if(errorObj.errorType === PDF_LOAD_FAIL){
        errorText = PDF_ERROR;
    }
    else{
        errorText = UNEXPECTED_ERROR;
    }
    return errorText;
}



// export const logoutOnError = async (navigation) => {
//     await store.dispatch({type:LOGOUT_ON_SESSION_INVALID, payload:''}); //hit api to remove fcm token on server
//     await AppAsyncStorage.deleteValue(SESSION_TOKEN);
//     await store.dispatch({type:SET_LOGIN_INITIAL_STATE_ON_LOGOUT, payload:''});
//     await store.dispatch({type:RESET_PRODUCT_PAGE_REDUCER_ON_LOGOUT, payload:''});
//     await store.dispatch({type:SET_INTERMEDDIATE_PAGE_INITIAL_STATE, payload:''});
//     await store.dispatch({type:SET_CART_REDUX_INITIAL_STATE, payload:''});
//     await store.dispatch({type:RESET_SPIFF_REDUCER_STATE, payload:''});
//     // added to handle corner cases in multiple company multiple template scenarios
//    // await AppAsyncStorage.setValue(PRODUCT_LIST,'');
//     //await AppAsyncStorage.deleteValue(USER_BRAND_DATA);
//     navigation.replace(ROUTE_AUTH);
// }
//
//
//
// export const logoutUser = async (navigation) => {
//     await AppAsyncStorage.deleteValue(SESSION_TOKEN);
//     await store.dispatch({type:SET_LOGIN_INITIAL_STATE_ON_LOGOUT, payload:''});
//     await store.dispatch({type:SET_INTERMEDDIATE_PAGE_INITIAL_STATE, payload:''});
//     await store.dispatch({type:RESET_PRODUCT_PAGE_REDUCER_ON_LOGOUT, payload:''});
//     await store.dispatch({type:SET_CART_REDUX_INITIAL_STATE, payload:''});
//     await store.dispatch({type:SET_LOGOUT_REDUX_INITIAL_STATE, payload:''});
//     await store.dispatch({type:RESET_SPIFF_REDUCER_STATE, payload:''});
//     // added to handle corner cases in multiple company multiple template scenarios
//     //await AppAsyncStorage.setValue(PRODUCT_LIST,'');
//    // await AppAsyncStorage.deleteValue(USER_BRAND_DATA);
//     navigation.replace(ROUTE_AUTH);
// debugger;
//
// }
