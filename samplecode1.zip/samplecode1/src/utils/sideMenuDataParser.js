import {validateRequiredField} from "./validators";

let serverResponse  = {
    "code":"200",
    "data":{
        "response":{
            "reasonCode":"1",
            "reasonText":"SUCCESS",
            "dataList": [

                {"MenuID":122341,"ParentMenuID":1124785,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Customer Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":13483929,"ParentMenuID":48761425,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Customer Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":2000245,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Daily Processing","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":3784412,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Inventory","NavURL":"","IsActive":true,"ImageUrl":"Inventory.png","MenuSubText":""},
                {"MenuID":48761425,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Fulfilment","NavURL":"","IsActive":true,"ImageUrl":"Fulfilment.png","MenuSubText":""},
                {"MenuID":51234,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Compliance","NavURL":"","IsActive":true,"ImageUrl":"Compliance.png","MenuSubText":""},
                {"MenuID":612345,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Reports","NavURL":"","IsActive":true,"ImageUrl":"Reports.png","MenuSubText":""},
                {"MenuID":7654321,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Tools","NavURL":"","IsActive":true,"ImageUrl":"Tools.png","MenuSubText":""},
                {"MenuID":81246778,"ParentMenuID":2000245,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Sales & growth","NavURL":"SalesGrowthMenuStack","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":97277374,"ParentMenuID":2000245,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Growth","NavURL":"comingSoon","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":1014523,"ParentMenuID":48761425,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Customer Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":1124785,"ParentMenuID":48761425,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Customer Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},

                {"MenuID":20002451,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Sales & Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":37844121,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Inventory","NavURL":"","IsActive":true,"ImageUrl":"Inventory.png","MenuSubText":""},
                {"MenuID":487614251,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Fulfilment","NavURL":"","IsActive":true,"ImageUrl":"Fulfilment.png","MenuSubText":""},
                {"MenuID":512341,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Compliance","NavURL":"","IsActive":true,"ImageUrl":"Compliance.png","MenuSubText":""},
                {"MenuID":6123451,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Reports","NavURL":"","IsActive":true,"ImageUrl":"Reports.png","MenuSubText":""},
                {"MenuID":76543211,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Tools","NavURL":"","IsActive":true,"ImageUrl":"Tools.png","MenuSubText":""},
                {"MenuID":812467781,"ParentMenuID":20002451,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Sales","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":972773741,"ParentMenuID":20002451,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":10145231,"ParentMenuID":487614251,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Customer Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":11247851,"ParentMenuID":487614251,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Customer Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":1223411,"ParentMenuID":11247851,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Customer Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":134839291,"ParentMenuID":512341,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Customer Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},

                {"MenuID":200024511,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Sales & Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":378441211,"ParentMenuID":37844121,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Inventory","NavURL":"","IsActive":true,"ImageUrl":"Inventory.png","MenuSubText":""},
                {"MenuID":4876142511,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Fulfilment","NavURL":"","IsActive":true,"ImageUrl":"Fulfilment.png","MenuSubText":""},
                {"MenuID":5123411,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Compliance","NavURL":"","IsActive":true,"ImageUrl":"Compliance.png","MenuSubText":""},
                {"MenuID":61234511,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Reports","NavURL":"","IsActive":true,"ImageUrl":"Reports.png","MenuSubText":""},
                {"MenuID":765432111,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Tools","NavURL":"","IsActive":true,"ImageUrl":"Tools.png","MenuSubText":""},
                {"MenuID":8124677811,"ParentMenuID":200024511,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Sales","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":9727737411,"ParentMenuID":200024511,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":101452311,"ParentMenuID":4876142511,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Customer Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":112478511,"ParentMenuID":4876142511,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Customer Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":12234111,"ParentMenuID":112478511,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Customer Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},
                {"MenuID":1348392911,"ParentMenuID":5123411,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Customer Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""},


            ],
            "error":"",
            "token":null,
            "isValid":null
        }
    }
}

let dataJSON = [];
let hash = new Array(70).fill("-1");
let mainIndex = 0;
let indexArray = new Array(70);

function convertApiDataIntoJson(dataList,dataLength){

    let len = dataLength;
    let data = dataList;
    let countDuplicateList = 0;
    const duplicateList = new Array(len);

    for( let i = 0 ; i < len ; i++ ){
        let getMenuId = data[i].MenuID;
        let getParentMenuID = data[i].ParentMenuID;
        data[i].level = 1;
        data[i].children_data = [];

        if(getParentMenuID == 0){
            data[i].MenuID = indexArray[data[i].MenuID];
            dataJSON.push(data[i])
            hash[getMenuId] = ""+mainIndex+",";
            mainIndex++;
        } else{
            if(hash[getParentMenuID] == "-1"){
                duplicateList[countDuplicateList] = data[i];
                countDuplicateList++;
            } else{
                let index = 0;
                let initData = dataJSON;
                let treeHashData = hash[getParentMenuID].split(",");
                let count = treeHashData.length-1;
                while( count != 0 ){
                    initData = initData[treeHashData[index]].children_data;
                    index++;
                    count--;
                }

                data[i].MenuID = indexArray[data[i].MenuID];
                data[i].ParentMenuID = indexArray[data[i].ParentMenuID];
                data[i].level = index+1;
                initData.push(data[i]);
                hash[getMenuId] = hash[getParentMenuID]+(""+(initData.length-1))+",";
            }
        }
    }

    if(countDuplicateList == 0)
        return dataJSON;
    else
        return convertApiDataIntoJson(duplicateList,countDuplicateList);
}

function updateDataListMenuId(dataList){
    // if(!validateRequiredField(dataList)){
    //     return ('');
    // }
    let count = 1;
    let len = dataList.length;

    for(let i=0;i<len;i++){
        let menuId = dataList[i].MenuID;
        let parentMenuID = dataList[i].ParentMenuID;
        let getIndexMenuId = indexArray.indexOf(menuId);
        if(getIndexMenuId == -1){
            indexArray[count] = menuId;
            dataList[i].MenuID = count;
            count++;
        } else{
            dataList[i].MenuID = getIndexMenuId;
        }

        if(parentMenuID != 0){
            let getIndexParentMenuId = indexArray.indexOf(parentMenuID);
            if(getIndexParentMenuId == -1){
                indexArray[count] = parentMenuID;
                dataList[i].ParentMenuID = count;
                count++;
            } else{
                dataList[i].ParentMenuID = getIndexParentMenuId;
            }
        }

    }

    return convertApiDataIntoJson(dataList,dataList.length);
}

export const getRequiredSideMenuJson = (rawMenuApiResponse) =>{
    console.log("rawMenuApiResponse is from --->",rawMenuApiResponse);
    let parsedData = updateDataListMenuId(rawMenuApiResponse);
    // re-initialize the global variables-->
    dataJSON = [];
    hash = new Array(70).fill("-1");
    mainIndex = 0;
    indexArray = new Array(70);
    console.log(parsedData);
    return parsedData;
}

