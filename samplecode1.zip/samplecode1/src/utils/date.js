import {COLON, DASH, DOT, FORWARD_SLASH, SINGLE_SPACE} from '../resources/constants/stringConstants';

// to add 1 extra zero at end to make 2 digit number.
const twoDigitZeroHandling = (dateOrMonth) => {
    if(dateOrMonth < 10){
        return '0' + dateOrMonth;
    }
    else
        return dateOrMonth;

}

// to add 1 or 2 extra zeros at end to mke 3 digit number.
const threeDigitZeroHandling = (milliseconds) => {
    if (milliseconds < 10)
        return milliseconds + '00';
    else if(milliseconds < 100)
        return milliseconds + '0';
    else
        return milliseconds;
}

// get date and time in server request format.
export const getOrderDateAndTime =() =>{
    const systemDateObj =new Date();
    let dateString =
        systemDateObj.getUTCFullYear() +
        DASH +
        twoDigitZeroHandling(systemDateObj.getUTCMonth()+ 1)+
        DASH +
        twoDigitZeroHandling(systemDateObj.getUTCDate())+
        SINGLE_SPACE +
        twoDigitZeroHandling(systemDateObj.getUTCHours())+
        COLON +
        twoDigitZeroHandling(systemDateObj.getUTCMinutes())+
        COLON +
        twoDigitZeroHandling(systemDateObj.getUTCSeconds())+
        DOT +
        threeDigitZeroHandling(systemDateObj.getUTCMilliseconds());
    console.log(dateString);
    return dateString;
};

/**'
 * Return todays date in YYYY-MM-DD formate
 */
export const getTodaysDateYYYYMMDD = () => {
    const systemDateObj =new Date();
    let dateString =
        systemDateObj.getUTCFullYear() +
        DASH +
        twoDigitZeroHandling(systemDateObj.getUTCMonth()+ 1)+
        DASH +
        twoDigitZeroHandling(systemDateObj.getUTCDate())
    console.log(dateString);
    return dateString;
}



export const parseSpiffDate = (iosDate) => {
  let parsedDateAndTime = new Date(iosDate);

  let inRequiredFormat =
      twoDigitZeroHandling((parsedDateAndTime.getMonth()+ 1)) +
      FORWARD_SLASH +
      twoDigitZeroHandling(parsedDateAndTime.getDate()) +
      FORWARD_SLASH +
      parsedDateAndTime.getFullYear() +
      SINGLE_SPACE +
      twoDigitZeroHandling(parsedDateAndTime.getHours()) +
      COLON +
      twoDigitZeroHandling(parsedDateAndTime.getMinutes())

    return inRequiredFormat;

};

export const parseCustomerDate = (isoDate) => {
    let parsedDateAndTime = new Date(isoDate);

    let inRequiredFormat =
        twoDigitZeroHandling((parsedDateAndTime.getMonth()+ 1)) +
        FORWARD_SLASH +
        twoDigitZeroHandling(parsedDateAndTime.getDate()) +
        FORWARD_SLASH +
        parsedDateAndTime.getFullYear();
        //+
        // SINGLE_SPACE +
        // twoDigitZeroHandling(parsedDateAndTime.getHours()) +
        // COLON +
        // twoDigitZeroHandling(parsedDateAndTime.getMinutes())

    return inRequiredFormat;

};
