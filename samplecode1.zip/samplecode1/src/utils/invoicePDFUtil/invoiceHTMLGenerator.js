import {roundToTwo} from "../validators";

export const pdfHTMLGeneratorMasterFunction = (pdfJson) => {
    let masterHTMLString ='';
    let orderLineLength = pdfJson.tableSection.orderLineArray.length;
    //let orderLineLength = pdfJson.tableSection.orderLineArray.length;
    let quotient = Math.floor(orderLineLength / 30);
    let remainder = orderLineLength % 30;
    let pdfPages = 1;
    if(quotient > 0 && remainder > 0){
        pdfPages = quotient + 1;
    } else if(quotient > 0 && remainder === 0){
        pdfPages = quotient;
    }
    for(let page=1; page<= pdfPages; page++){
        let headerString = getInvoiceHeaderSection(pdfJson.headerSection);
        let addressString = getInvoiceCustomerAddressSection(pdfJson.addressSection);
        let repString = getInvoiceRepSection(pdfJson.repSection);
        let tableString = getInvoiceTableSection(pdfJson.tableSection, orderLineLength, pdfPages, page);
        let footerString = getInvoiceFooterSection(pdfJson.footerSection, page, pdfPages);

        masterHTMLString = masterHTMLString +headerString + addressString + repString + tableString + footerString;
    }
    return masterHTMLString;
}


export const getInvoiceHeaderSection = (headerSection) => {
    let headerLogoString = 'data:image/png;base64,' + headerSection.headerLogoBase64;
    const headerStingOpen1 =
        '<div style=" width: 90%;  height: 80pt; margin-top: 8.5pt; margin-right: auto; margin-left: auto">'
    const headerStringRightPanelAddress =
        '<div style=" height: inherit; width: 35%; float: left; font-size: 8px;">'+
        '<span style="font-weight: bold;">' + headerSection.headerAddress.addressLine1 + '</span><br>'+
        '<span style="font-weight: bold;">'+ headerSection.headerAddress.addressLine2 + '</span><br>'+
        '<span style="font-weight: bold;">'+ headerSection.headerAddress.addressLine3 + '</span><br>'+
        '<span style="font-weight: bold;">' + headerSection.headerAddress.addressLine4 +'</span><br>'+
        '</div>';
    const headerStringBrandImage =
        '<div style="  height: inherit;width:30%; float: left; ">'+
        '<img style="display: block; margin-left: auto;margin-right: auto; height: 90%" src='+ headerLogoString +'>'+
        '</div>';
    const headerStringLeftPanelInvoiceDate =
        '<div style=" height: inherit; width:34%; float: left;text-align: end;">'+
        '<h4 style=" margin-top: 0;">' + 'INVOICE: ' + headerSection.invoiceNo + '</h4>'+
        '<p style="font-weight: bold;font-size: 9px;">' +'Date: ' + headerSection.dateTimeStamp + '</p>'+
        '</div>';
    const headerStringClose1 =
        '</div>';
    let headerHtmlString = headerStingOpen1 + headerStringRightPanelAddress + headerStringBrandImage +
        headerStringLeftPanelInvoiceDate + headerStringClose1;

    return headerHtmlString;
}

export const getInvoiceCustomerAddressSection = (addressSection) =>{
    const addressSectionOpening1 =
        '<div style="width: 90%; margin-top: 5pt; height: 80pt; border: black 1px solid; margin-right: auto; margin-left: auto; ">';
    const customerBillingAddress=
        '<div style="margin-left: 5px;height: inherit; width: 49%; border-right: black 1px solid; float: left; font-size: 8px;">'+
        '<span style="font-weight: bold;">BILL TO:</span><br>'+
        '<span style="">'+ addressSection.billToAddress.addressLine1 + '</span><br>'+
        '<span style="">'+ addressSection.billToAddress.addressLine2 +'</span><br>' +
        '<span style="">'+ addressSection.billToAddress.addressLine3 + '</span><br>'+
        '<span style="">'+ addressSection.billToAddress.addressLine4 + '</span>' +
        '</div>';
    const customerShippingAddress=
        '<div style=" margin-left: 5px;  height: inherit; width: 47%;float: left; font-size: 8px;">'+
        '<span style="font-weight: bold;">SHIP TO:</span><br>'+
        '<span style="">'+ addressSection.shipToAddress.addressLine1 + '</span><br>'+
        '<span style="">'+ addressSection.shipToAddress.addressLine2 +'</span><br>' +
        '<span style="">'+ addressSection.shipToAddress.addressLine3 + '</span><br>'+
        '<span style="">'+ addressSection.shipToAddress.addressLine4 + '</span>' +
        '</div>';
    const addressClosing1 =
        '</div>';

    const addressHtmlString = addressSectionOpening1+ customerBillingAddress + customerShippingAddress + addressClosing1;

    return addressHtmlString;
}


export const getInvoiceRepSection = (repSection) => {

    const repSectionOpening1 =
        '<div style="font-size: 9px; margin-top: 5pt; margin-bottom: 5pt; width: 90%;  height: 40pt; border: black 1px solid; margin-right: auto; margin-left: auto">';
    const midSection=
        '<div style="font-size: 9px; margin-left:5px; height: inherit; width: 24%; border-right: black 1px solid; float: left;">' +
        '<span style="">Customer No:</span><br>' +
        '<span style="font-weight: bold">' + repSection.customerNo + '</span><br>' +
        '</div>' +
        '<div style="font-size: 9px; margin-left:5px; height: inherit; width: 24%; border-right: black 1px solid; float: left;">\n' +
        '<span style="">Sales Rep:</span><br>' +
        '<span style="font-weight: bold">' + repSection.salesRep + '</span><br>' +
        '</div>' +
        '<div style="font-size: 9px; margin-left:5px; height: inherit; width: 24%; border-right: black 1px solid; float: left;">' +
        '<span style="">PO No:</span><br>' +
        '<span style="font-weight: bold">' + repSection.poNo + '</span><br>' +
        '</div>' +
        '<div style="font-size: 9px; margin-left:5px; height: inherit; width: 24%; float: left;">' +
        '<span style="">Terms:</span><br>' +
        '<span style="font-weight: bold">' + repSection.terms + '</span><br>' +
        '</div>';
    const repClosing1 =
        '</div>';

    const repHtmlString = repSectionOpening1+ midSection + repClosing1;

    return repHtmlString;


}


export const getInvoiceTableSection = (tableSection, orderLineLength, pdfPageCount, currentPage) => {
    let orderLineArray=tableSection.orderLineArray;
    // return stringhtml;
    const tableSectionOpening1 ='<div style=" width: 90%;  height: 342pt; border: black 1px solid; margin-right: auto; margin-left: auto;">';
    const tableHeader =
        '<div style=" height: 12pt; border-bottom:black 1px solid; font-weight: bold;  margin-right: auto; margin-left: auto;">' +
        '<div style=" height: inherit; width:7%; border-right: black 1px solid; float: left; font-size: 8px;">' +
        '<span style="margin-left: 5px">QTY</span>' +
        '</div>' +
        '<div style=" height: inherit; width:25%; border-right: black 1px solid;float: left; font-size: 8px;">' +
        '<span style="margin-left: 5px">ITEM CODE</span>' +
        '</div>' +
        '<div style=" height: inherit; width:39%; border-right: black 1px solid; float: left; font-size: 8px;">' +
        '<span style="margin-left: 5px">DESCRIPTION</span>' +
        '</div>' +
        // '<div style=" height: inherit; width:11%; border-right: black 1px solid; float: left; font-size: 8px;">' +
        // '<span style="margin-left: 5px">RETAIL</span>' +
        // '</div>' +
        '<div style=" height: inherit; width:11%; border-right: black 1px solid;float: left; font-size: 8px;">' +
        '<span style="margin-left: 5px">PRICE</span>' +
        '</div>' +
        '<div style=" height: inherit; width:11%; border-right: black 1px solid; float: left; font-size: 8px;">' +
        '<span style="margin-left: 5px">TOTAL</span>' +
        '</div>' +
        '<div style=" height: inherit; width:5%;float: left; font-size: 8px;">' +
        '<span style="margin-left: 5px">TAX</span>' +
        '</div>' +
        '</div>';

    let initialLineNo = 0;
    initialLineNo = (30*(currentPage - 1));
    let lastLineNo = 0;
    lastLineNo = initialLineNo + 29;
    if(lastLineNo >= orderLineLength){
        lastLineNo = orderLineLength-1;
    }
    let tableRowWithData ='';
    for(let j=initialLineNo; j<=lastLineNo; j++) {
        let eachRowData =
            '<div style=" height: 11pt; margin-right: auto; margin-left: auto;">' +
            '<div style=" height: inherit; width:7%; border-right: black 1px solid; float: left; font-size: 8px">' +
            '<span style="margin-left: 5px">' + orderLineArray[j].OrderQty + '</span>' +
            '</div>' +
            '<div style=" height: inherit; width:25%; border-right: black 1px solid;float: left; font-size: 8px">' +
            '<span style="margin-left: 5px; overflow: hidden;">' + orderLineArray[j].ItemNo + '</span>\n' +
            '</div>' +
            '<div style=" height: inherit; width:39%; border-right: black 1px solid; float: left; overflow: hidden; font-size: 8px">' +
            '<span style="margin-left: 5px">' + orderLineArray[j].Description1 + '</span>' +
            '</div>' +
            // '<div style=" height: inherit; width:11%; border-right: black 1px solid; float: left; font-size: 8px">' +
            // '<span style="margin-left: 5px">' + roundToTwo(orderLineArray[j].ListPrice) + '</span>' +
            // '</div>' +
            '<div style=" height: inherit; width:11%; border-right: black 1px solid;float: left; font-size: 8px">' +
            '<span style="margin-left: 5px">' + roundToTwo(orderLineArray[j].ListPrice) + '</span>' +
            '</div>' +
            '<div style=" height: inherit; width:11%; border-right: black 1px solid; float: left; font-size: 8px">' +
            '<span style="margin-left: 5px">'+ roundToTwo((orderLineArray[j].OrderQty * orderLineArray[j].ListPrice))+'</span>' +
            '</div>' +
            '<div style=" height: inherit; width:5%; float: left; font-size: 8px">' +
            '<span style="margin-left: 5px">' + ((orderLineArray[j].TaxFlag)?'Y': 'N') + '</span>' +
            '</div>' +
            '</div>';
        tableRowWithData = tableRowWithData + eachRowData;
    }
    let emptyRowCount = 30 - (lastLineNo - initialLineNo +1);
    for(let j= 1; j<=emptyRowCount; j++){
        let eachEmptyRowData =
            '<div style=" height: 11pt; margin-right: auto; margin-left: auto;">' +
            '<div style=" height: inherit; width:7%; border-right: black 1px solid; float: left; font-size: 8px">' +
            '<span style="margin-left: 5px"></span>' +
            '</div>' +
            '<div style=" height: inherit; width:25%; border-right: black 1px solid;float: left; font-size: 8px">' +
            '<span style="margin-left: 5px; overflow: hidden;"></span>' +
            '</div>' +
            '<div style=" height: inherit; width:39%; border-right: black 1px solid; float: left; overflow: hidden; font-size: 8px">' +
            '<span style="margin-left: 5px"></span>' +
            '</div>' +
            // '<div style=" height: inherit; width:11%; border-right: black 1px solid; float: left; font-size: 8px">' +
            // '<span style="margin-left: 5px"></span>' +
            // '</div>' +
            '<div style=" height: inherit; width:11%; border-right: black 1px solid;float: left; font-size: 8px">' +
            '<span style="margin-left: 5px"></span>' +
            '</div>' +
            '<div style=" height: inherit; width:11%; border-right: black 1px solid; float: left; font-size: 8px">' +
            '<span style="margin-left: 5px"></span>' +
            '</div>' +
            '<div style=" height: inherit; width:5%; float: left; font-size: 8px">' +
            '<span style="margin-left: 5px"></span>' +
            '</div>' +
            '</div>';
        tableRowWithData = tableRowWithData+ eachEmptyRowData;
    }

    const tableSectionClosing1 ='</div>';

    const tableHTMLString = tableSectionOpening1 + tableHeader + tableRowWithData + tableSectionClosing1;

    return tableHTMLString;

    //return '';
}

export const getInvoiceFooterSection = (footerSection, currentPageNo, lastPageNo) => {
    if(currentPageNo === lastPageNo) {
        let signatureString = 'data:image/png;base64,' + footerSection.signatureBase64;
        const footerSectionOpening1 =
            '<div style="font-size: 9px; margin-top: 10pt; width: 90%;  height: 70pt; margin-right: auto; margin-left: auto; font-weight: bold;text-align: end">';
        const signImage =
            '<div style="text-align: start; margin-left:5px; height: inherit; width: 30%; border-bottom: black 1px solid; float: left;">' +
            '<img style="display: block; margin-left: auto;margin-right: auto; height: 80%;" src="' + signatureString + '" >' +
            '<span style="font-size: 7px;">Signature:</span><br>' +
            '</div>';
        const priceSection =
            '<div style=" margin-left:5px; height: inherit; width: 22%; float: left; font-size: 8px">' +
            // '<span style="">Total Retail: ' + footerSection.numericalVal.totalRetail + '</span><br>' +
            // '<span style="">Profit: ' + footerSection.numericalVal.profit + '</span><br>' +
            // '<span style="">Percentage: ' + footerSection.numericalVal.percentage + '</span>' +
            '</div>' +
            '<div style=" margin-left:5px; height: inherit; width: 22%; float: left; font-size: 8px">' +
            '<span style="">Paid Cash: ' + footerSection.numericalVal.paidCash + '</span><br>' +
            '<span style="">Paid Check: ' + footerSection.numericalVal.paidCheck + '</span><br>' +
            '<span style="">Paid Card: ' + footerSection.numericalVal.paidCard + '</span><br>' +
            '<span style="">On Account: ' + footerSection.numericalVal.onAccount + '</span><br>' +
            '<span style="">CHK# ' + footerSection.numericalVal.chk + '</span>' +
            '</div>' +
            '<div style=" margin-left:5px; height: inherit; width: 22%; float: left; font-size: 8px">' +
            '<span style="">Num Of Items: ' + footerSection.numericalVal.noItems + '</span><br>' +
            '<span style="">Pre-Tax Total: ' + footerSection.numericalVal.preTaxTotal + '</span><br>' +
            '<span style="">Discount: ' + footerSection.numericalVal.discount + '</span><br>' +
            '<span style="">Total Sale: ' + roundToTwo(footerSection.numericalVal.totalSales) + '</span>' +
            '</div>' +
            '<div style="">' +
            '<span>page ' + currentPageNo + '</span>' +
            '</div>';
        const footerClosing1 =
            '</div>';
        const footerHtmlString = footerSectionOpening1 + signImage + priceSection + footerClosing1;

        return footerHtmlString;
    }else{
        const emptyFooterString =
            '<div style="font-size: 8px; margin-top: 10pt; width: 90%; height: 70pt; margin-right: auto; margin-left: auto; font-weight: bold; text-align: end">' +
            ' <div>' +
            ' <span>page ' + currentPageNo + '</span>' +
            ' </div>' +
            '</div>';
        return emptyFooterString;
    }
}
