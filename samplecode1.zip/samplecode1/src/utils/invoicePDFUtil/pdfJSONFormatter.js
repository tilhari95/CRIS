import {brandimgbase64} from "./imagebase64";
import {signImgbase64} from "./signImgbase64";
import {validateRequiredField} from "../validators";


export const pdfJsonFormatter = (dataObj) => {
    console.log('data obj --->> for pdf --->>>');
    console.log(dataObj);
    let pdfReqJson ={
    headerSection:{
        headerAddress:{
            addressLine1: validateRequiredField(dataObj.CompanyDetail.CompanyName)?dataObj.CompanyDetail.CompanyName:'',
            addressLine2: (validateRequiredField(dataObj.CompanyDetail.Address)?dataObj.CompanyDetail.Address:'') +', ' + (validateRequiredField(dataObj.CompanyDetail.City)?dataObj.CompanyDetail.City:''),
            addressLine3: (validateRequiredField(dataObj.CompanyDetail.State)?dataObj.CompanyDetail.State:'') + ', ' +  (validateRequiredField(dataObj.CompanyDetail.Zip)?dataObj.CompanyDetail.Zip:''),
            addressLine4: validateRequiredField(dataObj.CompanyDetail.Phone)?dataObj.CompanyDetail.Phone:''
        },
        headerLogoBase64: brandimgbase64, //replace this var with actual var
        invoiceNo:'',
        dateTimeStamp:'' //05-07-2021 10:20
    }   ,
    addressSection:{
        billToAddress:{
            addressLine1: (validateRequiredField(dataObj.CustomerInfo.CustomerName)?dataObj.CustomerInfo.CustomerName:'') + ' '+(validateRequiredField(dataObj.CustomerInfo.BillToName)?dataObj.CustomerInfo.BillToName:'') ,
            addressLine2: validateRequiredField(dataObj.CustomerInfo.Address1)?dataObj.CustomerInfo.Address1:'',
            addressLine3: (validateRequiredField(dataObj.CustomerInfo.Address2)?dataObj.CustomerInfo.Address2:'') + ' ' + (validateRequiredField(dataObj.CustomerInfo.City)?dataObj.CustomerInfo.City:'') + ' '+ (validateRequiredField(dataObj.CustomerInfo.State)?dataObj.CustomerInfo.State:'') + ' ' + (validateRequiredField(dataObj.CustomerInfo.PostalCode)?dataObj.CustomerInfo.PostalCode:''),
            addressLine4: (validateRequiredField(dataObj.CustomerInfo.Phone1)?dataObj.CustomerInfo.Phone1:''),
        },
        shipToAddress:{
            addressLine1: validateRequiredField(dataObj.CustomerInfo.ShipToName)?dataObj.CustomerInfo.ShipToName:'',
            addressLine2: validateRequiredField(dataObj.CustomerInfo.ShipToAddress1)?dataObj.CustomerInfo.ShipToAddress1:'',
            addressLine3: (validateRequiredField(dataObj.CustomerInfo.ShipToCity)?dataObj.CustomerInfo.ShipToCity:'') + ' ' + (validateRequiredField(dataObj.CustomerInfo.ShipToState)?dataObj.CustomerInfo.ShipToState:''),
            addressLine4: validateRequiredField(dataObj.CustomerInfo.ShipToZip)?dataObj.CustomerInfo.ShipToZip:'',
        },
    },
    repSection:{
        customerNo: validateRequiredField(dataObj.CustomerInfo.CustomerNo)?dataObj.CustomerInfo.CustomerNo:'',
        salesRep:'Static Name',
        poNo:validateRequiredField(dataObj.CustomerInfo.PostalCode)?dataObj.CustomerInfo.PostalCode:'',
        terms:validateRequiredField(dataObj.CustomerInfo.Terms)?dataObj.CustomerInfo.Terms:'',
    },
    tableSection:{
        orderLineArray:dataObj.ItemList
        // array of orderLine
    },
    footerSection:{
        signatureBase64:dataObj.SignatorImageData,
        numericalVal:{
            totalRetail:'----',
            profit:'----',
            percentage:'----',
            paidCash:validateRequiredField(dataObj.CashReceived)?dataObj.CashReceived:'0.00',
            paidCheck:validateRequiredField(dataObj.CheckAmount)?dataObj.CheckAmount:'0.00',
            paidCard:'0.00',
            onAccount:'----',
            chk: validateRequiredField(dataObj.CheckNo)?dataObj.CustomerInfo.CheckNo:'   ',
            noItems: getItemCount(dataObj.ItemList),
            preTaxTotal:validateRequiredField(dataObj.CartTotal)?dataObj.CartTotal:'0.00',
            discount:validateRequiredField(dataObj.RewardAmount)?dataObj.RewardAmount:'0.00',
            totalSales:validateRequiredField(dataObj.TotalDueAfterReward)?dataObj.TotalDueAfterReward:'0.00',
        }

    }
    }
    return pdfReqJson;
};



export const getItemCount = (orderLineList) =>{
    let totalCount =0;

    for(let cv =0; cv< orderLineList.length; cv++){
        totalCount = totalCount + orderLineList[cv].OrderQty
    }
    return totalCount
}
