import RNHTMLtoPDF from 'react-native-html-to-pdf';
import RNFetchBlob from 'rn-fetch-blob';
import {pdfJsonFormatter} from "./pdfJSONFormatter";
import {pdfHTMLGeneratorMasterFunction} from'./invoiceHTMLGenerator';


//todo: create universal-fit-size pdf to fix formatting issue on large pdfs > 3 pages for phase 2 release:
//todo: Find some math formula for converting font-size in pixel to get actual height and width of font pixel and then -->
//todo: adjust 'pt' as per that or bring all 'pt' to pixel sum it up and use some formula to get pdf width height in pixel and replace that with height and width in options.
export async function createInvoicePDF(data, withDefaultIntent = false) {
   // console.log('from new file__>>>');
    let pdfJson = pdfJsonFormatter(data);
    let finalPdfHtml =pdfHTMLGeneratorMasterFunction(pdfJson);
    let options = {
        html: finalPdfHtml,
        fileName: '123' + 'orderId', // attach invoice no here instead of '123'
        //directory: 'mcni360Documents',
        base64: true,
        height: (Platform.OS === 'android')?720:730, //727 min but put 730 to adjust on iPad with smaller font //height: 650,
        width: 550
    };

    let generatedPdfResponse = await RNHTMLtoPDF.convert(options);
    console.log('generated PDF response obj -->> ', generatedPdfResponse);

    if(withDefaultIntent){
        const android = RNFetchBlob.android;
        if (Platform.OS === "ios") {
            await RNFetchBlob.ios.openDocument(generatedPdfResponse.filePath);
        }
        else{
            await android.actionViewIntent(generatedPdfResponse.filePath, 'application/pdf')
        }
    }

    return generatedPdfResponse;
}




