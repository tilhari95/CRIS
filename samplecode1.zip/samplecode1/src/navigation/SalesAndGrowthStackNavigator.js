
import {
    ROUTE_HOME,
    ROUTE_COMING_SOON,
    ROUTE_SALES_GROWTH,
    ROUTE_CUSTOMER_DETAIL, ROUTE_SETTINGS,
    ROUTE_COUSTOMER_INFO,
    ROUTE_BILLING_TAB,
    ROUTE_CUSTOMER_DETAILS_TAB
} from '../resources/constants/navigationConstants';
import {createStackNavigator} from '@react-navigation/stack';
import React from 'react';
import HomeScreen from '../screens/HomeScreen/HomeScreen';
import InventoryActivities from '../screens/DailyProcessing/InventoryActivities/InventoryActivites';
import SalesAndGrowthLandingScreen from "../screens/DailyProcessing/SalesAndGrowth/SalesAndGrowthLandingScreen";
import CustomerDetailScreen from "../screens/DailyProcessing/SalesAndGrowth/CustomerDetails/CustomerDetailScreen";
import SettingsScreen from "../screens/SettingsScreen/SettingsScreen";
import CustomerInfo from '../screens/DailyProcessing/SalesAndGrowth/CustomerDetails/CustomerInfo';
import CustomerDetailTab from '../screens/DailyProcessing/SalesAndGrowth/CustomerDetails/details/CustomerDetailTab'
import BillingTab from '../screens/DailyProcessing/SalesAndGrowth/CustomerDetails/details/billing/BillingTab';


const SnGStack = createStackNavigator();

const SalesAndGrowthStackNavigator = () => (
    <SnGStack.Navigator headerMode="none" initialRouteName={ROUTE_SALES_GROWTH}>
        <SnGStack.Screen
            name={ROUTE_SALES_GROWTH}
            options={{gestureEnabled: false}}
            component={SalesAndGrowthLandingScreen}
        />
        <SnGStack.Screen
            name={ROUTE_CUSTOMER_DETAIL}
            options={{gestureEnabled: false}}
            component={CustomerDetailScreen}
        />

        <SnGStack.Screen
            name = {ROUTE_COUSTOMER_INFO}
            options = {{gestureEnabled: false}}
            component = {CustomerInfo}
        />

        <SnGStack.Screen
            name = {ROUTE_CUSTOMER_DETAILS_TAB}
            options = {{gestureEnabled: false}}
            component = {CustomerDetailTab}
        />

         <SnGStack.Screen
            name = {ROUTE_BILLING_TAB}
            options = {{gestureEnabled: false}}
            component = {BillingTab}
        />

    </SnGStack.Navigator>
);


export default SalesAndGrowthStackNavigator;
