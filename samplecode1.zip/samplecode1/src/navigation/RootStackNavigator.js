import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import splashScreen from '../screens/SplashScreen/SplashScreen';
import {
  ROUTE_AUTH,
  ROUTE_AUTH_SUCCESS,
  ROUTE_HOME,
  ROUTE_STACK_INVOICE,
  ROUTE_SPLASH,
  ROUTE_STACK_ROOT,
  ROUTE_INVOICE_SCREEN,
} from '../resources/constants/navigationConstants';
import AuthStackNavigator from './AuthStackNavigator';
import HomeStackNavigator from './HomeStackNavigator';
import InvoiceStackNavigator from './InvoiceStackNavigator';

const RootStack = createStackNavigator();
const RootStackNavigator = () => {
  return (
    <NavigationContainer>
      <RootStack.Navigator
        name={ROUTE_STACK_ROOT}
        headerMode="none"
        initialRouteName={ROUTE_SPLASH}>
        <RootStack.Screen name={ROUTE_SPLASH} component={splashScreen} />
        <RootStack.Screen
          name={ROUTE_AUTH}
          options={{gestureEnabled: false}}
          component={AuthStackNavigator}
        />
        <RootStack.Screen
          name={ROUTE_AUTH_SUCCESS}
          options={{gestureEnabled: false}}
          component={HomeStackNavigator}
        />
        <RootStack.Screen
          name={ROUTE_INVOICE_SCREEN}
          options={{gestureEnabled: false}}
          component={InvoiceStackNavigator}
        />
      </RootStack.Navigator>
    </NavigationContainer>
  );
};

export default RootStackNavigator;
