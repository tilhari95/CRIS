import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {
  ROUTE_INVOICE_SCREEN,
  ROUTE_ITEM_PROCESSING,
  ROUTE_PAYMENT,
  ROUTE_PAYMENT_SCREEN,
  ROUTE_PAYMENT_SIGNATURE_SCREEN,
  ROUTE_PAYMENT_EMAIL_SCREEN,
  ROUTE_PAYMENT_SURVEY_SCREEN,
  ROUTE_TICKET_PROCESSING_MOBILE_VIEW,
} from '../resources/constants/navigationConstants';
import InvoiceScreen from '../screens/DailyProcessing/SalesAndGrowth/Invoice/InvoiceScreen';
import ItemProcessing from '../screens/DailyProcessing/SalesAndGrowth/TicketProcessing/ScreenRightPanel/ItemProcessing';
import PaymentEmailScreen from '../screens/DailyProcessing/SalesAndGrowth/TicketProcessing/ScreenRightPanel/PaymentEmailScreen';
import PaymentScreen from '../screens/DailyProcessing/SalesAndGrowth/TicketProcessing/ScreenRightPanel/PaymentScreen';
import PaymentSignatureScreen from '../screens/DailyProcessing/SalesAndGrowth/TicketProcessing/ScreenRightPanel/PaymentSignatureScreen';
import PaymentSurveyScreen from '../screens/DailyProcessing/SalesAndGrowth/TicketProcessing/ScreenRightPanel/PaymentSurveyScreen';
import TicketProcessingMobileView from '../screens/DailyProcessing/SalesAndGrowth/TicketProcessing/ScreenRightPanel/TicketProcessingMobileView';

const InvoiceStack = createStackNavigator();

const InvoiceStackNavigator = () => (
  <InvoiceStack.Navigator
    headerMode="none"
    initialRouteName={ROUTE_INVOICE_SCREEN}>
    <InvoiceStack.Screen
      name={ROUTE_INVOICE_SCREEN}
      component={InvoiceScreen}
    />
    <InvoiceStack.Screen
      name={ROUTE_ITEM_PROCESSING}
      component={ItemProcessing}
    />

    <InvoiceStack.Screen
      name={ROUTE_PAYMENT_SCREEN}
      options={{gestureEnabled: false}}
      component={PaymentScreen}
    />

    <InvoiceStack.Screen
      name={ROUTE_PAYMENT_SIGNATURE_SCREEN}
      options={{gestureEnabled: false}}
      component={PaymentSignatureScreen}
    />

    <InvoiceStack.Screen
      name={ROUTE_PAYMENT_EMAIL_SCREEN}
      options={{gestureEnabled: false}}
      component={PaymentEmailScreen}
    />

    <InvoiceStack.Screen
      name={ROUTE_PAYMENT_SURVEY_SCREEN}
      options={{gestureEnabled: false}}
      component={PaymentSurveyScreen}
    />

    <InvoiceStack.Screen
      name={ROUTE_TICKET_PROCESSING_MOBILE_VIEW}
      options={{gestureEnabled: false}}
      component={TicketProcessingMobileView}
    />
  </InvoiceStack.Navigator>
);

export default InvoiceStackNavigator;
