
import {
    ROUTE_HOME,
    ROUTE_COMING_SOON,
    ROUTE_SALES_GROWTH,
    ROUTE_CUSTOMER_DETAIL, ROUTE_SETTINGS, ROUTE_SALES_GROWTH_MENU, ROUTE_CUSTOMER_DETAIL_FROM_HOME
} from '../resources/constants/navigationConstants';
import {createStackNavigator} from '@react-navigation/stack';
import React from 'react';
import HomeScreen from '../screens/HomeScreen/HomeScreen';
import InventoryActivities from '../screens/DailyProcessing/InventoryActivities/InventoryActivites';
import SalesAndGrowthLandingScreen from "../screens/DailyProcessing/SalesAndGrowth/SalesAndGrowthLandingScreen";
import CustomerDetailScreen from "../screens/DailyProcessing/SalesAndGrowth/CustomerDetails/CustomerDetailScreen";
import SettingsScreen from "../screens/SettingsScreen/SettingsScreen";
import SalesAndGrowthStackNavigator from "./SalesAndGrowthStackNavigator";


const HomeStack = createStackNavigator();

const HomeStackNavigator = () => (
  <HomeStack.Navigator headerMode="none" initialRouteName={ROUTE_HOME}>
    <HomeStack.Screen
      name={ROUTE_HOME}
      options={{gestureEnabled: false}}
      component={HomeScreen}
    />
    <HomeStack.Screen
      name={ROUTE_COMING_SOON}
      options={{gestureEnabled: false}}
      component={InventoryActivities}
    />

      <HomeStack.Screen
          name={ROUTE_SALES_GROWTH_MENU}
          options={{gestureEnabled: false}}
          component={SalesAndGrowthStackNavigator}
      />

    {/*<HomeStack.Screen*/}
    {/*  name={ROUTE_SALES_GROWTH}*/}
    {/*  options={{gestureEnabled: false}}*/}
    {/*  component={SalesAndGrowthLandingScreen}*/}
    {/*/>*/}
      <HomeStack.Screen
          name={ROUTE_CUSTOMER_DETAIL_FROM_HOME}
          options={{gestureEnabled: false}}
          component={CustomerDetailScreen}
      />
      <HomeStack.Screen
          name={ROUTE_SETTINGS}
          options={{gestureEnabled: false}}
          component={SettingsScreen}
      />

  </HomeStack.Navigator>
);


export default HomeStackNavigator;
