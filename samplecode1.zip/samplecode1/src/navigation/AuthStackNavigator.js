import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {
    ROUTE_FORGET_PASSWORD, ROUTE_LEARN_MORE,
    ROUTE_LOGIN,
} from '../resources/constants/navigationConstants';
import LoginScreen from "../screens/LoginScreen/LoginScreen";
import ForgetPasswordScreen from "../screens/ForgetPasswordScreen/ForgetPasswordScreen";
import LearnMoreScreen from "../screens/LoginScreen/LearnMoreScreen";

const AuthStack = createStackNavigator();

const AuthStackNavigator = () => (
    <AuthStack.Navigator  headerMode="none" initialRouteName={ROUTE_LOGIN}>
        <AuthStack.Screen name={ROUTE_LOGIN} component={LoginScreen} />
        <AuthStack.Screen name={ROUTE_FORGET_PASSWORD} component={ForgetPasswordScreen} />
        <AuthStack.Screen name={ROUTE_LEARN_MORE} component={LearnMoreScreen} />
    </AuthStack.Navigator>
);

export default AuthStackNavigator;

