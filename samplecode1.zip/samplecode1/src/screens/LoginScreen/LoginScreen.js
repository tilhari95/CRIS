import React, {useEffect, useState} from 'react';
import {ActivityIndicator, StyleSheet, View} from 'react-native';
import {WebView} from 'react-native-webview';
import {connect} from 'react-redux';
import {
  ROUTE_AUTH_SUCCESS,
  ROUTE_FORGET_PASSWORD,
  ROUTE_LEARN_MORE,
} from '../../resources/constants/navigationConstants';
import withLoadingSpinner from '../../components/HOC/withLoadingSpinner';
import GenericButton from '../../components/Buttons/GenericButton';
import GenericTemplate from '../../components/GenericTemplate/GenericTemplate';
import {
  AUTH_STACK_CONTAINER_WIDTH,
  AUTH_STACK_LOGO_HEIGHT,
  AUTH_STACK_LOGO_WIDTH,
  INPUT_FIELD_HEIGHT,
  MODAL_CONTAINER_WIDTH,
  SPACING_10,
  SPACING_15,
  SPACING_30,
  TEXT_SIZE_15,
} from '../../resources/constants/dimensions';
import TextInput from '../../components/FieldInputs/TextInput';
import FastImage from 'react-native-fast-image';
import {mcni360_blue_icon} from '../../resources/images';
import {
  ERROR_COLOR,
  FIELD_BORDER_RADIUS,
  FIELD_BORDER_WIDTH,
  GENERIC_BACKGROUND_COLOR,
  HEADER_FONT_WEIGHT,
  INPUT_FIELD_BORDER_COLOR,
  MODAL_BACKDROP_OPACITY,
  TEXT_FONT_WEIGHT,
} from '../../resources/constants/themeConstant';
import {
  EMAIL_ERROR,
  EMAIL_PLACEHOLDER,
  EMPTY_ERROR,
  FORGET_PASSWORD,
  INVALID_CREDENTIALS,
  LEARN_MORE,
  LOGIN,
  PASSWORD_PLACEHOLDER,
} from '../../resources/constants/stringConstants';
import {Text} from 'react-native-elements';
import {
  default as DeviceInfo,
  isLandscape,
  isTablet,
} from 'react-native-device-info';
import {
  passwordFormatter,
  validateEmail,
  validateRequiredField,
} from '../../utils/validators';
import {
  emailEntered,
  loginRequest,
  resetHttpApiError,
  userBrandRequest, userSideMenuRequest,
} from '../../store/Login/loginAction';
import withHttpsApiErrorHandling from '../../components/HOC/withHttpsApiErrorHandling';
import {
  resetAuthTable,
  checkAndUpdateSessionToken,
  deleteSessionFromAuthTable,
  testing
} from '../../realm/Models/loginModel';

const LoginScreen = (
  {
    navigation,
    setLoadingSpinnerVisibility,
    loginSuccessResponse,
    loginFailError,
    httpError,
    showHttpsApiErrorDialog,
    brandFailError,
    sideMenuDataResponseSuccess,
    brandSuccessResponse,
    loginRequest: _loginRequest,
    emailEntered: _emailEntered,
    resetHttpApiError: _resetHttpApiError,
    userBrandRequest: _userBrandRequest,
    userSideMenuRequest: _userSideMenuRequest,
    ...others
  },
  beta,
) => {
  // console.log(others);
  // console.log(beta);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailErrorMsg, setEmailErrorMsg] = useState('');
  const [passwordErrorMsg, setPasswordErrorMsg] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [secureTextEntry, setSecureTextEntry] = useState(true);
  const [loginFail, setLoginFail] = useState(false);
  const [webViewLoadingIndicator, setWebViewLoadingIndicator] = useState(false);

  useEffect(() => {
    if (
      loginSuccessResponse != null &&
      loginSuccessResponse.responseData.token != null
    ) {
      getCompanyDataRequest();
      //navigateToLandingPage();
    } else if (loginFailError != null) {
      showCredentialError();
    }
  }, [loginSuccessResponse, loginFailError]);

  useEffect(() => {
    if (brandSuccessResponse !== null) {
      getSideMenuDataRequest();
     // getCompanyDataRequest();

    } else if (loginFailError !== null) {
      //logout here
      setLoadingSpinnerVisibility(false);
      console.log('logout here issue in brand data api response');
    }
  }, [brandSuccessResponse, brandFailError]);
  useEffect(() => {
    if (sideMenuDataResponseSuccess !== null) {
      navigateToLandingPage();
     }
    //else if (loginFailError !== null) {
    //   //logout here
    // }
  }, [sideMenuDataResponseSuccess]);



  useEffect(() => {
    if (httpError != null) {
      debugger;
      console.log(httpError);

      _resetHttpApiError();
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(httpError);
     // _resetHttpApiError();
    }
  }, [httpError]);

  const preFillEmailFromLastLogin = () => {
    //TODO
  };

  const onPress = () => {
    //  _resetBrandSuccessResponse();
    // _resetBrandAsyncFromRedux();
    let fieldChecked = true;
    setLoginFail(false);
    if (!validateRequiredField(email)) {
      setEmailErrorMsg(EMPTY_ERROR);
      fieldChecked = false;
    } else if (!validateEmail(email)) {
      setEmailErrorMsg(EMAIL_ERROR);
      fieldChecked = false;
    }

    if (!validateRequiredField(password)) {
      setPasswordErrorMsg(EMPTY_ERROR);
      fieldChecked = false;
    }
    if (fieldChecked) {
      let formattedPassword = passwordFormatter(password);
      //  let encodedPassword = base64.encode(formattedPassword);
      console.log(formattedPassword);
      setLoadingSpinnerVisibility(true);
      _emailEntered(email);
      _loginRequest(email, formattedPassword);
    }
  };

  const rightIconOnPress = () => {
    showPassword
      ? (setShowPassword(false), setSecureTextEntry(true))
      : (setShowPassword(true), setSecureTextEntry(false));
  };

  const onTextInputChange = (input) => {
    input = input.toLowerCase();
    setEmail(input);
    !validateRequiredField(input)
      ? setEmailErrorMsg(EMPTY_ERROR)
      : !validateEmail(input)
      ? setEmailErrorMsg(EMAIL_ERROR)
      : setEmailErrorMsg('');
  };
  const onPasswordInputChange = (input) => {
    setPassword(input);
    !validateRequiredField(input)
      ? setPasswordErrorMsg(EMPTY_ERROR)
      : setPasswordErrorMsg('');
  };

  const showCredentialError = () => {
    setLoadingSpinnerVisibility(false);
    setLoginFail(true);
  };

  const getCompanyDataRequest = () => {
    //setLoadingSpinnerVisibility(false);
    setTimeout(()=>{
      _userBrandRequest(email);
    }, 500)
  }


  const getSideMenuDataRequest = () => {
    _userSideMenuRequest(email);
  }

  const navigateToLandingPage = () => {
    setLoadingSpinnerVisibility(false);
    navigation.replace(ROUTE_AUTH_SUCCESS);
  };

  return (
    <GenericTemplate
      navigation={navigation}
      style={{
        flex: 1,
        flexDirection: 'row',
      }}>
      <View
        style={[
          {},
          DeviceInfo.isTablet() ? {width: '40%'} : {width: '100%'},
          styles.container,
        ]}>
        <View style={{alignItems: 'center'}}>
          <FastImage source={mcni360_blue_icon} style={styles.authStackLogo} />
        </View>
        <Text h3 h3Style={styles.authHeaderStyle}>
          {LOGIN}
        </Text>
        <View
          style={[
            {
              marginTop: SPACING_30,
            },
            DeviceInfo.isTablet()
              ? {width: '80%'}
              : {width: AUTH_STACK_CONTAINER_WIDTH},
          ]}>
          <TextInput
            //value={email}
            placeholder={EMAIL_PLACEHOLDER}
            onChangeText={onTextInputChange}
            errorStyle={{color: ERROR_COLOR}}
            errorMessage={emailErrorMsg}
            containerStyle={{paddingLeft: 0, paddingRight: 0}}
            inputContainerStyle={styles.inputContainerStyle}
          />
          <TextInput
            placeholder={PASSWORD_PLACEHOLDER}
            rightIconType={showPassword ? 'eye-off-outline' : 'eye-off'}
            rightIconOnPress={rightIconOnPress}
            onChangeText={onPasswordInputChange}
            secureTextEntry={secureTextEntry}
            errorStyle={{color: ERROR_COLOR}}
            errorMessage={passwordErrorMsg}
            containerStyle={{paddingLeft: 0, paddingRight: 0}}
            inputContainerStyle={styles.inputContainerStyle}
          />
          <GenericButton
            title={LOGIN}
            onPress={onPress}
            titleStyle={{fontWeight: HEADER_FONT_WEIGHT}}
            //containerStyle={[ DeviceInfo.isTablet() ? {width: '100%'}: {width: AUTH_STACK_CONTAINER_WIDTH}]}
          />
          <View style={{marginBottom: 10}}>
            <Text
              h4
              h4Style={styles.ForgetPassStyle}
              onPress={() => navigation.push(ROUTE_FORGET_PASSWORD)}>
              {FORGET_PASSWORD}?
            </Text>
          </View>
          {!DeviceInfo.isTablet() ? (
            <View style={{alignSelf: 'center'}}>
              <GenericButton
                type={'clear'}
                title={LEARN_MORE}
                titleStyle={{fontWeight: HEADER_FONT_WEIGHT}}
                containerStyle={[{width: '50%'}]}
                //onPress={() => testing()}
                onPress={() => navigation.push(ROUTE_LEARN_MORE)}
                //onPress={() => showHttpsApiErrorDialog({errorType: "request_issue"})}
                //onPress={()=> checkAndUpdateSessionToken('suyasht@292asd.com', 'as_suyash_____test')}
              />
            </View>
          ) : null}
          <View>
            {loginFail ? (
              <Text h4 h4Style={styles.errorStyle}>
                {INVALID_CREDENTIALS}
              </Text>
            ) : null}
          </View>
        </View>
      </View>
      {DeviceInfo.isTablet() ? (
        <View
          style={{
            // backgroundColor: 'pink',
            //  flex: 1
            width: '60%',
          }}>
          <WebView
            source={{
              uri: 'https://mcni360.com/Home/Index',
            }}
            style={{}}
            cacheEnabled
            onLoadStart={() => setWebViewLoadingIndicator(true)}
            onLoad={() => setWebViewLoadingIndicator(false)}
            renderError={(errorName) => {
              setWebViewLoadingIndicator(false);
            }}
            containerStyle={{}}
          />
          {webViewLoadingIndicator ? (
            <ActivityIndicator
              style={{position: 'absolute', top: '50%', left: '50%'}}
              size="large"
            />
          ) : null}
        </View>
      ) : null}
    </GenericTemplate>
    // <GenericTemplate style={styles.container}>
    //     <Text>login screen ok...</Text>
    //     <GenericButton onPress={() => setLoadingSpinnerVisibility(true)}/>
    // </GenericTemplate>
  );
};

const styles = StyleSheet.create({
  authStackLogo: {
    width: AUTH_STACK_LOGO_WIDTH,
    height: AUTH_STACK_LOGO_HEIGHT,
    alignItems: 'center',
  },
  container: {
    //  justifyContent: 'center',
    alignItems: 'center',
  },
  inputContainerStyle: {
    borderBottomWidth: FIELD_BORDER_WIDTH,
    borderWidth: FIELD_BORDER_WIDTH,
    borderStyle: 'solid',
    borderColor: INPUT_FIELD_BORDER_COLOR,
    height: INPUT_FIELD_HEIGHT,
    padding: SPACING_10,
    // width:AUTH_STACK_CONTAINER_WIDTH,
    borderRadius: FIELD_BORDER_RADIUS,
  },
  authHeaderStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    textAlign: 'center',
    marginTop: SPACING_30,
  },
  ForgetPassStyle: {
    fontWeight: TEXT_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'right',
    textDecorationLine: 'underline',
    marginTop: SPACING_15,
  },
  errorStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'center',
    color: ERROR_COLOR,
    marginTop: SPACING_30,
  },
  overlay: {
    backgroundColor: GENERIC_BACKGROUND_COLOR,
    opacity: MODAL_BACKDROP_OPACITY,
  },
  overlayModalStyle: {
    borderWidth: FIELD_BORDER_WIDTH,
    borderColor: INPUT_FIELD_BORDER_COLOR,
    width: MODAL_CONTAINER_WIDTH,
  },
  modalErrorStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'center',
    //color:ERROR_COLOR,
    marginBottom: SPACING_30,
  },
});
const mapStateToProps = (reduxStore) => {
  return {
    passwordText: reduxStore.login.password,
    emailText: reduxStore.login.email,
    loginSuccessResponse: reduxStore.login.loginSuccessResponse,
    loginFailError: reduxStore.login.loginFailError,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    brandFailError:reduxStore.login.brandFailError,
    httpError: reduxStore.login.httpError,
    sideMenuDataResponseSuccess:reduxStore.login.sideMenuDataResponseSuccess
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {emailEntered, loginRequest, resetHttpApiError, userBrandRequest, userSideMenuRequest})(
      LoginScreen,
    ),
  ),
);
