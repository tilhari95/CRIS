import React, {useEffect} from 'react';
import {StyleSheet, View, Text} from 'react-native';
import {SPLASH_LOGO_HEIGHT, SPLASH_LOGO_WIDTH} from "../../resources/constants/dimensions";
import {WebView} from "react-native-webview";
import GenericTemplate from "../../components/GenericTemplate/GenericTemplate";

const LearnMoreScreen = ({navigation, routes}, prototype) => {
    return(
        <GenericTemplate navigation={navigation}
                         style={{
                             backgroundColor: 'yellow',
                             flex:1,
                             flexDirection : 'column'
                         }}
        >
        <View style={styles.container}>
            <WebView
                source={{
                    uri: 'https://mcni360.com/Home/Index'
                }}
               // style={{ height: '90%'}}
                containerStyle={{height: '80%'}}
            />
        </View>
        </GenericTemplate>
    );
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: 'red',
        width: '100%',
        height: '100%'
       // flex: 1,
        //justifyContent: 'center',
        //alignItems: 'center',
    },
    logo: {
        width: SPLASH_LOGO_WIDTH,
        height: SPLASH_LOGO_HEIGHT,
    },
});


export default LearnMoreScreen;

