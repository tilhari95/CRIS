import {
    APP_BLUE_COLOR,
    BLACK_COLOR,
    ERROR_COLOR,
    FIELD_BORDER_WIDTH,
    GENERIC_BACKGROUND_COLOR, HEADER_FONT_WEIGHT,
    INPUT_FIELD_BORDER_COLOR,
    MODAL_BACKDROP_OPACITY,
} from '../../../resources/constants/themeConstant';
import {Keyboard, TouchableHighlight, TouchableOpacity} from 'react-native';
import {SwipeListView} from 'react-native-swipe-list-view';
import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  View,
  TouchableWithoutFeedback,
  FlatList,
  RefreshControl,
} from 'react-native';
import {
    AUTH_STACK_CONTAINER_WIDTH,
    CONTAINER_HEIGHT_300,
    CONTAINER_HEIGHT_400,
    INPUT_FIELD_HEIGHT, MODAL_CONTAINER_WIDTH,
    SEARCH_HEIGHT, SPACING_10,
    SPACING_30,
    SPLASH_LOGO_HEIGHT,
    SPLASH_LOGO_WIDTH,
    TEXT_SIZE_10, TEXT_SIZE_15,
    TEXT_SIZE_8,
} from '../../../resources/constants/dimensions';
import {GenericButton, TextInput} from '../../../components';
import withLoadingSpinner from '../../../components/HOC/withLoadingSpinner';
import withHttpsApiErrorHandling from '../../../components/HOC/withHttpsApiErrorHandling';
import {connect} from 'react-redux';

import {validateRequiredField} from '../../../utils/validators';
import {Overlay, SearchBar, Text} from 'react-native-elements';
import {
    customerSearchRouteStopRequest,
    resetRouteStopHttpApiError,
    searchCustomerRouteStopApiReset,
    addRouteStopRequest,
    resetAddRouteStopSuccess, deleteRouteRequest, routeStopApiRequest, resetDeleteRouteStopSuccess,
} from '../../../store/Route/routeAction';
import {
    CANCEL,
    EMAIL_PLACEHOLDER,
    emptyUUID, OKAY,
    SAVE,
    SEARCH_PLACEHOLDER,
} from '../../../resources/constants/stringConstants';

import Toast from 'react-native-simple-toast';
import RoutesStopListTemplate from '../../../components/GenericTemplate/RouteStopListTemplate';
import RouteStopSearchTemplate from '../../../components/GenericTemplate/RouteStopSearchTemplate';

const RouteStopFlipView = ({
  navigation,
  routeStopList,
  currentRouteId,
  brandSuccessResponse,
  routeStopCustomerSearchSuccess,
  httpRouteStopApiError,
  setLoadingSpinnerVisibility,
  showHttpsApiErrorDialog,
  addRouteStopSuccess,
                               deleteRouteSuccess,
  customerSearchRouteStopRequest: _customerSearchRouteStopRequest,
  resetRouteStopHttpApiError: _resetRouteStopHttpApiError,
  searchCustomerRouteStopApiReset: _searchCustomerRouteStopApiReset,
  addRouteStopRequest: _addRouteStopRequest,
  resetAddRouteStopSuccess: _resetAddRouteStopSuccess,
                               deleteRouteRequest:_deleteRouteRequest,
                               routeStopApiRequest:_routeStopApiRequest,
                               resetDeleteRouteStopSuccess:_resetDeleteRouteStopSuccess

}) => {
  const [
    addRouteStopModalVisibility,
    setAddRouteStopModalVisibility,
  ] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showSearchLoading, setShowSearchLoading] = useState(false);
  const [routeStopSearchResultList, setRouteStopSearchResultList] = useState(
    [],
  );
  const [currentAddSeq, setCurrentAddSeq] = useState(0);
  const [routeStopListUI, setRouteStopListUI] = useState([]);
  const [deleteCnfModalVisibility, setDeleteCnfModalVisibility ] = useState({visibility: false, data:null})

  useEffect(() => {
    setLoadingSpinnerVisibility(false);
    setRouteStopListUI(routeStopList);
  }, [routeStopList]);

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      debugger;
      console.log(searchTerm);
      if (searchTerm !== '') {
        let filteredData = searchLogic(searchTerm);
        //setFilteredArray(filteredData);
      } else {
      }
      //debugger;
      // Send Axios request here
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm]);

    useEffect(() => {
        if (validateRequiredField(deleteRouteSuccess)) {
            callRouteStopRefresh();
            _resetDeleteRouteStopSuccess();
        }
    }, [deleteRouteSuccess]);

  useEffect(() => {
    if (validateRequiredField(routeStopCustomerSearchSuccess)) {
      console.log('customer searched list', routeStopCustomerSearchSuccess);
      setRouteStopSearchResultList(routeStopCustomerSearchSuccess);
      setShowSearchLoading(false);
      _searchCustomerRouteStopApiReset();
    }
  }, [routeStopCustomerSearchSuccess]);

  useEffect(() => {
    if (validateRequiredField(addRouteStopSuccess)) {
      console.log('updated route stop after adding new', addRouteStopSuccess);
      setRouteStopListUI(addRouteStopSuccess);
      setLoadingSpinnerVisibility(false);
      addRouteModalCancelPress();
      _resetAddRouteStopSuccess();
      //setRouteStopSearchResultList([]);
    }
  }, [addRouteStopSuccess]);

  useEffect(() => {
    if (httpRouteStopApiError !== null) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(httpRouteStopApiError);
      addRouteModalCancelPress();
      _resetRouteStopHttpApiError();
    }
  }, [httpRouteStopApiError]);

  const callRouteStopRefresh =() =>{
      let routeStopObj =  {
          Id: currentRouteId
      }
      _routeStopApiRequest(routeStopObj);
  }

  const updateSearch = (search) => {
    setSearchTerm(search);
  };

  const searchLogic = (searchKeyword) => {
    console.log('searchLogic', searchKeyword);
    const searchText = searchKeyword.toLowerCase();
    if (searchText.length > 0) {
      setShowSearchLoading(true);
      _customerSearchRouteStopRequest(
        brandSuccessResponse.CompanyId,
        brandSuccessResponse.DeviceId,
        0,
        searchText,
      );
    }
  };

  const onSearchClear = () => {
    setRouteStopSearchResultList([]);
    setSearchTerm('');
    setShowSearchLoading(false);
  };

  const onAddPress = (item) => {
    console.log(item);
    let thisSeq = currentAddSeq + 1;
    let routeStopToAdd = {
      Id: emptyUUID,
      RouteId: currentRouteId,
      CompanyId: brandSuccessResponse.CompanyId,
      Sequence: thisSeq + '',
      Location: emptyUUID,
      CustomerId: item.CustomerId,
    };
    console.log('hit api with ', routeStopToAdd);
    setAddRouteStopModalVisibility(false);
    setLoadingSpinnerVisibility(true);
    _addRouteStopRequest(routeStopToAdd);
  };

  const onSearchRouteStopPress = (data) => {
    console.log(data);
    setCurrentAddSeq(data.item.Sequence);
    setAddRouteStopModalVisibility(true);
  };

  const addRouteModalCancelPress = () => {
    setAddRouteStopModalVisibility(false);
    setCurrentAddSeq(1);
    setRouteStopSearchResultList([]);
    setSearchTerm('');
  };

  const onRouteStopDeletePress = (data) =>{
      let deleteObj ={
          Id: data.item.Id
      }
      setDeleteCnfModalVisibility({visibility: false, data:null})
      setLoadingSpinnerVisibility(true);
      _deleteRouteRequest(deleteObj);
  }

  return (
    <View style={{height: '100%', width: '100%'}}>
        {routeStopListUI.length > 0 ? (
          <SwipeListView
            style={{}}
            data={routeStopListUI}
            keyExtractor={(item) => item.Id}
            renderItem={({item, index, separators}) => (
              <TouchableOpacity
                activeOpacity={1}
                // onPress={() => {Toast.showWithGravity("Work in progress", Toast.SHORT, Toast.CENTER);}}
                onPress={() => {
                  // setIsFlipped(false)
                }}
                style={{backgroundColor: 'white'}}
                underlayColor={'#AAA'}>
                <View>
                  <RoutesStopListTemplate itemData={item} />
                </View>
              </TouchableOpacity>
            )}
            renderHiddenItem={(data, rowMap, third) => (
              <View style={styles.rowBack}>
                <GenericButton
                  //  title="Edit"
                  //titleStyle={{fontSize:10}}
                  //containerStyle={{backgroundColor: 'green'}}
                  icon={'delete'}
                  size={20}
                  iconType={'MaterialIcons'}
                  iconColor={APP_BLUE_COLOR}
                  type={'clear'}
                  onPress={() => {
                      setDeleteCnfModalVisibility({visibility: true, data:data});
                  }}

                />

                <GenericButton
                  //  title="Edit"
                  //titleStyle={{fontSize:10}}
                  containerStyle={{alignItems: 'flex-end'}}
                  icon={'playlist-add'}
                  size={20}
                  iconType={'MaterialIcons'}
                  iconColor={APP_BLUE_COLOR}
                  type={'clear'}
                  onPress={() => {
                    onSearchRouteStopPress(data, rowMap);
                  }}
                  // onPress={() => {setAddModalVisibility(true)}}
                />
              </View>
            )}
            rightOpenValue={-75}
          />
        ) : (
           <View style={{ justifyContent: 'center', alignItems: 'center', flex: 0.75}}>
               <Text style={{marginBottom: SPACING_10}}> No Route Stops.</Text>
               <GenericButton
                   title="Click to add Route Stops"
                   //type={'clear'}
                   onPress={() => {
                       setAddRouteStopModalVisibility(true);
                   }}
                   //onPress={onModalOpenPress}
               />
           </View>

        )}
      <Overlay
        backdropStyle={styles.overlay}
        isVisible={addRouteStopModalVisibility}
        overlayStyle={styles.overlayAddModalStyle}>
        <View style={{height: CONTAINER_HEIGHT_300}}>
          <View style={{height: '10%', flexDirection: 'row'}}>
            <View style={{width: '28%'}}>
              {/*<GenericButton*/}
              {/*    title={CANCEL}*/}
              {/*    titleStyle={{fontSize:15}}*/}
              {/*    type={'clear'}*/}
              {/*    onPress={() => {setAddRouteStopModalVisibility(false)}}*/}
              {/*    //onPress={onModalCancelPress}*/}
              {/*></GenericButton>*/}
            </View>
            <View
              style={{
                width: '44%',
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              <Text h5>ADD ROUTE STOP</Text>
            </View>
            <View style={{width: '28%'}}>
              <GenericButton
                title={CANCEL}
                titleStyle={{fontSize: 15}}
                type={'clear'}
                onPress={() => {
                  addRouteModalCancelPress();
                }}
                //onPress={onModalCancelPress}
              ></GenericButton>
            </View>
          </View>
          <SearchBar
            containerStyle={{
              //height:'10%',
              padding: 2,
            }}
            inputContainerStyle={{
              backgroundColor: GENERIC_BACKGROUND_COLOR,
              padding: 0,
              margin: 0,
              height: SEARCH_HEIGHT,
            }}
            //containerStyle={{ height: '100%', justifyContent:'center'}}
            // inputContainerStyle={{backgroundColor: GENERIC_BACKGROUND_COLOR}}
            placeholder={SEARCH_PLACEHOLDER}
            inputStyle={{color: BLACK_COLOR, fontSize: TEXT_SIZE_10}}
            onChangeText={updateSearch}
            value={searchTerm}
            onClear={onSearchClear}
            showLoading={showSearchLoading}
            lightTheme
          />
          {routeStopSearchResultList.length > 0 ? (
            <FlatList
              data={routeStopSearchResultList}
              renderItem={({item, index, separators}) => (
                <TouchableWithoutFeedback
                  onPress={() => {
                    Toast.showWithGravity(
                      'Work in progress',
                      Toast.SHORT,
                      Toast.CENTER,
                    );
                  }}
                  //    onPress={() => navigation.navigate(ROUTE_CUSTOMER_DETAIL)}
                >
                  <View>
                    <RouteStopSearchTemplate
                      itemData={item}
                      onAddPress={() => onAddPress(item)}
                    />
                  </View>
                </TouchableWithoutFeedback>
              )}
            />
          ) : (
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                height: 50,
              }}>
              <Text>No results to show.</Text>
            </View>
          )}
        </View>
      </Overlay>
        <Overlay
            backdropStyle={styles.overlay}
            isVisible={deleteCnfModalVisibility.visibility}
            overlayStyle={styles.overlayModalStyle}>
            <View>
                <Text h3 h3Style={styles.modalTextStyle}>
                    Are you sure want to delete this route stop?
                </Text>
                <View style={{flexDirection:'row', justifyContent:'space-between'}}>
                <GenericButton
                    title={CANCEL}
                    type={'clear'}
                    onPress={() => setDeleteCnfModalVisibility({visibility:false, data:null})}></GenericButton>
                <GenericButton
                    title={OKAY}
                    type={'clear'}
                    onPress={()=>{onRouteStopDeletePress(deleteCnfModalVisibility.data)}}></GenericButton>
            </View>
            </View>
        </Overlay>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  overlay: {
    backgroundColor: GENERIC_BACKGROUND_COLOR,
    opacity: MODAL_BACKDROP_OPACITY,
  },
  overlayAddModalStyle: {
    borderWidth: FIELD_BORDER_WIDTH,
    borderColor: INPUT_FIELD_BORDER_COLOR,
    width: AUTH_STACK_CONTAINER_WIDTH,
    //height:400
  },
    overlayModalStyle: {
        borderWidth: FIELD_BORDER_WIDTH,
        borderColor: INPUT_FIELD_BORDER_COLOR,
        width: MODAL_CONTAINER_WIDTH,
    },
    modalTextStyle: {
        fontWeight: HEADER_FONT_WEIGHT,
        fontSize: TEXT_SIZE_15,
        textAlign: 'center',
        //color:ERROR_COLOR,
        marginBottom: SPACING_30,
    },
  rowBack: {
    alignItems: 'center',
    //backgroundColor: '#DDD',
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingLeft: 15,
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    routeStopCustomerSearchSuccess:
      reduxStore.routeStop.routeStopCustomerSearchSuccess,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    httpRouteStopApiError: reduxStore.routeStop.httpRouteStopApiError,
    addRouteStopSuccess: reduxStore.routeStop.addRouteStopSuccess,
    deleteRouteSuccess: reduxStore.routeStop.deleteRouteSuccess,
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      customerSearchRouteStopRequest,
      resetRouteStopHttpApiError,
      searchCustomerRouteStopApiReset,
      addRouteStopRequest,
      resetAddRouteStopSuccess,
        deleteRouteRequest,
        routeStopApiRequest,
        resetDeleteRouteStopSuccess
    })(RouteStopFlipView),
  ),
);
