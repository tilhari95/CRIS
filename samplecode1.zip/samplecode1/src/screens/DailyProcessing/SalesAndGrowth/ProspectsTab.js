import CustomerListTemplate from '../../../components/GenericTemplate/CustomerListTemplate';
import React, {useEffect, useState} from 'react';
import {
    StyleSheet,
    View,
    //Text,
    ScrollView,
    TouchableWithoutFeedback,
    FlatList, RefreshControl, Keyboard, KeyboardAvoidingView, Platform,
} from 'react-native';
import {mcni360_blue_icon} from '../../../resources/images';
import FastImage from 'react-native-fast-image';
import {
    AUTH_STACK_CONTAINER_WIDTH,
    CONTAINER_HEIGHT_300, CONTAINER_HEIGHT_400, DEVICE_HEIGHT, INPUT_FIELD_HEIGHT, SPACING_10, SPACING_30, SPACING_5,
    SPLASH_LOGO_HEIGHT,
    SPLASH_LOGO_WIDTH, TEXT_SIZE_12,
} from '../../../resources/constants/dimensions';
import {default as DeviceInfo} from 'react-native-device-info';
import {GenericButton, TextInput} from '../../../components';
import {ROUTE_CUSTOMER_DETAIL} from '../../../resources/constants/navigationConstants';
import withLoadingSpinner from '../../../components/HOC/withLoadingSpinner';
import withHttpsApiErrorHandling from '../../../components/HOC/withHttpsApiErrorHandling';
import {connect} from 'react-redux';

import {validateEmail, validateFloat, validatePhone, validateRequiredField} from '../../../utils/validators';
import {getCustomersListFromRealM, resetCustomerTable} from '../../../realm/Models/customerModel';
import store from "../../../store/store";
import {SET_CUSTOMER_REDUX_INITIAL_STATE} from "../../../resources/constants/storeConstants";
import {
    prospectListRequest,
    prospectListToRedux,
    prospectListRequestOnScroll,
    resetProspectOnScrollRequest,
    resetProspectHttpApiError,
    resetProspectRedux,
    prospectStageRequest,
    addEditProspectRequest,
    resetProspectAddEditSuccess,
    prospectHeaderListRequest, decisionMakerApiRequest, resetDecisionMakerState, resetProspectHeaderState,
} from "../../../store/Prospect/prospectAction";
import {getProspectListFromRealM, resetProspectTable, updateProspectInRealM} from "../../../realm/Models/prospectModel";
import ProspectListTemplate from "../../../components/GenericTemplate/ProspectListTemplate";
import Toast from "react-native-simple-toast";
import {
    AMOUNT_ERROR,
    CANCEL, EMAIL_ERROR, EMPTY_ERROR, emptyUUID,
    FORM_ADDRESS,
    FORM_CITY, FORM_DECISION_MAKER, FORM_EMAIL, FORM_ESTIMATE_SALES,
    FORM_NAME, FORM_PHONE,
    FORM_STATE, FORM_ZIP, PHONE_ERROR,
    SAVE
} from "../../../resources/constants/stringConstants";
import DropDownPicker from "react-native-dropdown-picker";
import {Overlay, Text} from "react-native-elements";
import {
    ERROR_COLOR,
    FIELD_BORDER_WIDTH,
    GENERIC_BACKGROUND_COLOR, INPUT_FIELD_BORDER_COLOR,
    MODAL_BACKDROP_OPACITY
} from "../../../resources/constants/themeConstant";
import {updateRouteInRealM} from "../../../realm/Models/routeModel";

const ProspectTab = (
    {
        navigation,
        showHttpsApiErrorDialog,
        setLoadingSpinnerVisibility,
        onSearchProspectEdit,
        brandSuccessResponse,
        prospectApiSuccessResponse,
        prospectOnScrollApiSuccess,
        prospectApiHttpError,
        prospectSearchResultList,
        prospectStage,
        prospectAddEditSuccess,
        decisionMakerSuccess,
        prospectHeaderListSuccess,
        prospectListRequest: _prospectListRequest,
        prospectListToRedux: _prospectListToRedux,
        prospectListRequestOnScroll: _prospectListRequestOnScroll,
        resetProspectOnScrollRequest: _resetProspectOnScrollRequest,
        resetProspectHttpApiError: _resetProspectHttpApiError,
        resetProspectRedux: _resetProspectRedux,
        prospectStageRequest:_prospectStageRequest,
        addEditProspectRequest:_addEditProspectRequest,
        resetProspectAddEditSuccess:_resetProspectAddEditSuccess,
        prospectHeaderListRequest:_prospectHeaderListRequest,
        decisionMakerApiRequest:_decisionMakerApiRequest,
        resetProspectHeaderState:_resetProspectHeaderState,
        resetDecisionMakerState:_resetDecisionMakerState
    },
    prototype,
) => {
    const [prospectList, setProspectList] = useState([]);
    const [onScrollBoolean, setOnScrollBoolean] = useState(true);
    const [onRefreshBoolean, setOnRefreshBoolean] =useState(false);
    const [addModalVisibility, setAddModalVisibility] = useState(false);
    const [saveButtonDisable, setSaveButtonDisable] = useState(true);
    const [addEditModalData, setAddEditModalData] = useState({mode:0, companyName:'', address:'', city:'', state:'',
    zip:'', phone:'', emailAddress:'',decisionMaker:'',estimatedAnnualSales:'0', currentStage:'', stageName:'', approachProcessList:null });
    const [stageList, setStageList]= useState({ defaultList:[], stageBoxList:[], index: 0, defaultValue: null});
    const [formError, setFormError]=useState({emailError:'', addressError:'', companyNameError:'', amountError: '', phoneError:''});
    const [currentEditItem, setCurrentEditItem] = useState({itemIndex:null, itemData:{}});
    const [prospectHeaderList, setProspectHeaderList] = useState([]);
    const [decisionMakerList, setDecisionMakerList] = useState({List: [], lengthOfList: -1 });
    let dropDownStageController, dropDownDecisionMakerController, dropDownProspectHeaderStepController;


    useEffect(() => {
        if (validateRequiredField(prospectApiSuccessResponse)) {
            setLoadingSpinnerVisibility(false);
            updateProspectListOnUI(prospectApiSuccessResponse, false);
        } else {
            getProspectListFromLocalDB(0);
        }
    }, [prospectApiSuccessResponse]);

    useEffect(() => {
        if (prospectSearchResultList.length > 0) {
            setOnScrollBoolean(false);
            updateProspectListOnUI(prospectSearchResultList, false);
        } else {
            setOnScrollBoolean(true);
            updateProspectListOnUI(prospectApiSuccessResponse, false);
        }
    }, [prospectSearchResultList]);

    useEffect(() => {
        if (validateRequiredField(prospectStage) && (stageList.defaultList == 0)) {
            setStageDropDownList(prospectStage);
        }else if(prospectStage === null){
            callProspectStageApi();
        }
        else{

        }
    }, [prospectStage]);


    useEffect(() => {
        //console.log('fucking bitch',decisionMakerSuccess);
        if (decisionMakerSuccess!== null) {
            setLoadingSpinnerVisibility(false);
            setDecisionMakerDropDownList(decisionMakerSuccess);
            //setAddModalVisibility(true);
        }
    }, [decisionMakerSuccess]);

    useEffect(() => {
        if (validateRequiredField(prospectHeaderListSuccess)) {
            setHeaderDropDownList(prospectHeaderListSuccess);
            if(addEditModalData.mode === 0){
                setLoadingSpinnerVisibility(false);
                setAddModalVisibility(true);
            }
            else{
                callDecisionMakerApi(currentEditItem.itemData.Id);
            }
        }
    }, [prospectHeaderListSuccess]);

    useEffect(() => {
        if (prospectAddEditSuccess !== null) {
            setLoadingSpinnerVisibility(false);
            updateLocalUI();
            _resetProspectAddEditSuccess();
        }
    }, [prospectAddEditSuccess]);




    useEffect(() => {
        if (validateRequiredField(prospectOnScrollApiSuccess)) {
            console.log(prospectOnScrollApiSuccess.length);
            updateProspectListOnUI(prospectOnScrollApiSuccess, true);
            setOnScrollBoolean(true);
            _resetProspectOnScrollRequest();
        }
    }, [prospectOnScrollApiSuccess]);


    useEffect(() => {
        if (prospectApiHttpError !== null) {
        debugger;
            setLoadingSpinnerVisibility(false);
            showHttpsApiErrorDialog(prospectApiHttpError);
            setAddEditModalData({mode:0, companyName:'', address:'', city:'', state:'',
                zip:'', phone:'', emailAddress:'',decisionMaker:'',
                estimatedAnnualSales:'0', currentStage:'', stageName:'', approachProcessList:null });
            let defaultL =stageList.defaultList;
            setStageList({ ...stageList, stageBoxList:defaultL, index: 0, defaultValue: null});
            setCurrentEditItem({itemIndex:null, itemData:{}});
            setDecisionMakerList({List: [], lengthOfList: -1 });
            _resetProspectHttpApiError();
        }
    }, [prospectApiHttpError]);


    const callDecisionMakerApi = (prospectId) =>{
        setLoadingSpinnerVisibility(true);
        _decisionMakerApiRequest(prospectId);
    }

    const callProspectStageApi = () => {
        //setLoadingSpinnerVisibility(true);
        _prospectStageRequest(brandSuccessResponse.CompanyId);
    }

    const setStageDropDownList =(prospectStage) =>{
        let sortedStageList =prospectStage.sort(function(a, b) {
            return a.Sequence - b.Sequence;
        });
        let stageListArray=[]
        sortedStageList.forEach(stage =>{
            let obj={};
            obj["label"] = stage.ProcessName;
            obj["disabled"] = false;
            obj["value"] = stage.ProcessId;
            stageListArray.push(obj);
        });
        console.log('sorted listed -->',stageListArray);
        setStageList({...stageList, defaultList:stageListArray, stageBoxList: stageListArray, index:stageListArray.length});
        //setDefaultStageList(stageListArray);
    }

    const setHeaderDropDownList =(prospectHeaderList) =>{
        let headerListArray=[];
        prospectHeaderList.forEach(step =>{
            let obj={};
            obj["label"] = step.ProcessName;
            obj["value"] = step.ProcessListId;
            headerListArray.push(obj);
        });
        console.log('sorted listed -->',headerListArray);
        setProspectHeaderList(headerListArray);
        _resetProspectHeaderState();
    }

    const setDecisionMakerDropDownList =(decisionMakerList) =>{
        let dmArray=[];
        decisionMakerList.forEach(step =>{
            let obj={};
            obj["label"] = step.Name +" (Decision Maker)";
            obj["value"] = step.Id;
            dmArray.push(obj);
        });
        console.log('deciosn maker listed -->',dmArray);
        setDecisionMakerList({List: dmArray, lengthOfList: dmArray.length });
        setAddModalVisibility(true);
        _resetDecisionMakerState();
    }


    const updateLocalUI =() =>{
        if(addEditModalData.mode === 1){
            let indexToUpdate=currentEditItem.itemIndex;
            prospectList[indexToUpdate].CompanyName=addEditModalData.companyName;
            prospectList[indexToUpdate].Address=addEditModalData.address;
            prospectList[indexToUpdate].City=addEditModalData.city;
            prospectList[indexToUpdate].State=addEditModalData.state;
            prospectList[indexToUpdate].Zip=addEditModalData.zip;
            prospectList[indexToUpdate].Phone=addEditModalData.phone;
            prospectList[indexToUpdate].EmailAddress=addEditModalData.emailAddress;
            prospectList[indexToUpdate].DecisionMaker=addEditModalData.decisionMaker;
            prospectList[indexToUpdate].EstimatedAnnualSales=addEditModalData.estimatedAnnualSales;
            prospectList[indexToUpdate].CurrentStage=addEditModalData.currentStage;
            prospectList[indexToUpdate].Stage=addEditModalData.stageName;
            prospectList[indexToUpdate].ApproachProcessList=addEditModalData.approachProcessList;


            updateProspectInRealM(prospectList[indexToUpdate]);
            if(prospectSearchResultList.length > 0){
                onSearchProspectEdit(2, false);
                _resetProspectRedux();
            }
            setTimeout(()=>{Toast.showWithGravity("Prospect edited successfully.", Toast.SHORT, Toast.CENTER);},
                500);

        }
        else{
            // in case of add
            Toast.showWithGravity("Prospect added successfully. Refreshing List.", Toast.SHORT, Toast.CENTER);
            setTimeout(()=>{callProspectDataRefresh()},
                500)
        }
        setAddEditModalData({mode:0, companyName:'', address:'', city:'', state:'',
            zip:'', phone:'', emailAddress:'',decisionMaker:'',estimatedAnnualSales:'0', currentStage:'' , stageName:'',
        approachProcessList:null});
        let defaultL =stageList.defaultList;
        setStageList({ ...stageList, stageBoxList:defaultL, index: 0, defaultValue: null});
        setCurrentEditItem({itemIndex:null, itemData:{}})

    }


    const getProspectListFromLocalDB= async (offset) => {
        let prospListFromRealM = await getProspectListFromRealM(offset);
        console.log(
            'prospect list on tab page inside func',
            prospListFromRealM,
        );
        if (validateRequiredField(prospListFromRealM) && prospListFromRealM.length > 0) {
            console.log(prospListFromRealM.length);
            if(offset === 0){
                _prospectListToRedux(prospListFromRealM);
            }
            else{
                updateProspectListOnUI(prospListFromRealM, true);
            }
            setOnScrollBoolean(true);

        }
        else {
            if(offset === 0){
                setLoadingSpinnerVisibility(true);
                _prospectListRequest(brandSuccessResponse.ERPRepCode, 0, '');
            }
            else{
                _prospectListRequestOnScroll(brandSuccessResponse.ERPRepCode, offset);

            }

        }
    };

    const updateProspectListOnUI = (prospect, toBeConcat) => {
        if (toBeConcat) {
            let previousList = prospectList;
            let newList = previousList.concat(prospect);
            setProspectList(newList);
        } else {
            setProspectList(prospect);
        }
    };

    const callProspectPagingOnScroll = () => {
        let currentListLength = prospectList.length;
        if (onScrollBoolean && currentListLength>49) {
            console.log(currentListLength);
            setOnScrollBoolean(false);
            getProspectListFromLocalDB(currentListLength);
            // _customerListRequestOnScroll(brandSuccessResponse.CompanyId, brandSuccessResponse.DeviceId, currentListLength);
        }
    };

    const callProspectDataRefresh = async () => {
        setOnRefreshBoolean(true);
        await resetProspectTable();
        _resetProspectRedux();
        setOnRefreshBoolean(false);
    }

    const onModalOpenPress = () =>{
        setSaveButtonDisable(true);
        if(prospectHeaderList.length === 0){
            setLoadingSpinnerVisibility(true);
            _prospectHeaderListRequest(brandSuccessResponse.CompanyId);
        }else{
            setAddModalVisibility(true);
        }
    }
    const onModalCancelPress = () => {
        setAddModalVisibility(false);
        setAddEditModalData({mode:0, companyName:'', address:'', city:'', state:'',
            zip:'', phone:'', emailAddress:'',decisionMaker:'',estimatedAnnualSales:'0', currentStage:'', stageName:'',
            approachProcessList:null });
        let defaultL =stageList.defaultList;
        setStageList({ ...stageList, stageBoxList:defaultL, index: 0, defaultValue: null});
        setCurrentEditItem({itemIndex:null, itemData:{}})
        //setSaveButtonDisable(true);
        //setAddEditModalData({mode:0, name:'', description:'', every:'', frequency:''})
        //setFreqList({freqBoxList:[{label: 'N/A', value: '0'}], index:0, defaultValue:"0"});
    }
    const closeDropDownOnFocus= () =>{
        dropDownProspectHeaderStepController.close();
        dropDownStageController.close();
        dropDownDecisionMakerController.close();
    }


    const textFieldChange = (value, type) => {
        // console.log(type +  "   " + value);

        switch (type) {
            case FORM_NAME: {
                debugger;
               // console.log("name swithed");
                setAddEditModalData({...addEditModalData, companyName: value});
                if (validateRequiredField(value)) {
                    setSaveButtonDisable(false);
                    setFormError({...formError, companyNameError: ''});
                } else {
                    setSaveButtonDisable(true);
                    setFormError({...formError, companyNameError: EMPTY_ERROR});
                }
                break;
            }
            case FORM_ADDRESS: {
                setAddEditModalData({...addEditModalData, address: value});
                if (validateRequiredField(value)) {
                    setFormError({...formError, addressError: ''});
                } else {
                    setFormError({...formError, addressError: EMPTY_ERROR});
                }
                break;
            }
            case FORM_CITY: {
                setAddEditModalData({...addEditModalData, city: value});
                break;
            }
            case FORM_STATE: {
                setAddEditModalData({...addEditModalData, state: value});
                break;
            }
            case FORM_ZIP: {
                setAddEditModalData({...addEditModalData, zip: value});
                break;
            }
            case FORM_PHONE: {
                setAddEditModalData({...addEditModalData, phone: value});
                if (validatePhone(value) || value == '') {
                    setFormError({...formError, phoneError: ''});
                } else {
                    setFormError({...formError, phoneError: PHONE_ERROR});
                }
                break;
            }
            case FORM_EMAIL: {
                setAddEditModalData({...addEditModalData, emailAddress: value});
                if (validateEmail(value) || value == '') {
                    setFormError({...formError, emailError: ''});
                } else {
                    setFormError({...formError, emailError: EMAIL_ERROR});
                }
                break;
            }
            case FORM_DECISION_MAKER: {
                setAddEditModalData({...addEditModalData, decisionMaker: value});
                break;
            }
            case FORM_ESTIMATE_SALES: {
                setAddEditModalData({...addEditModalData, estimatedAnnualSales: value});
                if (validateFloat(value) || value == '') {
                    setFormError({...formError, amountError: ''});
                } else {
                    setFormError({...formError, amountError: AMOUNT_ERROR});
                }
                break;
            }
            default:{
                break;
            }
        }
    }


    const onEditPress =(item, indexPos) =>{

        setCurrentEditItem({itemIndex:indexPos, itemData:item});
         console.log(item);
         console.log(stageList);
        let enabledList = JSON.parse(JSON.stringify(stageList.stageBoxList));
        if(validateRequiredField(item.CurrentStage)){
            for(let index=0; index<stageList.stageBoxList.length; index++){
                if(enabledList[index].value === item.CurrentStage){
                    break;
                }
                else{
                    enabledList[index].disabled=true;
                }
            }
            setStageList({...stageList, stageBoxList:enabledList, index: enabledList.length, defaultValue: item.CurrentStage});
        }
        if(validateRequiredField(item.CompanyName)){
            setSaveButtonDisable(false);
        }
        let decisionM =item.DecisionMaker;
        let approachL = item.ApproachProcessList;
        if(!validateRequiredField(item.DecisionMaker) || item.DecisionMaker === emptyUUID){
            decisionM=null;
        }
        if(!validateRequiredField(item.ApproachProcessList) || item.ApproachProcessList === emptyUUID){
            approachL=null;
        }
        setAddEditModalData({
        mode:1, companyName:item.CompanyName, address:item.Address, city:item.City, state:item.State,
            zip:item.Zip, phone:item.Phone, emailAddress: item.EmailAddress, decisionMaker:decisionM,
                estimatedAnnualSales: ""+item.EstimatedAnnualSales, currentStage:item.CurrentStage, stageName:item.Stage,
                approachProcessList:approachL
        }
        )
        if(prospectHeaderList.length > 0){
            callDecisionMakerApi(item.Id);
        }else{
            setLoadingSpinnerVisibility(true);
            _prospectHeaderListRequest(brandSuccessResponse.CompanyId);
        }


    }


    const onModalSavePress = () =>{
        let allDataValid =true;
        if(!validateRequiredField(addEditModalData.address)){
            allDataValid=false;
            Toast.showWithGravity("Please fill required fields marked with *", Toast.SHORT, Toast.CENTER);
            setFormError({...formError, addressError: EMPTY_ERROR});
        }
        else if(!validateRequiredField(addEditModalData.companyName)){
            allDataValid=false;
            Toast.showWithGravity("Please fill required fields marked with *", Toast.SHORT, Toast.CENTER);
            setFormError({...formError, companyNameError: EMPTY_ERROR});
        }
        else if(validateRequiredField(addEditModalData.emailAddress) && !validateEmail(addEditModalData.emailAddress)){
            allDataValid=false;
            Toast.showWithGravity("Please fill valid email.", Toast.SHORT, Toast.CENTER);
            setFormError({...formError, emailError: EMAIL_ERROR});
        }
        else if(!validateRequiredField(addEditModalData.currentStage)){
            allDataValid=false;
            Toast.showWithGravity("Please select prospect stage.", Toast.SHORT, Toast.CENTER);
        }
        else if(validateRequiredField(addEditModalData.phone) && !validatePhone(addEditModalData.phone)){
            allDataValid=false;
            Toast.showWithGravity("Please fill valid phone number.", Toast.SHORT, Toast.CENTER);
        }
        else if(validateRequiredField(addEditModalData.estimatedAnnualSales) && !validateFloat(addEditModalData.estimatedAnnualSales)){
            allDataValid=false;
            Toast.showWithGravity("Please fill valid sales amount.", Toast.SHORT, Toast.CENTER);
        }

        if(allDataValid){
            console.log('prospect modal data -->', addEditModalData);
            console.log('currentedit item', currentEditItem);

          saveApiCall();
        }

    }

    const saveApiCall = () =>{
        if(addEditModalData.mode === 1){
            console.log(currentEditItem);
            let editProspectObj={
                Id: currentEditItem.itemData.Id,
                RepId: brandSuccessResponse.ERPRepCode,
                CompanyId:brandSuccessResponse.CompanyId,
                CompanyName: validateRequiredField(currentEditItem.itemData.CompanyName)?currentEditItem.itemData.CompanyName:'',
                Address: validateRequiredField(currentEditItem.itemData.Address)?currentEditItem.itemData.Address:'',
                City: validateRequiredField(currentEditItem.itemData.City)?currentEditItem.itemData.City:'',
                State: validateRequiredField(currentEditItem.itemData.State)?currentEditItem.itemData.State:'',
                Zip: validateRequiredField(currentEditItem.itemData.Zip)?currentEditItem.itemData.Zip:'',
                Phone: validateRequiredField(currentEditItem.itemData.Phone)?currentEditItem.itemData.Phone:'',
                EmailAddress: validateRequiredField(currentEditItem.itemData.EmailAddress)?currentEditItem.itemData.EmailAddress:'',
                DecisionMaker: validateRequiredField(currentEditItem.itemData.DecisionMaker)?currentEditItem.itemData.DecisionMaker:null,
                EstimatedAnnualSales: validateRequiredField(currentEditItem.itemData.EstimatedAnnualSales)?currentEditItem.itemData.EstimatedAnnualSales+"" :'',
                CurrentStage: validateRequiredField(currentEditItem.itemData.CurrentStage)?currentEditItem.itemData.CurrentStage:'',
                ApproachProcessList:validateRequiredField(currentEditItem.itemData.ApproachProcessList)?currentEditItem.itemData.ApproachProcessList:null,
                DecisionMakerName:null
            };

            // TODO --> this below check cannot be done as some variables come null and vice-versa in prospectList api but cannot be retured as
            //  null in request api, need to be discussed with server team, least priority work.
            // if(addEditModalData.companyName === editProspectObj.CompanyName &&
            //     addEditModalData.address === editProspectObj.Address &&
            //     addEditModalData.city === editProspectObj.City &&
            //     addEditModalData.state === editProspectObj.State &&
            //     addEditModalData.zip === editProspectObj.Zip &&
            //     addEditModalData.phone === editProspectObj.Phone &&
            //     addEditModalData.emailAddress === editProspectObj.EmailAddress &&
            //     addEditModalData.decisionMaker === editProspectObj.DecisionMaker &&
            //     addEditModalData.currentStage === editProspectObj.CurrentStage &&
            //     addEditModalData.estimatedAnnualSales === editProspectObj.EstimatedAnnualSales
            //     // &&
            //     // (addEditModalData.approachProcessList === editProspectObj.ApproachProcessList ||
            //     //     (addEditModalData.approachProcessList === null )
            //     // )
            // ){
            //     Toast.showWithGravity("No changes to save!", Toast.SHORT, Toast.CENTER);
            // }
            // else{
                editProspectObj.CompanyName= addEditModalData.companyName;
                editProspectObj.Address= addEditModalData.address;
                editProspectObj.City= addEditModalData.city;
                editProspectObj.State= addEditModalData.state;
                editProspectObj.Zip= addEditModalData.zip;
                editProspectObj.Phone= addEditModalData.phone;
                // server has email as null but doesnt accept null :(
                editProspectObj.EmailAddress=validateRequiredField(addEditModalData.emailAddress)?addEditModalData.emailAddress:'';
                editProspectObj.DecisionMaker= addEditModalData.decisionMaker;
                editProspectObj.EstimatedAnnualSales= addEditModalData.estimatedAnnualSales;
                editProspectObj.CurrentStage= addEditModalData.currentStage;
                editProspectObj.ApproachProcessList=validateRequiredField(addEditModalData.approachProcessList)?
                    addEditModalData.approachProcessList:emptyUUID

                console.log("edit mode hit api", editProspectObj);
                setAddModalVisibility(false);
                setSaveButtonDisable(true);
                setLoadingSpinnerVisibility(true);
                _addEditProspectRequest(editProspectObj);
            // }
        }
        else{
            console.log("add mode hit api");
            let approachLValid = validateRequiredField(addEditModalData.approachProcessList)? addEditModalData.approachProcessList:emptyUUID
            let addProspectObj={
                Id: emptyUUID,
                RepId: brandSuccessResponse.ERPRepCode,
                CompanyId: brandSuccessResponse.CompanyId,
                CompanyName: addEditModalData.companyName,
                Address: addEditModalData.address,
                City: addEditModalData.city,
                State:addEditModalData.state,
                Zip: addEditModalData.zip,
                Phone: addEditModalData.phone,
                EmailAddress: addEditModalData.emailAddress,
                DecisionMakerName: addEditModalData.decisionMaker, //addEditModalData.DecisionMaker ,
                DecisionMaker:null,
                EstimatedAnnualSales:addEditModalData.estimatedAnnualSales,
                CurrentStage: addEditModalData.currentStage,
                ApproachProcessList: approachLValid
            };
            console.log("add mode hit api", addProspectObj);
            setAddModalVisibility(false);
            setSaveButtonDisable(true);
            setLoadingSpinnerVisibility(true);
            _addEditProspectRequest(addProspectObj);

        }

    }

    const onStageChange = (newItem) =>{
        if(newItem.value !== addEditModalData.currentStage){
            setAddEditModalData({...addEditModalData, currentStage:newItem.value, stageName:newItem.label});
        }

    }

    const onDecisionMakerChange =(newItem)=>{
        if(newItem.value !== addEditModalData.decisionMaker){
            setAddEditModalData({...addEditModalData, decisionMaker:newItem.value,});
        }
    }

    const onProcessStepHeaderChange =(newItem)=>{
        if(newItem.value !== addEditModalData.approachProcessList){
            setAddEditModalData({...addEditModalData, approachProcessList:newItem.value,});
        }
    }

    return (
        <View style={styles.container}>
            <FlatList
                data={prospectList}
                renderItem={({item, index, separators}) => (
                    <TouchableWithoutFeedback
                        onPress={() => {Toast.showWithGravity("Work in progress", Toast.SHORT, Toast.CENTER);}}
                        //    onPress={() => navigation.navigate(ROUTE_CUSTOMER_DETAIL)}
                    >
                        <View>
                            <ProspectListTemplate itemData={item} onEditPress={() => onEditPress(item, index)} />
                        </View>
                    </TouchableWithoutFeedback>
                )}
                onEndReached={() => callProspectPagingOnScroll()}
                onEndReachedThreshold={0.8}
                refreshControl={
                    <RefreshControl
                        refreshing={onRefreshBoolean}
                        onRefresh={()=> callProspectDataRefresh()}
                        title={"Pull down to sync prospect data."}
                    />
                }
                // onRefresh={() => {console.log("pulled up to relresh")}}
                // refreshing={false}
            />
            <View style={{width:'100%', height:'10%'}}>
                <GenericButton
                    title="Add Prospect"
                    //titleStyle={{fontSize:10}}
                    //containerStyle={{alignItems:'flex-start'}}
                    type={'clear'}
                    //onPress={() => {Toast.showWithGravity("Work in progress", Toast.SHORT, Toast.CENTER);}}
                    onPress={onModalOpenPress}
                />
            </View>
            <Overlay
                backdropStyle={styles.overlay}
                isVisible={addModalVisibility}
                overlayStyle={styles.overlayAddModalStyle}>
                <View>
                <View style={{height: '8%',flexDirection:'row',}}>
                    <View style={{width:"28%",justifyContent: 'center'}}>
                        <GenericButton
                            title={CANCEL}
                            titleStyle={{fontSize:15}}
                            type={'clear'}
                            onPress={onModalCancelPress}
                        ></GenericButton>
                    </View>
                    <View style={{width:"44%",
                        alignItems:'center',
                        justifyContent:"center"
                    }}>
                        {
                            (addEditModalData.mode == 0)?
                                <Text h5 >ADD PROSPECT</Text>:
                                <Text h5 >EDIT PROSPECT</Text>
                        }

                    </View>
                    <View style={{width:"28%", justifyContent: 'center'}}>
                        <GenericButton
                            title={SAVE}
                            titleStyle={{fontSize:15}}
                            type={'clear'}
                            onPress={onModalSavePress}
                            disabled={saveButtonDisable}
                        ></GenericButton>
                    </View>
                </View>
                <KeyboardAvoidingView
                    style={{height: DEVICE_HEIGHT*.5,}}
                    behavior="padding"
                    keyboardVerticalOffset={ Platform.OS == 'ios' ? (DeviceInfo.isTablet() ? 70: 150) : 0}
                >
                <ScrollView
                   style={{
                       height: DEVICE_HEIGHT*.5,
                       marginTop:SPACING_5
                   }}
                >
                    <View
                        style={[{
                            //marginTop:SPACING_30,
                            //    width:AUTH_STACK_CONTAINER_WIDTH
                        }
                            ,(Platform.OS !== 'android' && {
                                zIndex: 600 // required for modal dropdown select issue on ios
                            })]}>
                        <DropDownPicker
                            items={stageList.stageBoxList}
                            controller={instance => {dropDownStageController = instance}}
                            onOpen={() => {dropDownProspectHeaderStepController.close(); dropDownDecisionMakerController.close(); Keyboard.dismiss();}}
                            placeholder="Select Stage"
                            defaultValue={stageList.defaultValue}
                            placeholderStyle={{color:"grey"}}
                            containerStyle={{height: INPUT_FIELD_HEIGHT}}
                            dropDownStyle={{}}
                            itemStyle={{
                                justifyContent: 'flex-start'
                            }}
                            onChangeItem={(item) => onStageChange(item)}
                        />
                    </View>
                    <View
                        style={[{
                            marginTop:SPACING_10,
                            //    width:AUTH_STACK_CONTAINER_WIDTH
                        }
                            ,(Platform.OS !== 'android' && {
                                zIndex: 200 // required for modal dropdown select issue on ios
                            })]}>
                        <DropDownPicker
                            items={prospectHeaderList}
                            controller={instance => {dropDownProspectHeaderStepController = instance}}
                            onOpen={() => {dropDownStageController.close(); dropDownDecisionMakerController.close(); Keyboard.dismiss();}}
                            placeholder="Select Prospect type"
                            defaultValue={addEditModalData.approachProcessList}
                            placeholderStyle={{color:"grey"}}
                            containerStyle={{height: INPUT_FIELD_HEIGHT}}
                            dropDownStyle={{}}
                            itemStyle={{
                                justifyContent: 'flex-start'
                            }}
                            onChangeItem={(item) => onProcessStepHeaderChange(item)}
                        />
                    </View>

                    <TextInput
                        value={addEditModalData.companyName}
                        onChangeText={(value) => {textFieldChange(value, FORM_NAME)}}
                        placeholder='Name*'
                        inputStyle={styles.modalFormTextStyle}
                        containerStyle={{paddingLeft: 0, paddingRight: 0}}
                        errorStyle={{color: ERROR_COLOR}}
                        errorMessage={formError.companyNameError}
                        onFocus={()=>{closeDropDownOnFocus()}}
                    />
                    <TextInput
                        value={addEditModalData.address}
                        onChangeText={(value) => {textFieldChange(value, FORM_ADDRESS)}}
                        placeholder='Address*'
                        inputStyle={styles.modalFormTextStyle}
                        containerStyle={{paddingLeft: 0, paddingRight: 0}}
                        errorStyle={{color: ERROR_COLOR}}
                        errorMessage={formError.addressError}
                    />
                    <TextInput
                        value={addEditModalData.city}
                        onChangeText={(value) => {textFieldChange(value, FORM_CITY)}}
                        placeholder='City'
                        inputStyle={styles.modalFormTextStyle}
                        //onChangeText={onRouteInputChange}
                        containerStyle={{paddingLeft: 0, paddingRight: 0}}
                        onFocus={()=>{closeDropDownOnFocus()}}
                    />
                    <TextInput
                        value={addEditModalData.state}
                        onChangeText={(value) => {textFieldChange(value, FORM_STATE)}}
                        placeholder='State'
                        inputStyle={styles.modalFormTextStyle}
                       containerStyle={{paddingLeft: 0, paddingRight: 0}}
                        onFocus={()=>{closeDropDownOnFocus()}}
                    />
                    <TextInput
                        value={addEditModalData.zip}
                        onChangeText={(value) => {textFieldChange(value, FORM_ZIP)}}
                        placeholder='Zip'
                        inputStyle={styles.modalFormTextStyle}
                        containerStyle={{paddingLeft: 0, paddingRight: 0}}
                        onFocus={()=>{closeDropDownOnFocus()}}
                    />

                    {(addEditModalData.mode == 0)?
                        <TextInput
                            value={addEditModalData.decisionMaker}
                            onChangeText={(value) => {
                                textFieldChange(value, FORM_DECISION_MAKER)
                            }}
                            placeholder='Decision Maker'
                            inputStyle={styles.modalFormTextStyle}
                            containerStyle={{paddingLeft: 0, paddingRight: 0}}
                            onFocus={()=>{closeDropDownOnFocus()}}
                        />:
                        <View
                            style={[{
                                //marginTop:SPACING_30,
                                //    width:AUTH_STACK_CONTAINER_WIDTH
                            }
                                ,(Platform.OS !== 'android' && {
                                    zIndex: 100 // required for modal dropdown select issue on ios
                                })]}>
                            <DropDownPicker
                                items={decisionMakerList.List}
                                controller={instance => {dropDownDecisionMakerController = instance}}
                                onOpen={() => {dropDownProspectHeaderStepController.close(); dropDownStageController.close(); Keyboard.dismiss();}}

                                placeholder="Select Decision Maker"
                                defaultValue={addEditModalData.decisionMaker}
                                placeholderStyle={{color:"grey"}}
                                containerStyle={{height: INPUT_FIELD_HEIGHT}}
                                dropDownStyle={{}}
                                itemStyle={{
                                    justifyContent: 'flex-start'
                                }}
                               onChangeItem={(item) => onDecisionMakerChange(item)}
                            />
                        </View>

                    }
                    <TextInput
                        value={addEditModalData.phone}
                        onChangeText={(value) => {textFieldChange(value, FORM_PHONE)}}
                        placeholder='Phone'
                        inputStyle={styles.modalFormTextStyle}
                        containerStyle={{paddingLeft: 0, paddingRight: 0}}
                        keyboardType={'numeric'}
                        errorStyle={{color: ERROR_COLOR}}
                        errorMessage={formError.phoneError}
                        onFocus={()=>{closeDropDownOnFocus()}}
                    />
                    <TextInput
                        value={addEditModalData.emailAddress}
                        onChangeText={(value) => {textFieldChange(value, FORM_EMAIL)}}
                        placeholder='Email'
                        inputStyle={styles.modalFormTextStyle}
                        containerStyle={{paddingLeft: 0, paddingRight: 0}}
                        errorStyle={{color: ERROR_COLOR}}
                        errorMessage={formError.emailError}
                        onFocus={()=>{closeDropDownOnFocus()}}
                    />
                    <TextInput
                        value={addEditModalData.estimatedAnnualSales}
                        onChangeText={(value) => {textFieldChange(value, FORM_ESTIMATE_SALES)}}
                        placeholder='EstimateSales'
                        inputStyle={styles.modalFormTextStyle}
                        containerStyle={{paddingLeft: 0, paddingRight: 0}}
                        keyboardType={'numeric'}
                        errorStyle={{color: ERROR_COLOR}}
                        errorMessage={formError.amountError}
                        returnKeyType={ 'done' }
                        onFocus={()=>{closeDropDownOnFocus()}}
                    />

                </ScrollView>
                </KeyboardAvoidingView>
                </View>
            </Overlay>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    logo: {
        width: SPLASH_LOGO_WIDTH,
        height: SPLASH_LOGO_HEIGHT,
    },
    overlay: {
        backgroundColor: GENERIC_BACKGROUND_COLOR,
        opacity: MODAL_BACKDROP_OPACITY
    },
    overlayAddModalStyle: {
        position: 'absolute',
        top: DeviceInfo.isTablet()?'10%':'15%',
        borderWidth: FIELD_BORDER_WIDTH,
        borderColor: INPUT_FIELD_BORDER_COLOR,
        width: AUTH_STACK_CONTAINER_WIDTH,
        //alignItems: 'flex-start'
        //height:400
    },
    modalFormTextStyle:{
        fontSize:TEXT_SIZE_12
    }
});

const mapStateToProps = (reduxStore) => {
    return {
        prospectApiSuccessResponse: reduxStore.prospect.prospectApiSuccessResponse,
        prospectOnScrollApiSuccess: reduxStore.prospect.prospectOnScrollApiSuccess,
        prospectApiHttpError: reduxStore.prospect.prospectApiHttpError,
        prospectAddEditSuccess: reduxStore.prospect.prospectAddEditSuccess,
        brandSuccessResponse: reduxStore.login.brandSuccessResponse,
        prospectStage: reduxStore.prospect.prospectStage,
        decisionMakerSuccess: reduxStore.prospect.decisionMakerSuccess,
        prospectHeaderListSuccess: reduxStore.prospect.prospectHeaderListSuccess,
    };
};

export default withLoadingSpinner()(
    withHttpsApiErrorHandling()(
        connect(mapStateToProps, {
            prospectListRequest,
            prospectListToRedux,
            prospectListRequestOnScroll,
            resetProspectOnScrollRequest,
            resetProspectHttpApiError,
            resetProspectRedux,
            prospectStageRequest,
            addEditProspectRequest,
            resetProspectAddEditSuccess,
            prospectHeaderListRequest,
            decisionMakerApiRequest,
            resetProspectHeaderState,
            resetDecisionMakerState
        })(ProspectTab)
    )
);
