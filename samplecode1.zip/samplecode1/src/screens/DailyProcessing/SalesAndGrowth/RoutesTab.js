import {
    APP_BLUE_COLOR,
    ERROR_COLOR,
    FIELD_BORDER_WIDTH,
    GENERIC_BACKGROUND_COLOR,
    INPUT_FIELD_BORDER_COLOR, MODAL_BACKDROP_OPACITY
} from "../../../resources/constants/themeConstant";
import {Keyboard, TouchableHighlight} from 'react-native'
import { SwipeListView } from 'react-native-swipe-list-view';
const everyList=[{label: 'Day', value: 'Day'}, {label: 'Week', value: 'Week'}, {label: 'Month', value: 'Month'},]
import React, {useEffect, useState} from 'react';
import {
    StyleSheet,
    View,
    TouchableWithoutFeedback,
    FlatList, RefreshControl,
} from 'react-native';
import {mcni360_blue_icon} from '../../../resources/images';
import FastImage from 'react-native-fast-image';
import FlipComponent from 'react-native-flip-component';
import {
    AUTH_STACK_CONTAINER_WIDTH, CONTAINER_HEIGHT_300, CONTAINER_HEIGHT_400, INPUT_FIELD_HEIGHT, SPACING_30,
    SPLASH_LOGO_HEIGHT,
    SPLASH_LOGO_WIDTH,
} from '../../../resources/constants/dimensions';
import {GenericButton, TextInput} from '../../../components';
import {ROUTE_CUSTOMER_DETAIL} from '../../../resources/constants/navigationConstants';
import withLoadingSpinner from '../../../components/HOC/withLoadingSpinner';
import withHttpsApiErrorHandling from '../../../components/HOC/withHttpsApiErrorHandling';
import {connect} from 'react-redux';
import {customerListRequest, customerListToRedux, customerListRequestOnScroll, resetOnScrollRequest} from '../../../store/Customer/customerAction';
import {validateRequiredField} from "../../../utils/validators";
import {getCustomersListFromRealM, resetCustomerTable} from "../../../realm/Models/customerModel";
import ProspectListTemplate from "../../../components/GenericTemplate/ProspectListTemplate";
import RoutesListTemplate from "../../../components/GenericTemplate/RouteListTemplate";
import {resetAppData} from "../../../services/onAuthService";
import {Overlay, Text} from 'react-native-elements';
import {
    resetRouteHttpApiError,
    routeListToRedux,
    routesListRequest,
    resetRouteRedux,
    addEditRouteApiRequest, resetRouteAddEditSuccess, routeStopApiRequest, routeStopApiReset
} from "../../../store/Route/routeAction";
import {getRouteListFromRealM, resetRouteTable, updateRouteInRealM} from "../../../realm/Models/routeModel";
import {
    CANCEL,
    EMAIL_PLACEHOLDER,
    freqDay,
    freqMonth,
    freqWeek,
    SAVE
} from "../../../resources/constants/stringConstants";
import DropDownPicker from "react-native-dropdown-picker";
import RouteStopFlipView from './RouteStopFlipView';

import Toast from "react-native-simple-toast";
import {CUSTOMER_REQUEST_FAIL} from "../../../resources/constants/storeConstants";
import RoutesStopListTemplate from "../../../components/GenericTemplate/RouteStopListTemplate";

const RoutesTab = (
    {
        navigation,
        httpRouteApiError,
        setLoadingSpinnerVisibility,
        showHttpsApiErrorDialog,
        routeSuccessResponse,
        brandSuccessResponse,
        routeSearchResultList,
        onSearchRouteEdit,
        routeAddEditSuccess,
        routeStopSuccess,
        routeListToRedux: _routeListToRedux,
        resetRouteHttpApiError: _resetRouteHttpApiError,
        routesListRequest: _routesListRequest,
        resetRouteRedux:_resetRouteRedux,
        addEditRouteApiRequest:_addEditRouteApiRequest,
        resetRouteAddEditSuccess:_resetRouteAddEditSuccess,
        routeStopApiRequest:_routeStopApiRequest,
        routeStopApiReset:_routeStopApiReset,


    },
    prototype,
) => {

    const [routeList, setRouteList] = useState([]);
    const [routeStopList, setRouteStopList] = useState([]);
    const [onRefreshBoolean, setOnRefreshBoolean] =useState(false);
    const [addModalVisibility, setAddModalVisibility] = useState(false);
    const [addEditModalData, setAddEditModalData] = useState({mode:0, name:'', description:'', every:'', frequency:'0'});
    const [freqList, setFreqList] = useState({freqBoxList:[{label: 'N/A', value: '0'}], index:0, defaultValue:'0'});
    const [saveButtonDisable, setSaveButtonDisable] = useState(true);
    const [currentEditItem, setCurrentEditItem] = useState({itemIndex:null, itemData:{}});
    const [isFlipped, setIsFlipped] =useState(false);
    const [pressedRouteId, setPressedRouteId] = useState('');
    let dropDownFreqController, dropDownEveryController;
    useEffect( () => {
        debugger;
        if(validateRequiredField(routeSuccessResponse)){
            setLoadingSpinnerVisibility(false);
            //  console.log(customerApiSuccessResponse.length);
            updateRouteListOnUI(routeSuccessResponse, false);
        }
        else {
            fetchRouteListFromRealM();
        }

    }, [routeSuccessResponse]);


    useEffect(() => {
        if (routeSearchResultList.length > 0) {
            //  console.log(customerApiSuccessResponse.length);
            updateRouteListOnUI(routeSearchResultList, false);
        } else {
            updateRouteListOnUI(routeSuccessResponse, false);
        }
    }, [routeSearchResultList]);

    useEffect(() => {
        if (httpRouteApiError !== null) {
            setLoadingSpinnerVisibility(false);
            showHttpsApiErrorDialog(httpRouteApiError);
            setAddEditModalData({mode:0, name:'', description:'', every:'', frequency:''})
            setFreqList({freqBoxList:[{label: 'N/A', value: '0'}], index:0, defaultValue:"0"});
            setCurrentEditItem({itemIndex:null, itemData:{}});
            _resetRouteHttpApiError();
        }
    }, [httpRouteApiError]);


    useEffect(() => {
        if (routeAddEditSuccess !== null) {
            setLoadingSpinnerVisibility(false);
            updateLocalUI();
            _resetRouteAddEditSuccess();
        }
    }, [routeAddEditSuccess]);

    useEffect(() => {
        if (routeStopSuccess !== null) {
            setLoadingSpinnerVisibility(false);
            updateFlipUI(routeStopSuccess);
            _routeStopApiReset();
        }
    }, [routeStopSuccess]);


    const updateFlipUI = (routeStopL) =>{
        setRouteStopList(routeStopL);
        setLoadingSpinnerVisibility(false);
        setIsFlipped(true);
    }



    const updateLocalUI =() =>{
        if(addEditModalData.mode === 1){
            let indexToUpdate=currentEditItem.itemIndex;
            routeList[indexToUpdate].RouteName=addEditModalData.name;
            routeList[indexToUpdate].Description=addEditModalData.description;
            routeList[indexToUpdate].Every=addEditModalData.every;
            routeList[indexToUpdate].Frequency=addEditModalData.frequency;
            updateRouteInRealM(routeList[indexToUpdate]);
            if(routeSearchResultList.length > 0){
                onSearchRouteEdit(1, false);
                _resetRouteRedux();
            }
            setTimeout(()=>{Toast.showWithGravity("Route edited successfully.", Toast.SHORT, Toast.CENTER);},
                500)

        }
        else{
            // in case of add
            Toast.showWithGravity("Route added successfully. Refreshing List.", Toast.SHORT, Toast.CENTER);
            setTimeout(()=>{callRouteDataRefresh();},
                500)


        }
        setAddEditModalData({mode:0, name:'', description:'', every:'', frequency:''})
        setFreqList({freqBoxList:[{label: 'N/A', value: '0'}], index:0, defaultValue:"0"});
        setCurrentEditItem({itemIndex:null, itemData:{}});
    }


    const fetchRouteListFromRealM = async () => {
        let routeListFetchRealM = await getRouteListFromRealM();
        console.log('ROUTE list on tab page insidde func', routeListFetchRealM);
        if(validateRequiredField(routeListFetchRealM) &&  routeListFetchRealM.length > 0){
            console.log(routeListFetchRealM.length);
            _routeListToRedux(routeListFetchRealM);
         //   updateRouteListOnUI(routeListFromRealM, not required if not pagging);
        }
        else{
            setLoadingSpinnerVisibility(true);
            _routesListRequest(brandSuccessResponse.CompanyId);
        }
    }

    const updateRouteListOnUI = (routes, toBeConcat) => {
        if(toBeConcat){
            let previousList = routeList;
            let newList = previousList.concat(routes);
            setRouteList(newList);
        }
        else{
            setRouteList(routes);
        }
    }

    const callRouteDataRefresh = async () => {
        setOnRefreshBoolean(true);
        await resetRouteTable();
        _resetRouteRedux();
        setOnRefreshBoolean(false);
    }

    const onRoutePress = (route) =>{
       setLoadingSpinnerVisibility(true);
        let routeStopObj =  {
            Id: route.Id
        }
        setPressedRouteId(route.Id);
        _routeStopApiRequest(routeStopObj);


    }

    const onEditPress =(item, index) =>{
        setCurrentEditItem({itemIndex:index, itemData:item});
        //item.Every="Week";
        //item.Frequency="7";
        if(validateRequiredField(item.RouteName)){
            setSaveButtonDisable(false);
        }else{
            setSaveButtonDisable(true);
        }
        if(validateRequiredField(item.Every)){
            let list=(item.Every === 'Day')?freqDay:(item.Every === 'Week')?freqWeek:freqMonth;
            let freq=item.Frequency +"";
            setFreqList({freqBoxList:list, index: list.length, defaultValue: freq});
            setAddEditModalData({mode:1, name:item.RouteName, description:item.Description, every: item.Every, frequency:freq})
        }
        else{
            setAddEditModalData({mode:1, name:item.RouteName, description:item.Description, every: "", frequency:"0"})
        }

        setAddModalVisibility(true);
        console.log('item', item);
    }

    const onModalOpenPress =() =>{
        if(!isFlipped){
            setAddModalVisibility(true);
        }else{

        }

    }

    const onEveryChange = (newItem) =>{
        console.log(newItem);
        debugger;
        if(newItem.value !== addEditModalData.every){
            console.log(addEditModalData.frequency);
            let it=(newItem.value === 'Day')?freqDay:(newItem.value === 'Week')?freqWeek:freqMonth;
            dropDownFreqController.selectItem('0');
            setAddEditModalData({...addEditModalData, every: newItem.value, frequency: "0"});
            setFreqList({freqBoxList:it, index: it.length, defaultValue: "0"});
        }
    }

    const onFreqChange = (newItem) =>{
        console.log(newItem);
        if(newItem.value !== addEditModalData.frequency){
            setAddEditModalData({...addEditModalData, frequency:newItem.value});
        }
    }

    const onModalCancelPress = () => {
        setAddModalVisibility(false);
        setSaveButtonDisable(true);
        setAddEditModalData({mode:0, name:'', description:'', every:'', frequency:''})
        setFreqList({freqBoxList:[{label: 'N/A', value: '0'}], index:0, defaultValue:"0"});
    }

    const onDescInputChange = (description) => {
        setAddEditModalData({...addEditModalData, description: description});
    }
    const onRouteInputChange = (routeName) => {
        setAddEditModalData({...addEditModalData, name: routeName});
        if(validateRequiredField(routeName)){
            setSaveButtonDisable(false);
        }else{
            setSaveButtonDisable(true);
        }
    }

    const onModalSavePress = () =>{
        let freqN="0";
        if(validateRequiredField(addEditModalData.frequency)){
            freqN = addEditModalData.frequency
        }
        if(addEditModalData.mode === 1){
            debugger;
            console.log(currentEditItem);
            let freq2 =currentEditItem.itemData.Frequency+"";
            if(addEditModalData.name === currentEditItem.itemData.RouteName &&
                addEditModalData.description === currentEditItem.itemData.Description &&
                addEditModalData.every === currentEditItem.itemData.Every &&
                freqN === freq2
            ){
                Toast.showWithGravity("No changes to save!", Toast.SHORT, Toast.CENTER);
            }
            else{
                let editRouteObj={
                    id: currentEditItem.itemData.Id,
                    companyId: currentEditItem.itemData.CompanyId,
                    routeName: addEditModalData.name,
                    description: addEditModalData.description,
                    every: addEditModalData.every,
                    frequency: freqN,
                    sequence: currentEditItem.itemData.Sequence + ""
                }
                console.log("edit mode hit api", editRouteObj);
                setAddModalVisibility(false);
                setSaveButtonDisable(true);
                setLoadingSpinnerVisibility(true);
                _addEditRouteApiRequest(editRouteObj);

            }
        }
        else{
            console.log("add mode hit api");
            let nextSeqLength =routeList.length+1;
            let addRouteObj={
                id: "00000000-0000-0000-0000-000000000000",
                companyId: brandSuccessResponse.CompanyId,
                routeName: addEditModalData.name,
                description: addEditModalData.description,
                every: addEditModalData.every,
                frequency: freqN,
                sequence: nextSeqLength+ ""
            }
            console.log("add mode hit api", addRouteObj);
            setAddModalVisibility(false);
            setSaveButtonDisable(true);
            setLoadingSpinnerVisibility(true);
            _addEditRouteApiRequest(addRouteObj);

        }

    }

    const flipFrontView = () =>{
        return(
            <View>
            <View  style={{width:'100%', height:'92%'}}>
            <FlatList
                //style={{borderWidth:2}}
                data={routeList}
                keyExtractor={(item) => item.Id}
                renderItem={({item, index, separators}) => (
                    <TouchableWithoutFeedback
                        // onPress={() => {Toast.showWithGravity("Work in progress", Toast.SHORT, Toast.CENTER);}}
                        onPress ={() => {onRoutePress(item)}}
                    >
                        <View>
                            <RoutesListTemplate itemData={item}  onEditPress={() => onEditPress(item, index)}/>
                        </View>
                    </TouchableWithoutFeedback>
                )}
                refreshControl={
                    <RefreshControl
                        refreshing={onRefreshBoolean}
                        onRefresh={()=> callRouteDataRefresh()}
                        title={"Pull down to sync routes data."}
                    />
                }
            />
            </View>
        <View style={{width:'100%', height:'8%'}}>
         <GenericButton
            title="Add Route"
            type={'clear'}
            //onPress ={()=>{setIsFlipped(!isFlipped)}}
            onPress={onModalOpenPress}
        />
        </View>
        </View>
        )
    }

    const flipBackView = () =>{

    }

    return (
        <View style={styles.container}>

            <FlipComponent
                isFlipped={isFlipped}
                containerStyles={{}}
                frontView={flipFrontView()}
                 backView={
                     <View style={{ alignItems: 'flex-start',}}>
                         <GenericButton
                             //containerStyle={{alignItems: 'flex-end',}}
                             icon={'arrow-back'}
                             size={20}
                             iconType={'MaterialIcons'}
                             iconColor={APP_BLUE_COLOR}
                             type={'clear'}
                             onPress={() => {setIsFlipped(!isFlipped)}}
                         />
                        <RouteStopFlipView  routeStopList={routeStopList} currentRouteId={pressedRouteId} />
                    </View>
                }
                backStyles={{
                    height:'100%',
                    width:'100%',
                    //borderWidth:2,
                    //backgroundColor: 'pink'
                }}
            />
            <Overlay
                backdropStyle={styles.overlay}
                isVisible={addModalVisibility}
                overlayStyle={styles.overlayAddModalStyle}>
                <View style={{ height: CONTAINER_HEIGHT_300, }}>
                    <View style={{height: '10%',flexDirection:'row',}}>
                        <View style={{width:"28%"}}>
                        <GenericButton
                            title={CANCEL}
                            titleStyle={{fontSize:15}}
                            type={'clear'}
                            onPress={onModalCancelPress}
                        ></GenericButton>
                        </View>
                        <View style={{width:"44%", alignItems:'center', justifyContent:"center"}}>
                            {
                                (addEditModalData.mode == 0)?
                                    <Text h5 >ADD ROUTE</Text>:
                                    <Text h5>EDIT ROUTE</Text>
                            }
                        </View>
                        <View style={{width:"28%"}}>
                        <GenericButton
                            title={SAVE}
                            titleStyle={{fontSize:15}}
                            type={'clear'}
                            onPress={onModalSavePress}
                            disabled={saveButtonDisable}
                        ></GenericButton>
                        </View>
                    </View>
                    <TextInput
                        value={addEditModalData.name}
                        placeholder='Route Name'
                        onChangeText={onRouteInputChange}
                        onFocus={()=>{dropDownFreqController.close(); dropDownEveryController.close();}}
                        containerStyle={{paddingLeft: 0, paddingRight: 0}}
                    />
                    <TextInput
                        value={addEditModalData.description}
                        placeholder='Route Description'
                        onChangeText={onDescInputChange}
                        onFocus={()=>{dropDownFreqController.close(); dropDownEveryController.close();}}
                        containerStyle={{paddingLeft: 0, paddingRight: 0}}
                    />
                    <View
                        style={[{
                            //marginTop:SPACING_30,
                        //    width:AUTH_STACK_CONTAINER_WIDTH
                        }
                            ,(Platform.OS !== 'android' && {
                        zIndex: 200 // required for modal dropdown select issue on ios
                    })]}>
                        <DropDownPicker
                            items={everyList}
                            controller={instance => {dropDownEveryController = instance}}
                            onOpen={() => {dropDownFreqController.close(); Keyboard.dismiss();}}
                            placeholder="Select Every"
                            defaultValue={addEditModalData.every}
                            placeholderStyle={{color:"grey"}}
                            containerStyle={{height: INPUT_FIELD_HEIGHT}}
                            dropDownStyle={{}}
                            itemStyle={{
                                justifyContent: 'flex-start'
                            }}
                            onChangeItem={(item) => onEveryChange(item)}
                        />
                    </View>
                    <View
                        style={[{marginTop:SPACING_30,
                        //    width:AUTH_STACK_CONTAINER_WIDTH
                        }
                            ,(Platform.OS !== 'android'
                            && {
                            zIndex: 100 // required for modal dropdown select issue on ios
                        })]}>
                        <DropDownPicker
                            onOpen={() => {dropDownEveryController.close();Keyboard.dismiss();}}
                            controller={instance => {dropDownFreqController = instance}}
                            items={freqList.freqBoxList}
                            placeholder="Select Frequency"
                            defaultValue={freqList.defaultValue}
                            placeholderStyle={{color:"grey"}}
                            //disabled={(addEditModalData.every === '' )? true:false}
                            containerStyle={{height: INPUT_FIELD_HEIGHT}}
                            dropDownStyle={{}}
                            itemStyle={{
                                justifyContent: 'flex-start'
                            }}
                            onChangeItem={(item) => onFreqChange(item)}
                            // onChangeList={(items, callback) => {
                            //     console.log("on change list called!!!!!");
                            //     dropDownFreqController.selectItem("0");
                            // }}
                        />
                    </View>

                </View>
            </Overlay>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    logo: {
        width: SPLASH_LOGO_WIDTH,
        height: SPLASH_LOGO_HEIGHT,
    },
    overlay: {
        backgroundColor: GENERIC_BACKGROUND_COLOR,
        opacity: MODAL_BACKDROP_OPACITY
    },
    overlayAddModalStyle: {
        borderWidth: FIELD_BORDER_WIDTH,
        borderColor: INPUT_FIELD_BORDER_COLOR,
        width: AUTH_STACK_CONTAINER_WIDTH,
        //height:400
    },
    rowBack: {
        alignItems: 'center',
        //backgroundColor: '#DDD',
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        paddingLeft: 15,
    },
});

const mapStateToProps = (reduxStore) => {
    return {
        routeSuccessResponse: reduxStore.route.routeSuccessResponse,
        httpRouteApiError:reduxStore.route.httpRouteApiError,
        brandSuccessResponse: reduxStore.login.brandSuccessResponse,
        routeAddEditSuccess: reduxStore.route.routeAddEditSuccess,
        routeStopSuccess: reduxStore.route.routeStopSuccess,

    };
};

export default withLoadingSpinner()(
    withHttpsApiErrorHandling()(
        connect(mapStateToProps, {
            routesListRequest,
            resetRouteHttpApiError,
            routeListToRedux,
            resetRouteRedux,
            addEditRouteApiRequest,resetRouteAddEditSuccess,
            routeStopApiRequest,
            routeStopApiReset,
        })(RoutesTab),
    ),
);
