import CustomerListTemplate from '../../../components/GenericTemplate/CustomerListTemplate';
import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableWithoutFeedback,
  FlatList, RefreshControl,
} from 'react-native';
import {mcni360_blue_icon} from '../../../resources/images';
import FastImage from 'react-native-fast-image';
import {
  SPLASH_LOGO_HEIGHT,
  SPLASH_LOGO_WIDTH,
} from '../../../resources/constants/dimensions';
import {GenericButton} from '../../../components';
import {ROUTE_CUSTOMER_DETAIL} from '../../../resources/constants/navigationConstants';
import withLoadingSpinner from '../../../components/HOC/withLoadingSpinner';
import withHttpsApiErrorHandling from '../../../components/HOC/withHttpsApiErrorHandling';
import {connect} from 'react-redux';
import {
  customerListRequest,
  customerListToRedux,
  customerListRequestOnScroll,
  resetOnScrollRequest,
    resetCustomerHttpApiError,
  resetCustomerRedux,
  selectCustomerAction
} from '../../../store/Customer/customerAction';
import {
  resetShipToAddressResponseAction
} from '../../../store/shippingAddress/shippingAddressAction';
import {validateRequiredField} from '../../../utils/validators';
import {getCustomersListFromRealM, resetCustomerTable} from '../../../realm/Models/customerModel';
import store from "../../../store/store";
import {SET_CUSTOMER_REDUX_INITIAL_STATE} from "../../../resources/constants/storeConstants";

const CustomersTab = (
  {
    navigation,
    routes,
  customerApiHttpError,
    showHttpsApiErrorDialog,
    customerSearchResultList,
    customerApiSuccessResponse,
    customerOnScrollApiSuccess,
      brandSuccessResponse,
    setLoadingSpinnerVisibility,
    customerListRequest: _customerListRequest,
    customerListToRedux: _customerListToRedux,
    customerListRequestOnScroll: _customerListRequestOnScroll,
    resetOnScrollRequest: _resetOnScrollRequest,
      resetCustomerHttpApiError:_resetCustomerHttpApiError,
    resetCustomerRedux:_resetCustomerRedux,
    selectCustomerAction: _selectCustomerAction,
    resetShipToAddressResponseAction: _resetShipToAddressResponseAction
  },
  prototype,
) => {
  console.log(brandSuccessResponse);

  const [customerList, setCustomerList] = useState([]);
  const [onScrollBoolean, setOnScrollBoolean] = useState(true);
  const [onRefreshBoolean, setOnRefreshBoolean] =useState(false);

  useEffect(() => {
    if (validateRequiredField(customerApiSuccessResponse)) {
      //  console.log(customerApiSuccessResponse.length);
      setLoadingSpinnerVisibility(false);
      updateCustomerListOnUI(customerApiSuccessResponse, false);
    } else {
      debugger;
      console.log("gettingintoelse");
      getCustomerListFromLocalDB(0);
    }
  }, [customerApiSuccessResponse]);

  useEffect(() => {
    if (customerSearchResultList.length > 0) {
      //  console.log(customerApiSuccessResponse.length);
      setOnScrollBoolean(false);
      updateCustomerListOnUI(customerSearchResultList, false);
    } else {
      setOnScrollBoolean(true);
      updateCustomerListOnUI(customerApiSuccessResponse, false);
    }
  }, [customerSearchResultList]);

  useEffect(() => {
    if (validateRequiredField(customerOnScrollApiSuccess)) {
      console.log(customerOnScrollApiSuccess.length);
      updateCustomerListOnUI(customerOnScrollApiSuccess, true);
      setOnScrollBoolean(true);
      _resetOnScrollRequest();
    }
  }, [customerOnScrollApiSuccess]);


    useEffect(() => {
        if (customerApiHttpError !== null) {
          debugger;
            setLoadingSpinnerVisibility(false);
            showHttpsApiErrorDialog(customerApiHttpError);
            _resetCustomerHttpApiError();
        }
        else{
          debugger;
        }
    }, [customerApiHttpError]);




  const getCustomerListFromLocalDB= async (offset) => {
    let customerListFromRealM = await getCustomersListFromRealM(offset);
    console.log(
      'customer list on tab page inside func',
      customerListFromRealM,
    );
    if (validateRequiredField(customerListFromRealM) && customerListFromRealM.length > 0) {
      console.log(customerListFromRealM.length);
      if(offset === 0){
        _customerListToRedux(customerListFromRealM);
      }
      else{
        updateCustomerListOnUI(customerListFromRealM, true);
      }
      setOnScrollBoolean(true);

    }
    else {
      if(offset === 0){
        setLoadingSpinnerVisibility(true);
        _customerListRequest(brandSuccessResponse.CompanyId, brandSuccessResponse.DeviceId, 0, '');
      }
      else{
        _customerListRequestOnScroll(brandSuccessResponse.CompanyId, brandSuccessResponse.DeviceId, offset);

      }

    }
  };

  const updateCustomerListOnUI = (customers, toBeConcat) => {
    if (toBeConcat) {
      let previousList = customerList;
      let newList = previousList.concat(customers);
      setCustomerList(newList);
    } else {
      setCustomerList(customers);
    }
  };

  const callCustomerPagingOnScroll = () => {
    let currentListLength = customerList.length;
    if (onScrollBoolean && currentListLength>49) {
      console.log(currentListLength);
      setOnScrollBoolean(false);
      getCustomerListFromLocalDB(currentListLength);
     // _customerListRequestOnScroll(brandSuccessResponse.CompanyId, brandSuccessResponse.DeviceId, currentListLength);
    }
  };

  const callCustomerDataRefresh = async () => {
    setOnRefreshBoolean(true);
    await resetCustomerTable();
    _resetCustomerRedux();
    setOnRefreshBoolean(false);
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={customerList}
        renderItem={({item, index, separators}) => (
          <TouchableWithoutFeedback
            onPress={() => {
              _selectCustomerAction(item);
              _resetShipToAddressResponseAction();
              navigation.navigate(ROUTE_CUSTOMER_DETAIL)
            }}>
            <View>
              <CustomerListTemplate itemData={item} />
            </View>
          </TouchableWithoutFeedback>
        )}
        onEndReached={() => callCustomerPagingOnScroll()}
        onEndReachedThreshold={0.8}
        refreshControl={
          <RefreshControl
              refreshing={onRefreshBoolean}
              onRefresh={()=> callCustomerDataRefresh()}
              title={"Pull down to sync customer data."}
          />
        }
        // onRefresh={() => {console.log("pulled up to relresh")}}
        // refreshing={false}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: SPLASH_LOGO_WIDTH,
    height: SPLASH_LOGO_HEIGHT,
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    customerApiSuccessResponse: reduxStore.customer.customerApiSuccessResponse,
    customerOnScrollApiSuccess: reduxStore.customer.customerOnScrollApiSuccess,
    customerApiHttpError: reduxStore.customer.customerApiHttpError,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      customerListRequest,
      customerListToRedux,
      customerListRequestOnScroll,
      resetOnScrollRequest,
        resetCustomerHttpApiError,
      resetCustomerRedux,
      selectCustomerAction,
      resetShipToAddressResponseAction
    })(CustomersTab),
  ),
);
