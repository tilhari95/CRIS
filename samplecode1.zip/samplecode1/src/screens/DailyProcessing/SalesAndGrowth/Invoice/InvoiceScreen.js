import React, {useState} from 'react';
import {Dimensions, StyleSheet, View, TouchableOpacity} from 'react-native';
import GenericTemplate from '../../../../components/GenericTemplate/GenericTemplate';
import {default as DeviceInfo} from 'react-native-device-info';
import ListTab from '../TicketProcessing/ScreenLeftPanel/ListTab';
import HistoryTab from '../TicketProcessing/ScreenLeftPanel/HistoryTab';
import HotKeyTab from '../TicketProcessing/ScreenLeftPanel/HotKeyTab';
import TemplateTab from '../TicketProcessing/ScreenLeftPanel/TemplateTab';
import ItemProcessing from '../TicketProcessing/ScreenRightPanel/ItemProcessing';
import {ROUTE_ITEM_PROCESSING} from '../../../../resources/constants/navigationConstants';
import {ROUTE_PAYMENT_SIGNATURE_SCREEN} from '../../../../resources/constants/navigationConstants';

import {
  AUTH_STACK_CONTAINER_WIDTH,
  AUTH_STACK_LOGO_HEIGHT,
  AUTH_STACK_LOGO_WIDTH,
  INPUT_FIELD_HEIGHT,
  MODAL_CONTAINER_WIDTH,
  SPACING_10,
  SPACING_15,
  SPACING_30,
  TEXT_SIZE_15,
} from '../../../../resources/constants/dimensions';
import {
  APP_BLUE_COLOR,
  COLORS,
  ERROR_COLOR,
  FIELD_BORDER_RADIUS,
  FIELD_BORDER_WIDTH,
  GENERIC_BACKGROUND_COLOR,
  HEADER_FONT_WEIGHT,
  INPUT_FIELD_BORDER_COLOR,
  MODAL_BACKDROP_OPACITY,
  PRODUCT_BORDER_COLOR,
  TEXT_FONT_WEIGHT,
} from '../../../../resources/constants/themeConstant';
import {Header, Text, Icon, Badge} from 'react-native-elements';

import {connect} from 'react-redux';
import withLoadingSpinner from '../../../../components/HOC/withLoadingSpinner';
import withHttpsApiErrorHandling from '../../../../components/HOC/withHttpsApiErrorHandling';
import {SceneMap, TabBar, TabView} from 'react-native-tab-view';
import withBadge from '../../../../components/HOC/withBadge';

const InvoiceScreen = ({
  navigation,
  setLoadingSpinnerVisibility,
  showHttpsApiErrorDialog,
  setPasswordReduxInitialState: _setPasswordReduxInitialState,
  resetPasswordRequest: _resetPasswordRequest,
  setHttpResetErrorToInitial: _setHttpResetErrorToInitial,
  resetSuccessResponse,
  resetFailError,
  resetPasswordHttpError,
  getItemsRequest: _getItemsRequest,
  brandSuccessResponse,
  getItemSuccessResponse,
  selectedCustomer,
  addedItemsList,
}) => {
  const [index, setIndex] = useState(0);
  const [routes] = useState([
    {
      key: '1',
      title: 'List',
    },
    {
      key: '2',
      title: 'History',
    },
    {
      key: '3',
      title: 'Hot Keys',
    },
    {
      key: '4',
      title: 'Templates',
    },
  ]);

  const renderTabBar = (props) => {
    return (
      <TabBar
        {...props}
        indicatorStyle={{backgroundColor: APP_BLUE_COLOR, height: 7}}
        inactiveColor="black"
        activeColor={APP_BLUE_COLOR}
        tabStyle={{backgroundColor: COLORS.grayMedium}}
        renderLabel={({route, focused, color}) => (
          <Text style={{color}}>{route.title}</Text>
        )}
      />
    );
  };

  const List = () => <ListTab navigation={navigation} />;
  const HotKeys = () => <HotKeyTab navigation={navigation} />;
  const History = () => <HistoryTab navigation={navigation} />;
  const Template = () => <TemplateTab navigation={navigation} />;

  const initialLayout = {width: Dimensions.get('window').width, height: 200};

  const renderScene = SceneMap({
    1: List,
    2: History,
    3: HotKeys,
    4: Template,
  });

  const BadgedIcon = withBadge(addedItemsList.length)(Icon);

  return (
    <GenericTemplate
      navigation={navigation}
      style={{
        flex: 1,
      }}>
      {/* Header   */}

      <Header
        leftComponent={
          <Icon
            name="arrow-back"
            type="MaterialIcons"
            color="white"
            onPress={() => navigation.pop()}
            size={40}
          />
        }
        centerComponent={
          <Text style={styles.headerTitle}>{selectedCustomer.CustomerName}</Text>
        }
        rightComponent={
          DeviceInfo.isTablet() ? null : (
            <TouchableOpacity
              onPress={() => navigation.navigate(ROUTE_ITEM_PROCESSING)}>
              <BadgedIcon
                name="shopping-cart"
                type="MaterialIcons"
                color="white"
                size={30}
              />
            </TouchableOpacity>
          )
        }
      />

      <View style={{flexDirection: 'row', flex: 1}}>
        {/* Mobile View left pannel*/}
        <View
          style={[DeviceInfo.isTablet() ? {width: '40%'} : {width: '100%'}]}>
          <TabView
            navigationState={{index, routes}}
            renderScene={renderScene}
            onIndexChange={setIndex}
            initialLayout={initialLayout}
            renderTabBar={renderTabBar}
            lazy
          />
        </View>
        {DeviceInfo.isTablet() ? <View style={styles.deviderStyle} /> : null}

        {/* Tab View right pannel */}
        {DeviceInfo.isTablet() ? (
          <View style={styles.tabViewContainer}>
            <ItemProcessing navigation={navigation} />
          </View>
        ) : null}
      </View>
    </GenericTemplate>
  );
};

const styles = StyleSheet.create({
  deviderStyle: {
    backgroundColor: COLORS.grayDark,
    height: '100%',
    width: 1
  },
  headerTitle: {
    color: COLORS.white,
    fontSize: 22,
    alignContent: 'center',
    paddingBottom: 5,
    fontWeight: 'bold',
  },
  tabViewHeader: {
    flex: 2,
  },
  tabViewBody: {
    backgroundColor: 'blue',
    flex: 4,
  },
  tabViewFooter: {
    flex: 0.5,
  },
  tabViewContainer: {
    flex: 1,
    flexDirection: 'column',
    width: '60%',
  },
  authStackLogo: {
    width: AUTH_STACK_LOGO_WIDTH,
    height: AUTH_STACK_LOGO_HEIGHT,
    alignItems: 'center',
  },
  container: {
    //  justifyContent: 'center',
    alignItems: 'center',
  },
  inputContainerStyle: {
    borderBottomWidth: FIELD_BORDER_WIDTH,
    borderWidth: FIELD_BORDER_WIDTH,
    borderStyle: 'solid',
    borderColor: INPUT_FIELD_BORDER_COLOR,
    height: INPUT_FIELD_HEIGHT,
    padding: SPACING_10,
    // width:AUTH_STACK_CONTAINER_WIDTH,
    borderRadius: FIELD_BORDER_RADIUS,
  },
  authHeaderStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    textAlign: 'center',
    marginTop: SPACING_30,
  },
  ForgetPassStyle: {
    fontWeight: TEXT_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'right',
    textDecorationLine: 'underline',
    marginTop: SPACING_15,
  },
  errorStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'center',
    color: ERROR_COLOR,
    marginTop: SPACING_30,
  },
  overlay: {
    backgroundColor: GENERIC_BACKGROUND_COLOR,
    opacity: MODAL_BACKDROP_OPACITY,
  },
  overlayModalStyle: {
    borderWidth: FIELD_BORDER_WIDTH,
    borderColor: INPUT_FIELD_BORDER_COLOR,
    width: MODAL_CONTAINER_WIDTH,
  },
  modalErrorStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'center',
    //color:ERROR_COLOR,
    marginBottom: SPACING_30,
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    // resetSuccessResponse: reduxStore.resetPassword.resetSuccessResponse,
    // resetFailError: reduxStore.resetPassword.resetFailError,
    // resetPasswordHttpError: reduxStore.resetPassword.resetPasswordHttpError,
    // brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    // getItemSuccessResponse: reduxStore.items.getItemSuccessResponse,
    selectedCustomer: reduxStore.customer.selectedCustomer,
    addedItemsList: reduxStore.orderLine.addedItemsList,
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      // resetPasswordRequest,
      // setPasswordReduxInitialState,
      // setHttpResetErrorToInitial,
      // getItemsRequest,
    })(InvoiceScreen),
  ),
);
