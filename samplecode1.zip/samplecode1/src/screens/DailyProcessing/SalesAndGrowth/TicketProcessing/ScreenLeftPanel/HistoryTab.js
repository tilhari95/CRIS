import React, {useState, useEffect} from 'react';
import {
  Text,
  FlatList,
  RefreshControl,
  View,
  StyleSheet,
  TouchableWithoutFeedback,
} from 'react-native';
import {connect} from 'react-redux';
import withHttpsApiErrorHandling from '../../../../../components/HOC/withHttpsApiErrorHandling';
import withLoadingSpinner from '../../../../../components/HOC/withLoadingSpinner';
import {
  getItemHistoryApiRequestAction,
  resetItemHistoryApiErrorAction,
  resetItemHistoryApiHttpError,
  itemHistoryOnScrollRequestAction,
  resetItemHistoryListOnScrollAction,
  resetItemHistoryApiResponseAction,
} from '../../../../../store/itemHistory/itemHistoryAction';
import {validateRequiredField} from '../../../../../utils/validators';
import ItemCardTemplate from '../../../../../components/GenericTemplate/ItemCardTemplate';
import Toast from 'react-native-simple-toast';
import ItemDetailDialogTemplate from '../../../../../components/GenericTemplate/ItemDetailDialogTemplate';
import {
  itemDetailApiRequestAction,
  resetItemDataResponseAction,
  resetItemDetailApiErrorAction,
  resetItemDetailApiHttpErrorAction,
} from '../../../../../store/item/itemAction';

const HistoryTab = ({
  navigation,
  getItemHistoryApiRequestAction: _getItemHistoryApiRequestAction,
  resetItemHistoryApiErrorAction: _resetItemHistoryApiErrorAction,
  resetItemHistoryApiHttpError: _resetItemHistoryApiHttpError,
  itemHistoryList,
  itemHistoryApiError,
  itemHistoryApiHttpError,
  selectedCustomer,
  brandSuccessResponse,
  setLoadingSpinnerVisibility,
  showHttpsApiErrorDialog,
  itemHistoryOnScrollRequestAction: _itemHistoryOnScrollRequestAction,
  itemHistoryListOnScroll,
  resetItemHistoryListOnScrollAction: _resetItemHistoryListOnScrollAction,
  resetItemHistoryApiResponseAction: _resetItemHistoryApiResponseAction,
  itemDetailApiRequestAction: _itemDetailApiRequestAction,
  resetItemDataResponseAction: _resetItemDataResponseAction,
  itemDetail,
  itemDetailFailError,
  itemDetailHttpError,
  resetItemDetailApiErrorAction: _resetItemDetailApiErrorAction,
  resetItemDetailApiHttpErrorAction: _resetItemDetailApiHttpErrorAction,

}) => {
  const [itemList, setItemList] = useState('');
  const [onScrollFlag, setOnScrollFlag] = useState(true);
  const [onRefreshFlag, setOnRefreshFlag] = useState(false);
  const [modelVisibility, setModelVisibility] = useState(false);
  const [tappedItem, setTappedItem] = useState(null);
  const [newItemDetail, setNewItemDetail] = useState('');

  useEffect(() => {
    if (itemHistoryList != null) {
      console.log('ITEM HIRSTY LIST legth', itemHistoryList.length);
      setLoadingSpinnerVisibility(false);
      setOnRefreshFlag(false);

      if (itemHistoryList.length > 0) {
        updateItemListOnUI(itemHistoryList, false);
      } else {
        //Toast.showWithGravity('No History found.', Toast.SHORT, Toast.CENTER);
      }
    } else {
      setLoadingSpinnerVisibility(true);
      _getItemHistoryApiRequestAction(
        brandSuccessResponse.CompanyId,
        selectedCustomer.CustomerId,
        0,
      );
    }
  }, [itemHistoryList]);

  useEffect(() => {
    console.log('New History item on scroll', itemHistoryListOnScroll);

    if (itemHistoryListOnScroll != null) {
      setLoadingSpinnerVisibility(false);
      updateItemListOnUI(itemHistoryListOnScroll, true);
      _resetItemHistoryListOnScrollAction();
    }
  }, [itemHistoryListOnScroll]);

  useEffect(() => {
    if (itemHistoryApiError != null) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(itemHistoryApiError);
      _resetItemHistoryApiErrorAction();
    }
  }, [itemHistoryApiError]);

  useEffect(() => {
    if (itemHistoryApiHttpError != null) {
     setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(itemHistoryApiHttpError);
      _resetItemHistoryApiHttpError();
    }
  }, [itemHistoryApiHttpError]);

  const updateItemListOnUI = (items, toBeConcat) => {
    if (toBeConcat) {
      let prevList = itemList;
      let newList = prevList.concat(items);
      setItemList(newList);
    } else {
      setItemList(items);
    }
  };

  const callItemPagingOnScroll = () => {
    let currentListLength = itemList.length;
    console.log('Scroll current list length', currentListLength);

    if (currentListLength > 14) {
      setLoadingSpinnerVisibility(true);
      _itemHistoryOnScrollRequestAction(
        brandSuccessResponse.CompanyId,
        selectedCustomer.CustomerId,
        currentListLength + 15,
      );
    }
  };

  const callItemDataRefresh = () => {
    setOnRefreshFlag(true)
    _resetItemHistoryApiResponseAction();
  }

  useEffect(() => {
    if (itemDetail != null) {
      setNewItemDetail(itemDetail);
      setLoadingSpinnerVisibility(false);
      setModelVisibility(true);
    }
  }, [itemDetail]);

  useEffect(() => {
    if (itemDetailFailError != null) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(itemDetailFailError);
      _resetItemDetailApiErrorAction();
    }
  }, [itemDetailFailError]);

  useEffect(() => {
    if (itemDetailHttpError != null) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(itemDetailHttpError);
      _resetItemDetailApiHttpErrorAction();
    }
  }, [itemDetailHttpError]);

  return (
    <View style={styles.container}>
      {
        (validateRequiredField(itemList) && itemList.length > 0) ?
            <FlatList
                data={itemList}
                renderItem={({item, index, separators}) => (
                    <TouchableWithoutFeedback
                        onPress={() => {
                          setTappedItem(item);
                          console.log('Item CLIKCed - ', tappedItem);
                          setLoadingSpinnerVisibility(true);
                          _itemDetailApiRequestAction(item.Id, selectedCustomer.CustomerId);
                        }}>
                      <View>
                        <ItemCardTemplate item={item}/>
                      </View>
                    </TouchableWithoutFeedback>
                )}
                keyExtractor={(item, index) => index.toString()}
                style={{width: '100%'}}
                onEndReached={() => callItemPagingOnScroll()}
                onEndReachedThreshold={0.8}
                refreshControl={
                  <RefreshControl
                      refreshing={onRefreshFlag}
                      onRefresh={() => callItemDataRefresh()}
                      title={'Pull down to sync item data.'}
                  />
                }
            />
            :
            <View
                style={{
                  justifyContent: 'center',
                  alignItems: 'center',
                  height: 50,
                }}>
              <Text>No History Found.</Text>
            </View>
      }
       <ItemDetailDialogTemplate
        overlayVisible = {modelVisibility}
        itemDetail = {newItemDetail}
        onAddPress = {() => console.log("Add called")}
        onCancelPress = {() => {
            console.log("Cancel Btn clicked");
            _resetItemDataResponseAction();
            setModelVisibility(false);
         }}
        />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    itemHistoryList: reduxStore.itemsHistory.itemHistoryList,
    itemHistoryApiError: reduxStore.itemsHistory.itemHistoryApiError,
    itemHistoryApiHttpError: reduxStore.itemsHistory.itemHistoryApiHttpError,
    selectedCustomer: reduxStore.customer.selectedCustomer,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    itemHistoryListOnScroll: reduxStore.itemsHistory.itemHistoryListOnScroll,
    itemDetail: reduxStore.items.itemDetail,
    itemDetailFailError: reduxStore.items.itemDetailFailError,
    itemDetailHttpError: reduxStore.items.itemDetailHttpError,
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      getItemHistoryApiRequestAction,
      resetItemHistoryApiErrorAction,
      resetItemHistoryApiHttpError,
      itemHistoryOnScrollRequestAction,
      resetItemHistoryListOnScrollAction,
      resetItemHistoryApiResponseAction,
      itemDetailApiRequestAction,
      resetItemDataResponseAction,
      resetItemDetailApiErrorAction,
      resetItemDetailApiHttpErrorAction,
    })(HistoryTab),
  ),
);
