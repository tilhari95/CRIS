import React, {useEffect, useState} from 'react';
import {
  Text,
  View,
  StyleSheet,
  FlatList,
  TouchableWithoutFeedback,
} from 'react-native';
import withLoadingSpinner from '../../../../../components/HOC/withLoadingSpinner';
import withHttpsApiErrorHandling from '../../../../../components/HOC/withHttpsApiErrorHandling';
import {connect} from 'react-redux';
import {
  SearchBar,
  ListItem,
  Avatar,
  Overlay,
  Button,
} from 'react-native-elements';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Toast from "react-native-simple-toast";

import {
  getItemsRequest,
  getItemApiSuccess,
  getItemOnScrollRequest,
  resetItemList,
  resetItemApiFailError,
  resetGetItemHttpError,
  getItemOnSearchApiRequest,
  resetItemSearchResponse,
  itemDetailApiRequestAction,
  resetItemDataResponseAction,
  resetItemListOnScrollAction,
  resetItemDetailApiErrorAction,
  resetItemDetailApiHttpErrorAction
} from '../../../../../store/item/itemAction';

import {
  BLACK_COLOR,
  COLORS,
  GENERIC_BACKGROUND_COLOR,
} from '../../../../../resources/constants/themeConstant';
import {validateRequiredField} from '../../../../../utils/validators';
import {
  getItemsListFromRealm,
  resetItemTable,
} from '../../../../../realm/Models/itemModel';
import {RefreshControl} from 'react-native';
import {SEARCH_PLACEHOLDER} from '../../../../../resources/constants/stringConstants';
import ItemCardTemplate from '../../../../../components/GenericTemplate/ItemCardTemplate';
import ItemDetailDialogTemplate from '../../../../../components/GenericTemplate/ItemDetailDialogTemplate';

const ListTab = ({
  navigation,
  itemsList,
  brandSuccessResponse,
  selectedCustomer,
  getItemsRequest: _getItemsRequest,
  setLoadingSpinnerVisibility,
  showHttpsApiErrorDialog,
  getItemApiSuccess: _getItemApiSuccess,
  getItemOnScrollRequest: _getItemOnScrollRequest,
  resetItemList: _resetItemList,
  getItemHttpError,
  getItemFailError,
  resetItemApiFailError: _resetItemApiFailError,
  resetGetItemHttpError: _resetGetItemHttpError,
  itemListOnSearch,
  getItemOnSearchApiRequest: _getItemOnSearchApiRequest,
  resetItemSearchResponse: _resetItemSearchResponse,
  itemDetailApiRequestAction: _itemDetailApiRequestAction,
  itemDetail,
  resetItemDataResponseAction: _resetItemDataResponseAction,
  itemListOnScroll,
  resetItemListOnScrollAction: _resetItemListOnScrollAction,
  itemDetailFailError,
  itemDetailHttpError,
  resetItemDetailApiErrorAction: _resetItemDetailApiErrorAction,
  resetItemDetailApiHttpErrorAction: _resetItemDetailApiHttpErrorAction
}) => {
  const [itemList, setItemList] = useState('');
  // const [onScrollFlag, setOnScrollFlag] = useState(true);
  const [onRefreshFlag, setOnRefreshFlag] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [showSearchLoading, setShowSearchLoading] = useState(false);
  const [modelVisibility, setModelVisibility] = useState(false);
  const [tappedItem, setTappedItem] = useState(null);
  const [newItemDetail, setNewItemDetail] = useState('');

  useEffect(() => {
    console.log('ITEM LIST');
    console.log(itemsList);

    if (validateRequiredField(itemsList)) {
      console.log('ITEM LIST legth', itemsList.length);
      setLoadingSpinnerVisibility(false);
      updateItemListOnUI(itemsList, false);
    } else {
      getItemListFromLocalDB(0);
    }
  }, [itemsList]);

  useEffect(() => {
    if (getItemFailError != null) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(getItemFailError);
      _resetItemApiFailError();
    }
  }, [getItemFailError]);

  useEffect(() => {
    if (getItemHttpError != null) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(getItemHttpError);
      _resetGetItemHttpError();
    }
  }, [getItemHttpError]);

  useEffect(() => {
    setShowSearchLoading(false);

    if (itemListOnSearch != null && itemListOnSearch.length >= 0) {
      updateItemListOnUI(itemListOnSearch, false);
    } else {
      updateItemListOnUI(itemsList, false);
    }
  }, [itemListOnSearch]);

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      if (searchText != '') {
        setShowSearchLoading(true);
        _getItemOnSearchApiRequest(
          brandSuccessResponse.CompanyId,
          selectedCustomer.CustomerId,
          0,
          searchText,
        );
      } else {
        // updateItemListOnUI(itemsList, false);
        onSearchClear();
      }
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [searchText]);

  useEffect(() => {
    if (itemDetail != null) {
      setNewItemDetail(itemDetail);
      setLoadingSpinnerVisibility(false);
      setModelVisibility(true);
    }
  }, [itemDetail]);

  useEffect(() => {
    if (itemDetailFailError != null) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(itemDetailFailError);
      _resetItemDetailApiErrorAction();
    }
  }, [itemDetailFailError]);

  useEffect(() => {
    if (itemDetailHttpError != null) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(itemDetailHttpError);
      _resetItemDetailApiHttpErrorAction();
    }
  }, [itemDetailHttpError]);

  const updateItemListOnUI = (items, toBeConcat) => {
    if (toBeConcat) {
      let prevList = itemList;
      let newList = prevList.concat(items);
      setItemList(newList);
    } else {
      setItemList(items);
    }
  };

  useEffect(() => {
    if(validateRequiredField(itemListOnScroll)){
      console.log('New item from scroll --', itemListOnScroll);
      updateItemListOnUI(itemListOnScroll, true)
      _resetItemListOnScrollAction();
    }
  }, [itemListOnScroll])

  const getItemListFromLocalDB = async (offset) => {
    let itemListFromRealm = await getItemsListFromRealm(offset);
    console.log('Item List from DB on ListTab ', itemListFromRealm);

    if (
      validateRequiredField(itemListFromRealm) &&
      itemListFromRealm.length > 0
    ) {
      console.log(itemListFromRealm.length);
      if (offset === 0) {
        _getItemApiSuccess(itemListFromRealm);
      } else {
        updateItemListOnUI(itemListFromRealm, true);
      }

      // setOnScrollFlag(true);
    } else {
      if (offset === 0) {
        setLoadingSpinnerVisibility(true);
        _getItemsRequest(
          brandSuccessResponse.CompanyId,
          selectedCustomer.CustomerId,
          0,
        );
      } else {
        _getItemOnScrollRequest(
          brandSuccessResponse.CompanyId,
          selectedCustomer.CustomerId,
          offset,
        );
      }
    }
  };

  const callItemPagingOnScroll = () => {
    let currentListLength = itemList.length;

    if (currentListLength > 19) {
      console.log('Scroll current list length', currentListLength);
      // setOnScrollFlag(false);
      getItemListFromLocalDB(currentListLength);
    }
  };

  const callItemDataRefresh = async () => {
    setOnRefreshFlag(true);
    await resetItemTable();
    _resetItemList();
    setOnRefreshFlag(false);
  };

  const updateSearch = (search) => {
    setSearchText(search);
  };

  const onSearchClear = () => {
    _resetItemSearchResponse();
  };

  return (
    <View style={styles.container}>
      <SearchBar
        inputContainerStyle={{backgroundColor: GENERIC_BACKGROUND_COLOR}}
        placeholder={SEARCH_PLACEHOLDER}
        inputStyle={{color: BLACK_COLOR}}
        lightTheme
        containerStyle={{width: '100%'}}
        onChangeText={updateSearch}
        value={searchText}
        onClear={onSearchClear}
        showLoading={showSearchLoading}
      />
      <FlatList
        data={itemList}
        renderItem={({item, index, separators}) => (
          <TouchableWithoutFeedback
            onPress={() => {
              setTappedItem(item);
              console.log('Item CLIKCed - ', tappedItem);
              setLoadingSpinnerVisibility(true);
              _itemDetailApiRequestAction(item.Id, selectedCustomer.CustomerId);
            }}>
            <View>
              <ItemCardTemplate item={item} />
            </View>
          </TouchableWithoutFeedback>
        )}
        keyExtractor={(item, index) => index.toString()}
        style={{width: '100%'}}
        onEndReached={() => callItemPagingOnScroll()}
        onEndReachedThreshold={0.8}
        refreshControl={
          <RefreshControl
            refreshing={onRefreshFlag}
            onRefresh={() => callItemDataRefresh()}
            title={'Pull down to sync item data.'}
          />
        }
      />
      <ItemDetailDialogTemplate
        overlayVisible = {modelVisibility}
        itemDetail = {newItemDetail}
        onAddPress = {() => {
          _resetItemDataResponseAction();
          setModelVisibility(false);
          Toast.showWithGravity("Item added successfully.", Toast.LONG, Toast.CENTER);
        }}
        onCancelPress = {() => {
            _resetItemDataResponseAction();
            setModelVisibility(false);
         }}
        />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    width: 100,
    backgroundColor: COLORS.pink,
  },
  footer: {
    height: 40,
    flexDirection: 'row',
    margin: 10,
    width: '100%',
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    itemsList: reduxStore.items.itemsList,
    selectedCustomer: reduxStore.customer.selectedCustomer,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    getItemHttpError: reduxStore.items.getItemHttpError,
    getItemFailError: reduxStore.items.getItemFailError,
    itemListOnSearch: reduxStore.items.itemListOnSearch,
    itemDetail: reduxStore.items.itemDetail,
    itemListOnScroll: reduxStore.items.itemListOnScroll,
    itemDetailFailError: reduxStore.items.itemDetailFailError,
    itemDetailHttpError: reduxStore.items.itemDetailHttpError,
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      getItemsRequest,
      getItemApiSuccess,
      getItemOnScrollRequest,
      resetItemList,
      resetGetItemHttpError,
      resetItemApiFailError,
      getItemOnSearchApiRequest,
      resetItemSearchResponse,
      itemDetailApiRequestAction,
      resetItemDataResponseAction,
      resetItemListOnScrollAction,
      resetItemDetailApiErrorAction,
      resetItemDetailApiHttpErrorAction
    })(ListTab),
  ),
);
