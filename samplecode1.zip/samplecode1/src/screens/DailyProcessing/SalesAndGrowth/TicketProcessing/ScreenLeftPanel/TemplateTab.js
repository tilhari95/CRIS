import React, {useEffect, useState} from 'react';
import {
  Text,
  StyleSheet,
  View,
  RefreshControl,
  FlatList,
  TouchableWithoutFeedback,
  Button,
} from 'react-native';
import {connect} from 'react-redux';
import withHttpsApiErrorHandling from '../../../../../components/HOC/withHttpsApiErrorHandling';
import withLoadingSpinner from '../../../../../components/HOC/withLoadingSpinner';
import {
  getTemplateListApiRequestAction,
  resetTemplateListResponseAction,
  resetTemplateListApiFailAction,
  resetTemplateListApiHttpErrorAction,
  templateItemApiRequestAction,
  resetTemplateItemRequestSuccessAction,
  resetTemplateItemApiFailErrorAction,
  resetTemplateItemApiHttpErrorAction
} from '../../../../../store/template/templateAction';
import {Card, Icon} from 'react-native-elements';
import FlipComponent from 'react-native-flip-component';
import ItemCardTemplate from '../../../../../components/GenericTemplate/ItemCardTemplate';
import {validateRequiredField} from '../../../../../utils/validators';
import{
  resetItemDetailApiErrorAction,
  resetItemDetailApiHttpErrorAction,
  itemDetailApiRequestAction,
  resetItemDataResponseAction,
} from '../../../../../store/item/itemAction';
import ItemDetailDialogTemplate from '../../../../../components/GenericTemplate/ItemDetailDialogTemplate';

const TemplateTab = ({
  navigation,
  selectedCustomer,
  brandSuccessResponse,
  templateList,
  templateListApiFailError,
  templateListApiHttpError,
  getTemplateListApiRequestAction: _getTemplateListApiRequestAction,
  resetTemplateListApiFailAction: _resetTemplateListApiFailAction,
  resetTemplateListApiHttpErrorAction: _resetTemplateListApiHttpErrorAction,
  templateItemApiRequestAction: _templateItemApiRequestAction,
  resetTemplateItemApiFailErrorAction: _resetTemplateItemApiFailErrorAction,
  resetTemplateItemApiHttpErrorAction: _resetTemplateItemApiHttpErrorAction,
  resetTemplateItemRequestSuccessAction: _resetTemplateItemRequestSuccessAction,
  templateItemList,
  templateItemApiFailError,
  templateItemHttpApiError,
  showHttpsApiErrorDialog,
  setLoadingSpinnerVisibility,
  itemDetailFailError,
  itemDetailHttpError,
  resetItemDetailApiErrorAction: _resetItemDetailApiErrorAction,
  resetItemDetailApiHttpErrorAction: _resetItemDetailApiHttpErrorAction,
  itemDetailApiRequestAction: _itemDetailApiRequestAction,
  itemDetail,
  resetItemDataResponseAction: _resetItemDataResponseAction,
}) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const [selectedTemplateId, setSelectedTemplateId] = useState('');
  const [modelVisibility, setModelVisibility] = useState(false);
  const [tappedItem, setTappedItem] = useState(null);
  const [newItemDetail, setNewItemDetail] = useState('');

  useEffect(() => {
    if (templateList != null) {
      setLoadingSpinnerVisibility(false);
      console.log('TEMPLATE LIST', templateList);
    } else {
      setLoadingSpinnerVisibility(true);
      _getTemplateListApiRequestAction(brandSuccessResponse.CompanyId);
    }
  }, [templateList]);

  useEffect(() => {
    if(templateItemList != null){
      setLoadingSpinnerVisibility(false);
      setIsFlipped(true);
    }
  }, [templateItemList])

  useEffect(() => {
    if (selectedTemplateId != '') {
      setLoadingSpinnerVisibility(true);
      _templateItemApiRequestAction(
        selectedTemplateId,
        brandSuccessResponse.CompanyId,
        selectedCustomer.CustomerId
      )
    }
  }, [selectedTemplateId]);


  useEffect(() => {
    if (templateItemApiFailError != null) {
      setLoadingSpinnerVisibility(false);
      setIsFlipped(false);
      showHttpsApiErrorDialog(templateItemApiFailError);
      _resetTemplateItemApiFailErrorAction();
    }
  }, [templateItemApiFailError]);

  useEffect(() => {
    if (templateItemHttpApiError != null) {
      setLoadingSpinnerVisibility(false);
      setIsFlipped(false);
      showHttpsApiErrorDialog(templateItemHttpApiError);
      _resetTemplateItemApiHttpErrorAction();
    }
  }, [templateItemHttpApiError]);

  useEffect(() => {
    if (templateListApiFailError != null) {
      setLoadingSpinnerVisibility(false);
      setIsFlipped(false);
      showHttpsApiErrorDialog(templateListApiFailError);
      _resetTemplateListApiFailAction();
    }
  }, [templateListApiFailError]);

  useEffect(() => {
    if (templateListApiHttpError != null) {
      setLoadingSpinnerVisibility(false);
      setIsFlipped(false);
      showHttpsApiErrorDialog(templateListApiHttpError);
      _resetTemplateListApiHttpErrorAction();
    }
  }, [templateListApiHttpError]);

  useEffect(() => {
    if (itemDetail != null) {
      setNewItemDetail(itemDetail);
      setLoadingSpinnerVisibility(false);
      setModelVisibility(true);
    }
  }, [itemDetail]);

  useEffect(() => {
    if (itemDetailFailError != null) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(itemDetailFailError);
      _resetItemDetailApiErrorAction();
    }
  }, [itemDetailFailError]);

  useEffect(() => {
    if (itemDetailHttpError != null) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(itemDetailHttpError);
      _resetItemDetailApiHttpErrorAction();
    }
  }, [itemDetailHttpError]);


  const renderItem = ({item, index, separators}) => (
    <TouchableWithoutFeedback
      onPress={() => {
        console.log(item.TemplateId);
        setSelectedTemplateId(item.TemplateId);
        console.log(item);
      }}>
      <Card>
        <Text>{item.TemplateName}</Text>
      </Card>
    </TouchableWithoutFeedback>
  );

  return (
    <View style={styles.container}>
      <FlipComponent
        isFlipped={isFlipped}
        frontView={
          <FlatList
            data={templateList}
            renderItem={renderItem}
            keyExtractor={(item, index) => index.toString()}
          />
        }
        backView={
          <View>
            <Icon
              name="arrow-back"
              type="MaterialIcons"
              color="black"
              onPress={() => {
                setSelectedTemplateId('');
                setIsFlipped(false);
                _resetTemplateItemRequestSuccessAction()
              }}
              size={30}
              style={{alignItems: 'flex-start', margin: 5}}
            />
            <FlatList
              data={templateItemList}
              renderItem={({item, index, separators}) => (
                <TouchableWithoutFeedback
                  onPress={() => {
                    setTappedItem(item);
                    console.log('Item CLIKCed - ', tappedItem);
                    setLoadingSpinnerVisibility(true);
                    _itemDetailApiRequestAction(item.ItemId, selectedCustomer.CustomerId);
                  }}>
                  <View>
                    <ItemCardTemplate item={item} />
                  </View>
                </TouchableWithoutFeedback>
              )}
              keyExtractor={(item, index) => index.toString()}
            />
            <ItemDetailDialogTemplate
              overlayVisible = {modelVisibility}
              itemDetail = {newItemDetail}
              onAddPress = {() => console.log("Add called")}
              onCancelPress = {() => {
              console.log("Cancel Btn clicked");
              _resetItemDataResponseAction();
              setModelVisibility(false);
         }}
        />
          </View>
        }
        backStyles={{
          height: '100%',
          width: '100%',
        }}
        containerStyles={{width: '100%', height: '100%'}}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    height: '100%',
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    selectedCustomer: reduxStore.customer.selectedCustomer,
    templateList: reduxStore.template.templateList,
    templateListApiFailError: reduxStore.template.templateListApiFailError,
    templateListApiHttpError: reduxStore.template.templateListApiHttpError,
    templateItemList: reduxStore.template.templateItemList,
    templateItemApiFailError: reduxStore.template.templateItemApiFailError,
    templateItemHttpApiError: reduxStore.template.templateItemHttpApiError,
    itemDetailFailError: reduxStore.items.itemDetailFailError,
    itemDetailHttpError: reduxStore.items.itemDetailHttpError,
    itemDetail: reduxStore.items.itemDetail,
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      getTemplateListApiRequestAction,
      resetTemplateListResponseAction,
      resetTemplateListApiFailAction,
      resetTemplateListApiHttpErrorAction,
      templateItemApiRequestAction,
      resetTemplateItemRequestSuccessAction,
      resetTemplateItemApiFailErrorAction,
      resetTemplateItemApiHttpErrorAction,
      resetItemDetailApiErrorAction,
      resetItemDetailApiHttpErrorAction,
      itemDetailApiRequestAction,
      resetItemDataResponseAction,
    })(TemplateTab),
  ),
);
