import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
  TouchableWithoutFeedback,
} from 'react-native';
import {default as DeviceInfo} from 'react-native-device-info';

import {
  ROUTE_CUSTOMER_DETAIL,
  ROUTE_PAYMENT_SCREEN,
  ROUTE_PAYMENT_EMAIL_SCREEN,
} from '../../../../../resources/constants/navigationConstants';
import SignatureCapture from 'react-native-signature-capture';

import {
  cards_image,
  p_and_s,
  refresh,
  tick,
} from '../../../../../resources/images';
import {Header, Divider} from 'react-native-elements';
import withHttpsApiErrorHandling from '../../../../../components/HOC/withHttpsApiErrorHandling';
import withLoadingSpinner from '../../../../../components/HOC/withLoadingSpinner';
import {connect} from 'react-redux';
import {
  COLORS,
  PaymentMode,
} from '../../../../../resources/constants/themeConstant';

import {
  roundToTwo,
  validateRequiredField,
} from '../../../../../utils/validators';
import {
  getOrderHeaderAPiReqAction,
  resetOrderHeaderApiFailErrAction,
  resetOrderHeaderApiHttpErrAction,
  resetOrderHeaderApiResponseAction,
} from '../../../../../store/OrderHeader/orderHeaderAction';
import {getTodaysDateYYYYMMDD} from '../../../../../utils/date';
import {
  resetOrderLineStoreAction,
  setSignatoryNameAction,
  setSignatureImgDataAction
} from '../../../../../store/OrderLine/orderLineAction';
import Toast from 'react-native-simple-toast';

const PaymentSignatureScreen = ({
  navigation,
  getOrderHeaderAPiReqAction: _getOrderHeaderAPiReqAction,
  resetOrderHeaderApiFailErrAction: _resetOrderHeaderApiFailErrAction,
  resetOrderHeaderApiHttpErrAction: _resetOrderHeaderApiHttpErrAction,
  resetOrderHeaderApiResponseAction: _resetOrderHeaderApiResponseAction,
  orderHeaderApiResponse,
  orderHeaderApiFailErr,
  orderHeaderApiHttpErr,
  setLoadingSpinnerVisibility,
  showHttpsApiErrorDialog,
  orderId,
  brandSuccessResponse,
  selectedCustomer,
  customerInfoApiResponse,
  cartTotal,
  cartSubTotal,
  cartTaxPercent,
  cartTaxValue,
  rewardAmount,
  totalDueAfterReward,
  amountReceived,
  paymentMode,
  balanceDue,
  checkAmount,
  checkNo,
  cashReceived,
  rewardId,
  orderNo,
  resetOrderLineStoreAction: _resetOrderLineStoreAction,
  setSignatoryNameAction: _setSignatoryNameAction,
  setSignatureImgDataAction: _setSignatureImgDataAction
}) => {
  const [showSoldToBar, setShowSoldToBar] = React.useState(true);
  const [showShipToBar, setShowShipToBar] = React.useState(false);
  const [address, setAddress] = React.useState(
    'SPLASH EXPRESS COTATI \n 1245 Santa Rose Eve \n Santa Rose CA 9504',
  );
  const [signatoryName, setSignatoryName] = useState('');
  const [soldToSelected, setSoldToSelected] = useState(true);
  const [isShipToAvailable, setIsShipToAvailable] = useState(false);
  const [customerInfo, setCustomerInfo] = useState('');
  const ref = React.useRef(null);

  useEffect(() => {
    if (validateRequiredField(customerInfoApiResponse)) {
      console.log('CustomerInfo', customerInfoApiResponse);
      setCustomerInfo(customerInfoApiResponse);

      if (validateRequiredField(customerInfoApiResponse.ShippingAddressId)) {
        setIsShipToAvailable(true);
      } else {
        setIsShipToAvailable(false);
      }
    }
  }, [customerInfoApiResponse]);

  useEffect(() => {
    if (validateRequiredField(orderHeaderApiResponse)) {
      setLoadingSpinnerVisibility(false);
      Toast.show('Order header added successfully', Toast.LONG);
      //_resetOrderLineStoreAction();
      _resetOrderHeaderApiResponseAction();

      callPdfpage();
    }
  }, [orderHeaderApiResponse]);



  const callPdfpage = () =>{
    _resetOrderHeaderApiResponseAction();
    navigation.navigate(ROUTE_PAYMENT_EMAIL_SCREEN);
    // setTimeout(()=>{
    //
    // }, 0);

  }


  useEffect(() => {
    if (validateRequiredField(orderHeaderApiFailErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(orderHeaderApiFailErr);
      _resetOrderHeaderApiFailErrAction(orderHeaderApiFailErr);
    }
  }, [orderHeaderApiFailErr]);

  useEffect(() => {
    if (validateRequiredField(orderHeaderApiHttpErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(orderHeaderApiHttpErr);
      _resetOrderHeaderApiHttpErrAction(orderHeaderApiHttpErr);
    }
  }, [orderHeaderApiHttpErr]);

  function saveSign() {
    ref.current.saveImage();
  }

  function resetSign() {
    ref.current.resetImage();
  }

  const _onSaveEvent = (result) => {
    //result.encoded - for the base64 encoded png
    //result.pathName - for the file path name
    _setSignatoryNameAction(signatoryName);
    _setSignatureImgDataAction(result.encoded);
    console.log(result);
  };

  const _onDragEvent = () => {
    // This callback will be called when the user enters signature

    // console.log('dragged');
    // console.log('Customer -- ', selectedCustomer);
    // console.log('Comapny --', brandSuccessResponse);
    // console.log('CustomerInfo -', customerInfoApiResponse);
  };

  const isPaidByCash = () => {
    if (paymentMode == PaymentMode.CASH) {
      return 1;
    } else {
      return 0;
    }
  };

  const isPaidByCheck = () => {
    if (paymentMode == PaymentMode.CHECK) {
      return 1;
    } else {
      return 0;
    }
  };

  const getCheckNo = () => {
    if (paymentMode == PaymentMode.CHECK) {
      return checkNo;
    } else {
      return '';
    }
  };

  const addOrderHeaderApiCall = () => {
    saveSign();
    setLoadingSpinnerVisibility(true);
    _getOrderHeaderAPiReqAction(
      orderId,
      orderNo, //OrderNo
      brandSuccessResponse.CompanyId,
      'N',
      customerInfoApiResponse.CustomerNo,
      '', //Comment1
      '', //Comment2
      selectedCustomer.PostalCode,
      cartSubTotal,
      cartTaxValue,
      rewardAmount, // TODO:// Discount
      isPaidByCash(), //paidCash,
      isPaidByCheck(), //PaidCheck,
      0, //Paid card
      customerInfoApiResponse.ShippingAddressId,
      customerInfoApiResponse.ShipToName,
      getCheckNo(), //CheckNo
      customerInfoApiResponse.CustType,
      selectedCustomer.EmailAddress,
      'I',
      getTodaysDateYYYYMMDD(), // CreatedDate
      getTodaysDateYYYYMMDD(), //TODO:// requestedShipDate
      customerInfoApiResponse.ShipToAddress1,
      customerInfoApiResponse.ShipToCity,
      customerInfoApiResponse.ShipToState,
      customerInfoApiResponse.ShipToZip,
      customerInfoApiResponse.IsPRO,
      customerInfoApiResponse.BillToName,
      customerInfoApiResponse.Address1,
      customerInfoApiResponse.City,
      customerInfoApiResponse.State,
      customerInfoApiResponse.PostalCode,
      brandSuccessResponse.DeviceId,
      selectedCustomer.CustomerId,
      customerInfoApiResponse.TaxScheduleId, //taxScheduleId
      selectedCustomer.CustomerName,
      customerInfoApiResponse.CustomerListId,
      customerInfoApiResponse.TaxSchedule,
      customerInfoApiResponse.Terms,
      rewardId, //Reward Id
    );
  };

  return (
    <View style={styles.container}>
      <Header
        centerComponent={{
          text: selectedCustomer.CustomerName,
          style: {color: '#fff'},
        }}
      />
      <View style={styles.container}>
        {DeviceInfo.isTablet() ? (
          <View style={[styles.container, {flexDirection: 'row'}]}>
            <View style={styles.leftContainer}>
              <View
                style={styles.viewContainer}
                onStartShouldSetResponder={() => navigation.pop()}>
                <Text style={{color: 'blue', fontSize: 50}}>‹</Text>
                <Text style={styles.backButton}>Back</Text>
              </View>

              <View style={{flexDirection: 'row'}}>
                <View style={[styles.leftView, {marginTop: 80}]}>
                  <Image style={{width: 22, height: 22}} source={tick} />
                </View>
                <Text style={[{marginTop: 80}, styles.leftViewText]}>
                  Payment
                </Text>
              </View>

              <View style={styles.leftVerticalLine}></View>

              <View style={{flexDirection: 'row'}}>
                <View style={styles.leftView} />
                <Text style={styles.leftViewText}>Signature</Text>
              </View>

              <View style={styles.leftVerticalLine}></View>

              <View style={{flexDirection: 'row'}}>
                <View style={styles.leftView} />
                <Text style={styles.leftViewText}>Print/Email</Text>
              </View>

              <View style={styles.leftVerticalLine}></View>

              <View style={{flexDirection: 'row'}}>
                <View style={styles.leftView} />
                <Text style={styles.leftViewText}>Survey</Text>
              </View>
            </View>
            <View style={styles.rightContainer}>
              <View style={styles.viewContainer}>
                <View>
                  <View style={{flexDirection: 'column'}}>
                    <Text style={styles.companyName}>
                      {brandSuccessResponse.CompanyName}
                    </Text>
                    <View>
                      <View style={styles.addressSelection}>
                        <TouchableWithoutFeedback
                          on
                          onPress={() => setSoldToSelected(true)}>
                          <View>
                            <Text>Sold To:</Text>
                            <Divider
                              style={[
                                soldToSelected
                                  ? {backgroundColor: 'blue'}
                                  : {backgroundColor: COLORS.grayDark},
                                {},
                              ]}
                            />
                          </View>
                        </TouchableWithoutFeedback>
                        {isShipToAvailable ? (
                          <TouchableWithoutFeedback
                            onPress={() => setSoldToSelected(false)}>
                            <View style={{marginStart: 10}}>
                              <Text>Ship To</Text>
                              <Divider
                                style={[
                                  soldToSelected
                                    ? {backgroundColor: COLORS.grayDark}
                                    : {backgroundColor: 'blue'},
                                  {},
                                ]}
                              />
                            </View>
                          </TouchableWithoutFeedback>
                        ) : null}
                      </View>
                      {soldToSelected ? (
                        <View style={styles.address}>
                          <Text style={styles.textStyle}>
                            {customerInfo.CustomerName}
                          </Text>
                          <Text style={styles.textStyle}>
                            {customerInfo.Address1}
                          </Text>
                          <Text style={styles.textStyle}>
                            {customerInfo.City}
                          </Text>
                          <Text style={styles.textStyle}>
                            {customerInfo.State} , {customerInfo.PostalCode}
                          </Text>
                        </View>
                      ) : (
                        <View style={styles.address}>
                          <Text style={styles.textStyle}>
                            {customerInfo.ShipToName}
                          </Text>
                          <Text style={styles.textStyle}>
                            {customerInfo.ShipToAddress1}
                          </Text>
                          <Text style={styles.textStyle}>
                            {customerInfo.ShipToCity}
                          </Text>
                          <Text style={styles.textStyle}>
                            {customerInfo.ShipToState}, {customerInfo.ShipToZip}
                          </Text>
                        </View>
                      )}
                    </View>
                  </View>
                </View>

                <View style={styles.imageContainer}>
                  <Image style={{width: 80, height: 80}} source={p_and_s} />
                </View>

                <View style={{width: '25%'}}>
                  <View style={[styles.placeTextToRight, {bottom: 0}]}>
                    <Text style={{fontSize: 15}}> Invoice : {orderNo ? orderNo : 'NA'} </Text>
                  </View>
                  {/* <View style={styles.placeTextToRight}>
                    <Text
                      style={styles.returnToTicketContainer}
                      onPress={() =>
                        navigation.navigate(ROUTE_CUSTOMER_DETAIL)
                      }>
                      {' '}
                      Return to Ticket{' '}
                    </Text>
                  </View> */}
                </View>
              </View>

              <View style={styles.rightFullHorizontalLine} />

              <View style={{flex: 1, flexDirection: 'row'}}>
                <View style={{left: 0, position: 'absolute'}}>
                  <Text style={styles.termsAndConditions}>
                    Terms And Conditions
                  </Text>

                  <Text style={styles.bySigningBelowYou}>
                    By Signing below you
                  </Text>
                </View>

                <View
                  style={[
                    styles.placeTextToRight,
                    {marginTop: 50, flexDirection: 'row'},
                  ]}>
                  <View>
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]} />
                    <Text style={[styles.moneyDisplay, {fontSize: 10}]} />
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]}>
                      Reward:
                    </Text>
                    <Text style={[styles.moneyDisplay, {fontSize: 23}]}>
                      Total Due:
                    </Text>
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]}>
                      Received:
                    </Text>
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]}>
                      Balance Due:
                    </Text>
                  </View>
                  <View>
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]}>
                      ${roundToTwo(cartTotal)}
                    </Text>
                    <Text style={[styles.moneyDisplay, {fontSize: 10}]}>
                      plus ${cartTaxPercent} Tax{' '}
                    </Text>
                    <View style={styles.rightBalanceHorizontalLine} />

                    {/* {/ This is for Rewards /} */}
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]}>
                      ${roundToTwo(rewardAmount)}
                    </Text>

                    {/* {/ This is for Total Due /} */}
                    <Text style={[styles.moneyDisplay, {fontSize: 23}]}>
                      ${roundToTwo(totalDueAfterReward)}
                    </Text>

                    {/* {/ This is for Received /} */}
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]}>
                      ${roundToTwo(amountReceived)}
                    </Text>
                    <View style={styles.rightBalanceHorizontalLine} />

                    {/* {/ This is for Balance Due /} */}
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]}>
                      ${roundToTwo(balanceDue)}
                    </Text>
                  </View>
                </View>
              </View>

              <TextInput
                style={styles.signatureTextInput}
                value={signatoryName}
                onChangeText = {setSignatoryName}
                placeholder={'Signatory Name...'}
              />

              <View style={{flexDirection: 'row'}}>
                <Text style={styles.signHere}>Sign Here:</Text>
                <Text style={styles.startOver} onPress={resetSign}>
                  Start Over
                </Text>
              </View>

              <View style={styles.signViewContainer}>
                <SignatureCapture
                  style={styles.signatureCaptureContainer}
                  ref={ref}
                  onSaveEvent={_onSaveEvent}
                  onDragEvent={_onDragEvent}
                  saveImageFileInExtStorage={false}
                  showNativeButtons={false}
                  showTitleLabel={false}
                  backgroundColor="white"
                  strokeColor="black"
                  minStrokeWidth={5}
                  maxStrokeWidth={5}
                  viewMode={'landscape'}
                />
              </View>

              <Text
                style={styles.nextButton}
                // onPress={() => navigation.navigate(ROUTE_PAYMENT_EMAIL_SCREEN)}
                onPress={addOrderHeaderApiCall}>
                Next...
              </Text>
              {/* <FAB title="Create" /> */}
            </View>
          </View>
        ) : null}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  backButton: {
    color: 'blue',
    fontSize: 20,
    padding: 10,
    marginTop: 15,
  },
  leftView: {
    marginLeft: 80,
    height: 26,
    width: 26,
    borderRadius: 100,
    borderWidth: 2,
    backgroundColor: 'white',
    borderColor: 'grey',
  },
  leftViewText: {
    fontSize: 16,
    marginLeft: 30,
  },
  leftVerticalLine: {
    height: 50,
    width: 2,
    marginLeft: 93,
    backgroundColor: 'grey',
  },
  rightSmallHorizontalLine: {
    borderBottomColor: 'blue',
    borderBottomWidth: 1,
  },
  rightFullHorizontalLine: {
    borderBottomColor: 'black',
    borderBottomWidth: 1,
  },
  imageContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeTextToRight: {
    position: 'absolute',
    right: 0,
  },
  textInput: {
    width: 180,
    height: 30,
    marginLeft: 30,
    borderWidth: 1.2,
    padding: 5,
  },
  nextButton: {
    fontSize: 25,
    marginBottom: 10,
    marginRight: 10,
    right: 0,
    bottom: 0,
    position: 'absolute',
    color: 'blue',
  },
  moneyDisplay: {
    fontSize: 18,
    marginRight: 20,
    marginTop: 5,
    textAlign: 'right',
  },
  viewContainer: {
    flexDirection: 'row',
    marginLeft: 10,
  },
  leftContainer: {
    backgroundColor: 'lightgrey',
    width: '40%',
  },
  rightContainer: {
    backgroundColor: 'white',
    width: '60%',
  },
  addressContainer: {
    fontSize: 14,
    marginLeft: 5,
  },
  returnToTicketContainer: {
    fontSize: 15,
    color: 'blue',
    padding: 10,
  },
  termsAndConditions: {
    fontSize: 26,
    padding: 20,
  },
  bySigningBelowYou: {
    color: 'grey',
    marginLeft: 23,
    fontSize: 16,
  },
  signatureTextInput: {
    width: 250,
    height: 30,
    marginBottom: 10,
    marginLeft: 50,
    borderBottomWidth: 1.2,
    padding: 2,
  },
  signHere: {
    fontSize: 20,
    marginLeft: 50,
    marginBottom: 5,
  },
  startOver: {
    fontSize: 14,
    marginRight: 50,
    right: 0,
    position: 'absolute',
    color: 'grey',
  },
  // signViewContainer: {
  //   width: '84%',
  //   height: 150,
  //   marginBottom: 80,
  //   marginLeft: 50,
  //   borderWidth: 1.2,
  //   padding: 5,
  // },
  topBorder: {
    height: 50,
    backgroundColor: '#A865C9',
    fontSize: 25,
    textAlign: 'center',
    padding: 6,
    justifyContent: 'center',
    alignItems: 'center',
    color: '#FFFFFF',
  },
  signViewContainer: {
    width: 525,
    height: 155,
    marginBottom: 80,
    marginLeft: 50,
    borderWidth: 2,
    borderColor: 'grey',
  },
  signatureCaptureContainer: {
    width: 520,
    height: 150,
  },
  addressSelection: {
    flexDirection: 'row',
    alignContent: 'center',
    marginTop: 5,
  },
  address: {
    marginTop: 10,
    marginBottom: 10,
  },
  textStyle: {
    fontSize: 10,
  },
  companyName: {
    marginTop: 10,
    fontWeight: 'bold',
  },
  rightBalanceHorizontalLine: {
    borderBottomWidth: 1,
    borderBottomColor: 'grey',
    marginRight: 20,
    width: 120,
    alignSelf: 'flex-end',
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    orderHeaderApiResponse: reduxStore.orderHeader.orderHeaderApiResponse,
    orderHeaderApiFailErr: reduxStore.orderHeader.orderHeaderApiFailErr,
    orderHeaderApiHttpErr: reduxStore.orderHeader.orderHeaderApiHttpErr,
    orderId: reduxStore.orderLine.orderId,
    selectedCustomer: reduxStore.customer.selectedCustomer,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    customerInfoApiResponse: reduxStore.customerDetail.customerInfoApiResponse,

    cartTotal: reduxStore.orderLine.cartTotal,
    cartSubTotal: reduxStore.orderLine.cartSubTotal,
    cartTaxPercent: reduxStore.orderLine.cartTaxPercent,
    cartTaxValue: reduxStore.orderLine.cartTaxValue,
    rewardAmount: reduxStore.orderLine.rewardAmount,
    totalDueAfterReward: reduxStore.orderLine.totalDueAfterReward,
    amountReceived: reduxStore.orderLine.amountReceived,
    paymentMode: reduxStore.orderLine.paymentMode,
    balanceDue: reduxStore.orderLine.balanceDue,
    checkAmount: reduxStore.orderLine.checkAmount,
    checkNo: reduxStore.orderLine.checkNo,
    cashReceived: reduxStore.orderLine.cashReceived,
    rewardId: reduxStore.orderLine.rewardId,
    orderNo: reduxStore.orderLine.orderNo
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      getOrderHeaderAPiReqAction,
      resetOrderHeaderApiFailErrAction,
      resetOrderHeaderApiHttpErrAction,
      resetOrderLineStoreAction,
      resetOrderHeaderApiResponseAction,
      setSignatoryNameAction,
      setSignatureImgDataAction
    })(PaymentSignatureScreen),
  ),
);
