import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import {default as DeviceInfo} from 'react-native-device-info';

import {
  ROUTE_PAYMENT_EMAIL_SCREEN,
  ROUTE_CUSTOMER_DETAIL,
} from '../../../../../resources/constants/navigationConstants';

import {
  cards_image,
  p_and_s,
  refresh,
  tick,
} from '../../../../../resources/images';
import {Header} from 'react-native-elements';

const PaymentSurveyScreen = ({navigation}) => {
  const [showSoldToBar, setShowSoldToBar] = React.useState(true);
  const [showShipToBar, setShowShipToBar] = React.useState(false);
  const [address, setAddress] = React.useState(
    'SPLASH EXPRESS COTATI \n 1245 Santa Rose Eve \n Santa Rose CA 9504',
  );

  return (
    <View style={styles.container}>
      <Header
        centerComponent={{
          text: 'SPLASH EXPRESS - COTATI',
          style: {color: '#fff'},
        }}
      />
      <View style={styles.container}>
        {DeviceInfo.isTablet() ? (
          <View style={[styles.container, {flexDirection: 'row'}]}>
            <View style={styles.leftContainer}>
              <View
                style={styles.viewContainer}
                onStartShouldSetResponder={() =>
                  navigation.navigate(ROUTE_PAYMENT_EMAIL_SCREEN)
                }>
                <Text style={{color: 'blue', fontSize: 50}}>‹</Text>
                <Text style={styles.backButton}>Back</Text>
              </View>

              <View style={{flexDirection: 'row'}}>
                <View style={[styles.leftView, {marginTop: 80}]}>
                  <Image style={{width: 22, height: 22}} source={tick} />
                </View>
                <Text style={[{marginTop: 80}, styles.leftViewText]}>
                  Payment
                </Text>
              </View>

              <View style={styles.leftVerticalLine}></View>

              <View style={{flexDirection: 'row'}}>
                <View style={styles.leftView}>
                  <Image style={{width: 22, height: 22}} source={tick} />
                </View>
                <Text style={styles.leftViewText}>Signature</Text>
              </View>

              <View style={styles.leftVerticalLine}></View>

              <View style={{flexDirection: 'row'}}>
                <View style={styles.leftView}>
                  <Image style={{width: 22, height: 22}} source={tick} />
                </View>
                <Text style={styles.leftViewText}>Print/Email</Text>
              </View>

              <View style={styles.leftVerticalLine}></View>

              <View style={{flexDirection: 'row'}}>
                <View style={styles.leftView} />
                <Text style={styles.leftViewText}>Survey</Text>
              </View>
            </View>
            <View style={styles.rightContainer}>
              <View style={styles.viewContainer}>
                <View>
                  <View style={{flexDirection: 'column'}}>
                    <Text style={{padding: 10}}>P and S Sales</Text>
                    <View style={{flexDirection: 'row'}}>
                      <View style={{padding: 5}}>
                        <Text
                          onPress={() => {
                            setShowSoldToBar(true);
                            setShowShipToBar(false);
                            setAddress(
                              'SPLASH EXPRESS COTATI \n 1245 Santa Rose Eve \n Santa Rose CA 9504',
                            );
                          }}>
                          SoldTo
                        </Text>
                        {showSoldToBar ? (
                          <View style={styles.rightSmallHorizontalLine} />
                        ) : null}
                      </View>
                      <View style={{padding: 5}}>
                        <Text
                          onPress={() => {
                            setShowSoldToBar(false);
                            setShowShipToBar(true);
                            setAddress(
                              'SPLASH EXPRESS COTATI \n 5421 Santa Rose Eve \n Santa Rose CA 4059',
                            );
                          }}>
                          ShipTo
                        </Text>
                        {showShipToBar ? (
                          <View style={styles.rightSmallHorizontalLine} />
                        ) : null}
                      </View>
                    </View>

                    <View>
                      <Text style={styles.addressContainer}>{address}</Text>
                    </View>
                  </View>
                </View>

                <View style={styles.imageContainer}>
                  <Image style={{width: 80, height: 80}} source={p_and_s} />
                </View>

                <View style={{width: '25%'}}>
                  <View style={styles.placeTextToRight}>
                    <Text style={{fontSize: 15}}> Invoice : 994237 </Text>
                  </View>
                </View>
              </View>

              <View style={styles.rightFullHorizontalLine} />

              <Text style={styles.survey}>Surveys</Text>
              <Text style={styles.nextButton}>Finish...</Text>
            </View>
          </View>
        ) : null}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  survey: {
    fontSize: 26,
    padding: 20,
  },
  backButton: {
    color: 'blue',
    fontSize: 20,
    padding: 10,
    marginTop: 15,
  },
  leftView: {
    marginLeft: 80,
    height: 26,
    width: 26,
    borderRadius: 100,
    borderWidth: 2,
    backgroundColor: 'white',
    borderColor: 'grey',
  },
  leftViewText: {
    fontSize: 16,
    marginLeft: 30,
  },
  leftVerticalLine: {
    height: 50,
    width: 2,
    marginLeft: 93,
    backgroundColor: 'grey',
  },
  rightSmallHorizontalLine: {
    borderBottomColor: 'blue',
    borderBottomWidth: 1,
  },
  rightFullHorizontalLine: {
    borderBottomColor: 'black',
    borderBottomWidth: 1,
  },
  imageContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeTextToRight: {
    position: 'absolute',
    right: 0,
  },
  textInput: {
    width: 180,
    height: 30,
    marginLeft: 30,
    borderWidth: 1.2,
    padding: 5,
  },
  nextButton: {
    fontSize: 25,
    marginBottom: 10,
    marginRight: 10,
    right: 0,
    bottom: 0,
    position: 'absolute',
    color: 'blue',
  },
  moneyDisplay: {
    fontSize: 18,
    marginRight: 20,
    marginTop: 5,
    textAlign: 'right',
  },
  viewContainer: {
    flexDirection: 'row',
    marginLeft: 10,
  },
  leftContainer: {
    backgroundColor: 'lightgrey',
    width: '40%',
  },
  rightContainer: {
    backgroundColor: 'white',
    width: '60%',
  },
  addressContainer: {
    fontSize: 14,
    marginLeft: 5,
  },
  returnToTicketContainer: {
    fontSize: 15,
    color: 'blue',
    padding: 10,
  },
  termsAndConditions: {
    fontSize: 26,
    padding: 20,
  },
  bySigningBelowYou: {
    color: 'grey',
    marginLeft: 23,
    fontSize: 16,
  },
  signatureTextInput: {
    width: 250,
    height: 30,
    marginBottom: 10,
    marginLeft: 50,
    borderBottomWidth: 1.2,
    padding: 2,
  },
  signHere: {
    fontSize: 20,
    marginLeft: 50,
    marginBottom: 5,
  },
  startOver: {
    fontSize: 14,
    marginRight: 50,
    right: 0,
    position: 'absolute',
    color: 'grey',
  },
  signViewContainer: {
    width: '84%',
    height: 150,
    marginBottom: 80,
    marginLeft: 50,
    borderWidth: 1.2,
    padding: 5,
  },
  topBorder: {
    height: 50,
    backgroundColor: '#A865C9',
    fontSize: 25,
    textAlign: 'center',
    padding: 6,
    justifyContent: 'center',
    alignItems: 'center',
    color: '#FFFFFF',
  },
});

export default PaymentSurveyScreen;
