import React, {useEffect, useState} from 'react';
import {
  View,
  StyleSheet,
  FlatList,
  TouchableWithoutFeedback,
} from 'react-native';
import {
  Text,
  Divider,
  Avatar,
  Header,
  Overlay,
  Input,
} from 'react-native-elements';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {default as DeviceInfo} from 'react-native-device-info';
import {
  APP_BLUE_COLOR,
  COLORS,
  FIELD_BORDER_WIDTH,
  GENERIC_BACKGROUND_COLOR,
  HEADER_FONT_WEIGHT,
  INPUT_FIELD_BORDER_COLOR,
  MODAL_BACKDROP_OPACITY,
} from '../../../../../resources/constants/themeConstant';
import {connect} from 'react-redux';
import withHttpsApiErrorHandling from '../../../../../components/HOC/withHttpsApiErrorHandling';
import withLoadingSpinner from '../../../../../components/HOC/withLoadingSpinner';
import CartItemTemplate from '../../../../../components/GenericTemplate/CartItemTemplate';
import {
  ROUTE_PAYMENT_SCREEN,
  ROUTE_TICKET_PROCESSING_MOBILE_VIEW,
} from '../../../../../resources/constants/navigationConstants';
import {
  roundToTwo,
  validateRequiredField,
} from '../../../../../utils/validators';
import {
  getCustomerInfoApiReqAction,
  resetCustomerInfoApiResponseAction,
  resetCustomerInfoApiFailErrAction,
  resetCustomerInfoHttpErrAction,
} from '../../../../../store/CustomerDetail/customerDetailAction';
import {GenericButton} from '../../../../../components';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {SwipeListView} from 'react-native-swipe-list-view';
import {
  deleteOrderLineApiReqAction,
  resetDeleteOrderLineApiResponseAction,
  resetDeleteOrderLineApiFailAction,
  resetDeleteOrderlineApiHttpErrAction,
  removeOrderLineItemFromListAction,
  setCartSubTotalAction,
  setCartTotalAction,
  setCartTaxPercentAction,
  setCartTaxValueAction,
  getOrderLineItemApiReqAction,
  getOrderLineItemApiResponseAction,
  resetGetOrderLineItemApiResponseAction,
  resetGetOrderLineItemFailErrAction,
  resetGetOrderLineItemHttpAction,
  resetOrderLineStoreAction,
  setOrderLineItemListAction,
  setOrderNoAction,
  setOrderIdAction,
  setPoNoAction,
} from '../../../../../store/OrderLine/orderLineAction';
import {CANCEL, OKAY} from '../../../../../resources/constants/stringConstants';
import {
  MODAL_CONTAINER_WIDTH,
  SPACING_30,
  TEXT_SIZE_15,
} from '../../../../../resources/constants/dimensions';
import Toast from 'react-native-simple-toast';

const ItemProcessing = ({
  navigation,
  selectedCustomer,
  brandSuccessResponse,
  addedItemsList,
  getCustomerInfoApiReqAction: _getCustomerInfoApiReqAction,
  resetCustomerInfoApiResponseAction: _resetCustomerInfoApiResponseAction,
  resetCustomerInfoApiFailErrAction: _resetCustomerInfoApiFailErrAction,
  resetCustomerInfoHttpErrAction: _resetCustomerInfoHttpErrAction,
  customerInfoApiResponse,
  customerInfoApiFailErr,
  customerInfoApiHttpErr,
  setLoadingSpinnerVisibility,
  showHttpsApiErrorDialog,
  deleteOrderLineApiReqAction: _deleteOrderLineApiReqAction,
  resetDeleteOrderLineApiResponseAction: _resetDeleteOrderLineApiResponseAction,
  resetDeleteOrderLineApiFailAction: _resetDeleteOrderLineApiFailAction,
  resetDeleteOrderlineApiHttpErrAction: _resetDeleteOrderlineApiHttpErrAction,
  removeOrderLineItemFromListAction: _removeOrderLineItemFromListAction,
  deleteOrderLineApiResponse,
  deleteOrderLineApiFailErr,
  deleteOrderLineApiHttErr,
  setCartTaxPercentAction: _setCartTaxPercentAction,
  setCartTaxValueAction: _setCartTaxValueAction,
  setCartSubTotalAction: _setCartSubTotalAction,
  setCartTotalAction: _setCartTotalAction,
  cartTotal,
  cartSubTotal,
  cartTaxPercent,
  cartTaxValue,
  orderNo,
  getOrderLineItemApiReqAction: _getOrderLineItemApiReqAction,
  getOrderLineItemApiResponseAction: _getOrderLineItemApiResponseAction,
  resetGetOrderLineItemApiResponseAction: _resetGetOrderLineItemApiResponseAction,
  resetGetOrderLineItemFailErrAction: _resetGetOrderLineItemFailErrAction,
  resetGetOrderLineItemHttpAction: _resetGetOrderLineItemHttpAction,
  getOrderLineItemApiResponse,
  getOrderLineItemApiFailErr,
  getOrderLineItemApiHttpErr,
  resetOrderLineStoreAction: _resetOrderLineStoreAction,
  setOrderLineItemListAction: _setOrderLineItemListAction,
  setOrderNoAction: _setOrderNoAction,
  setOrderIdAction: _setOrderIdAction,
  setPoNoAction: _setPoNoAction,
  poNo,
}) => {
  const [itemList, setItemList] = useState([]);
  const [soldToSelected, setSoldToSelected] = useState(true);
  const [isShipToAvailable, setIsShipToAvailable] = useState(false);
  const [customerInfo, setCustomerInfo] = useState('');
  const [deleteCnfModalVisibility, setDeleteCnfModalVisibility] = useState({
    visibility: false,
    data: null,
  });
  const [poOverlayVisibility, setPoOverlayVisibility] = useState(false);
  const [inputPoNo, setInputPoNo] = useState('');

  useEffect(() => {
    _resetOrderLineStoreAction();
    setLoadingSpinnerVisibility(true);
    _resetCustomerInfoApiResponseAction();
    _getOrderLineItemApiReqAction(
      brandSuccessResponse.CompanyId,
      selectedCustomer.CustomerId,
      brandSuccessResponse.ERPRepCode,
    );
  }, []);

  useEffect(() => {
    if (validateRequiredField(getOrderLineItemApiResponse)) {
      _setOrderLineItemListAction(getOrderLineItemApiResponse);

      if (getOrderLineItemApiResponse.length > 0) {
        _setOrderNoAction(getOrderLineItemApiResponse[0].OrderNo);
        _setOrderIdAction(getOrderLineItemApiResponse[0].OrderId);
      }
    }
  }, [getOrderLineItemApiResponse]);

  useEffect(() => {
    if (validateRequiredField(getOrderLineItemApiFailErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(getOrderLineItemApiFailErr);
      _resetGetOrderLineItemFailErrAction();
    }
  }, [getOrderLineItemApiFailErr]);

  useEffect(() => {
    if (validateRequiredField(getOrderLineItemApiHttpErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(getOrderLineItemApiHttpErr);
      _resetGetOrderLineItemHttpAction();
    }
  }, [getOrderLineItemApiHttpErr]);

  useEffect(() => {
    if (validateRequiredField(customerInfoApiResponse)) {
      setLoadingSpinnerVisibility(false);
      setCustomerInfo(customerInfoApiResponse);
      _setCartTaxPercentAction(customerInfoApiResponse.TaxPercent);

      if (validateRequiredField(customerInfoApiResponse.ShippingAddressId)) {
        setIsShipToAvailable(true);
      } else {
        setIsShipToAvailable(false);
      }
    } else {
      setLoadingSpinnerVisibility(true);
      _getCustomerInfoApiReqAction(selectedCustomer.CustomerId);
    }
  }, [customerInfoApiResponse]);

  useEffect(() => {
    if (validateRequiredField(customerInfoApiFailErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(customerInfoApiFailErr);
      _resetCustomerInfoApiFailErrAction();
    }
  }, [customerInfoApiFailErr]);

  useEffect(() => {
    if (validateRequiredField(customerInfoApiHttpErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(customerInfoApiHttpErr);
      _resetCustomerInfoHttpErrAction();
    }
  }, [customerInfoApiHttpErr]);

  useEffect(() => {
    if (validateRequiredField(addedItemsList)) {
      console.log('ORDER LINE Items --', addedItemsList);
      setItemList(addedItemsList);
      updateCart(addedItemsList);
    }
  }, [addedItemsList]);

  const updateCart = (addedItemsList) => {
    console.log('CART LENGTH', addedItemsList.length);
    let totalValue = 0;
    let taxValue = 0;
    let subTotal = 0;

    if (addedItemsList.length > 0) {
      let itemValue = 0;
      let itemTaxValue = 0;

      addedItemsList.map((item) => {
        itemValue = item.OrderQty * item.ListPrice;

        if (item.TaxFlag === 'Y') {
          itemTaxValue = (itemValue * cartTaxPercent) / 100;
        }

        totalValue = totalValue + itemValue;
        taxValue = taxValue + itemTaxValue;
      });
    }

    subTotal = totalValue + taxValue;

    _setCartTotalAction(totalValue);
    _setCartSubTotalAction(subTotal);
    _setCartTaxValueAction(taxValue);
  };

  useEffect(() => {
    if (validateRequiredField(deleteOrderLineApiResponse)) {
      setLoadingSpinnerVisibility(false);
      _removeOrderLineItemFromListAction(
        deleteCnfModalVisibility.data.OrderLineId,
      );
      setDeleteCnfModalVisibility({visibility: false, data: null});
      _resetDeleteOrderLineApiResponseAction();
    }
  }, [deleteOrderLineApiResponse]);

  useEffect(() => {
    if (validateRequiredField(deleteOrderLineApiFailErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(deleteOrderLineApiFailErr);
      _resetDeleteOrderLineApiFailAction();
    }
  }, [deleteOrderLineApiFailErr]);

  useEffect(() => {
    if (validateRequiredField(deleteOrderLineApiHttErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(deleteOrderLineApiHttErr);
      _resetDeleteOrderlineApiHttpErrAction();
    }
  }, [deleteOrderLineApiHttErr]);

  const onOrderLineItemDeletePress = (data) => {
    setLoadingSpinnerVisibility(true);
    _deleteOrderLineApiReqAction(data.OrderLineId);
  };

  const onCartPress = () => {
    if (addedItemsList.length > 0 && DeviceInfo.isTablet()) {
      navigation.navigate(ROUTE_PAYMENT_SCREEN);
    } else if (addedItemsList.length > 0 && !DeviceInfo.isTablet()) {
      navigation.navigate(ROUTE_TICKET_PROCESSING_MOBILE_VIEW);
    } else {
      Toast.showWithGravity('No item added.', Toast.SHORT, Toast.CENTER);
    }
  };

  return (
    <View>
      {DeviceInfo.isTablet() ? null : (
        <Header
          placement="right"
          leftComponent={
            <Icon
              name="keyboard-backspace"
              type="ionicon"
              color="white"
              onPress={() => navigation.pop()}
              size={40}
            />
          }
        />
      )}
      <View style={{flexDirection: 'row'}}>
        <View style={styles.addressBlock}>
          <Text h5 style={styles.companyName}>
            {brandSuccessResponse.CompanyName}
          </Text>
          <View>
            <View style={styles.addressSelection}>
              <TouchableWithoutFeedback
                on
                onPress={() => setSoldToSelected(true)}>
                <View>
                  <Text>Sold To:</Text>
                  <Divider
                    style={[
                      soldToSelected
                        ? {backgroundColor: 'blue'}
                        : {backgroundColor: COLORS.grayDark},
                      {},
                    ]}
                  />
                </View>
              </TouchableWithoutFeedback>
              {isShipToAvailable ? (
                <TouchableWithoutFeedback
                  onPress={() => setSoldToSelected(false)}>
                  <View style={{marginStart: 10}}>
                    <Text>Ship To</Text>
                    <Divider
                      style={[
                        soldToSelected
                          ? {backgroundColor: COLORS.grayDark}
                          : {backgroundColor: 'blue'},
                        {},
                      ]}
                    />
                  </View>
                </TouchableWithoutFeedback>
              ) : null}
            </View>
            {soldToSelected ? (
              <View style={styles.address}>
                <Text style={styles.textStyle}>
                  {customerInfo.CustomerName}
                </Text>
                <Text style={styles.textStyle}>{customerInfo.Address1}</Text>
                <Text style={styles.textStyle}>{customerInfo.City}</Text>
                <Text style={styles.textStyle}>
                  {customerInfo.State} , {customerInfo.PostalCode}
                </Text>
              </View>
            ) : (
              <View style={styles.address}>
                <Text style={styles.textStyle}>{customerInfo.ShipToName}</Text>
                <Text style={styles.textStyle}>
                  {customerInfo.ShipToAddress1}
                </Text>
                <Text style={styles.textStyle}>{customerInfo.ShipToCity}</Text>
                <Text style={styles.textStyle}>
                  {customerInfo.ShipToState}, {customerInfo.ShipToZip}
                </Text>
              </View>
            )}
          </View>
        </View>

        {DeviceInfo.isTablet() ? (
          <View style={styles.middleBlock}>
            <Avatar
              size="large"
              source={{
                uri:
                  'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
              }}
              onPress={() => console.log('Works!')}
              activeOpacity={0.7}
            />
            {poNo ? (
              <Text style={{marginTop: 5}}>Purchase Order#: {poNo}</Text>
            ) : (
              <TouchableOpacity onPress={() => setPoOverlayVisibility(true)}>
                <View style={{flexDirection: 'row', marginTop: 5}}>
                  <Text>Enter PO#</Text>
                  <Icon
                    name="circle-edit-outline"
                    type="MaterialCommunityIcons"
                    color="black"
                    style={{marginStart: 5}}
                    size={20}
                  />
                </View>
              </TouchableOpacity>
            )}

            <Text>Payment Terms: {customerInfo.Terms}</Text>
          </View>
        ) : null}

        <View style={styles.cartContainer}>
          <Text style={[{fontSize: 20}, styles.textInsideCart]}>
            Invoice:{'   '} {orderNo ? orderNo : 'NA'}
          </Text>
          <Text style={[{fontSize: 15}, styles.textInsideCart]}>
            {' '}
            ${roundToTwo(cartTotal)}
          </Text>
          <Text style={[{fontSize: 10}, styles.textInsideCart]}>
            {' '}
            plus ${cartTaxPercent} Tax
          </Text>

          <View style={{flexDirection: 'row'}}>
            <View>
              <Icon
                name="cart"
                type="font-awesome"
                color="blue"
                size={40}
                style={{marginBottom: 20, marginRight: 20}}
                onPress={onCartPress}
              />
            </View>
            <View>
              <View style={styles.horizontalLineInCart} />
              <Text style={[{fontSize: 20}, styles.textInsideCart]}>
                {' '}
                ${roundToTwo(cartSubTotal)}
              </Text>
            </View>
          </View>
        </View>
      </View>

      {DeviceInfo.isTablet() ? null : (
        <View style={{flexDirection: 'row', margin: 10}}>
          <View>
            <Avatar
              size="large"
              source={{
                uri:
                  'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
              }}
              onPress={() => console.log('Works!')}
              activeOpacity={0.7}
            />
          </View>
          <View style={{marginStart: 10}}>
            {poNo ? (
              <Text style={{marginTop: 5}}>Purchase Order#: {poNo}</Text>
            ) : (
              <TouchableOpacity onPress={() => setPoOverlayVisibility(true)}>
                <View style={{flexDirection: 'row', marginTop: 5}}>
                  <Text>Enter PO#</Text>
                  <Icon
                    name="circle-edit-outline"
                    type="MaterialCommunityIcons"
                    color="black"
                    style={{marginStart: 5}}
                    size={20}
                  />
                </View>
              </TouchableOpacity>
            )}

            <Text>Payment Terms: {customerInfo.Terms}</Text>
          </View>
        </View>
      )}

      <View style={styles.deviderStyle} />
      <View style={{height: '100%'}}>
        {/* <FlatList
          data={itemList}
          renderItem={({item, index, separators}) => (
            <TouchableWithoutFeedback
              onPress={() => {
                console.log('Item CLicked -', item);
              }}>
              <View>
                <CartItemTemplate item={item} />
              </View>
            </TouchableWithoutFeedback>
          )}
          keyExtractor={(item, index) => index.toString()}
          style={{width: '100%', height: '100%'}}
        /> */}

        {itemList.length > 0 ? (
          <SwipeListView
            data={itemList}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({item, index, separators}) => (
              <TouchableOpacity
                activeOpacity={1}
                onPress={() => {}}
                style={{backgroundColor: 'white'}}
                underlayColor={'#AAA'}>
                <View>
                  <CartItemTemplate item={item} />
                </View>
              </TouchableOpacity>
            )}
            renderHiddenItem={(data, rowMap, third) => (
              <View style={styles.rowBack}>
                <GenericButton
                  icon={'delete'}
                  size={30}
                  iconType={'MaterialIcons'}
                  iconColor={'#ffffff'}
                  type={'clear'}
                  onPress={() => {
                    console.log(data.item);
                    setDeleteCnfModalVisibility({
                      visibility: true,
                      data: data.item,
                    });
                  }}
                />
              </View>
            )}
            rightOpenValue={-50}
          />
        ) : (
          <Text style={{textAlign: 'center'}}>No Item Added</Text>
        )}
      </View>
      <Overlay
        backdropStyle={styles.overlay}
        isVisible={deleteCnfModalVisibility.visibility}
        overlayStyle={styles.overlayModalStyle}>
        <View>
          <Text h3 h3Style={styles.modalTextStyle}>
            Are you sure want to delete this item?
          </Text>
          <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
            <GenericButton
              title={CANCEL}
              type={'clear'}
              onPress={() =>
                setDeleteCnfModalVisibility({visibility: false, data: null})
              }
            />
            <GenericButton
              title={OKAY}
              type={'clear'}
              onPress={() => {
                onOrderLineItemDeletePress(deleteCnfModalVisibility.data);
              }}
            />
          </View>
        </View>
      </Overlay>

      <Overlay
        backdropStyle={styles.overlay}
        isVisible={poOverlayVisibility}
        overlayStyle={styles.overlayModalStyle}>
        <View>
          <Text h3 h3Style={styles.modalTextStyle}>
            Enter Purchase Order
          </Text>
          <Input
            placeholder="Enter PO"
            value={inputPoNo}
            onChangeText={setInputPoNo}
          />
          <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
            <GenericButton
              title={CANCEL}
              type={'clear'}
              onPress={() => {
                setPoOverlayVisibility(false);
              }}
            />
            <GenericButton
              title={OKAY}
              type={'clear'}
              onPress={() => {
                _setPoNoAction(inputPoNo);
                setPoOverlayVisibility(false);
              }}
            />
          </View>
        </View>
      </Overlay>
    </View>
  );
};

const styles = StyleSheet.create({
  rowBack: {
    alignItems: 'center',
    backgroundColor: 'red',
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingLeft: 15,
  },
  deviderStyle: {
    backgroundColor: COLORS.grayDark,
    height: 1,
    width: '100%',
  },
  addressBlock: {flex: 1, margin: 10},
  companyName: {fontWeight: 'bold'},
  addressSelection: {
    flexDirection: 'row',
    alignContent: 'center',
    marginTop: 5,
  },
  address: {marginTop: 10},
  middleBlock: {flex: 1, alignItems: 'center', margin: 10},
  cartBlock: {
    backgroundColor: '#ffdd00',
    flex: 1,
    flexDirection: 'row',
    borderRadius: 20,
    margin: 10,
    alignItems: 'center',
    padding: 10,
  },
  textStyle: {
    fontSize: 10,
  },
  cartContainer: {
    alignItems: 'flex-end',
    width: 200,
    height: 110,
    margin: 10,
    backgroundColor: 'yellow',
    borderColor: 'grey',
    borderWidth: 1,
    borderRadius: 15,
  },
  textInsideCart: {
    alignSelf: 'flex-end',
    padding: 2,
    marginRight: 10,
  },
  horizontalLineInCart: {
    width: 100,
    height: 2,
    backgroundColor: 'grey',
    alignSelf: 'flex-end',
    marginRight: 10,
  },
  overlayModalStyle: {
    borderWidth: FIELD_BORDER_WIDTH,
    borderColor: INPUT_FIELD_BORDER_COLOR,
    width: MODAL_CONTAINER_WIDTH,
  },
  overlay: {
    backgroundColor: GENERIC_BACKGROUND_COLOR,
    opacity: MODAL_BACKDROP_OPACITY,
  },
  modalTextStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'center',
    //color:ERROR_COLOR,
    marginBottom: SPACING_30,
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    selectedCustomer: reduxStore.customer.selectedCustomer,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    addedItemsList: reduxStore.orderLine.addedItemsList,
    customerInfoApiResponse: reduxStore.customerDetail.customerInfoApiResponse,
    customerInfoApiFailErr: reduxStore.customerDetail.customerInfoApiFailErr,
    customerInfoApiHttpErr: reduxStore.customerDetail.customerInfoApiHttpErr,
    deleteOrderLineApiResponse: reduxStore.orderLine.deleteOrderLineApiResponse,
    deleteOrderLineApiFailErr: reduxStore.orderLine.deleteOrderLineApiFailErr,
    deleteOrderLineApiHttErr: reduxStore.orderLine.deleteOrderLineApiHttErr,
    cartTotal: reduxStore.orderLine.cartTotal,
    cartSubTotal: reduxStore.orderLine.cartSubTotal,
    cartTaxPercent: reduxStore.orderLine.cartTaxPercent,
    cartTaxValue: reduxStore.orderLine.cartTaxValue,
    orderNo: reduxStore.orderLine.orderNo,
    poNo: reduxStore.orderLine.poNo,
    getOrderLineItemApiResponse:
      reduxStore.orderLine.getOrderLineItemApiResponse,
    getOrderLineItemApiFailErr: reduxStore.orderLine.getOrderLineItemApiFailErr,
    getOrderLineItemApiHttpErr: reduxStore.orderLine.getOrderLineItemApiHttpErr,
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      getCustomerInfoApiReqAction,
      resetCustomerInfoApiResponseAction,
      resetCustomerInfoApiFailErrAction,
      resetCustomerInfoHttpErrAction,
      deleteOrderLineApiReqAction,
      resetDeleteOrderLineApiResponseAction,
      resetDeleteOrderLineApiFailAction,
      resetDeleteOrderlineApiHttpErrAction,
      removeOrderLineItemFromListAction,
      setCartTaxPercentAction,
      setCartTaxValueAction,
      setCartSubTotalAction,
      setCartTotalAction,
      getOrderLineItemApiReqAction,

      getOrderLineItemApiResponseAction,
      resetGetOrderLineItemApiResponseAction,
      resetGetOrderLineItemFailErrAction,
      resetGetOrderLineItemHttpAction,
      resetOrderLineStoreAction,
      setOrderLineItemListAction,
      setOrderNoAction,
      setOrderIdAction,
      setPoNoAction,
    })(ItemProcessing),
  ),
);
