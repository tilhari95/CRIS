import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
  ScrollView,
  TouchableWithoutFeedback,
} from 'react-native';
import {default as DeviceInfo} from 'react-native-device-info';
import {connect} from 'react-redux';
import withHttpsApiErrorHandling from '../../../../../components/HOC/withHttpsApiErrorHandling';
import withLoadingSpinner from '../../../../../components/HOC/withLoadingSpinner';
import {
  roundToTwo,
  validateRequiredField,
} from '../../../../../utils/validators';
import {Header, Divider, Icon} from 'react-native-elements';
import SignatureCapture from 'react-native-signature-capture';
import {
  APP_BLUE_COLOR,
  COLORS,
  PaymentMode,
} from '../../../../../resources/constants/themeConstant';
import {
  cards_image,
  p_and_s,
  refresh,
  plus,
  minus,
  back,
  tick,
} from '../../../../../resources/images';
import PDFView from 'react-native-view-pdf';
import {
  getRewardAmountApiReqAction,
  resetRewardApiHttpErrAction,
  resetGetAmountApiFailErrAction,
  resetRewardReduxStateAction,
} from '../../../../../store/Reward/rewardAction';
import {
  setCouponCodeAction,
  setRewardAmountAction,
  setTotalDueAmtAfterRewardAction,
  setAmountReceivedAction,
  setPaymentModeAction,
  setBalanceDueAction,
  setCheckAmountAction,
  setCheckNoAction,
  setCashReceivedAction,
  setSignatoryNameAction,
  setSignatureImgDataAction,
  resetPaymentScreenDataAction,
  setRewardIdAction,
  resetRewardIdAction,
} from '../../../../../store/OrderLine/orderLineAction';
import {
  ROUTE_ITEM_PROCESSING,
  ROUTE_PAYMENT_EMAIL_SCREEN,
} from '../../../../../resources/constants/navigationConstants';
import {
  getOrderHeaderAPiReqAction,
  resetOrderHeaderApiFailErrAction,
  resetOrderHeaderApiHttpErrAction,
  resetOrderHeaderApiResponseAction,
} from '../../../../../store/OrderHeader/orderHeaderAction';
import {getTodaysDateYYYYMMDD} from '../../../../../utils/date';
import Toast from 'react-native-simple-toast';
import {Stopwatch, Timer} from 'react-native-stopwatch-timer';
import { createInvoicePDF } from '../../../../../utils/invoicePDFUtil/invoicePDFCreater';

const TicketProcessingMobileView = ({
  navigation,
  setLoadingSpinnerVisibility,
  showHttpsApiErrorDialog,
  getRewardAmountApiReqAction: _getRewardAmountApiReqAction,
  resetRewardApiHttpErrAction: _resetRewardApiHttpErrAction,
  resetGetAmountApiFailErrAction: _resetGetAmountApiFailErrAction,
  getRewardApiResponse,
  getRewardApiHttpErr,
  getRewardApiFailErr,
  selectedCustomer,
  brandSuccessResponse,
  orderId,
  cartSubTotal,
  resetRewardReduxStateAction: _resetRewardReduxStateAction,
  customerInfoApiResponse,
  setCouponCodeAction: _setCouponCodeAction,
  setRewardAmountAction: _setRewardAmountAction,
  setTotalDueAmtAfterRewardAction: _setTotalDueAmtAfterRewardAction,
  setAmountReceivedAction: _setAmountReceivedAction,
  setPaymentModeAction: _setPaymentModeAction,
  setBalanceDueAction: _setBalanceDueAction,
  setCheckAmountAction: _setCheckAmountAction,
  setCheckNoAction: _setCheckNoAction,
  setCashReceivedAction: _setCashReceivedAction,
  setSignatoryNameAction: _setSignatoryNameAction,
  setSignatureImgDataAction: _setSignatureImgDataAction,
  resetPaymentScreenDataAction: _resetPaymentScreenDataAction,
  cartTotal,
  cartTaxPercent,
  cartTaxValue,
  rewardAmount,
  totalDueAfterReward,
  amountReceived,
  paymentMode,
  balanceDue,
  checkAmount,
  checkNo,
  cashReceived,
  setRewardIdAction: _setRewardIdAction,
  resetRewardIdAction: _resetRewardIdAction,
  orderNo,
  getOrderHeaderAPiReqAction: _getOrderHeaderAPiReqAction,
  resetOrderHeaderApiFailErrAction: _resetOrderHeaderApiFailErrAction,
  resetOrderHeaderApiHttpErrAction: _resetOrderHeaderApiHttpErrAction,
  resetOrderHeaderApiResponseAction: _resetOrderHeaderApiResponseAction,
  orderHeaderApiResponse,
  orderHeaderApiFailErr,
  orderHeaderApiHttpErr,
  rewardId,
  addedItemsList,
  signatoryName,
  signatorImageData,
}) => {
  const [customCheckBox, setCustomCheckBox] = React.useState(true);

  //Reward
  const [rewardsCode, setRewardsCode] = React.useState('');

  //Check
  const [checkReceived, setCheckReceived] = React.useState('');
  const [checkNumber, setCheckNumber] = React.useState('');

  //Cash
  const [cashAmount, setCashAmount] = React.useState('');

  const ref = React.useRef(null);
  const [signatureName, setSignatureName] = useState('');

  /**
   * this is for Phone Settings
   */
  const [soldToAddress, setSoldToAddress] = React.useState('');
  const [shipToAddress, setShipToAddress] = React.useState('');
  const [expandPayment, setExpandPayment] = React.useState(false);
  const [expandSignature, setExpandSignature] = React.useState(false);
  const [expandEmail, setExpandEmail] = React.useState(false);
  // const [cardNumber, setCardNumber] = React.useState('');
  // const [expiry, setExpiry] = React.useState('');
  // const [cvv, setCvv] = React.useState('');
  const [pdfBase64, setPdfBase64] = useState('');
  const [counter, setCounter] = useState({min: '00', sec: '00'});
  const [selectedPaymentMode, setSelectedPaymentMode] = useState('');

  function saveSign() {
    ref.current.saveImage();
  }

  function resetSign() {
    ref.current.resetImage();
  }

  useEffect(() => {
    _resetRewardReduxStateAction();
    _resetPaymentScreenDataAction();
    _setPaymentModeAction(PaymentMode.CHECK);
    setSelectedPaymentMode(PaymentMode.CHECK);
  }, []);

  useEffect(() => {
    if (validateRequiredField(selectedPaymentMode)) {
      switch (selectedPaymentMode) {
        case PaymentMode.CASH:
          _setCashReceivedAction(cashAmount);
          _setAmountReceivedAction(cashAmount);
          _setPaymentModeAction(PaymentMode.CASH);
          break;

        case PaymentMode.CHECK:
          _setCheckAmountAction(checkReceived);
          _setCheckNoAction(checkNumber);
          _setAmountReceivedAction(checkReceived);
          _setPaymentModeAction(PaymentMode.CHECK);
          break;

        default:
          console.log('No payment mode selected');
          break;
      }
    }
  }, [selectedPaymentMode, checkNumber, checkReceived, cashAmount]);

  useEffect(() => {
    if (validateRequiredField(customerInfoApiResponse)) {
      setSoldToAndShipToAddress(customerInfoApiResponse);
    }
  }, [customerInfoApiResponse]);

  useEffect(() => {
    if (!validateRequiredField(rewardAmount)) {
      _setRewardAmountAction(0);
    }

    if (!validateRequiredField(amountReceived)) {
      _setAmountReceivedAction(0);
    }

    if (validateRequiredField(getRewardApiResponse)) {
      setLoadingSpinnerVisibility(false);

      _setRewardIdAction(getRewardApiResponse.RewardId);

      if (getRewardApiResponse.DiscountType === 'A') {
        _setRewardAmountAction(getRewardApiResponse.DiscountPercentOrAmount);
      } else if (getRewardApiResponse.DiscountType === 'P') {
        let amt =
          (cartSubTotal * getRewardApiResponse.DiscountPercentOrAmount) / 100;
        _setRewardAmountAction(amt);
      } else {
        _setRewardAmountAction(0);
      }
    } else {
      _resetRewardIdAction();
    }

    //Due after reward apply
    let totalDueAfReward = cartSubTotal - rewardAmount;
    if (validateRequiredField(totalDueAfReward)) {
      _setTotalDueAmtAfterRewardAction(roundToTwo(totalDueAfReward));
    } else {
      _setTotalDueAmtAfterRewardAction(0);
    }

    // Total due balance
    let totalDVal = cartSubTotal - rewardAmount - amountReceived;
    if (validateRequiredField(totalDVal)) {
      _setBalanceDueAction(roundToTwo(totalDVal));
    } else {
      _setBalanceDueAction(0);
    }
  }, [getRewardApiResponse, rewardAmount, amountReceived]);

  useEffect(() => {
    if (validateRequiredField(getRewardApiHttpErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(getRewardApiHttpErr);
      _resetRewardApiHttpErrAction(getRewardApiFailErr);
    }
  }, [getRewardApiHttpErr]);

  useEffect(() => {
    if (validateRequiredField(getRewardApiFailErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(getRewardApiFailErr);
      _resetGetAmountApiFailErrAction(getRewardApiFailErr);
    }
  }, [getRewardApiFailErr]);

  const setSoldToAndShipToAddress = (customerInfo) => {
    let soldToAdds =
      customerInfoApiResponse.CustomerName +
      '\n' +
      customerInfoApiResponse.Address1 +
      '\n' +
      customerInfoApiResponse.City +
      ', ' +
      customerInfoApiResponse.State +
      ', ' +
      customerInfoApiResponse.PostalCode;

    setSoldToAddress(soldToAdds);

    if (validateRequiredField(customerInfoApiResponse.ShippingAddressId)) {
      let shipToAdds =
        customerInfoApiResponse.ShipToName +
        '\n' +
        customerInfoApiResponse.ShipToAddress1 +
        '\n' +
        customerInfoApiResponse.ShipToCity +
        ', ' +
        customerInfoApiResponse.ShipToState +
        ', ' +
        customerInfoApiResponse.ShipToZip;

      setShipToAddress(shipToAdds);
    }
  };

  const _onSaveEvent = (result) => {
    //result.encoded - for the base64 encoded png
    //result.pathName - for the file path name
    _setSignatoryNameAction(signatureName);
    _setSignatureImgDataAction(result.encoded);
    console.log(result);
  };

  const _onDragEvent = () => {
    // This callback will be called when the user enters signature
    // console.log('dragged');
    // console.log('Customer -- ', selectedCustomer);
    // console.log('Comapny --', brandSuccessResponse);
    // console.log('CustomerInfo -', customerInfoApiResponse);
  };

  useEffect(() => {
    if (validateRequiredField(orderHeaderApiResponse)) {
      setLoadingSpinnerVisibility(false);
      Toast.show('Order header added successfully', Toast.LONG);
      _resetOrderHeaderApiResponseAction();

      generatePDF();
    }
  }, [orderHeaderApiResponse]);

  useEffect(() => {
    if (validateRequiredField(orderHeaderApiFailErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(orderHeaderApiFailErr);
      _resetOrderHeaderApiFailErrAction(orderHeaderApiFailErr);
    }
  }, [orderHeaderApiFailErr]);

  useEffect(() => {
    if (validateRequiredField(orderHeaderApiHttpErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(orderHeaderApiHttpErr);
      _resetOrderHeaderApiHttpErrAction(orderHeaderApiHttpErr);
    }
  }, [orderHeaderApiHttpErr]);

  const isPaidByCash = () => {
    if (paymentMode == PaymentMode.CASH) {
      return 1;
    } else {
      return 0;
    }
  };

  const isPaidByCheck = () => {
    if (paymentMode == PaymentMode.CHECK) {
      return 1;
    } else {
      return 0;
    }
  };

  const getCheckNo = () => {
    if (paymentMode == PaymentMode.CHECK) {
      return checkNo;
    } else {
      return '';
    }
  };

  const addOrderHeaderApiCall = () => {
    saveSign();
    setLoadingSpinnerVisibility(true);
    _getOrderHeaderAPiReqAction(
      orderId,
      orderNo, //OrderNo
      brandSuccessResponse.CompanyId,
      'N',
      customerInfoApiResponse.CustomerNo,
      '', //Comment1
      '', //Comment2
      selectedCustomer.PostalCode,
      cartSubTotal,
      cartTaxValue,
      rewardAmount, // TODO:// Discount
      isPaidByCash(), //paidCash,
      isPaidByCheck(), //PaidCheck,
      0, //Paid card
      customerInfoApiResponse.ShippingAddressId,
      customerInfoApiResponse.ShipToName,
      getCheckNo(), //CheckNo
      customerInfoApiResponse.CustType,
      selectedCustomer.EmailAddress,
      'I',
      getTodaysDateYYYYMMDD(), // CreatedDate
      getTodaysDateYYYYMMDD(), //TODO:// requestedShipDate
      customerInfoApiResponse.ShipToAddress1,
      customerInfoApiResponse.ShipToCity,
      customerInfoApiResponse.ShipToState,
      customerInfoApiResponse.ShipToZip,
      customerInfoApiResponse.IsPRO,
      customerInfoApiResponse.BillToName,
      customerInfoApiResponse.Address1,
      customerInfoApiResponse.City,
      customerInfoApiResponse.State,
      customerInfoApiResponse.PostalCode,
      brandSuccessResponse.DeviceId,
      selectedCustomer.CustomerId,
      customerInfoApiResponse.TaxScheduleId, //taxScheduleId
      selectedCustomer.CustomerName,
      customerInfoApiResponse.CustomerListId,
      customerInfoApiResponse.TaxSchedule,
      customerInfoApiResponse.Terms,
      rewardId, //Reward Id
    );
  };

   const generatePDF = async (openOnIntent = false) => {
    let orderInfoJson = {
      OrderId: orderId,
      CompanyDetail: brandSuccessResponse,
      CustomerDetail: selectedCustomer,
      CustomerInfo: customerInfoApiResponse,
      ItemList: addedItemsList,
      CartTotal: cartTotal,
      CartSubTotal: cartSubTotal,
      CartTaxPercent: cartTaxPercent,
      CartTaxValue: cartTaxValue,
      RewardAmount: rewardAmount,
      TotalDueAfterReward: totalDueAfterReward,
      AmountReceived: amountReceived,
      PaymentMode: paymentMode,
      BalanceDue: balanceDue,
      CheckAmount: checkAmount,
      CheckNo: checkNo,
      CashReceived: cashReceived,
      RewardId: rewardId,
      SignatoryName: signatoryName,
      SignatorImageData: signatorImageData,
    };
    console.log(orderInfoJson);
     let generatedPdfObject = await createInvoicePDF(orderInfoJson, openOnIntent);
    console.log('PDF ->' , generatedPdfObject.base64);
    setPdfBase64(generatedPdfObject.base64);
  };

  return (
    <View style={{flexDirection: 'column', height: '100%'}}>
      <Header
        leftComponent={
          <Icon
            name="arrow-back"
            type="MaterialIcons"
            color="white"
            onPress={() => navigation.pop()}
            size={30}
          />
        }
        centerComponent={
          <Text style={{color: '#ffffff'}}>
            {selectedCustomer.CustomerName}
          </Text>
        }
      />

      <ScrollView style={stylesPhone.container}>
        <View style={stylesPhone.container}>
          <View style={stylesPhone.placeTextToRight}>
            <Text style={{marginEnd: 16, marginTop: 8}}>
              {' '}
              Invoice : {orderNo}
            </Text>
          </View>
          <View
            style={[
              stylesPhone.placeTextToLeft,
              {flexDirection: 'row', marginTop: 8},
            ]}>
            <Text style={{marginStart: 16}}> Elapsed : </Text>
            <Stopwatch
              laps
              start={true}
              options={{backgroundColor: '#ffdd00'}}
            />
          </View>

          <View style={{flexDirection: 'column'}}>
            <View>
              <View style={[stylesPhone.addressContainer, {marginTop: 20}]}>
                <Text style={{fontSize: 15}}>Sold To</Text>
                <Text style={stylesPhone.textInputAddress}>
                  {soldToAddress}
                </Text>
              </View>

              <View style={[stylesPhone.addressContainer, {marginTop: 20}]}>
                <Text style={{fontSize: 15}}>Delivered To</Text>
                <TextInput
                  multiline={true}
                  numberOfLines={3}
                  blurOnSubmit={false}
                  style={stylesPhone.textInputAddress}
                  onChangeText={setShipToAddress}
                  value={shipToAddress}
                />
              </View>
            </View>
            <View
              style={[
                stylesPhone.placeTextToRight,
                {marginTop: 20, flexDirection: 'row'},
              ]}>
              <View>
                <Text style={[stylesPhone.moneyDisplay, {fontSize: 15}]} />
                <Text style={[stylesPhone.moneyDisplay, {fontSize: 10}]} />
                <Text style={[stylesPhone.moneyDisplay, {fontSize: 13}]}>
                  Reward:
                </Text>
                <Text style={[stylesPhone.moneyDisplay, {fontSize: 18}]}>
                  Total Due:
                </Text>
                <Text style={[stylesPhone.moneyDisplay, {fontSize: 13}]}>
                  Received:
                </Text>
                <Text style={[stylesPhone.moneyDisplay, {fontSize: 13}]}>
                  Balance Due:
                </Text>
              </View>
              <View>
                <Text style={[stylesPhone.moneyDisplay, {fontSize: 15}]}>
                  ${roundToTwo(cartTotal)}
                </Text>
                <Text style={[stylesPhone.moneyDisplay, {fontSize: 10}]}>
                  plus ${roundToTwo(customerInfoApiResponse.TaxPercent)} Tax{' '}
                </Text>

                {/* This is for Rewards */}
                <Text style={[stylesPhone.moneyDisplay, {fontSize: 13}]}>
                  ${roundToTwo(rewardAmount)}
                </Text>

                {/* This is for Total Due */}
                <Text style={[stylesPhone.moneyDisplay, {fontSize: 18}]}>
                  ${roundToTwo(totalDueAfterReward)}
                </Text>

                {/* This is for Received */}
                <Text style={[stylesPhone.moneyDisplay, {fontSize: 13}]}>
                  ${roundToTwo(amountReceived)}
                </Text>

                {/* This is for Balance Due */}
                <Text style={[stylesPhone.moneyDisplay, {fontSize: 13}]}>
                  ${roundToTwo(balanceDue)}
                </Text>
              </View>
            </View>
          </View>

          <View style={{flexDirection: 'row'}}>
            <View style={stylesPhone.placeTextToLeft}>
              <View style={{flexDirection: 'row'}}>
                {expandSignature ? (
                  <View style={[stylesPhone.leftView, {marginTop: 30}]}>
                    <Image style={{width: 22, height: 22}} source={tick} />
                  </View>
                ) : expandEmail ? (
                  <View style={[stylesPhone.leftView, {marginTop: 30}]}>
                    <Image style={{width: 22, height: 22}} source={tick} />
                  </View>
                ) : (
                  <View style={[stylesPhone.leftView, {marginTop: 30}]} />
                )}
                <TouchableOpacity
                  onPress={() => {
                    setExpandPayment(!expandPayment);
                    setExpandSignature(false);
                    setExpandEmail(false);
                  }}>
                  {expandPayment ? (
                    <Image
                      style={[stylesPhone.plusContainer, {marginTop: 30}]}
                      source={minus}
                    />
                  ) : (
                    <Image
                      style={[stylesPhone.plusContainer, {marginTop: 30}]}
                      source={plus}
                    />
                  )}
                </TouchableOpacity>
                <Text
                  style={[
                    {marginTop: 30, fontWeight: 'bold'},
                    stylesPhone.leftViewText,
                  ]}>
                  Payment
                </Text>
              </View>

              {expandPayment ? (
                <View>
                  <View
                    style={{
                      flexDirection: 'row',
                    }}>
                    <View style={stylesPhone.expandLeftVerticalLinePayment} />
                    <View
                      style={{
                        flexDirection: 'column',
                        marginTop: 20,
                        marginBottom: 30,
                        width: '100%',
                      }}>
                      <View style={{flexDirection: 'row'}}>
                        <Text style={stylesPhone.rewardsCodeContainer}>
                          Rewards Code{' '}
                        </Text>
                        <TextInput
                          style={stylesPhone.textInput}
                          onChangeText={setRewardsCode}
                          value={rewardsCode}
                        />
                        <TouchableOpacity
                          onPress={() => {
                            setLoadingSpinnerVisibility(true);
                            _getRewardAmountApiReqAction(
                              selectedCustomer.CustomerId,
                              brandSuccessResponse.CompanyId,
                              rewardsCode,
                            );
                          }}>
                          <Image
                            style={stylesPhone.touchableOpacity}
                            source={refresh}
                          />
                        </TouchableOpacity>
                      </View>
                      <View style={{flexDirection: 'row'}}>
                        {customCheckBox ? (
                          <View style={stylesPhone.customCheckBox}>
                            <Image
                              style={{width: 22, height: 22}}
                              source={tick}
                            />
                          </View>
                        ) : (
                          <View
                            style={stylesPhone.customCheckBox}
                            onStartShouldSetResponder={() => {
                              setCustomCheckBox(!customCheckBox);
                              setSelectedPaymentMode(PaymentMode.CHECK);
                            }}
                          />
                        )}
                        <Text style={stylesPhone.checkReceivedContainer}>
                          Check Received
                        </Text>
                        <View style={{flexDirection: 'column'}}>
                          <View style={{flexDirection: 'row', marginTop: 30}}>
                            <TextInput
                              style={stylesPhone.textInput}
                              onChangeText={setCheckReceived}
                              value={checkReceived}
                              editable={customCheckBox}
                            />
                            <TouchableOpacity
                              onPress={() => setCheckReceived('')}>
                              <Image
                                style={stylesPhone.touchableOpacity}
                                source={refresh}
                              />
                            </TouchableOpacity>
                          </View>

                          <TextInput
                            style={stylesPhone.textInputCheckNumber}
                            onChangeText={setCheckNumber}
                            value={checkNumber}
                            placeholder="Check Number..."
                            editable={customCheckBox}
                          />
                        </View>
                      </View>
                      <View style={{flexDirection: 'row'}}>
                        {!customCheckBox ? (
                          <View style={stylesPhone.customCheckBox}>
                            <Image
                              style={{width: 22, height: 22}}
                              source={tick}
                            />
                          </View>
                        ) : (
                          <View
                            style={stylesPhone.customCheckBox}
                            onStartShouldSetResponder={() => {
                              setCustomCheckBox(!customCheckBox);
                              setSelectedPaymentMode(PaymentMode.CASH);
                            }}
                          />
                        )}
                        <Text style={stylesPhone.cashReceivedContainer}>
                          Cash Received{' '}
                        </Text>
                        <View style={{flexDirection: 'row', marginTop: 30}}>
                          <TextInput
                            style={stylesPhone.textInput}
                            onChangeText={setCashAmount}
                            value={cashAmount}
                            editable={!customCheckBox}
                          />
                          <TouchableOpacity onPress={() => setCashAmount('')}>
                            <Image
                              style={stylesPhone.touchableOpacity}
                              source={refresh}
                            />
                          </TouchableOpacity>
                        </View>
                      </View>

                      {/*Comment down payment gateway UI for future implementation*/}
                      {/*<Image*/}
                      {/*  style={stylesPhone.cardImageContainer}*/}
                      {/*  source={cards_image}*/}
                      {/*/>*/}
                      {/*<Text style={stylesPhone.cardNumberContainer}>*/}
                      {/*  Card Number*/}
                      {/*</Text>*/}
                      {/*<TextInput*/}
                      {/*  style={[stylesPhone.textInputCardNumber, {width: 250}]}*/}
                      {/*  onChangeText={setCardNumber}*/}
                      {/*  value={cardNumber}*/}
                      {/*/>*/}
                      {/*<Text style={stylesPhone.cardNumberContainer}>*/}
                      {/*  Expiry*/}
                      {/*</Text>*/}
                      {/*<TextInput*/}
                      {/*  style={[stylesPhone.textInputCardNumber, {width: 100}]}*/}
                      {/*  onChangeText={setExpiry}*/}
                      {/*  value={expiry}*/}
                      {/*/>*/}
                      {/*<Text style={stylesPhone.cardNumberContainer}>CVV</Text>*/}
                      {/*<TextInput*/}
                      {/*  keyboardType="number-pad"*/}
                      {/*  maxLength={3}*/}
                      {/*  style={[stylesPhone.textInputCardNumber, {width: 50}]}*/}
                      {/*  onChangeText={setCvv}*/}
                      {/*  value={cvv}*/}
                      {/*/>*/}
                    </View>
                  </View>
                </View>
              ) : (
                <View style={stylesPhone.leftVerticalLine} />
              )}

              <View style={{flexDirection: 'row'}}>
                {expandEmail ? (
                  <View style={stylesPhone.leftView}>
                    <Image style={{width: 22, height: 22}} source={tick} />
                  </View>
                ) : (
                  <View style={stylesPhone.leftView} />
                )}
                <TouchableOpacity
                  onPress={() => {
                    setExpandSignature(!expandSignature);
                    setExpandPayment(false);
                    setExpandEmail(false);
                  }}>
                  {expandSignature ? (
                    <Image style={stylesPhone.plusContainer} source={minus} />
                  ) : (
                    <Image style={stylesPhone.plusContainer} source={plus} />
                  )}
                </TouchableOpacity>
                <Text style={[stylesPhone.leftViewText, {fontWeight: 'bold'}]}>
                  Signature
                </Text>
              </View>

              {expandSignature ? (
                <View>
                  <View style={{flexDirection: 'row'}}>
                    <View style={stylesPhone.expandLeftVerticalLineSignature} />
                    <View style={{flexDirection: 'column', marginTop: 35}}>
                      <Text
                        style={stylesPhone.startOver}
                        onPress={() => {
                          resetSign();
                        }}>
                        Start Over
                      </Text>
                      <View style={stylesPhone.signatureContainer}>
                        {/* this is for Signature Screen */}
                        <SignatureCapture
                          style={stylesPhone.signatureCaptureContainer}
                          ref={ref}
                          onSaveEvent={_onSaveEvent}
                          onDragEvent={_onDragEvent}
                          saveImageFileInExtStorage={false}
                          showNativeButtons={false}
                          showTitleLabel={false}
                          backgroundColor="white"
                          strokeColor="black"
                          minStrokeWidth={5}
                          maxStrokeWidth={5}
                          viewMode={'portrait'}
                        />
                      </View>
                      <TextInput
                        style={[stylesPhone.textInputCardNumber, {width: 360}]}
                        onChangeText={setSignatureName}
                        value={signatureName}
                        placeholder="Signatory Name..."
                      />

                      <Text
                        style={{
                          color: APP_BLUE_COLOR,
                          width: '100%',
                          textAlign: 'right',
                          marginTop: 10,
                        }}
                        onPress={addOrderHeaderApiCall}>
                        Next
                      </Text>
                    </View>
                  </View>
                </View>
              ) : (
                <View style={stylesPhone.leftVerticalLine} />
              )}

              <View style={{flexDirection: 'row'}}>
                <View style={stylesPhone.leftView} />
                <TouchableOpacity
                  onPress={() => {
                    setExpandEmail(!expandEmail);
                    setExpandPayment(false);
                    setExpandSignature(false);
                  }}>
                  {expandEmail ? (
                    <Image style={stylesPhone.plusContainer} source={minus} />
                  ) : (
                    <Image style={stylesPhone.plusContainer} source={plus} />
                  )}
                </TouchableOpacity>
                <Text style={[stylesPhone.leftViewText, {fontWeight: 'bold'}]}>
                  Print/Email
                </Text>
              </View>

              {expandEmail ? (
                <View>
                  <View style={{flexDirection: 'row'}}>
                    <View style={stylesPhone.expandLeftVerticalLineEmail} />
                    <View style={{flexDirection: 'row', marginTop: 50}}>
                      <View style={stylesPhone.pdfContainer}>
                        {/* this is for PDF */}
                        <PDFView
                          fadeInDuration={250.0}
                          style={{flex: 1}}
                          resource={pdfBase64}
                          resourceType={'base64'}
                          onLoad={() => console.log('PDF rendered from Base64')}
                          onError={() => console.log('Cannot render PDF')}
                        />
                      </View>
                      <Text
                        style={stylesPhone.rightArrow}
                        onPress={() =>
                          navigation.navigate(ROUTE_PAYMENT_EMAIL_SCREEN)
                        }>
                        ˃
                      </Text>
                    </View>
                  </View>
                </View>
              ) : (
                <View style={stylesPhone.leftVerticalLine} />
              )}

              <View style={{flexDirection: 'row', marginBottom: 10}}>
                <View style={stylesPhone.leftView} />
                <Image style={stylesPhone.plusContainer} source={plus} />
                <Text style={[stylesPhone.leftViewText, {fontWeight: 'bold'}]}>
                  Survey
                </Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const stylesPhone = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  customCheckBox: {
    height: 26,
    width: 26,
    marginLeft: 5,
    marginTop: 30,
    borderRadius: 7,
    borderWidth: 2,
    backgroundColor: 'white',
    borderColor: 'grey',
  },
  rightArrow: {
    color: 'grey',
    fontSize: 100,
    marginLeft: 50,
    marginTop: 60,
  },
  startOver: {
    alignSelf: 'flex-end',
    fontSize: 16,
    marginBottom: 10,
  },
  signatureContainer: {
    marginLeft: 15,
    width: 360,
    height: 160,
    borderWidth: 2,
    borderColor: 'grey',
  },
  signatureCaptureContainer: {
    width: 355,
    height: 155,
  },
  pdfContainer: {
    marginLeft: 60,
    width: 180,
    height: 250,
    borderWidth: 2,
    borderColor: 'grey',
  },
  cardImageContainer: {
    marginLeft: 10,
    marginTop: 30,
  },
  cardNumberContainer: {
    marginTop: 20,
    marginLeft: 12,
    fontSize: 20,
  },
  textInputCardNumber: {
    height: 30,
    marginLeft: 15,
    borderWidth: 2,
    borderColor: 'grey',
    padding: 5,
    marginTop: 10,
  },
  // placeTextToRight: {
  //   alignItems: 'flex-end',
  // },
  placeTextToLeft: {
    alignItems: 'flex-start',
  },
  addressContainer: {
    alignItems: 'flex-start',
    marginLeft: 16,
  },
  plusContainer: {
    height: 23,
    width: 23,
    marginLeft: 10,
  },
  textInputAddress: {
    padding: 5,
    width: 190,
    height: 60,
    borderWidth: 1,
    borderColor: 'grey',
    marginLeft: 10,
    fontSize: 10,
  },
  leftVerticalLine: {
    height: 60,
    width: 2,
    marginLeft: 18,
    backgroundColor: 'grey',
  },
  expandLeftVerticalLinePayment: {
    width: 2,
    marginLeft: 16,
    backgroundColor: 'grey',
  },
  expandLeftVerticalLineSignature: {
    height: 290,
    width: 2,
    marginLeft: 18,
    backgroundColor: 'grey',
  },
  expandLeftVerticalLineEmail: {
    height: 320,
    width: 2,
    marginLeft: 18,
    backgroundColor: 'grey',
  },
  leftViewText: {
    fontSize: 16,
    marginLeft: 10,
  },
  leftView: {
    marginLeft: 6,
    height: 26,
    width: 26,
    borderRadius: 100,
    borderWidth: 2,
    backgroundColor: 'white',
    borderColor: 'grey',
  },
  textInput: {
    width: 150,
    height: 30,
    marginLeft: 15,
    borderWidth: 1.2,
    borderColor: 'grey',
    padding: 5,
  },
  rewardsCodeContainer: {
    fontSize: 18,
    marginLeft: 40,
  },
  checkReceivedContainer: {
    fontSize: 18,
    marginLeft: 9,
    marginTop: 30,
  },
  cashReceivedContainer: {
    fontSize: 18,
    marginLeft: 9,
    marginTop: 30,
  },
  textInputCheckNumber: {
    width: 120,
    height: 30,
    marginLeft: 45,
    marginTop: 10,
    borderWidth: 1.2,
    borderColor: 'grey',
    padding: 5,
  },
  placeTextToRight: {
    position: 'absolute',
    right: 0,
  },
  touchableOpacity: {
    width: 30,
    height: 30,
    marginLeft: 5,
  },
  moneyDisplay: {
    fontSize: 18,
    marginRight: 20,
    marginTop: 5,
    textAlign: 'right',
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    selectedCustomer: reduxStore.customer.selectedCustomer,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    getRewardApiResponse: reduxStore.reward.getRewardApiResponse,
    getRewardApiHttpErr: reduxStore.reward.getRewardApiHttpErr,
    getRewardApiFailErr: reduxStore.reward.getRewardApiFailErr,
    orderId: reduxStore.orderLine.orderId,
    customerInfoApiResponse: reduxStore.customerDetail.customerInfoApiResponse,
    cartTotal: reduxStore.orderLine.cartTotal,
    cartSubTotal: reduxStore.orderLine.cartSubTotal,
    cartTaxPercent: reduxStore.orderLine.cartTaxPercent,
    cartTaxValue: reduxStore.orderLine.cartTaxValue,
    rewardAmount: reduxStore.orderLine.rewardAmount,
    totalDueAfterReward: reduxStore.orderLine.totalDueAfterReward,
    amountReceived: reduxStore.orderLine.amountReceived,
    paymentMode: reduxStore.orderLine.paymentMode,
    balanceDue: reduxStore.orderLine.balanceDue,
    checkAmount: reduxStore.orderLine.checkAmount,
    checkNo: reduxStore.orderLine.checkNo,
    cashReceived: reduxStore.orderLine.cashReceived,
    orderNo: reduxStore.orderLine.orderNo,
    orderHeaderApiResponse: reduxStore.orderHeader.orderHeaderApiResponse,
    orderHeaderApiFailErr: reduxStore.orderHeader.orderHeaderApiFailErr,
    orderHeaderApiHttpErr: reduxStore.orderHeader.orderHeaderApiHttpErr,
    rewardId: reduxStore.orderLine.rewardId,
    addedItemsList: reduxStore.orderLine.addedItemsList,
    signatoryName: reduxStore.orderLine.signatoryName,
    signatorImageData: reduxStore.orderLine.signatorImageData,
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      getRewardAmountApiReqAction,
      resetRewardApiHttpErrAction,
      resetGetAmountApiFailErrAction,
      resetRewardReduxStateAction,
      setCouponCodeAction,
      setRewardAmountAction,
      setTotalDueAmtAfterRewardAction,
      setAmountReceivedAction,
      setPaymentModeAction,
      setBalanceDueAction,
      setCheckAmountAction,
      setCheckNoAction,
      setCashReceivedAction,
      setSignatoryNameAction,
      setSignatureImgDataAction,
      resetPaymentScreenDataAction,
      setRewardIdAction,
      resetRewardIdAction,
      getOrderHeaderAPiReqAction,
      resetOrderHeaderApiFailErrAction,
      resetOrderHeaderApiHttpErrAction,
      resetOrderHeaderApiResponseAction,
    })(TicketProcessingMobileView),
  ),
);
