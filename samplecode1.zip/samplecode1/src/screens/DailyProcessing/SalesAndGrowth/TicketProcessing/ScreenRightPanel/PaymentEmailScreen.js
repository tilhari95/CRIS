import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import {default as DeviceInfo} from 'react-native-device-info';

import {
  ROUTE_CUSTOMER_DETAIL,
  ROUTE_PAYMENT_SURVEY_SCREEN,
  ROUTE_PAYMENT_SIGNATURE_SCREEN,
} from '../../../../../resources/constants/navigationConstants';

import {
  cards_image,
  p_and_s,
  refresh,
  tick,
} from '../../../../../resources/images';

import {Header} from 'react-native-elements';
import {createInvoicePDF} from '../../../../../utils/invoicePDFUtil/invoicePDFCreater';
import {connect} from 'react-redux';
import withHttpsApiErrorHandling from '../../../../../components/HOC/withHttpsApiErrorHandling';
import withLoadingSpinner from '../../../../../components/HOC/withLoadingSpinner';
import {roundToTwo} from '../../../../../utils/validators';

import {resetOrderLineStoreAction} from '../../../../../store/OrderLine/orderLineAction';

import PDFView from 'react-native-view-pdf';

const PaymentEmailScreen = ({
  navigation,
  addedItemsList,
  orderId,
  brandSuccessResponse,
  selectedCustomer,
  customerInfoApiResponse,
  cartTotal,
  cartSubTotal,
  cartTaxPercent,
  cartTaxValue,
  rewardAmount,
  totalDueAfterReward,
  amountReceived,
  paymentMode,
  balanceDue,
  checkAmount,
  checkNo,
  cashReceived,
  rewardId,
  signatoryName,
  signatorImageData,
  resetOrderLineStoreAction: _resetOrderLineStoreAction,
}) => {
  const [pdfBase64, setPdfBase64] = useState('');

  useEffect(() => {
    generatePDF();
  }, []);

  const generatePDF = async (openOnIntent = false) => {
    let orderInfoJson = {
      OrderId: orderId,
      CompanyDetail: brandSuccessResponse,
      CustomerDetail: selectedCustomer,
      CustomerInfo: customerInfoApiResponse,
      ItemList: addedItemsList,
      CartTotal: cartTotal,
      CartSubTotal: cartSubTotal,
      CartTaxPercent: cartTaxPercent,
      CartTaxValue: cartTaxValue,
      RewardAmount: rewardAmount,
      TotalDueAfterReward: totalDueAfterReward,
      AmountReceived: amountReceived,
      PaymentMode: paymentMode,
      BalanceDue: balanceDue,
      CheckAmount: checkAmount,
      CheckNo: checkNo,
      CashReceived: cashReceived,
      RewardId: rewardId,
      SignatoryName: signatoryName,
      SignatorImageData: signatorImageData,
    };
    console.log(orderInfoJson);
    let generatedPdfObject = await createInvoicePDF(
      orderInfoJson,
      openOnIntent,
    );
    setPdfBase64(generatedPdfObject.base64);
  };

  const shareFile = async() => {
    const shareOptions = {
        message : 'this is meaage body',
        url : "data:application/pdf;base64," + pdfBase64,
        subject : "Invoice PDF",                     
    }

    try {
        const shareResopnse = await Share.open(shareOptions);
        console.log("User Choosen -> "+JSON.stringify(shareResopnse));
    } catch(error){
        console.log("Error -> "+error);
    }
};



  return (
    <View style={styles.container}>
      <Header
        centerComponent={{
          text: 'SPLASH EXPRESS - COTATI',
          style: {color: '#fff'},
        }}
      />
      <View style={styles.container}>
        {DeviceInfo.isTablet() ? (
          <View style={[styles.container, {flexDirection: 'row'}]}>
            <View style={styles.leftContainer}>
              <View
                style={styles.viewContainer}
                onStartShouldSetResponder={() =>
                  navigation.navigate(ROUTE_PAYMENT_SIGNATURE_SCREEN)
                }>
                <Text style={{color: 'blue', fontSize: 50}}>‹</Text>
                <Text style={styles.backButton}>Back</Text>
              </View>

              <View style={{flexDirection: 'row'}}>
                <View style={[styles.leftView, {marginTop: 80}]}>
                  <Image style={{width: 22, height: 22}} source={tick} />
                </View>
                <Text style={[{marginTop: 80}, styles.leftViewText]}>
                  Payment
                </Text>
              </View>

              <View style={styles.leftVerticalLine}></View>

              <View style={{flexDirection: 'row'}}>
                <View style={styles.leftView}>
                  <Image style={{width: 22, height: 22}} source={tick} />
                </View>
                <Text style={styles.leftViewText}>Signature</Text>
              </View>

              <View style={styles.leftVerticalLine}></View>

              <View style={{flexDirection: 'row'}}>
                <View style={styles.leftView} />
                <Text style={styles.leftViewText}>Print/Email</Text>
              </View>

              <View style={styles.leftVerticalLine}></View>

              <View style={{flexDirection: 'row'}}>
                <View style={styles.leftView} />
                <Text style={styles.leftViewText}>Survey</Text>
              </View>
            </View>
            <View style={styles.rightContainer}>
              <View style={styles.rightViewTopBar}>
                <Text
                  style={[styles.topRightSideText, {marginRight: 95}]}
                  onPress={shareFile}>
                  Send
                </Text>
                <Text
                  style={[styles.topRightSideText, {marginRight: 55}]}
                  onPress={shareFile}>
                  Mail
                </Text>
                <Text
                  style={[styles.topRightSideText, {marginRight: 15}]}
                  onPress={generatePDF} // send all data here as args...
                >
                  Print
                </Text>
              </View>
              
                <PDFView
                  fadeInDuration={250.0}
                  style={{ flex: 1 }}
                  resource={pdfBase64}
                  resourceType={'base64'}
                  onLoad={() => console.log('PDF rendered from Base64')}
                  onError={() => console.log('Cannot render PDF')}
                />
             
              <View style={{height: 40}}>
                <Text
                  style={styles.nextButton}
                  onPress={() => {
                    _resetOrderLineStoreAction();
                    navigation.navigate(ROUTE_CUSTOMER_DETAIL);
                  }}>
                  Next...
                </Text>
              </View>
            </View>
          </View>
        ) : (
          <View style={styles.container}>
            <View style={styles.rightViewTopBar}>
              <Text
                style={styles.returnToTicket}
                onPress={() => navigation.pop()}>
                {' '}
                Back{' '}
              </Text>

              <Text
                style={[styles.topRightSideText, {marginRight: 95}]}
                //open directly  using () without args afterwards delete this....
                onPress={
                  generatePDF // send all data here as args...
                }>
                Send
              </Text>
              <Text
                style={[styles.topRightSideText, {marginRight: 55}]}
                onPress={
                  shareFile // send all data here as args...
                }>
                Mail
              </Text>
              <Text
                style={[styles.topRightSideText, {marginRight: 15}]}
                onPress={generatePDF}>
                Print
              </Text>
            </View>
            <View>
              <PDFView
                fadeInDuration={250.0}
                style={{height: '100%', width: '100%'}}
                resource={pdfBase64}
                resourceType={'base64'}
                onLoad={() => console.log('PDF rendered from Base64')}
                onError={() => console.log('Cannot render PDF')}
              />
            </View>
          </View>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  backButton: {
    color: 'blue',
    fontSize: 20,
    padding: 10,
    marginTop: 15,
  },
  leftView: {
    marginLeft: 80,
    height: 26,
    width: 26,
    borderRadius: 100,
    borderWidth: 2,
    backgroundColor: 'white',
    borderColor: 'grey',
  },
  leftViewText: {
    fontSize: 16,
    marginLeft: 30,
  },
  leftVerticalLine: {
    height: 50,
    width: 2,
    marginLeft: 93,
    backgroundColor: 'grey',
  },
  viewContainer: {
    flexDirection: 'row',
    marginLeft: 10,
  },
  leftContainer: {
    backgroundColor: 'lightgrey',
    width: '40%',
  },
  rightContainer: {
    backgroundColor: 'white',
    width: '60%',
    flexDirection: 'column',
  },
  rightViewTopBar: {
    flexDirection: 'row',
    marginLeft: 10,
    height: 40,
  },
  returnToTicket: {
    fontSize: 15,
    color: 'blue',
    padding: 10,
  },
  topRightSideText: {
    color: 'blue',
    fontSize: 16,
    marginTop: 10,
    right: 0,
    position: 'absolute',
  },
  nextButton: {
    fontSize: 25,
    marginBottom: 10,
    marginRight: 10,
    right: 0,
    bottom: 0,
    position: 'absolute',
    color: 'blue',
  },
  topBorder: {
    height: 50,
    backgroundColor: '#A865C9',
    fontSize: 25,
    textAlign: 'center',
    padding: 6,
    justifyContent: 'center',
    alignItems: 'center',
    color: '#FFFFFF',
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    addedItemsList: reduxStore.orderLine.addedItemsList,
    orderId: reduxStore.orderLine.orderId,
    selectedCustomer: reduxStore.customer.selectedCustomer,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    customerInfoApiResponse: reduxStore.customerDetail.customerInfoApiResponse,

    cartTotal: reduxStore.orderLine.cartTotal,
    cartSubTotal: reduxStore.orderLine.cartSubTotal,
    cartTaxPercent: reduxStore.orderLine.cartTaxPercent,
    cartTaxValue: reduxStore.orderLine.cartTaxValue,
    rewardAmount: reduxStore.orderLine.rewardAmount,
    totalDueAfterReward: reduxStore.orderLine.totalDueAfterReward,
    amountReceived: reduxStore.orderLine.amountReceived,
    paymentMode: reduxStore.orderLine.paymentMode,
    balanceDue: reduxStore.orderLine.balanceDue,
    checkAmount: reduxStore.orderLine.checkAmount,
    checkNo: reduxStore.orderLine.checkNo,
    cashReceived: reduxStore.orderLine.cashReceived,
    rewardId: reduxStore.orderLine.rewardId,
    signatoryName: reduxStore.orderLine.signatoryName,
    signatorImageData: reduxStore.orderLine.signatorImageData,
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      resetOrderLineStoreAction,
    })(PaymentEmailScreen),
  ),
);
