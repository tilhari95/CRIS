import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
  ScrollView,
  TouchableWithoutFeedback,
} from 'react-native';
import {default as DeviceInfo} from 'react-native-device-info';
import TicketProcessingMobileView from './TicketProcessingMobileView';
import {
  ROUTE_CUSTOMER_DETAIL,
  ROUTE_PAYMENT_SIGNATURE_SCREEN,
  ROUTE_PAYMENT_EMAIL_SCREEN,
} from '../../../../../resources/constants/navigationConstants';
import {connect} from 'react-redux';
import withHttpsApiErrorHandling from '../../../../../components/HOC/withHttpsApiErrorHandling';
import withLoadingSpinner from '../../../../../components/HOC/withLoadingSpinner';
import {
  roundToTwo,
  validateRequiredField,
} from '../../../../../utils/validators';

import {Header, Divider} from 'react-native-elements';
import {
  cards_image,
  p_and_s,
  refresh,
  plus,
  minus,
  back,
  tick,
} from '../../../../../resources/images';
import SignatureCapture from 'react-native-signature-capture';
import {
  getRewardAmountApiReqAction,
  resetRewardApiHttpErrAction,
  resetGetAmountApiFailErrAction,
  resetRewardReduxStateAction,
} from '../../../../../store/Reward/rewardAction';
import {
  setCouponCodeAction,
  setRewardAmountAction,
  setTotalDueAmtAfterRewardAction,
  setAmountReceivedAction,
  setPaymentModeAction,
  setBalanceDueAction,
  setCheckAmountAction,
  setCheckNoAction,
  setCashReceivedAction,
  setSignatoryNameAction,
  setSignatureImgDataAction,
  resetPaymentScreenDataAction,
  setRewardIdAction,
  resetRewardIdAction,
} from '../../../../../store/OrderLine/orderLineAction';

import SimpleToast from 'react-native-simple-toast';
import {
  COLORS,
  PaymentMode,
} from '../../../../../resources/constants/themeConstant';

const PaymentScreen = ({
  navigation,
  setLoadingSpinnerVisibility,
  showHttpsApiErrorDialog,
  getRewardAmountApiReqAction: _getRewardAmountApiReqAction,
  resetRewardApiHttpErrAction: _resetRewardApiHttpErrAction,
  resetGetAmountApiFailErrAction: _resetGetAmountApiFailErrAction,
  getRewardApiResponse,
  getRewardApiHttpErr,
  getRewardApiFailErr,
  selectedCustomer,
  brandSuccessResponse,
  orderId,
  cartSubTotal,
  resetRewardReduxStateAction: _resetRewardReduxStateAction,
  customerInfoApiResponse,
  setCouponCodeAction: _setCouponCodeAction,
  setRewardAmountAction: _setRewardAmountAction,
  setTotalDueAmtAfterRewardAction: _setTotalDueAmtAfterRewardAction,
  setAmountReceivedAction: _setAmountReceivedAction,
  setPaymentModeAction: _setPaymentModeAction,
  setBalanceDueAction: _setBalanceDueAction,
  setCheckAmountAction: _setCheckAmountAction,
  setCheckNoAction: _setCheckNoAction,
  setCashReceivedAction: _setCashReceivedAction,
  setSignatoryNameAction: _setSignatoryNameAction,
  setSignatureImgDataAction: _setSignatureImgDataAction,
  resetPaymentScreenDataAction: _resetPaymentScreenDataAction,
  cartTotal,
  cartTaxPercent,
  cartTaxValue,
  rewardAmount,
  totalDueAfterReward,
  amountReceived,
  paymentMode,
  balanceDue,
  checkAmount,
  checkNo,
  cashReceived,
  setRewardIdAction: _setRewardIdAction,
  resetRewardIdAction: _resetRewardIdAction,
  orderNo,
}) => {
  const [customCheckBox, setCustomCheckBox] = React.useState(true);
  const [soldToSelected, setSoldToSelected] = useState(true);
  const [isShipToAvailable, setIsShipToAvailable] = useState(false);
  const [selectedPaymentMode, setSelectedPaymentMode] = useState('');

  //Reward
  const [rewardsCode, setRewardsCode] = React.useState('');
  const [rewardValue, setRewardValue] = useState('0.00');

  //Check
  const [checkReceived, setCheckReceived] = React.useState('');
  const [checkNumber, setCheckNumber] = React.useState('');

  //Cash
  const [cashAmount, setCashAmount] = React.useState('');


  const [customerInfo, setCustomerInfo] = useState('');

  const ref = React.useRef(null);

  useEffect(() => {
    _resetRewardReduxStateAction();
    _resetPaymentScreenDataAction();
    setPaymentModeAction(PaymentMode.CHECK);
    setSelectedPaymentMode(PaymentMode.CHECK);
  }, []);

  useEffect(() => {
    if (validateRequiredField(customerInfoApiResponse)) {
      setCustomerInfo(customerInfoApiResponse);

      if (validateRequiredField(customerInfoApiResponse.ShippingAddressId)) {
        setIsShipToAvailable(true);
      } else {
        setIsShipToAvailable(false);
      }
    }
  }, [customerInfoApiResponse]);

  useEffect(() => {
    if (!validateRequiredField(rewardAmount)) {
      _setRewardAmountAction(0);
    }

    if (!validateRequiredField(amountReceived)) {
      _setAmountReceivedAction(0);
    }

    if (validateRequiredField(getRewardApiResponse)) {
      setLoadingSpinnerVisibility(false);

      _setRewardIdAction(getRewardApiResponse.RewardId);

      if (getRewardApiResponse.DiscountType === 'A') {
        _setRewardAmountAction(getRewardApiResponse.DiscountPercentOrAmount);
      } else if (getRewardApiResponse.DiscountType === 'P') {
        let amt =
          (cartSubTotal * getRewardApiResponse.DiscountPercentOrAmount) / 100;
        _setRewardAmountAction(amt);
      } else {
        _setRewardAmountAction(0);
      }
    } else {
      _resetRewardIdAction();
    }

    //Due after reward apply
    let totalDueAfReward = cartSubTotal - rewardAmount;
    if (validateRequiredField(totalDueAfReward)) {
      _setTotalDueAmtAfterRewardAction(roundToTwo(totalDueAfReward));
    } else {
      _setTotalDueAmtAfterRewardAction(0);
    }

    // Total due balance
    let totalDVal = cartSubTotal - rewardAmount - amountReceived;
    if (validateRequiredField(totalDVal)) {
      _setBalanceDueAction(roundToTwo(totalDVal));
    } else {
      _setBalanceDueAction(0);
    }
  }, [getRewardApiResponse, rewardAmount, amountReceived]);

  useEffect(() => {
    if (validateRequiredField(getRewardApiHttpErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(getRewardApiHttpErr);
      _resetRewardApiHttpErrAction(getRewardApiFailErr);
    }
  }, [getRewardApiHttpErr]);

  useEffect(() => {
    if (validateRequiredField(getRewardApiFailErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(getRewardApiFailErr);
      _resetGetAmountApiFailErrAction(getRewardApiFailErr);
    }
  }, [getRewardApiFailErr]);

  useEffect(() => {
    if (validateRequiredField(selectedPaymentMode)) {
      switch (selectedPaymentMode) {
        case PaymentMode.CASH:
          _setCashReceivedAction(cashAmount);
          _setAmountReceivedAction(cashAmount);
          _setPaymentModeAction(PaymentMode.CASH);
          break;

        case PaymentMode.CHECK:
          _setCheckAmountAction(checkReceived);
          _setCheckNoAction(checkNumber);
          _setAmountReceivedAction(checkReceived);
          _setPaymentModeAction(PaymentMode.CHECK);
          break;

        default:
          console.log('No payment mode selected');
          break;
      }
    }
  }, [selectedPaymentMode, checkNumber, checkReceived, cashAmount]);

  function saveSign() {
    ref.current.saveImage();
  }

  function resetSign() {
    ref.current.resetImage();
  }

  const _onSaveEvent = (result) => {
    //result.encoded - for the base64 encoded png
    //result.pathName - for the file path name
    console.log(result);
  };

  const _onDragEvent = () => {
    // This callback will be called when the user enters signature
    console.log('dragged');
  };

  return (
    <View style={styles.container}>
      <Header
        centerComponent={{
          text: selectedCustomer.CustomerName,
          style: {color: '#fff'},
        }}
      />
      <View style={styles.container}>
        {DeviceInfo.isTablet() ? (
          <View style={[styles.container, {flexDirection: 'row'}]}>
            <View style={styles.leftContainer}>
              <View
                style={styles.viewContainer}
                onStartShouldSetResponder={() => navigation.pop()}>
                <Text style={{color: 'blue', fontSize: 50}}>‹</Text>
                <Text style={styles.backButton}>Back</Text>
              </View>

              <View style={{flexDirection: 'row'}}>
                <View style={[styles.leftView, {marginTop: 80}]} />
                <Text style={[{marginTop: 80}, styles.leftViewText]}>
                  Payment
                </Text>
              </View>

              <View style={styles.leftVerticalLine}></View>

              <View style={{flexDirection: 'row'}}>
                <View style={styles.leftView} />
                <Text style={styles.leftViewText}>Signature</Text>
              </View>

              <View style={styles.leftVerticalLine}></View>

              <View style={{flexDirection: 'row'}}>
                <View style={styles.leftView} />
                <Text style={styles.leftViewText}>Print/Email</Text>
              </View>

              <View style={styles.leftVerticalLine}></View>

              <View style={{flexDirection: 'row'}}>
                <View style={styles.leftView} />
                <Text style={styles.leftViewText}>Survey</Text>
              </View>
            </View>
            <View style={styles.rightContainer}>
              <View style={styles.viewContainer}>
                <View>
                  <View style={{flexDirection: 'column'}}>
                    <Text style={styles.companyName}>
                      {brandSuccessResponse.CompanyName}
                    </Text>
                    <View>
                      <View style={styles.addressSelection}>
                        <TouchableWithoutFeedback
                          on
                          onPress={() => setSoldToSelected(true)}>
                          <View>
                            <Text>Sold To:</Text>
                            <Divider
                              style={[
                                soldToSelected
                                  ? {backgroundColor: 'blue'}
                                  : {backgroundColor: COLORS.grayDark},
                                {},
                              ]}
                            />
                          </View>
                        </TouchableWithoutFeedback>
                        {isShipToAvailable ? (
                          <TouchableWithoutFeedback
                            onPress={() => setSoldToSelected(false)}>
                            <View style={{marginStart: 10}}>
                              <Text>Ship To</Text>
                              <Divider
                                style={[
                                  soldToSelected
                                    ? {backgroundColor: COLORS.grayDark}
                                    : {backgroundColor: 'blue'},
                                  {},
                                ]}
                              />
                            </View>
                          </TouchableWithoutFeedback>
                        ) : null}
                      </View>
                      {soldToSelected ? (
                        <View style={styles.address}>
                          <Text style={styles.textStyle}>
                            {customerInfo.CustomerName}
                          </Text>
                          <Text style={styles.textStyle}>
                            {customerInfo.Address1}
                          </Text>
                          <Text style={styles.textStyle}>
                            {customerInfo.City}
                          </Text>
                          <Text style={styles.textStyle}>
                            {customerInfo.State} , {customerInfo.PostalCode}
                          </Text>
                        </View>
                      ) : (
                        <View style={styles.address}>
                          <Text style={styles.textStyle}>
                            {customerInfo.ShipToName}
                          </Text>
                          <Text style={styles.textStyle}>
                            {customerInfo.ShipToAddress1}
                          </Text>
                          <Text style={styles.textStyle}>
                            {customerInfo.ShipToCity}
                          </Text>
                          <Text style={styles.textStyle}>
                            {customerInfo.ShipToState}, {customerInfo.ShipToZip}
                          </Text>
                        </View>
                      )}
                    </View>
                  </View>
                </View>

                <View style={styles.imageContainer}>
                  <Image style={{width: 80, height: 80}} source={p_and_s} />
                </View>

                <View style={{width: '25%'}}>
                  <View style={[styles.placeTextToRight, {bottom: 0}]}>
                    <Text style={{fontSize: 15}}>
                      {' '}
                      Invoice : {orderNo ? orderNo : 'NA'}{' '}
                    </Text>
                  </View>
                  <View style={styles.placeTextToRight}>
                    {/* <Text
                      style={styles.returnToTicketContainer}
                      onPress={() =>
                        navigation.navigate(ROUTE_CUSTOMER_DETAIL)
                      }>
                      {' '}
                      Return to Ticket{' '}
                    </Text> */}
                  </View>
                </View>
              </View>

              <View style={styles.rightFullHorizontalLine} />

              <View style={{flex: 1, flexDirection: 'row'}}>
                <View style={{left: 0, position: 'absolute'}}>
                  <Text style={styles.paymentContainer}>Payment</Text>
                  <Text style={styles.rewardsCodeContainer}>Rewards Code</Text>
                  <View style={{flexDirection: 'row'}}>
                    <TextInput
                      style={[styles.textInput, {marginLeft: 60}]}
                      onChangeText={setRewardsCode}
                      value={rewardsCode}
                    />
                    <TouchableOpacity
                      onPress={() => {
                        setLoadingSpinnerVisibility(true);
                        _getRewardAmountApiReqAction(
                          selectedCustomer.CustomerId,
                          brandSuccessResponse.CompanyId,
                          rewardsCode,
                        );
                      }}>
                      <Image style={styles.touchableOpacity} source={refresh} />
                    </TouchableOpacity>
                  </View>

                  <Text style={styles.checkReceivedContainer}>
                    Check Received
                  </Text>
                  <View style={{flexDirection: 'row'}}>
                    {customCheckBox ? (
                      <View style={styles.customCheckBox}>
                        <Image style={{width: 22, height: 22}} source={tick} />
                      </View>
                    ) : (
                      <View
                        style={styles.customCheckBox}
                        onStartShouldSetResponder={() => {
                          setCustomCheckBox(!customCheckBox);
                          setSelectedPaymentMode(PaymentMode.CHECK);
                        }}
                      />
                    )}
                    <TextInput
                      style={[styles.textInput, {marginLeft: 25}]}
                      onChangeText={setCheckReceived}
                      value={checkReceived}
                      editable={customCheckBox}
                    />
                    <TouchableOpacity onPress={() => setCheckReceived(0)}>
                      <Image style={styles.touchableOpacity} source={refresh} />
                    </TouchableOpacity>
                  </View>

                  <TextInput
                    style={styles.textInputCheckNumber}
                    onChangeText={setCheckNumber}
                    value={checkNumber}
                    placeholder="Check Number..."
                    editable={customCheckBox}
                  />

                  <Text style={styles.cashReceivedContainer}>
                    Cash Received
                  </Text>
                  <View style={{flexDirection: 'row'}}>
                    {!customCheckBox ? (
                      <View style={styles.customCheckBox}>
                        <Image style={{width: 22, height: 22}} source={tick} />
                      </View>
                    ) : (
                      <View
                        style={styles.customCheckBox}
                        onStartShouldSetResponder={() => {
                          setCustomCheckBox(!customCheckBox);
                          setSelectedPaymentMode(PaymentMode.CASH);
                        }}
                      />
                    )}
                    <TextInput
                      style={[styles.textInput, {marginLeft: 25}]}
                      onChangeText={setCashAmount}
                      value={cashAmount}
                      editable={!customCheckBox}
                    />
                    <TouchableOpacity onPress={() => setCashAmount(0)}>
                      <Image style={styles.touchableOpacity} source={refresh} />
                    </TouchableOpacity>
                  </View>
                </View>

                <View
                  style={[
                    styles.placeTextToRight,
                    {marginTop: 50, flexDirection: 'row'},
                  ]}>
                  <View>
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]} />
                    <Text style={[styles.moneyDisplay, {fontSize: 10}]} />
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]}>
                      Reward:
                    </Text>
                    <Text style={[styles.moneyDisplay, {fontSize: 23}]}>
                      Total Due:
                    </Text>
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]}>
                      Received:
                    </Text>
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]}>
                      Balance Due:
                    </Text>
                  </View>
                  <View>
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]}>
                      ${roundToTwo(cartTotal)}
                    </Text>
                    <Text style={[styles.moneyDisplay, {fontSize: 10}]}>
                      plus ${cartTaxPercent} Tax{' '}
                    </Text>
                    <View style={styles.rightBalanceHorizontalLine} />

                    {/* {/ This is for Rewards /} */}
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]}>
                      ${roundToTwo(rewardAmount)}
                    </Text>

                    {/* {/ This is for Total Due /} */}
                    <Text style={[styles.moneyDisplay, {fontSize: 23}]}>
                      ${roundToTwo(totalDueAfterReward)}
                    </Text>

                    {/* {/ This is for Received /} */}
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]}>
                      ${roundToTwo(amountReceived)}
                    </Text>
                    <View style={styles.rightBalanceHorizontalLine} />

                    {/* {/ This is for Balance Due /} */}
                    <Text style={[styles.moneyDisplay, {fontSize: 18}]}>
                      ${roundToTwo(balanceDue)}
                    </Text>
                  </View>
                </View>
              </View>

              <Image
                style={{marginLeft: '25%', marginBottom: '12%'}}
                source={cards_image}
              />
              <Text
                style={styles.nextButton}
                onPress={() =>
                  navigation.navigate(ROUTE_PAYMENT_SIGNATURE_SCREEN)
                }>
                Next...
              </Text>
            </View>
          </View>
        ) : (
          <TicketProcessingMobileView />
        )}
      </View>
    </View>
  );
};


const styles = StyleSheet.create({
  companyName: {
    marginTop: 10,
    fontWeight: 'bold',
  },
  container: {
    flex: 1,
  },
  backButton: {
    color: 'blue',
    fontSize: 20,
    padding: 10,
    marginTop: 15,
  },
  leftView: {
    marginLeft: 80,
    height: 26,
    width: 26,
    borderRadius: 100,
    borderWidth: 2,
    backgroundColor: 'white',
    borderColor: 'grey',
  },
  leftViewText: {
    fontSize: 16,
    marginLeft: 30,
  },
  leftVerticalLine: {
    height: 50,
    width: 2,
    marginLeft: 93,
    backgroundColor: 'grey',
  },
  rightSmallHorizontalLine: {
    borderBottomColor: 'blue',
    borderBottomWidth: 1,
  },
  rightFullHorizontalLine: {
    borderBottomColor: 'black',
    borderBottomWidth: 1,
  },
  imageContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeTextToRight: {
    position: 'absolute',
    right: 0,
  },
  textInput: {
    width: 180,
    height: 30,
    borderWidth: 1.2,
    padding: 5,
  },
  textInputCheckNumber: {
    width: 150,
    height: 30,
    marginLeft: 90,
    marginTop: 5,
    borderWidth: 1.2,
    padding: 5,
  },
  touchableOpacity: {
    width: 30,
    height: 30,
    marginLeft: 5,
  },
  nextButton: {
    fontSize: 25,
    marginBottom: 10,
    marginRight: 10,
    right: 0,
    bottom: 0,
    position: 'absolute',
    color: 'blue',
  },
  moneyDisplay: {
    fontSize: 18,
    marginRight: 20,
    marginTop: 5,
    textAlign: 'right',
  },
  viewContainer: {
    flexDirection: 'row',
    marginLeft: 10,
  },
  leftContainer: {
    backgroundColor: 'lightgrey',
    width: '40%',
  },
  rightContainer: {
    backgroundColor: 'white',
    width: '60%',
  },
  addressContainer: {
    fontSize: 14,
    marginLeft: 5,
  },
  returnToTicketContainer: {
    fontSize: 15,
    color: 'blue',
    padding: 10,
  },
  paymentContainer: {
    fontSize: 26,
    padding: 20,
  },
  rewardsCodeContainer: {
    fontSize: 20,
    marginLeft: 60,
  },
  checkReceivedContainer: {
    fontSize: 20,
    marginLeft: 60,
    marginTop: 20,
  },
  cashReceivedContainer: {
    fontSize: 20,
    marginLeft: 60,
    marginTop: 20,
  },
  topBorder: {
    height: 50,
    backgroundColor: '#A865C9',
    fontSize: 25,
    textAlign: 'center',
    padding: 6,
    justifyContent: 'center',
    alignItems: 'center',
    color: '#FFFFFF',
  },
  customCheckBox: {
    height: 26,
    width: 26,
    marginLeft: 10,
    borderRadius: 10,
    borderWidth: 2,
    backgroundColor: 'white',
    borderColor: 'grey',
  },
  addressSelection: {
    flexDirection: 'row',
    alignContent: 'center',
    marginTop: 5,
  },
  address: {
    marginTop: 10,
    marginBottom: 10,
  },
  textStyle: {
    fontSize: 10,
  },
  rightBalanceHorizontalLine: {
    borderBottomWidth: 1,
    borderBottomColor: 'grey',
    marginRight: 20,
    width: 120,
    alignSelf: 'flex-end',
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    selectedCustomer: reduxStore.customer.selectedCustomer,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    getRewardApiResponse: reduxStore.reward.getRewardApiResponse,
    getRewardApiHttpErr: reduxStore.reward.getRewardApiHttpErr,
    getRewardApiFailErr: reduxStore.reward.getRewardApiFailErr,
    orderId: reduxStore.orderLine.orderId,
    customerInfoApiResponse: reduxStore.customerDetail.customerInfoApiResponse,
    cartTotal: reduxStore.orderLine.cartTotal,
    cartSubTotal: reduxStore.orderLine.cartSubTotal,
    cartTaxPercent: reduxStore.orderLine.cartTaxPercent,
    cartTaxValue: reduxStore.orderLine.cartTaxValue,
    rewardAmount: reduxStore.orderLine.rewardAmount,
    totalDueAfterReward: reduxStore.orderLine.totalDueAfterReward,
    amountReceived: reduxStore.orderLine.amountReceived,
    paymentMode: reduxStore.orderLine.paymentMode,
    balanceDue: reduxStore.orderLine.balanceDue,
    checkAmount: reduxStore.orderLine.checkAmount,
    checkNo: reduxStore.orderLine.checkNo,
    cashReceived: reduxStore.orderLine.cashReceived,
    orderNo: reduxStore.orderLine.orderNo,
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      getRewardAmountApiReqAction,
      resetRewardApiHttpErrAction,
      resetGetAmountApiFailErrAction,
      resetRewardReduxStateAction,
      setCouponCodeAction,
      setRewardAmountAction,
      setTotalDueAmtAfterRewardAction,
      setAmountReceivedAction,
      setPaymentModeAction,
      setBalanceDueAction,
      setCheckAmountAction,
      setCheckNoAction,
      setCashReceivedAction,
      setSignatoryNameAction,
      setSignatureImgDataAction,
      resetPaymentScreenDataAction,
      setRewardIdAction,
      resetRewardIdAction,
    })(PaymentScreen),
  ),
);
