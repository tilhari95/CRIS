import React from 'react';
import { StyleSheet, Text, View, Image, ScrollView } from 'react-native';
import { tick } from '../../../../../resources/images';

const TimelineTab = () => {
  var imagesNotes = [];
  var messageNotes = [];
  var Notes = [];

  messageNotes.push(["Issue with compounds", "check in detailing department indicate that the 5g of 76321 has grit that has obvious when the container was opened", "12.30pm"])
  messageNotes.push(["Demo of new products", "Left Samples as well and Response is good", "02.30pm"])
  messageNotes.push(["Issue with compounds", "check in detailing department indicate that the 5g of 76321 has grit that has obvious when the container was opened", "12.30pm"])
  messageNotes.push(["Demo of new products", "Left Samples as well and Response is good", "02.30pm"])
  messageNotes.push(["Issue with compounds", "check in detailing department indicate that the 5g of 76321 has grit that has obvious when the container was opened", "12.30pm"])
  messageNotes.push(["Demo of new products", "Left Samples as well and Response is good", "02.30pm"])
  messageNotes.push(["Demo of new products", "Left Samples as well and Response is good", "02.30pm"])

  for (var i = 0; i < messageNotes.length; i++) {
    Notes.push(
      <View style={styles.container}>
        <Image style={styles.image} source={tick} />
        <View style={{ flexDirection: 'column' }}>
          <Text style={[{ fontSize: 20 }, styles.messageTaskContainer]}>{messageNotes[i][0]}</Text>
          <Text style={[{ fontSize: 17 }, styles.messageTaskContainer]}>{messageNotes[i][1]}</Text>
          <Text style={[{ fontSize: 17,marginBottom : 10 }, styles.messageTaskContainer]}>{messageNotes[i][2]}</Text>
        </View>
      </View>
    )
  }

  return (
    <ScrollView style={{ flex: 1 }}>
      <Text style={styles.notesContainer}>Notes</Text>
      {Notes}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    marginLeft: 30,
    marginTop: 5
  },
  notesContainer: {
    margin: 10,
    color: 'white',
    fontSize: 20
  },
  image: {
    width: 22,
    height: 22,
    marginLeft: 10
  },
  messageTaskContainer: {
    marginLeft: 20,
    marginRight: 70,
    color: 'white'
  },
})

export default TimelineTab;