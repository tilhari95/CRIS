import React from 'react';
import { Text } from 'react-native';

const ContactTab = () => {
  return (
    <Text>Coming Soon.</Text>
  );
}

export default ContactTab;