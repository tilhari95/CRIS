import React, {useEffect, useState} from 'react';
import {ActivityIndicator, Dimensions, StyleSheet, View} from 'react-native';
import GenericTemplate from '../../../../components/GenericTemplate/GenericTemplate';
import {default as DeviceInfo} from 'react-native-device-info';
import FastImage from 'react-native-fast-image';
import ContactTab from './contacts/ContactTab';
import TaskTab from './tasks/TaskTab'
import CustomerDetailTab from './details/CustomerDetailTab'
import CustomerInfo from './CustomerInfo'

import {
  AUTH_STACK_CONTAINER_WIDTH,
  AUTH_STACK_LOGO_HEIGHT,
  AUTH_STACK_LOGO_WIDTH,
  INPUT_FIELD_HEIGHT,
  MODAL_CONTAINER_WIDTH,
  SPACING_10,
  SPACING_15,
  SPACING_30,
  TEXT_SIZE_15,
} from '../../../../resources/constants/dimensions';
import {
    APP_BLUE_COLOR,
    ERROR_COLOR,
    FIELD_BORDER_RADIUS,
    FIELD_BORDER_WIDTH,
    GENERIC_BACKGROUND_COLOR,
    HEADER_FONT_WEIGHT,
    INPUT_FIELD_BORDER_COLOR,
    MODAL_BACKDROP_OPACITY,
    PRODUCT_BORDER_COLOR,
    TEXT_FONT_WEIGHT,
} from '../../../../resources/constants/themeConstant';
import {WebView} from 'react-native-webview';
import {Text} from 'react-native-elements';
import {
  resetPasswordRequest,
  setHttpResetErrorToInitial,
  setPasswordReduxInitialState,
} from '../../../../store/ResetPassword/resetPasswordAction';
import {connect} from 'react-redux';
import withLoadingSpinner from '../../../../components/HOC/withLoadingSpinner';
import withHttpsApiErrorHandling from '../../../../components/HOC/withHttpsApiErrorHandling';
import UserBrandHeader from '../../../../components/Headers/UserBrandHeader';
import {SceneMap, TabBar, TabView} from 'react-native-tab-view';
//import CustomersTab from '../CustomersTab';

import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { validateRequiredField } from '../../../../utils/validators';

const CustomerDetailScreen = ({
  navigation,
  setLoadingSpinnerVisibility,
  showHttpsApiErrorDialog,
  setPasswordReduxInitialState: _setPasswordReduxInitialState,
  resetPasswordRequest: _resetPasswordRequest,
  setHttpResetErrorToInitial: _setHttpResetErrorToInitial,
  resetSuccessResponse,
  resetFailError,
  resetPasswordHttpError,
  selectedCustomer,
  brandSuccessResponse
}) => {
  const [customer, setCustomer] = useState('');
  const [companyInfo, setCompanyInfo] = useState('');
  const [index, setIndex] = useState(0);
  const [routes] = useState([
    {
      key: '1',
      title: 'Details',
      icon: 'account',
      iconOutline: 'account-outline',
    },
    {key: '2', title: 'Contacts', icon: 'directions', iconOutline: 'directions'},
    {key: '3', title: 'Tasks', icon: 'pickaxe', iconOutline: 'pickaxe'},
  ]);

  useEffect(() => {
    if(validateRequiredField(selectedCustomer)){
      setCustomer(selectedCustomer);
    }
  }, [selectedCustomer]);

  useEffect(() => {
    if (validateRequiredField(brandSuccessResponse)){
      setCompanyInfo(brandSuccessResponse);
    }
  },  [brandSuccessResponse]);

  const renderTabIcon = ({route, focused, color}) => {
    return (
      <Icon
        size={20}
        name={focused ? route.icon : route.iconOutline}
        color={'white'}
      />
    );
  };
  const renderTabBar = (props) => {
      //console.log(props);
      return(
    <TabBar
      {...props}
      indicatorStyle={{backgroundColor: APP_BLUE_COLOR, height: 7}}
      inactiveColor='black'
      activeColor={APP_BLUE_COLOR}
      tabStyle={{backgroundColor:'white'}}
      //renderIcon={renderTabIcon}
      contentContainerStyle={{
        borderWidth: 2,
        borderColor: APP_BLUE_COLOR,
      }}
    />
  )};

  const CustomerDetail = () => <CustomerDetailTab navigation={navigation} />;
  const Contact = () => <ContactTab navigation={navigation} />
  const Task = () => <ContactTab navigation={navigation} />

  const initialLayout = {width: Dimensions.get('window').width, height: 200};
  const renderScene = SceneMap({
    1: CustomerDetail,
    2: Contact,
    3: Task
  });

  return (
    <GenericTemplate
      navigation={navigation}
      style={{
       // backgroundColor: 'yellow',
        flex: 1,
      }}>
      <UserBrandHeader
        navigation={navigation}
        headerNavigator={DeviceInfo.isTablet() ? false : true}
        //sideMenuOpen ={showSideMenu}
        sideMenuPage="HOME"
        headerNavigator={true}
        headerBackButton={true}
        // onSideMenuPress ={() => {showSideMenu? toggleSideMenu(false): toggleSideMenu(true)}}
      />
      <View style={{flexDirection: 'row', flex: 1}}>
        <View
          style={[
            {
            //  backgroundColor: 'red',
              //  flex: 1
            },
            DeviceInfo.isTablet() ? {width: '40%'} : {width: '100%'},
          //  styles.container,
          ]}>

          <TabView
            navigationState={{index, routes}}
            renderScene={renderScene} 
            onIndexChange={setIndex}
            initialLayout={initialLayout}
            renderTabBar={renderTabBar}
          />
        </View>

        {DeviceInfo.isTablet() ? (
          <View style={styles.tabViewContainer}>
              <CustomerInfo navigation = {navigation} />
          </View>
        ) : null}
      </View>
    </GenericTemplate>
  );
};

const styles = StyleSheet.create({
  tabViewHeader: {
    backgroundColor: 'red',
    flex: 2
  },
  tabViewBody: {
    backgroundColor: 'blue',
    flex: 4
  },
  tabViewFooter: {
    backgroundColor: 'pink',
    flex: .5
  },
  tabViewContainer: {
    flex: 1,
    flexDirection: 'column',
    width: '60%',
  },
  authStackLogo: {
    width: AUTH_STACK_LOGO_WIDTH,
    height: AUTH_STACK_LOGO_HEIGHT,
    alignItems: 'center',
  },
  container: {
    //  justifyContent: 'center',
    alignItems: 'center',
  },
  inputContainerStyle: {
    borderBottomWidth: FIELD_BORDER_WIDTH,
    borderWidth: FIELD_BORDER_WIDTH,
    borderStyle: 'solid',
    borderColor: INPUT_FIELD_BORDER_COLOR,
    height: INPUT_FIELD_HEIGHT,
    padding: SPACING_10,
    // width:AUTH_STACK_CONTAINER_WIDTH,
    borderRadius: FIELD_BORDER_RADIUS,
  },
  authHeaderStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    textAlign: 'center',
    marginTop: SPACING_30,
  },
  ForgetPassStyle: {
    fontWeight: TEXT_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'right',
    textDecorationLine: 'underline',
    marginTop: SPACING_15,
  },
  errorStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'center',
    color: ERROR_COLOR,
    marginTop: SPACING_30,
  },
  overlay: {
    backgroundColor: GENERIC_BACKGROUND_COLOR,
    opacity: MODAL_BACKDROP_OPACITY,
  },
  overlayModalStyle: {
    borderWidth: FIELD_BORDER_WIDTH,
    borderColor: INPUT_FIELD_BORDER_COLOR,
    width: MODAL_CONTAINER_WIDTH,
  },
  modalErrorStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'center',
    //color:ERROR_COLOR,
    marginBottom: SPACING_30,
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    resetSuccessResponse: reduxStore.resetPassword.resetSuccessResponse,
    resetFailError: reduxStore.resetPassword.resetFailError,
    resetPasswordHttpError: reduxStore.resetPassword.resetPasswordHttpError,
    selectedCustomer: reduxStore.customer.selectedCustomer,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      resetPasswordRequest,
      setPasswordReduxInitialState,
      setHttpResetErrorToInitial,
    })(CustomerDetailScreen),
  ),
);
