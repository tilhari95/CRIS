import React, { useEffect } from 'react';
import { StyleSheet, Text, View, Dimensions } from 'react-native';
import ShippingTab from './shipping/ShippingTab'
import BillingTab from './billing/BillingTab'
import { TabView, SceneMap, TabBar } from 'react-native-tab-view';
import GenericTemplate from '../../../../../components/GenericTemplate/GenericTemplate'
import {
  default as DeviceInfo,
  isLandscape,
  isTablet,
} from 'react-native-device-info';
import {
  APP_BLUE_COLOR,
  ERROR_COLOR,
  FIELD_BORDER_RADIUS,
  FIELD_BORDER_WIDTH,
  GENERIC_BACKGROUND_COLOR,
  HEADER_FONT_WEIGHT,
  INPUT_FIELD_BORDER_COLOR,
  MODAL_BACKDROP_OPACITY,
  PRODUCT_BORDER_COLOR,
  TEXT_FONT_WEIGHT,
} from '../../../../../resources/constants/themeConstant';

const CustomerDetailTab = ({navigation}) => {
  const [index, setIndex] = React.useState(0);
  
  const [routes] = React.useState([
    { key: '1', title: 'Billing' },
    { key: '2', title: 'Shipping' },
  ]);

  const Billing = () => <BillingTab navigation={navigation} />  
  const Shipping = () => <ShippingTab navigation={navigation} />  

  const renderScene = SceneMap({
    1: Billing,
    2: Shipping,
  });

  const initialLayout = {width: Dimensions.get('window').width, height: 200, backgroundColor: '#ffdd00'};

  const renderTabBar = (props) => {
    console.log(props);
    return(
      <TabBar
        {...props}
        indicatorStyle={{backgroundColor: APP_BLUE_COLOR, height: 7, }}
        inactiveColor='black'
        activeColor={APP_BLUE_COLOR}
        tabStyle={{backgroundColor:'white'}}
        renderLabel={({ route, focused, color }) => (
          <Text style={{ color}}>
            {route.title}
          </Text>
        )}
      />
)};

  return (
      <GenericTemplate
            navigation={navigation}
            style={{ flex: 1 }}>
        <View style={styles.container}>
            <TabView
                navigationState={{ index, routes }}
                renderScene={renderScene}
                onIndexChange={setIndex}
                initialLayout={initialLayout}
                renderTabBar={renderTabBar} 
                lazy
              />
        </View>
      </GenericTemplate>   
  );
}

const styles = StyleSheet.create({
  container: {
      flex: 1
  }
});

export default CustomerDetailTab;