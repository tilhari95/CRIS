import React, {useEffect, useState} from 'react';
import {
  FlatList,
  StyleSheet,
  Text,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import withLoadingSpinner from '../../../../../../components/HOC/withLoadingSpinner';
import withHttpsApiErrorHandling from '../../../../../../components/HOC/withHttpsApiErrorHandling';
import {Button, ListItem} from 'react-native-elements';
import {connect} from 'react-redux';
import {
  resetShipToAddressFailAction,
  resetShipToAddressHttpErrAction,
  resetShipToAddressResponseAction,
  shipToAddressListApiReqAction,
  updateShippingAddressApiReqAction,
  resetUpdateShippingAddressApiFailErrAction,
  resetUpdateShippingAddressApiHttpErrAction,
  resetUpdateShippingAddressApiResponseAction,
} from '../../../../../../store/shippingAddress/shippingAddressAction';
import {COLORS} from '../../../../../../resources/constants/themeConstant';
import {validateRequiredField} from '../../../../../../utils/validators';
import Toast from 'react-native-simple-toast';

const ShippingTab = ({
  shipToAddressListApiReqAction: _shipToAddressListApiReqAction,
  resetShipToAddressResponseAction: _resetShipToAddressResponseAction,
  resetShipToAddressFailAction: _resetShipToAddressFailAction,
  resetShipToAddressHttpErrAction: _resetShipToAddressHttpErrAction,
  shipToAddressList,
  shipToAddressListApiFailErr,
  shipToAddressListApiHttpErr,
  setLoadingSpinnerVisibility,
  showHttpsApiErrorDialog,
  brandSuccessResponse,
  selectedCustomer,
  updateShippingAddressApiReqAction: _updateShippingAddressApiReqAction,
  resetUpdateShippingAddressApiFailErrAction: _resetUpdateShippingAddressApiFailErrAction,
  resetUpdateShippingAddressApiHttpErrAction: _resetUpdateShippingAddressApiHttpErrAction,
  resetUpdateShippingAddressApiResponseAction: _resetUpdateShippingAddressApiResponseAction,
  updateShippingAddressApiResponse,
  updateShippingAddressApiFailErr,
  updateShippingAddressHttpErr,
}) => {
  const [addressList, setAddressList] = useState([]);

  useEffect(() => {
    setLoadingSpinnerVisibility(false);
    console.log('ADDRESS--', shipToAddressList);
    if (shipToAddressList == null) {
      setLoadingSpinnerVisibility(true);
      _shipToAddressListApiReqAction(
        brandSuccessResponse.CompanyId,
        selectedCustomer.CustomerId,
      );
    } else {
      if (shipToAddressList.length > 0) {
        setAddressList(shipToAddressList);
      }
    }
  }, [shipToAddressList]);

  useEffect(() => {
    if (shipToAddressListApiFailErr != null) {
      setLoadingSpinnerVisibility(false);
      _resetShipToAddressFailAction();
    }
  }, [shipToAddressListApiFailErr]);

  useEffect(() => {
    if (shipToAddressListApiHttpErr != null) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(shipToAddressListApiHttpErr);
      _resetShipToAddressHttpErrAction();
    }
  }, [shipToAddressListApiHttpErr]);

  useEffect(() => {
    if (validateRequiredField(updateShippingAddressApiResponse)) {
      setLoadingSpinnerVisibility(false);
      _resetUpdateShippingAddressApiResponseAction();
      _resetShipToAddressResponseAction();
      Toast.show('Shipping Address Selected', Toast.LONG);
    }
  }, [updateShippingAddressApiResponse]);

  useEffect(() => {
    if (validateRequiredField(updateShippingAddressApiFailErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(updateShippingAddressApiFailErr);
      _resetUpdateShippingAddressApiFailErrAction();
    }
  }, [updateShippingAddressApiFailErr]);

  useEffect(() => {
    if (validateRequiredField(updateShippingAddressHttpErr)) {
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(shipToAddressListApiHttpErr);
      _resetUpdateShippingAddressApiHttpErrAction();
    }
  }, [updateShippingAddressHttpErr]);

  const renderItem = ({item, index, separators}) => (
    <TouchableWithoutFeedback
      onPress={() => {
        console.log(item);
      }}>
      <ListItem bottomDivider>
        <ListItem.Content>
          <ListItem.Title>{item.ContactName}</ListItem.Title>
          <ListItem.Subtitle>{item.Address}</ListItem.Subtitle>
          <ListItem.Subtitle>
            {item.City}, {item.State}, {item.Zip}
          </ListItem.Subtitle>
          <ListItem.Subtitle>{item.PhoneNumber}</ListItem.Subtitle>
        </ListItem.Content>
        <ListItem.CheckBox
          checked={item.DefaultShipAddress}
          onIconPress={() => {
            setLoadingSpinnerVisibility(true);
            _updateShippingAddressApiReqAction(
              item.ShipToId,
              selectedCustomer.CustomerId,
            );
          }}
        />
      </ListItem>
    </TouchableWithoutFeedback>
  );

  return (
    <View style={styles.container}>
      {addressList.length <= 0 ? (
        <View style={styles.noAddressTxt}>
          <Text style={{textAlign: 'center'}}>No address found.</Text>
        </View>
      ) : null}

      <View style={{flex: 1}}>
        <FlatList
          data={addressList}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          style={{width: '100%'}}
        />
      </View>
      <View style={styles.footer}>
        <Button title="New" type="solid" buttonStyle={styles.button} />
        <Button title="Count" type="solid" buttonStyle={styles.button} />
        <Button title="Incent" type="solid" buttonStyle={styles.button} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  noAddressTxt: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
  },
  button: {
    width: 100,
    backgroundColor: COLORS.pink,
  },
  footer: {
    height: 40,
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    margin: 10,
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    selectedCustomer: reduxStore.customer.selectedCustomer,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    shipToAddressList: reduxStore.shippingAddress.shipToAddressList,
    shipToAddressListApiFailErr:
      reduxStore.shippingAddress.shipToAddressListApiFailErr,
    shipToAddressListApiHttpErr:
      reduxStore.shippingAddress.shipToAddressListApiHttpErr,
    updateShippingAddressApiResponse:
      reduxStore.shippingAddress.updateShippingAddressApiResponse,
    updateShippingAddressApiFailErr:
      reduxStore.shippingAddress.updateShippingAddressApiFailErr,
    updateShippingAddressHttpErr:
      reduxStore.shippingAddress.updateShippingAddressHttpErr,
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      shipToAddressListApiReqAction,
      resetShipToAddressResponseAction,
      resetShipToAddressFailAction,
      resetShipToAddressHttpErrAction,
      updateShippingAddressApiReqAction,
      resetUpdateShippingAddressApiFailErrAction,
      resetUpdateShippingAddressApiHttpErrAction,
      resetUpdateShippingAddressApiResponseAction,
    })(ShippingTab),
  ),
);
