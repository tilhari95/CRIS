import React, {useEffect, useState} from 'react';
import {StyleSheet, View} from 'react-native';
import {Avatar, Card, Text, Button} from 'react-native-elements';
import {ScrollView} from 'react-native-gesture-handler';
import {COLORS} from '../../../../../../resources/constants/themeConstant';
import {getCustomerDetailDataRequestAction, resetCustomerDetailApiHttpError, resetCustomerDetailDataApiError} from '../../../../../../store/CustomerDetail/customerDetailAction';
import {useDispatch} from 'react-redux';
import withLoadingSpinner from '../../../../../../components/HOC/withLoadingSpinner';
import withHttpsApiErrorHandling from '../../../../../../components/HOC/withHttpsApiErrorHandling';
import {connect} from 'react-redux';
import {useFocusEffect} from '@react-navigation/core';
import {roundToTwo, validateRequiredField} from '../../../../../../utils/validators';
import ShippingTab from '../shipping/ShippingTab';
import {ROUTE_COUSTOMER_INFO} from '../../../../../../resources/constants/navigationConstants';
import {default as DeviceInfo} from 'react-native-device-info';

const BillingTab = ({
  navigation,
  getCustomerDetailDataRequestAction: _getCustomerDetailDataRequestAction,
  customerDetailApiSuccessResponse,
  selectedCustomer,
  brandSuccessResponse,
  setLoadingSpinnerVisibility,
  showHttpsApiErrorDialog,
  resetCustomerDetailApiHttpError: _resetCustomerDetailApiHttpError,
  customerDetailApiHttpError,
  customerDetailApiFailError,
  resetCustomerDetailDataApiError: _resetCustomerDetailDataApiError
}) => {
  const [customerName, setCustomerName] = useState('');
  const [address1, setAddress1] = useState('');
  const [address2, setAddress2] = useState('');
  const [phone1, setPhone1] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [postalCode, setPostalCode] = useState('');

  const [yearGoal, setYearGoal] = useState('0');
  const [yearActual, setYearActual] = useState('0');
  const [yearDiff, setYearDiff] = useState('0');
  const [monthGoal, setMonthGoal] = useState('0');
  const [monthActual, setMonthActual] = useState('0');
  const [monthDiff, setMonthDiff] = useState('0');
  const [balance, setBalance] = useState('0');
  const [current, setCurrent] = useState('0');
  const [thirthyDays, setThirtyDays] = useState('0');
  const [sixtyDays, setSixtyDays] = useState('0');
  const [ninetyDays, setNinetyDays] = useState('0');
  const [older, setOlder] = useState('0');
  const [spiffBalance, setSpiffBalance] = useState('0');
  const [proBalance, setProBalance] = useState('0');
  const [previousRo, setPriviousRo] = useState('0');

  useEffect(() => {
    if (
      validateRequiredField(selectedCustomer) &&
      validateRequiredField(brandSuccessResponse)
    ) {
      updateCustomerData(selectedCustomer);
      setLoadingSpinnerVisibility(true);
      _getCustomerDetailDataRequestAction(
        brandSuccessResponse.CompanyId,
        brandSuccessResponse.ERPRepCode,
        selectedCustomer.CustomerId,
      );
    }
  }, []);

  useEffect(() => {
    console.log('RANE_____ HOOK BALA' + customerDetailApiSuccessResponse);
    console.log(customerDetailApiSuccessResponse);
    if(validateRequiredField(customerDetailApiSuccessResponse)){
      setLoadingSpinnerVisibility(false);
      console.log('RANE_____ HOOK BALA INSDIE' + customerDetailApiSuccessResponse);
      updateCustomerStaticsUI(customerDetailApiSuccessResponse)
    }
  }, [customerDetailApiSuccessResponse]);

  useEffect(() => {
    if(customerDetailApiHttpError != null){
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(customerDetailApiHttpError);
      _resetCustomerDetailApiHttpError();
    }
  }, [customerDetailApiHttpError]);

  useEffect(() => {
    if(customerDetailApiFailError != null){
      setLoadingSpinnerVisibility(false);
      showHttpsApiErrorDialog(customerDetailApiFailError);
      _resetCustomerDetailDataApiError();
    }
  }, [customerDetailApiFailError]);

  const updateCustomerData = (customer) => {
    setCustomerName(customer.CustomerName);
    setAddress1(customer.Address1);
    setCity(customer.City);
    setState(customer.State);
    setPostalCode(customer.PostalCode);
    setPhone1(customer.Phone1);
    setEmail(customer.EmailAddress);
  };

  const updateCustomerStaticsUI = (customerDetailRes) => {
    console.log('RANE_____ HOOK BALA UI' + customerDetailRes);

    setYearGoal(customerDetailRes.YearGoal);
    setYearActual(customerDetailRes.YearActual);
    setYearDiff(customerDetailRes.YearDiff);

    setMonthGoal(customerDetailRes.MonthGoal);
    setMonthActual(customerDetailRes.MonthActual);
    setMonthDiff(customerDetailRes.MonthDiff);

    setBalance(customerDetailRes.Balance);
    setCurrent(customerDetailRes.Current);
    setThirtyDays(customerDetailRes.ThirtyDays);
    setSixtyDays(customerDetailRes.SixtyDays);
    setNinetyDays(customerDetailRes.NintyDays);
    setOlder(customerDetailRes.Older);
    setSpiffBalance(customerDetailRes.SpiffBalance);
    setProBalance(customerDetailRes.ProBalance);
    setPriviousRo(customerDetailRes.PreviousRO);
  };

  return (
    <ScrollView>
      <View style={styles.container}>
        <View style={styles.profileSection}>
          {/*------------------------------- Header Section -----------------------  */}
          <View style={styles.avatarContainer}>
            <Avatar
              size="large"
              rounded
              source={{
                uri:
                  'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
              }}
              containerStyle={styles.avatar}
            />
            {/* <Text style={styles.nameText}>Rajneesh Shukla</Text> */}
          </View>
          <View style={styles.companyDetail}>
            <Text style={{fontWeight: 'bold'}}>{customerName}</Text>
            <Text>{address1}</Text>
            <Text>
              {city}, {state}, {postalCode}{' '}
            </Text>
            <Text>{phone1}</Text>
            <Text style={{color: COLORS.pink}}>{email}</Text>
          </View>
        </View>

        {/* ----------------------- Year Performence Section -------------------- */}
        <Card style={styles.yearPerfSection}>
          <Text>This Year's Performance</Text>
          <Text style={{alignSelf: 'flex-end'}}> Goal: ${roundToTwo(yearGoal)}</Text>
          <Text style={{alignSelf: 'flex-end'}}> Actual: ${roundToTwo(yearActual)}</Text>
          <Text style={{alignSelf: 'flex-end'}}> Diff: ${roundToTwo(yearDiff)}</Text>
        </Card>

        {/* ----------------------- Month Performence Section -------------------- */}
        <Card style={styles.monthPerfSection}>
          <Text>This Month's Performance</Text>
          <Text style={{alignSelf: 'flex-end'}}> Goal: ${roundToTwo(monthGoal)}</Text>
          <Text style={{alignSelf: 'flex-end'}}> Actual: ${roundToTwo(monthActual)}</Text>
          <Text style={{alignSelf: 'flex-end'}}> Diff: ${roundToTwo(monthDiff)}</Text>
        </Card>

        {/* ----------------------- Amount Section -------------------- */}
        <Card style={styles.accountSection}>
          <View>
            <Text>Accounts Receivable</Text>
            <View style={{flexDirection: 'row', marginTop: 10}}>
              <Text style={{flex: 1}}>Balance:</Text>
              <Text>${roundToTwo(balance)}</Text>
            </View>
            <View style={{flexDirection: 'row'}}>
              <Text style={{flex: 1}}>Current:</Text>
              <Text>${roundToTwo(current)}</Text>
            </View>
            <View style={{flexDirection: 'row'}}>
              <Text style={{flex: 1}}>30 Days:</Text>
              <Text>${roundToTwo(thirthyDays)}</Text>
            </View>
            <View style={{flexDirection: 'row'}}>
              <Text style={{flex: 1}}>60 Days:</Text>
              <Text>${roundToTwo(sixtyDays)}</Text>
            </View>
            <View style={{flexDirection: 'row'}}>
              <Text style={{flex: 1}}>90 Days:</Text>
              <Text>${roundToTwo(ninetyDays)}</Text>
            </View>
            <View style={{flexDirection: 'row'}}>
              <Text style={{flex: 1}}>Older:</Text>
              <Text>${roundToTwo(older)}</Text>
            </View>
            <View style={{flexDirection: 'row'}}>
              <Text style={{flex: 1}}>Spiff Balance:</Text>
              <Text>${roundToTwo(spiffBalance)}</Text>
            </View>
            <View style={{flexDirection: 'row'}}>
              <Text style={{flex: 1}}>PRO Balance:</Text>
              <Text>${roundToTwo(proBalance)}</Text>
            </View>
            <View style={{flexDirection: 'row'}}>
              <Text style={{flex: 1}}>Previous RO:</Text>
              <Text>${roundToTwo(previousRo)}</Text>
            </View>
          </View>
        </Card>

        {/* ----------------------- Footer Section -------------------- */}
        <View style={styles.footerSection}>
          {DeviceInfo.isTablet() ? null : (
            <Button
              title="SELL"
              type="solid"
              buttonStyle={styles.footerBtn}
              onPress={() => navigation.navigate(ROUTE_COUSTOMER_INFO)}
            />
          )}
          <Button title="COUNT" type="solid" buttonStyle={styles.footerBtn} />
          <Button title="INCENT" type="solid" buttonStyle={styles.footerBtn} />
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  companyDetail: {
    flex: 2,
    alignItems: 'flex-end',
    paddingTop: 10,
    paddingEnd: 10,
  },
  nameText: {
    marginTop: 10,
    width: '100%',
    textAlign: 'center',
    justifyContent: 'center',
  },
  avatar: {
    justifyContent: 'flex-end',
    alignSelf: 'center',
  },
  avatarContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  container: {
    flex: 1,
    flexDirection: 'column',
  },
  profileSection: {
    flexDirection: 'row',
    backgroundColor: COLORS.grayMedium,
  },
  yearPerfSection: {
    padding: 16,
  },
  monthPerfSection: {
    backgroundColor: '#ffdd00',
    flexWrap: 'wrap',
  },
  accountSection: {
    backgroundColor: 'blue',
  },
  footerSection: {
    //backgroundColor: 'white',
    flexDirection: 'row',
    backgroundColor: COLORS.grayMedium,
    justifyContent: 'space-evenly',
    paddingTop: 10,
    paddingBottom: 10,
    marginTop: 10,
  },
  footerBtn: {
    width: 100,
    backgroundColor: COLORS.pink,
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    customerDetailApiSuccessResponse:
    reduxStore.customerDetail.customerDetailApiSuccessResponse,
    selectedCustomer: reduxStore.customer.selectedCustomer,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    customerDetailApiHttpError: reduxStore.customerDetail.customerDetailApiHttpError,
    customerDetailApiFailError: reduxStore.customerDetail.customerDetailApiFailError
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      getCustomerDetailDataRequestAction,
      resetCustomerDetailApiHttpError,
      resetCustomerDetailDataApiError
    })(BillingTab),
  ),
);
