import React from 'react';
import { Text } from 'react-native';

const TaskTab = () => {
  return (
    <Text>Coming Soon.</Text>
  );
}

export default TaskTab;