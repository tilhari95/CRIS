import React, {useEffect, useState} from 'react';
import {Text, StyleSheet, View, Dimensions, ScrollView} from 'react-native';
import {SceneMap, TabBar, TabView} from 'react-native-tab-view';
import TimelineTab from './timeline/TimelineTab';
import TaskInfoTab from './taskInfo/TaskInfoTab';
import NotesTab from './notes/NotesTab';
import {COLORS} from '../../../../resources/constants/themeConstant';
import {Card, Icon, Avatar, Header} from 'react-native-elements';
import GenericButtonWithTitle from '../../../../components/Buttons/GenericButtonWithTitle';
import Toast from 'react-native-simple-toast';
import {default as DeviceInfo} from 'react-native-device-info';
import InvoiceScreen from '../Invoice/InvoiceScreen';
import {resetItemHistoryReduxStataAction} from '../../../../store/itemHistory/itemHistoryAction';
import {resetHotkeysStore} from  '../../../../store/hotKeys/hotKeysAction';
import {resetTemplateToInitialStateAction} from '../../../../store/template/templateAction';

import {
  AUTH_STACK_CONTAINER_WIDTH,
  AUTH_STACK_LOGO_HEIGHT,
  AUTH_STACK_LOGO_WIDTH,
  INPUT_FIELD_HEIGHT,
  MODAL_CONTAINER_WIDTH,
  SPACING_10,
  SPACING_15,
  SPACING_30,
  TEXT_SIZE_15,
} from '../../../../resources/constants/dimensions';
import {
  APP_BLUE_COLOR,
  ERROR_COLOR,
  FIELD_BORDER_RADIUS,
  FIELD_BORDER_WIDTH,
  GENERIC_BACKGROUND_COLOR,
  HEADER_FONT_WEIGHT,
  INPUT_FIELD_BORDER_COLOR,
  MODAL_BACKDROP_OPACITY,
  PRODUCT_BORDER_COLOR,
  TEXT_FONT_WEIGHT,
} from '../../../../resources/constants/themeConstant';
import {ROUTE_INVOICE_SCREEN} from '../../../../resources/constants/navigationConstants';
import withLoadingSpinner from '../../../../components/HOC/withLoadingSpinner';
import withHttpsApiErrorHandling from '../../../../components/HOC/withHttpsApiErrorHandling';
import { connect } from 'react-redux';
import { validateRequiredField } from '../../../../utils/validators';

const CustomerInfo = ({
  navigation,
  selectedCustomer,
  brandSuccessResponse,
  resetItemHistoryReduxStataAction: _resetItemHistoryReduxStataAction,
  resetHotkeysStore: _resetHotkeysStore,
  resetTemplateToInitialStateAction: _resetTemplateToInitialStateAction
}) => {
  const [customerName, setCustomerName] = useState('');
  const [address1, setAddress1] = useState('');
  const [address2, setAddress2] = useState('');
  const [phone1, setPhone1] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [postalCode, setPostalCode] = useState('');

  const [index, setIndex] = useState(0);
  const [routes] = useState([
    {key: '1', title: 'Timeline'},
    {key: '2', title: 'Notes'},
    {key: '3', title: 'Tasks'},
  ]);

  useEffect(() => {
    if(validateRequiredField(selectedCustomer)){
      updateCustomerData(selectedCustomer);
    }
  }, []);

  const updateCustomerData = (customerData) => {
    setCustomerName(customerData.CustomerName);
    setAddress1(customerData.Address1);
    setCity(customerData.City);
    setState(customerData.State);
    setPostalCode(customerData.PostalCode);
    setPhone1(customerData.Phone1);
    setEmail(customerData.EmailAddress);
  };

  const renderTabBar = (props) => {
    return (
      <TabBar
        {...props}
        indicatorStyle={{backgroundColor: APP_BLUE_COLOR, height: 7}}
        inactiveColor="black"
        activeColor={APP_BLUE_COLOR}
        tabStyle={{backgroundColor: COLORS.grayMedium}}
        renderLabel={({route, focused, color}) => (
          <Text style={{color}}>{route.title}</Text>
        )}
        indicatorStyle={{backgroundColor: '#ffdd00'}}
      />
    );
  };

  const initialLayout = {width: Dimensions.get('window').width, height: 200};
  const renderScene = SceneMap({
    1: TimelineTab,
    2: NotesTab,
    3: TaskInfoTab,
  });

  return (
    <View style={{flex: 1}}>
      {DeviceInfo.isTablet() ? null : (
        <Header
          placement="right"
          leftComponent={
            <Icon
              name="arrow-back"
              type="MaterialIcons"
              color="white"
              onPress={() => navigation.pop()}
              size={40}
            />
          }
          rightComponent={
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'flex-end',
                paddingBottom: 10,
              }}>
              <Icon
                raised
                name="map"
                type="font-awesome"
                color={COLORS.black}
                onPress={() => console.log('hello')}
                size={20}
              />

              <Icon
                raised
                name="comment"
                type="font-awesome"
                color={COLORS.black}
                onPress={() => console.log('hello')}
                size={20}
              />

              <Icon
                raised
                name="inbox"
                type="font-awesome"
                color={COLORS.black}
                onPress={() => console.log('hello')}
                size={20}
              />
            </View>
          }
        />
      )}
      <View style={styles.tabViewHeader}>
        <View style={styles.profileContainer}>
          <Avatar
            size="xlarge"
            source={{
              uri:
                'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
            }}
            overlayContainerStyle={{borderRadius: 20}}
            activeOpacity={1}></Avatar>
        </View>
        <View
          style={{
            flex: 1,
          }}>
          {DeviceInfo.isTablet() ? (
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'flex-end',
              }}>
              <Icon
                raised
                name="map"
                type="font-awesome"
                color={COLORS.black}
                onPress={() => console.log('hello')}
              />

              <Icon
                raised
                name="comment"
                type="font-awesome"
                color={COLORS.black}
                onPress={() => console.log('hello')}
              />

              <Icon
                raised
                name="inbox"
                type="font-awesome"
                color={COLORS.black}
                onPress={() => console.log('hello')}
              />
            </View>
          ) : null}

          <Text
            style={[
              styles.customerName,
              DeviceInfo.isTablet() ? {paddingTop: 0} : {paddingTop: 20},
            ]}>
            {customerName}
          </Text>
          <Text>{address1}</Text>
          <Text>
            {city}, {state}, {postalCode}
          </Text>
          <Text>{phone1}</Text>
          <Text style={{color: COLORS.pink}}>{email}</Text>
        </View>
      </View>
      <View style={styles.tabViewBody}>
        <TabView
          navigationState={{index, routes}}
          renderScene={renderScene}
          onIndexChange={setIndex}
          initialLayout={initialLayout}
          renderTabBar={renderTabBar}
        />
      </View>
      <ScrollView style={styles.tabViewFooter} horizontal={true}>
        <GenericButtonWithTitle
          icon={'microsoft-access'}
          size={30}
          buttonStyle={styles.footerBtn}
          containerStyle={{marginRight: 7}}
          onPress={() => {
            _resetItemHistoryReduxStataAction();
            _resetHotkeysStore();
            _resetTemplateToInitialStateAction();
            navigation.navigate(ROUTE_INVOICE_SCREEN)
            }
          }
          label="INVOICE"
          componentStyle={styles.footerBtnBg}
          labelStyle={styles.footerBtnLabelStyle}
        />
        <GenericButtonWithTitle
          icon={'microsoft-access'}
          size={30}
          buttonStyle={styles.footerBtn}
          containerStyle={{marginRight: 7}}
          onPress={() => {
            Toast.showWithGravity(
              'Specifications coming soon.',
              Toast.SHORT,
              Toast.CENTER,
            );
          }}
          label="RETURN"
          componentStyle={styles.footerBtnBg}
          labelStyle={styles.footerBtnLabelStyle}
        />
        <GenericButtonWithTitle
          icon={'microsoft-teams'}
          size={30}
          buttonStyle={styles.footerBtn}
          containerStyle={{marginRight: 7}}
          onPress={() => {
            Toast.showWithGravity(
              'Specifications coming soon.',
              Toast.SHORT,
              Toast.CENTER,
            );
          }}
          label="SALE ORDER"
          componentStyle={styles.footerBtnBg}
          labelStyle={styles.footerBtnLabelStyle}
        />
        <GenericButtonWithTitle
          icon={'bus-alert'}
          size={30}
          buttonStyle={styles.footerBtn}
          containerStyle={{marginRight: 7}}
          onPress={() => {
            Toast.showWithGravity(
              'Specifications coming soon.',
              Toast.SHORT,
              Toast.CENTER,
            );
          }}
          label="PRE ORDER"
          componentStyle={styles.footerBtnBg}
          labelStyle={styles.footerBtnLabelStyle}
        />
        <GenericButtonWithTitle
          icon={'bus-alert'}
          size={30}
          buttonStyle={styles.footerBtn}
          containerStyle={{marginRight: 7}}
          onPress={() => {
            Toast.showWithGravity(
              'Specifications coming soon.',
              Toast.SHORT,
              Toast.CENTER,
            );
          }}
          label="QUOTE"
          componentStyle={styles.footerBtnBg}
          labelStyle={styles.footerBtnLabelStyle}
        />
        <GenericButtonWithTitle
          icon={'cached'}
          size={30}
          buttonStyle={styles.footerBtn}
          containerStyle={{marginRight: 7}}
          onPress={() => {
            Toast.showWithGravity(
              'Specifications coming soon.',
              Toast.SHORT,
              Toast.CENTER,
            );
          }}
          label="GO!"
          componentStyle={styles.footerBtnBg}
          labelStyle={styles.footerBtnLabelStyle}
        />
        <GenericButtonWithTitle
          icon={'microsoft-teams'}
          size={30}
          buttonStyle={styles.footerBtn}
          containerStyle={{marginRight: 7}}
          onPress={() => {
            Toast.showWithGravity(
              'Specifications coming soon.',
              Toast.SHORT,
              Toast.CENTER,
            );
          }}
          label="ROA"
          componentStyle={styles.footerBtnBg}
          labelStyle={styles.footerBtnLabelStyle}
        />
        <GenericButtonWithTitle
          icon={'bus-alert'}
          size={30}
          buttonStyle={styles.footerBtn}
          containerStyle={{marginRight: 7}}
          onPress={() => {
            Toast.showWithGravity(
              'Specifications coming soon.',
              Toast.SHORT,
              Toast.CENTER,
            );
          }}
          label="COUNT"
          componentStyle={styles.footerBtnBg}
          labelStyle={styles.footerBtnLabelStyle}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  customerName: {
    fontWeight: 'bold',
    fontSize: 20,
  },
  profileContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingStart: 16,
    paddingEnd: 16,
  },
  footerBtnLabelStyle: {
    fontSize: 10,
    color: COLORS.black,
  },
  footerBtnBg: {
    width: 70,
    height: 70,
    backgroundColor: COLORS.pink,
    marginRight: 10,
  },
  footerBtn: {
    backgroundColor: COLORS.white,
  },
  tabViewHeader: {
    backgroundColor: COLORS.grayDark,
    flex: 2,
    flexDirection: 'row',
  },
  tabViewBody: {
    backgroundColor: COLORS.grayLite,
    flex: 4,
  },
  tabViewFooter: {
    backgroundColor: APP_BLUE_COLOR,
    paddingTop: 10,
    paddingStart: 10,
    paddingEnd: 10,
    height: 10,
  },
  tabViewContainer: {
    backgroundColor: 'green',
    flex: 1,
    flexDirection: 'column',
    width: '60%',
  },
  authStackLogo: {
    width: AUTH_STACK_LOGO_WIDTH,
    height: AUTH_STACK_LOGO_HEIGHT,
    alignItems: 'center',
  },
  container: {
    //  justifyContent: 'center',
    alignItems: 'center',
  },
  inputContainerStyle: {
    borderBottomWidth: FIELD_BORDER_WIDTH,
    borderWidth: FIELD_BORDER_WIDTH,
    borderStyle: 'solid',
    borderColor: INPUT_FIELD_BORDER_COLOR,
    height: INPUT_FIELD_HEIGHT,
    padding: SPACING_10,
    // width:AUTH_STACK_CONTAINER_WIDTH,
    borderRadius: FIELD_BORDER_RADIUS,
  },
  authHeaderStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    textAlign: 'center',
    marginTop: SPACING_30,
  },
  ForgetPassStyle: {
    fontWeight: TEXT_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'right',
    textDecorationLine: 'underline',
    marginTop: SPACING_15,
  },
  errorStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'center',
    color: ERROR_COLOR,
    marginTop: SPACING_30,
  },
  overlay: {
    backgroundColor: GENERIC_BACKGROUND_COLOR,
    opacity: MODAL_BACKDROP_OPACITY,
  },
  overlayModalStyle: {
    borderWidth: FIELD_BORDER_WIDTH,
    borderColor: INPUT_FIELD_BORDER_COLOR,
    width: MODAL_CONTAINER_WIDTH,
  },
  modalErrorStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'center',
    //color:ERROR_COLOR,
    marginBottom: SPACING_30,
  },
});

const mapStateToProps = (reduxStore) => {
  return {
    selectedCustomer: reduxStore.customer.selectedCustomer,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
  }
}

export default withLoadingSpinner() (
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      resetItemHistoryReduxStataAction,
      resetHotkeysStore,
      resetTemplateToInitialStateAction
    })(CustomerInfo)
  )
)

