import React from 'react';
import { ScrollView, StyleSheet, Text, View, Image } from 'react-native';
import { tick } from '../../../../../resources/images';
import CheckBox from '@react-native-community/checkbox';

const TaskInfoTab = () => {
  var imageTask = [];
  var messageTask = [];
  var Task = [];

  messageTask.push(["Follow Up", "Follow Up with brent to make sure that he is satisfied our service", "Today - January 28, 2021"])
  messageTask.push(["Restock POS material", "Display are in parts department and service desk", "Today - January 28, 2021"])
  messageTask.push(["Issue with compounds", "check in detailing department indicate that the 5g of 76321 has grit that has obvious when the container was opened", "Today - January 28, 2021"])
  messageTask.push(["Follow Up", "Follow Up with brent to make sure that he is satisfied our service", "Today - January 28, 2021"])
  messageTask.push(["Restock POS material", "Display are in parts department and service desk", "Today - January 28, 2021"])
  messageTask.push(["Issue with compounds", "check in detailing department indicate that the 5g of 76321 has grit that has obvious when the container was opened", "Today - January 28, 2021"])
  messageTask.push(["Follow Up", "Follow Up with brent to make sure that he is satisfied our service", "Today - January 28, 2021"])
  messageTask.push(["Restock POS material v2", "Display are in parts department and service desk", "Today - January 28, 2021"])

  for (var i = 0; i < messageTask.length; i++) {
    Task.push(
      <View style={styles.container}>
        <CheckBox boxType='square'/>
        <Image style={styles.image} source={tick} />
        <View style={{ flexDirection: 'column' }}>
          <Text style={[{ fontSize: 20 }, styles.messageTaskContainer]}>{messageTask[i][0]}</Text>
          <Text style={[{ fontSize: 17 }, styles.messageTaskContainer]}>{messageTask[i][1]}</Text>
          <Text style={[{ fontSize: 17, marginBottom: 10 }, styles.messageTaskContainer]}>{messageTask[i][2]}</Text>
        </View>
      </View>
    )
  }

  return (
    <ScrollView style={{ flex: 1 }}>
      <Text style={styles.taskContainer}>Tasks</Text>
      {Task}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    marginLeft: 30,
    marginTop: 5
  },
  taskContainer: {
    margin: 10,
    color: 'white',
    fontSize: 20
  },
  image: {
    width: 22,
    height: 22,
    marginLeft: 20
  },
  messageTaskContainer: {
    marginLeft: 20,
    marginRight: 120,
    color: 'white'
  },
})

export default TaskInfoTab;