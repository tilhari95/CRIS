import React from 'react';
import { StyleSheet, Text, View, Image, ScrollView } from 'react-native';
import { tick } from '../../../../../resources/images';

const TimelineTab = () => {
  var dateTimeLine = [];
  var headingDateTimeLine = [];
  var imagesTimeLine = [];
  var messageTimeLine = [];
  var dateTimeLineEachHeadingSize = [];

  headingDateTimeLine.push("January, 2021");
  headingDateTimeLine.push("Feburary, 2021");
  headingDateTimeLine.push("March, 2021");

  dateTimeLineEachHeadingSize.push(3);
  dateTimeLineEachHeadingSize.push(3);
  dateTimeLineEachHeadingSize.push(2);

  dateTimeLine.push("16 Jan");
  dateTimeLine.push("10 Jan");
  dateTimeLine.push("05 Jan");
  dateTimeLine.push("10 Feb");
  dateTimeLine.push("10 Feb");
  dateTimeLine.push("19 Mar");
  dateTimeLine.push("16 Mar");
  dateTimeLine.push("10 Mar");

  messageTimeLine.push(["SMS Message", "Hi brent How r you", "5.43pm"])
  messageTimeLine.push(["Sales Checklist", "14 cheklist items received", "9.12am"])
  messageTimeLine.push(["Invoice 70878", "3 Products for $379.00 total", "9.08am"])
  messageTimeLine.push(["Email Message-thank you for your buisiness", "Thank you for your buisiness", "9.08am"])
  messageTimeLine.push(["SMS Message", "Hi brent How r you", "5.43pm"])
  messageTimeLine.push(["Sales Checklist", "14 cheklist items received", "9.12am"])
  messageTimeLine.push(["Invoice 70878", "3 Products for $379.00 total", "9.08am"])
  messageTimeLine.push(["Email Message-thank you for your buisiness", "Thank you for your buisiness", "9.08am"])

  var TimeLine = [];
  var size = headingDateTimeLine.length;
  var dontDisplayVerticalLine = false;
  var displayDateTimeLineHeading = false;
  var index = 0;

  for (var i = 0; i < size; i++) {
    for (var j = 0; j < dateTimeLineEachHeadingSize[i]; j++) {
      dontDisplayVerticalLine = false;
      displayDateTimeLineHeading = false;
      if (j == 0)
        displayDateTimeLineHeading = true;
      if (j == dateTimeLineEachHeadingSize[i] - 1)
        dontDisplayVerticalLine = true;

      TimeLine.push(
        <View>
          <View style={{ flexDirection: 'column' }}>
            {
              displayDateTimeLineHeading ? (
                <Text style={styles.heading}>{headingDateTimeLine[i]}</Text>
              ) : null
            }
            <View style={{ flexDirection: 'row' }}>
              <View style={{ flexDirection: 'column' }}>
                <View style={styles.rundedCircle} />
                {
                  !dontDisplayVerticalLine ? (
                    <View style={styles.verticalLine}></View>
                  ) : null
                }
              </View>
              <View style={{ flexDirection: 'row' }}>
                <Text style={{ marginLeft: 10 }}>{dateTimeLine[index]}</Text>
                <Image style={styles.image} source={tick} />
                <View style={{ flexDirection: 'column' }}>
                  <Text style={[{ fontSize: 20 }, styles.messageTaskContainer]}>{messageTimeLine[index][0]}</Text>
                  <Text style={[{ fontSize: 17 }, styles.messageTaskContainer]}>{messageTimeLine[index][1]}</Text>
                  <Text style={[{ fontSize: 17, marginBottom: 10 }, styles.messageTaskContainer]}>{messageTimeLine[index][2]}</Text>
                </View>
              </View>
            </View>
          </View>
        </View>
      )

      index++;
    }
  }
  return (
    <ScrollView style={{ flex: 1 }}>
      {TimeLine}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  heading: {
    margin: 10,
    color: 'white',
    fontSize: 20
  },
  rundedCircle: {
    marginLeft: 30,
    height: 26,
    width: 26,
    borderRadius: 100,
    borderWidth: 2,
    backgroundColor: 'white',
    borderColor: 'grey'
  },
  verticalLine: {
    height: 70,
    width: 2,
    marginLeft: 43,
    backgroundColor: 'grey'
  },
  image: {
    width: 22,
    height: 22,
    marginLeft: 20
  },
  messageTaskContainer: {
    marginLeft: 20,
    marginRight: 150,
    color: 'white'
  },
})

export default TimelineTab;