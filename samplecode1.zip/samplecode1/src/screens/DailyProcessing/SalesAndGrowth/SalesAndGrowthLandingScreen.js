import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  View,
  Text,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import {
  SPLASH_LOGO_HEIGHT,
  SPLASH_LOGO_WIDTH,
} from '../../../resources/constants/dimensions';
import {TabView, SceneMap, TabBar} from 'react-native-tab-view';
import GenericTemplate from '../../../components/GenericTemplate/GenericTemplate';
import {default as DeviceInfo} from 'react-native-device-info';
import UserBrandHeader from '../../../components/Headers/UserBrandHeader';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {SearchBar} from 'react-native-elements';
import {
  BLACK_COLOR,
  GENERIC_BACKGROUND_COLOR,
  PRODUCT_BORDER_COLOR,
} from '../../../resources/constants/themeConstant';
import {
  SEARCH_PLACEHOLDER,
  TYPE_PRODUCT_HERE,
} from '../../../resources/constants/stringConstants';
import CustomersTab from './CustomersTab';
import {WebView} from 'react-native-webview';
import {validateRequiredField} from '../../../utils/validators';
import withLoadingSpinner from '../../../components/HOC/withLoadingSpinner';
import withHttpsApiErrorHandling from '../../../components/HOC/withHttpsApiErrorHandling';
import {connect} from 'react-redux';
import {customerSearchRequest, resetCustomerSearchRequest} from '../../../store/Customer/customerAction';
import  ProspectsTab from './ProspectsTab'
import RoutesTab from "./RoutesTab";
import Toast from "react-native-simple-toast";
import {prospectSearchRequest, resetProspectSearchRequest} from "../../../store/Prospect/prospectAction";
const SalesAndGrowthLandingScreen = (
  {navigation,
    routers,
    customerSearchList,
    brandSuccessResponse,
    setLoadingSpinnerVisibility,
    routeSuccessResponse,
    prospectSearchList,
    resetCustomerSearchRequest:_resetCustomerSearchRequest,
    customerSearchRequest:_customerSearchRequest,
    prospectSearchRequest: _prospectSearchRequest,
    resetProspectSearchRequest: _resetProspectSearchRequest
  },
  prototype,
) => {
  const [tabIndex, setTabIndex] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [showSearchLoading, setShowSearchLoading] = useState(false);
  const [customerSearchResultList, setCustomerSearchResultList] = useState([]);
  const [prospectSearchResultList, setProspectSearchResultList] = useState([]);
  const [routeSearchResultList, setRouteSearchResultList] = useState([]);

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      debugger;
      console.log(searchTerm);
      if (searchTerm !== '') {
        let filteredData = searchLogic(searchTerm);
        //setFilteredArray(filteredData);
      }
      else{
        setCustomerSearchResultList([]);
        setProspectSearchResultList([]);
        setRouteSearchResultList([]);
      }
      //debugger;
      // Send Axios request here
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm]);


  useEffect(() => {
    if (validateRequiredField(customerSearchList)) {
      console.log('customer searched list', customerSearchList);
      setCustomerSearchResultList(customerSearchList);
      setShowSearchLoading(false);
      if(customerSearchList.length <= 0)
      Toast.showWithGravity("No search results found.", Toast.SHORT, Toast.CENTER);
      _resetCustomerSearchRequest();


    }
  }, [customerSearchList]);

  useEffect(() => {
    if (validateRequiredField(prospectSearchList)) {
      console.log('prospect searched list', prospectSearchList);
      setProspectSearchResultList(prospectSearchList);
      setShowSearchLoading(false);
      if(prospectSearchList.length <= 0)
        Toast.showWithGravity("No search results found.", Toast.SHORT, Toast.CENTER);
      _resetProspectSearchRequest();

    }
  }, [prospectSearchList]);

  const updateSearch = (search) => {
    setSearchTerm(search);
  };

  const searchLogic = (searchKeyword) => {
    console.log("index is  -> " + tabIndex);
    console.log('searchLogic',searchKeyword);
    const searchText = searchKeyword.toLowerCase();
    if(searchText.length > 0){
      setShowSearchLoading(true);
      if(tabIndex === 0){ //search in customers
        _customerSearchRequest(brandSuccessResponse.CompanyId, brandSuccessResponse.DeviceId, 0, searchText);
      }
      else if(tabIndex === 1){ //search in route
          console.log("search in routes");
          let newData=[];
        routeSuccessResponse.filter((item) => {
            if (item.RouteName.toLowerCase().indexOf(searchText) !== -1) {
              newData.push(item);
            }
        });
        setShowSearchLoading(false);
        if(newData.length <= 0){
          Toast.showWithGravity("No search results found.", Toast.SHORT, Toast.CENTER);
        }
        setRouteSearchResultList(newData);
      }
      else if(tabIndex === 2){ //search in prospect
        console.log("search in prospect");
        _prospectSearchRequest(brandSuccessResponse.ERPRepCode, 0, searchText);
      }
      else{
        console.log("NO tab selected for search this is unexpected condition.");
      }

    }
  };

  const onSearchClear = () =>{
    setCustomerSearchResultList([]);
    setProspectSearchResultList([]);
    setRouteSearchResultList([]);
    setSearchTerm('');
  }

  const [routes] = useState([
    {
      key: '1',
      title: 'Customers',
      icon: 'account',
      iconOutline: 'account-outline',
    },
    {key: '2', title: 'Routes', icon: 'directions', iconOutline: 'directions'},
    {key: '3', title: 'Prospects', icon: 'pickaxe', iconOutline: 'pickaxe'},
  ]);
  const Customers = () => <CustomersTab navigation={navigation} customerSearchResultList={customerSearchResultList} />;
  const Routes = () => (<RoutesTab navigation={navigation} routeSearchResultList={routeSearchResultList} onSearchRouteEdit={onTabIndexChange}/>);
  const Prospects = () => <ProspectsTab navigation={navigation} prospectSearchResultList={prospectSearchResultList} onSearchProspectEdit={onTabIndexChange}/>;
  //const Prospects = () => <View />;

  const renderTabIcon = ({route, focused, color}) => {
    return (
      <Icon
        size={20}
        name={focused ? route.icon : route.iconOutline}
        color={'white'}
      />
    );
  };
  const renderTabBar = (props) => (
    <TabBar
      {...props}
      indicatorStyle={{backgroundColor: 'white', height: 7}}
      renderIcon={renderTabIcon}
      labelStyle={{fontSize: 10}}
      contentContainerStyle={{
        borderBottomWidth: 2,
        borderBottomColor: PRODUCT_BORDER_COLOR,
      }}
    />
  );

  const initialLayout = {width: Dimensions.get('window').width, height: 200};
  const renderScene = SceneMap({
    1: Customers,
    2: Routes,
    3: Prospects,
  });
  const onTabIndexChange = (newIndex, updateIndex) => {
    if(updateIndex){
      setTabIndex(newIndex);
    }
    setSearchTerm('');
    setRouteSearchResultList([]);
    setProspectSearchResultList([]);
    setRouteSearchResultList([]);
  }

  return (
    <GenericTemplate
        keyboardTapPersist='handled'
       //keyboardTapPersist='always'
      style={{
        flex: 1,
        // flexDirection: 'row',
      }}>
      <UserBrandHeader
        navigation={navigation}
        headerNavigator={DeviceInfo.isTablet() ? false : true}
        //sideMenuOpen ={showSideMenu}
        sideMenuPage="HOME"
        headerNavigator={true}
        headerBackButton={true}
        // onSideMenuPress ={() => {showSideMenu? toggleSideMenu(false): toggleSideMenu(true)}}
      />
      <View style={{flexDirection: 'row', flex: 1}}>
        <View
          style={[
            {},
            DeviceInfo.isTablet() ? {width: '40%'} : {width: '100%'},
            //  styles.container,
          ]}>
          <SearchBar
            //containerStyle={{ height: '100%', justifyContent:'center'}}
            inputContainerStyle={{backgroundColor: GENERIC_BACKGROUND_COLOR}}
            placeholder={SEARCH_PLACEHOLDER}
            inputStyle={{color: BLACK_COLOR}}
            onChangeText={updateSearch}
            value={searchTerm}
            onClear={onSearchClear}
            // onChangeText={updateSearch}
            // value={searchTerm}
            showLoading={showSearchLoading}
            lightTheme
          />
          <TabView
            navigationState={{index: tabIndex, routes}}
            renderScene={renderScene}
            onIndexChange={(index => {onTabIndexChange(index, true)})}
            initialLayout={initialLayout}
            renderTabBar={renderTabBar}
            swipeEnabled={false}
            //lazy
          />
        </View>

        {DeviceInfo.isTablet() ? (
          <View
            style={{
              backgroundColor: 'pink',
              //  flex: 1
              width: '60%',
            }}></View>
        ) : null}
      </View>
    </GenericTemplate>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 0.75,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: SPLASH_LOGO_WIDTH,
    height: SPLASH_LOGO_HEIGHT,
  },
  scene: {
    flex: 1,
  },
});
const mapStateToProps = (reduxStore) => {
  return {
    customerSearchList: reduxStore.customer.customerSearchList,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    routeSuccessResponse: reduxStore.route.routeSuccessResponse,
    prospectSearchList: reduxStore.prospect.prospectSearchList
  };
};

export default withLoadingSpinner()(
  withHttpsApiErrorHandling()(
    connect(mapStateToProps, {
      customerSearchRequest, resetCustomerSearchRequest, prospectSearchRequest,
      resetProspectSearchRequest
    })(
      SalesAndGrowthLandingScreen,
    ),
  ),
);
