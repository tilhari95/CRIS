import React, {useEffect} from 'react';
import {StyleSheet, View, Text} from 'react-native';
import {mcni360_blue_icon} from "../../../resources/images";
import FastImage from "react-native-fast-image";
import {SPLASH_LOGO_HEIGHT, SPLASH_LOGO_WIDTH} from "../../../resources/constants/dimensions";
import {GenericButton} from "../../../components";

const InventoryActivities = ({navigation, routes}, prototype) => {

    return(
        <View style={styles.container}>
            <FastImage source={mcni360_blue_icon} style={styles.logo}/>
            <Text style={{fontSize: 20}}>
                Detail Pages. Specification coming soon!!
            </Text>
            <GenericButton title='back'  onPress={() => navigation.pop()}/>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 0.75,
        justifyContent: 'center',
        alignItems: 'center',
    },
    logo: {
        width: SPLASH_LOGO_WIDTH,
        height: SPLASH_LOGO_HEIGHT,
    },
});


export default InventoryActivities;

