import React, {useEffect} from 'react';
import {StyleSheet, View, Text} from 'react-native';
import {ROUTE_AUTH, ROUTE_AUTH_SUCCESS} from "../../resources/constants/navigationConstants";
import {mcni360_blue_icon} from "../../resources/images";
import FastImage from "react-native-fast-image";
import {SPLASH_LOGO_HEIGHT, SPLASH_LOGO_WIDTH} from "../../resources/constants/dimensions";
import {getUserDataOfCurrentLogin} from "../../realm/Models/loginModel";
import {validateRequiredField} from "../../utils/validators";
import {connect} from "react-redux";
import {setUserBrandDataInRedux} from "../../store/Login/loginAction";
import AppAsyncStorage from "../../api/helper/AppAsyncStorage";
import {AUTO_LOGGED_OUT, SIDE_MENU_RAW_JSON} from "../../resources/constants/asyncKeys";
import {NO} from "../../resources/constants/stringConstants";

const SplashScreen = ({navigation, routes,
                          setUserBrandDataInRedux:_setUserBrandDataInRedux}, prototype) => {
    setTimeout( async function() {
            let isAutoLoggedOut = await AppAsyncStorage.getValue(AUTO_LOGGED_OUT);
            let sideMenuDataFromAsync = await AppAsyncStorage.getValue(SIDE_MENU_RAW_JSON);
            let parsedSideMenuDataFromAsync= JSON.parse(sideMenuDataFromAsync);
            console.log('isAutoLoggedOut',isAutoLoggedOut);
            console.log('SIDE_MENU_RAW_JSON on splash screen-->',parsedSideMenuDataFromAsync);

            if (validateRequiredField(isAutoLoggedOut) && (isAutoLoggedOut === NO)) {
                getUserDataOfCurrentLogin()
                    .then(currentUserObject => {
                        if (validateRequiredField(currentUserObject)) {
                            // set sessionToken and email in redux
                            console.log(currentUserObject);
                            _setUserBrandDataInRedux(currentUserObject, parsedSideMenuDataFromAsync);
                            //
                            navigation.replace(ROUTE_AUTH_SUCCESS);
                        } else {
                            navigation.replace(ROUTE_AUTH);
                        }
                    })
                    .catch(error => {
                        console.log('error on autologin' + error)
                    })

            }
            else{
                navigation.replace(ROUTE_AUTH);
            }
        }
            ,500);

    return(
       <View style={styles.container}>
           <FastImage source={mcni360_blue_icon} style={styles.logo}/>
       </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 0.75,
        justifyContent: 'center',
        alignItems: 'center',
    },
    logo: {
        width: SPLASH_LOGO_WIDTH,
        height: SPLASH_LOGO_HEIGHT,
    },
});
const mapStateToProps = (reduxStore) => {
    return {
        emailText: reduxStore.login.email,
    };
};


export default connect(mapStateToProps, {setUserBrandDataInRedux}) (SplashScreen);

