import React, {useEffect} from 'react';
import {StyleSheet, View, Text, ScrollView} from 'react-native';
import {connect} from "react-redux";
import {setUserBrandDataInRedux} from "../../store/Login/loginAction";
import {INPUT_FIELD_BORDER_COLOR, PRODUCT_NAME_COLOR} from "../../resources/constants/themeConstant";
import {menuApiResponse} from "../../resources/constants/sidemenujson";
import CategoryTree from "../../components/DynamicSideMenu/CategoryTree";
import GenericButton from "../../components/Buttons/GenericButton";
import {onLogoutPressHandler} from "../../utils/LogoutHandlers";
import {resetAppData} from "../../services/onAuthService";
import {getRequiredSideMenuJson} from "../../utils/sideMenuDataParser";

const SideMenu = ({navigation, routes,
                      menuApiResponse
                  }, prototype) => {
    console.log("menu api responseis --** ", menuApiResponse);
    let dataC = getRequiredSideMenuJson(menuApiResponse);
    console.log("dataCdataCdataCdataC api responseis --** ", dataC);


    return(
        <ScrollView style={[{}, styles.container,]}>
            {/*<View*/}
            {/*    style={{*/}
            {/*        backgroundColor: INPUT_FIELD_BORDER_COLOR,*/}
            {/*        //    height: 20*/}
            {/*    }}>*/}
            {/*    <Text*/}
            {/*        style={{*/}
            {/*            color: PRODUCT_NAME_COLOR,*/}
            {/*            fontSize: 20,*/}
            {/*            marginTop: 5,*/}
            {/*            marginBottom: 5,*/}
            {/*        }}>*/}
            {/*        {menuApiResponse[0].name}*/}
            {/*    </Text>*/}
            {/*</View>*/}
            <View>
                {/*<CategoryTree categories={menuApiResponse[0].children_data} />*/}
                <CategoryTree categories={dataC} />
            </View>
            {/*<View*/}
            {/*    style={{*/}
            {/*        backgroundColor: INPUT_FIELD_BORDER_COLOR,*/}
            {/*        //    height: 20*/}
            {/*    }}>*/}
            {/*    <Text*/}
            {/*        style={{*/}
            {/*            color: PRODUCT_NAME_COLOR,*/}
            {/*            fontSize: 20,*/}
            {/*            marginTop: 5,*/}
            {/*            marginBottom: 5,*/}
            {/*        }}>*/}
            {/*        {menuApiResponse[1].name}*/}
            {/*    </Text>*/}
            {/*</View>*/}
            {/*<View>*/}
            {/*    <CategoryTree categories={menuApiResponse[1].children_data} />*/}
            {/*</View>*/}
            {/*<GenericButton*/}
            {/*    title="Logout"*/}
            {/*    //onPress={onGeoPress}*/}
            {/*    type={'clear'}*/}
            {/*    onPress={() => onLogoutPressHandler(navigation)}*/}
            {/*/>*/}
            {/*<GenericButton*/}
            {/*    title="Sync application data"*/}
            {/*    //onPress={onGeoPress}*/}
            {/*    type={'clear'}*/}
            {/*    onPress={() => resetAppData(false)}*/}
            {/*/>*/}
        </ScrollView>

    );
}

const styles = StyleSheet.create({
    container: {
        // flex: 0.75,
        // justifyContent: 'center',
        // alignItems: 'center',
    },
});
const mapStateToProps = (reduxStore) => {
    return {
        emailText: reduxStore.login.email,
    };
};


export default connect(mapStateToProps, {setUserBrandDataInRedux}) (SideMenu);

