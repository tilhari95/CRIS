import React, {useEffect, useState} from 'react';
import {StyleSheet, View, ScrollView, Image, Text} from 'react-native';
import MapView, {PROVIDER_GOOGLE} from 'react-native-maps';
import Geolocation from '@react-native-community/geolocation';
import {Marker, Callout} from 'react-native-maps';
import {useFocusEffect} from '@react-navigation/native';

import {
  AUTH_STACK_LOGO_HEIGHT,
  AUTH_STACK_LOGO_WIDTH,
  DEVICE_HEIGHT,
  INPUT_FIELD_HEIGHT,
  LAT_DELTA,
  LONG_DELTA,
  MAP_DEFAULT_LAT,
  MAP_DEFAULT_LONG,
  MAP_DISTANCE_FILTER,
  MAP_LOCATION_AGE, MAP_LOCATION_AGE_REFRESH,
  MAP_TIMEOUT,
  MODAL_CONTAINER_WIDTH,
  SPACING_10,
  SPACING_15,
  SPACING_30,
  TEXT_SIZE_15, WIDTH_200,
} from '../../resources/constants/dimensions';
import GenericTemplate from '../../components/GenericTemplate/GenericTemplate';
import {default as DeviceInfo} from 'react-native-device-info';
import {
  ERROR_COLOR,
  FIELD_BORDER_RADIUS,
  FIELD_BORDER_WIDTH,
  GENERIC_BACKGROUND_COLOR,
  HEADER_FONT_WEIGHT,
  INPUT_FIELD_BORDER_COLOR,
  MODAL_BACKDROP_OPACITY,
  TEXT_FONT_WEIGHT,
} from '../../resources/constants/themeConstant';
import GenericButton from '../../components/Buttons/GenericButton';
import {connect} from 'react-redux';
import {setLoginReduxInitialState} from '../../store/Login/loginAction';

import {requestCustomerGeoLocation, selectCustomerAction} from '../../store/Customer/customerAction';
import {menuApiResponse} from '../../resources/constants/sidemenujson';
import UserBrandHeader from '../../components/Headers/UserBrandHeader';
import {resetAuthTable} from '../../realm/Models/loginModel';
import {onLogoutPressHandler} from '../../utils/LogoutHandlers';

import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {validateRequiredField} from '../../utils/validators';
import SideMenu from './SideMenu';
import withHttpsApiErrorHandling from '../../components/HOC/withHttpsApiErrorHandling';
import {resetHomeHttpApiError} from '../../store/Home/homeAction';
import {resetAppData} from "../../services/onAuthService";
import {
  ROUTE_CUSTOMER_DETAIL,
  ROUTE_CUSTOMER_DETAIL_FROM_HOME, ROUTE_SALES_GROWTH_MENU,
  ROUTE_SETTINGS
} from "../../resources/constants/navigationConstants";
import Toast from "react-native-simple-toast";
import {resetShipToAddressResponseAction} from "../../store/shippingAddress/shippingAddressAction";
import {createInvoicePDF} from "../../utils/invoicePDFUtil/invoicePDFCreater";

const HomeScreen = ({
  navigation,
  setLoginReduxInitialState: _setLoginReduxInitialState,
  customerGeolocationSuccess,
  homeScreenApiError,
  showHttpsApiErrorDialog,
                      sideMenuDataResponseSuccess,
                      brandSuccessResponse,
  requestCustomerGeoLocation: _requestCustomerGeoLocation,
  resetHomeHttpApiError: _resetHomeHttpApiError,
                      selectCustomerAction: _selectCustomerAction,
                      resetShipToAddressResponseAction: _resetShipToAddressResponseAction
}) => {
  const [showSideMenu, toggleSideMenu] = useState(false);
  const [customerMarkers, setCustomerMarkers] = useState([]);
  const [currentCoordinates, setCurrentCoordinates] = useState({
    latitude: MAP_DEFAULT_LAT,
    longitude: MAP_DEFAULT_LONG,
  });
  useEffect(() => {
    getGeoLocation();
  }, []);

  useFocusEffect(
    React.useCallback(() => {
      const watchId = Geolocation.watchPosition(
        (position) => {
          console.log('Watch Position response', position);
          const {latitude, longitude} = position.coords;
          console.log("previous lat long " +currentCoordinates.latitude+ "  " + currentCoordinates.longitude )
          console.log("new lat long " +latitude+ "  " + longitude )

          if (
            currentCoordinates.latitude !== latitude ||
            currentCoordinates.longitude !== longitude
          ) {
            updateCurrentCoordinates(latitude, longitude);
          }
        },
        (error) => {
          console.log('error on watchPosition -->', error);
        },
        {
          enableHighAccuracy: true,
          timeout: MAP_TIMEOUT,
          maximumAge: MAP_LOCATION_AGE,
          distanceFilter: MAP_DISTANCE_FILTER,
        },
      );
      return () => Geolocation.clearWatch(watchId);
    }, []),
  );

  useEffect(() => {
    if (
      validateRequiredField(customerGeolocationSuccess) &&
      customerGeolocationSuccess.length > 0
    ) {
      console.log(
        'going to mark these in use effect',
        customerGeolocationSuccess,
      );
      setCustomerMarkers(customerGeolocationSuccess);
    }
  }, [customerGeolocationSuccess]);

  useEffect(() => {
    if (homeScreenApiError !== null) {
      showHttpsApiErrorDialog(homeScreenApiError);
      _resetHomeHttpApiError();
    }
  }, [homeScreenApiError]);

  const callCustomerMarkingAPI = (lat, long) => {
    _requestCustomerGeoLocation(lat, long, brandSuccessResponse.CompanyId, brandSuccessResponse.DeviceId,);
  };

  const updateCurrentCoordinates = (newLat, newLong) => {
    console.log("here in marking");
    setCurrentCoordinates({latitude: newLat, longitude: newLong});
    callCustomerMarkingAPI(newLat, newLong);
  };

  let options = {
    enableHighAccuracy: true,
    timeout: MAP_TIMEOUT,
    maximumAge: MAP_LOCATION_AGE_REFRESH,
  };
  function success(pos) {
    let crd = pos.coords;
    console.log('Your current position is :-->', pos);
    if (
        currentCoordinates.latitude !== crd.latitude ||
        currentCoordinates.longitude !== crd.longitude
    ){
      setCurrentCoordinates({latitude: crd.latitude, longitude: crd.longitude});
      callCustomerMarkingAPI(crd.latitude, crd.longitude);
    }

  }
  function error(err) {
    console.log(`ERROR(${err.code}): ${err.message}`);
    setTimeout(()=>{
      getGeoLocation();
    }, 3000);
  }
  const getGeoLocation = () => {
    Geolocation.getCurrentPosition(success, error, options);
  };

  return (
    <GenericTemplate
      navigation={navigation}
      keyboardAwareView={false}
      style={
        {
          //  flex:1,
          //     flexDirection : 'row'
        }
      }>
      <UserBrandHeader
        navigation={navigation}
        headerNavigator={DeviceInfo.isTablet() ? false : true}
        sideMenuOpen={showSideMenu}
        sideMenuPage="HOME"
        onSideMenuPress={() => {
          showSideMenu ? toggleSideMenu(false) : toggleSideMenu(true);
        }}
      />
      <View style={{flexDirection: 'row',
        height:"92%"
      }}
      >
        {DeviceInfo.isTablet() || (!DeviceInfo.isTablet() && showSideMenu) ? (
          <View
            style={[DeviceInfo.isTablet() ? {width: '30%'} : {width: '100%'} ]}>
            <SideMenu menuApiResponse={sideMenuDataResponseSuccess} navigation={navigation} />
          </View>
        ) : (
          <View style={{width: 0}}></View>
        )}
        {DeviceInfo.isTablet() || (!DeviceInfo.isTablet() && !showSideMenu) ? (
          <View
            style={[
              {
              //  height: DEVICE_HEIGHT * 0.90,
                justifyContent: 'center',
                alignItems: 'center',
                //backgroundColor: 'red',
                height:"100%",
                //borderWidth:2,
                // flex: 1
              },
              DeviceInfo.isTablet()
                ? {width: '70%',
                  //  height: DEVICE_HEIGHT * 0.90
            }
                : !showSideMenu
                ? {width: '100%',
                   // height:100
            }
                : {width: 0, height: 0},
            ]}>
            <View style={styles.containerMap}>
              <MapView
                provider={PROVIDER_GOOGLE}
                style={styles.map}
                initialRegion={{
                  latitude: MAP_DEFAULT_LAT,
                  longitude: MAP_DEFAULT_LONG,
                  latitudeDelta: LAT_DELTA, // for around 10km
                  longitudeDelta: LONG_DELTA,
                }}
                showsUserLocation={true}
                userLocationPriority={'balanced'}
                userLocationUpdateInterval={MAP_LOCATION_AGE}
                userLocationAnnotationTitle={'SALES REP'}
                region={{
                  latitude: currentCoordinates.latitude,
                  longitude: currentCoordinates.longitude,
                  latitudeDelta: LAT_DELTA, // for around 10km
                  longitudeDelta: LONG_DELTA,
                }}>
                {customerMarkers.map((marker, index) => {
                  let lat = parseFloat(marker.Latitude);
                  let long = parseFloat(marker.Longitude);
                  if (isNaN(lat) || isNaN(long)) {
                    lat = 0;
                    long = 0;
                  }
                  //  console.log('for marking --->', marker.CustomerName + " "+ lat + '  ' + long)
                  return (
                    <Marker
                      coordinate={{latitude: lat, longitude: long}}
                      title={marker.CustomerName}
                      description={marker.Address1}
                      onCalloutPress={()=>{
                        _selectCustomerAction(marker);
                        _resetShipToAddressResponseAction();
                        navigation.navigate(ROUTE_SALES_GROWTH_MENU,{
                        screen: ROUTE_CUSTOMER_DETAIL
                      })}}
                      key={index}>
                      {/*todo callout view width adjustment*/}
                      <Callout
                          width={AUTH_STACK_LOGO_WIDTH}
                          onPress={()=>{
                            _selectCustomerAction(marker);
                            _resetShipToAddressResponseAction();
                            navigation.navigate(ROUTE_SALES_GROWTH_MENU,{
                            screen: ROUTE_CUSTOMER_DETAIL
                          })}}>
                        <View>
                          <Text>{marker.CustomerName}</Text>
                          <Text>{marker.Address1}</Text>
                        </View>
                      </Callout>

                      <Icon size={40} name={'map-marker'} color={'red'} />
                    </Marker>
                  );
                })}
              </MapView>
              <View style={{flexDirection:'row', paddingBottom: 10}}>
                <GenericButton
                    //  title="Sync"
                    //onPress={onGeoPress}
                    //type={'clear'}
                    icon={'microsoft-teams'}
                    size={40}
                    buttonStyle={{ borderRadius: 30, width:80, height:60}}
                    containerStyle={{marginRight:7}}
                    onPress={() => {Toast.showWithGravity("Specifications coming soon.", Toast.SHORT, Toast.CENTER);}}
                />
                <GenericButton
                    //  title="Sync"
                    onPress={() =>getGeoLocation()}
                    //type={'clear'}
                    iconType={'ionicon'}
                    icon={'locate-sharp'}
                    size={40}
                    buttonStyle={{ borderRadius: 30, width:80, height:60}}
                    containerStyle={{marginRight:7}}
                    //onPress={() => {Toast.showWithGravity("Specifications coming soon.", Toast.SHORT, Toast.CENTER);}}
                />
                <GenericButton
                    //  title="Sync"
                    //onPress={onGeoPress}
                    //type={'clear'}
                    icon={'linkedin'}
                    size={40}
                    buttonStyle={{ borderRadius: 30, width:80, height:60}}
                    containerStyle={{marginRight:7}}
                   // onPress = {() => {createInvoicePDF()}}
                    //onPress ={() =>{getRequiredSideMenuJson(sideMenuDataResponseSuccess)}}
                    onPress={() => {Toast.showWithGravity("Specifications coming soon.", Toast.SHORT, Toast.CENTER);}}
                />
                <GenericButton
                  //  title="Sync"
                    //onPress={onGeoPress}
                    //type={'clear'}
                    iconType={'material'}
                    icon={'settings'}
                    size={40}
                    buttonStyle={{ borderRadius: 30, width:80, height:60}}
                    containerStyle={{marginRight:7}}
                     onPress={() => navigation.navigate(ROUTE_SETTINGS)}
                />
              </View>


            </View>
          </View>
        ) : (
          <View style={{width: 0}}></View>
        )}
      </View>
    </GenericTemplate>
  );
};

const styles = StyleSheet.create({
  authStackLogo: {
    width: AUTH_STACK_LOGO_WIDTH,
    height: AUTH_STACK_LOGO_HEIGHT,
    alignItems: 'center',
  },
  container: {
    //   backgroundColor:'green',
    //  justifyContent: 'center',
    //    alignItems: 'center',
  },
  inputContainerStyle: {
    borderBottomWidth: FIELD_BORDER_WIDTH,
    borderWidth: FIELD_BORDER_WIDTH,
    borderStyle: 'solid',
    borderColor: INPUT_FIELD_BORDER_COLOR,
    height: INPUT_FIELD_HEIGHT,
    padding: SPACING_10,
    borderRadius: FIELD_BORDER_RADIUS,
  },
  authHeaderStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    textAlign: 'center',
    marginTop: SPACING_30,
  },
  ForgetPassStyle: {
    fontWeight: TEXT_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'right',
    textDecorationLine: 'underline',
    marginTop: SPACING_15,
  },
  errorStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'center',
    color: ERROR_COLOR,
    marginTop: SPACING_30,
  },
  overlay: {
    backgroundColor: GENERIC_BACKGROUND_COLOR,
    opacity: MODAL_BACKDROP_OPACITY,
  },
  overlayModalStyle: {
    borderWidth: FIELD_BORDER_WIDTH,
    borderColor: INPUT_FIELD_BORDER_COLOR,
    width: MODAL_CONTAINER_WIDTH,
  },
  modalErrorStyle: {
    fontWeight: HEADER_FONT_WEIGHT,
    fontSize: TEXT_SIZE_15,
    textAlign: 'center',
    //color:ERROR_COLOR,
    marginBottom: SPACING_30,
  },
  containerMap: {
    //...StyleSheet.absoluteFillObject,
    height: '100%',
    width: '100%',
    justifyContent: 'flex-end',
    alignItems: 'center',
    //borderWidth:1,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
});
const mapStateToProps = (reduxStore) => {
  return {
    customerGeolocationSuccess: reduxStore.customer.customerGeolocationSuccess,
    homeScreenApiError: reduxStore.home.homeScreenApiError,
    brandSuccessResponse: reduxStore.login.brandSuccessResponse,
    sideMenuDataResponseSuccess:reduxStore.login.sideMenuDataResponseSuccess
  };
};

export default withHttpsApiErrorHandling()(
  connect(mapStateToProps, {
    setLoginReduxInitialState,
    requestCustomerGeoLocation,
    resetHomeHttpApiError,
    selectCustomerAction,
    resetShipToAddressResponseAction
  })(HomeScreen),
);
