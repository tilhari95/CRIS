import GenericTemplate from "../../components/GenericTemplate/GenericTemplate";
import {Text} from'react-native-elements';
const prospectJson =[{"Id":"00000000-0000-0000-0000-000000000001","CompanyId":"00000000-0000-0000-0000-000000000000","CompanyName":"Star Ford","Address":"","City":null,"State":null,"Zip":null,"EmailAddress":null,"Phone":"","RepId":"00000000-0000-0000-0000-000000000000","BusinessTypeId":0,"PriorityId":0,"CreatedBy":"00000000-0000-0000-0000-000000000000","CreatedOn":"2020-10-14T19:08:53.813","Active":false,"Status":null,"AreaRegion":"00000000-0000-0000-0000-000000000000","VisitFrequency":null,"PreferredDayOfWeek":null,"PreferredTimeOfDay":null,"CurrentProduct":"00000000-0000-0000-0000-000000000000","DecisionMaker":"00000000-0000-0000-0000-000000000000","ApproachProcessList":"00000000-0000-0000-0000-000000000000","CurrentStage":"00000000-0000-0000-0000-000000000000","EstimatedAnnualSales":0.0},{"Id":"00000000-0000-0000-0000-000000000003","CompanyId":"00000000-0000-0000-0000-000000000000","CompanyName":"Star ford ","Address":"1101 S Brand Blvd1101 S Brand Blvd","City":null,"State":null,"Zip":null,"EmailAddress":null,"Phone":"800-4749313","RepId":"00000000-0000-0000-0000-000000000000","BusinessTypeId":0,"PriorityId":0,"CreatedBy":"00000000-0000-0000-0000-000000000000","CreatedOn":"2020-10-14T19:08:53.983","Active":false,"Status":null,"AreaRegion":"00000000-0000-0000-0000-000000000000","VisitFrequency":null,"PreferredDayOfWeek":null,"PreferredTimeOfDay":null,"CurrentProduct":"00000000-0000-0000-0000-000000000000","DecisionMaker":"00000000-0000-0000-0000-000000000000","ApproachProcessList":"00000000-0000-0000-0000-000000000000","CurrentStage":"00000000-0000-0000-0000-000000000000","EstimatedAnnualSales":0.0},{"Id":"00000000-0000-0000-0000-000000000004","CompanyId":"00000000-0000-0000-0000-000000000000","CompanyName":"Car Pros Kia of Glendale","Address":"400 S Brand Blvd400 S Brand Blvd","City":null,"State":null,"Zip":null,"EmailAddress":null,"Phone":"844-846-7206","RepId":"00000000-0000-0000-0000-000000000000","BusinessTypeId":0,"PriorityId":0,"CreatedBy":"00000000-0000-0000-0000-000000000000","CreatedOn":"2020-10-14T19:08:54.14","Active":false,"Status":null,"AreaRegion":"00000000-0000-0000-0000-000000000000","VisitFrequency":null,"PreferredDayOfWeek":null,"PreferredTimeOfDay":null,"CurrentProduct":"00000000-0000-0000-0000-000000000000","DecisionMaker":"00000000-0000-0000-0000-000000000000","ApproachProcessList":"00000000-0000-0000-0000-000000000000","CurrentStage":"00000000-0000-0000-0000-000000000000","EstimatedAnnualSales":0.0},{"Id":"00000000-0000-0000-0000-000000000005","CompanyId":"00000000-0000-0000-0000-000000000000","CompanyName":"Car Pros Honda El Monte","Address":"3464 Peck Rd3464 Peck Rd","City":null,"State":null,"Zip":null,"EmailAddress":null,"Phone":"626-478-2371","RepId":"00000000-0000-0000-0000-000000000000","BusinessTypeId":0,"PriorityId":0,"CreatedBy":"00000000-0000-0000-0000-000000000000","CreatedOn":"2020-10-14T19:08:54.36","Active":false,"Status":null,"AreaRegion":"00000000-0000-0000-0000-000000000000","VisitFrequency":null,"PreferredDayOfWeek":null,"PreferredTimeOfDay":null,"CurrentProduct":"00000000-0000-0000-0000-000000000000","DecisionMaker":"00000000-0000-0000-0000-000000000000","ApproachProcessList":"00000000-0000-0000-0000-000000000000","CurrentStage":"00000000-0000-0000-0000-000000000000","EstimatedAnnualSales":0.0},{"Id":"00000000-0000-0000-0000-000000000006","CompanyId":"00000000-0000-0000-0000-000000000000","CompanyName":"Mercedes Benz ","Address":"1511 Auto Center Drive1511 Auto Center Drive","City":null,"State":null,"Zip":null,"EmailAddress":null,"Phone":"805-604-6500","RepId":"00000000-0000-0000-0000-000000000000","BusinessTypeId":0,"PriorityId":0,"CreatedBy":"00000000-0000-0000-0000-000000000000","CreatedOn":"2020-10-14T19:08:54.53","Active":false,"Status":null,"AreaRegion":"00000000-0000-0000-0000-000000000000","VisitFrequency":null,"PreferredDayOfWeek":null,"PreferredTimeOfDay":null,"CurrentProduct":"00000000-0000-0000-0000-000000000000","DecisionMaker":"00000000-0000-0000-0000-000000000000","ApproachProcessList":"00000000-0000-0000-0000-000000000000","CurrentStage":"00000000-0000-0000-0000-000000000000","EstimatedAnnualSales":0.0},{"Id":"00000000-0000-0000-0000-000000000007","CompanyId":"00000000-0000-0000-0000-000000000000","CompanyName":"Ventura Ford","Address":"3440 E Main St3440 E Main St","City":null,"State":null,"Zip":null,"EmailAddress":null,"Phone":"805)642-67-01","RepId":"00000000-0000-0000-0000-000000000000","BusinessTypeId":0,"PriorityId":0,"CreatedBy":"00000000-0000-0000-0000-000000000000","CreatedOn":"2020-10-14T19:08:54.687","Active":false,"Status":null,"AreaRegion":"00000000-0000-0000-0000-000000000000","VisitFrequency":null,"PreferredDayOfWeek":null,"PreferredTimeOfDay":null,"CurrentProduct":"00000000-0000-0000-0000-000000000000","DecisionMaker":"00000000-0000-0000-0000-000000000000","ApproachProcessList":"00000000-0000-0000-0000-000000000000","CurrentStage":"00000000-0000-0000-0000-000000000000","EstimatedAnnualSales":0.0},{"Id":"00000000-0000-0000-0000-000000000008","CompanyId":"00000000-0000-0000-0000-000000000000","CompanyName":"Simi Valley CDJR","Address":"2350 First Street2350 First Street","City":null,"State":null,"Zip":null,"EmailAddress":null,"Phone":"(805)581-9090","RepId":"00000000-0000-0000-0000-000000000000","BusinessTypeId":0,"PriorityId":0,"CreatedBy":"00000000-0000-0000-0000-000000000000","CreatedOn":"2020-10-14T19:08:54.923","Active":false,"Status":null,"AreaRegion":"00000000-0000-0000-0000-000000000000","VisitFrequency":null,"PreferredDayOfWeek":null,"PreferredTimeOfDay":null,"CurrentProduct":"00000000-0000-0000-0000-000000000000","DecisionMaker":"00000000-0000-0000-0000-000000000000","ApproachProcessList":"00000000-0000-0000-0000-000000000000","CurrentStage":"00000000-0000-0000-0000-000000000000","EstimatedAnnualSales":0.0},{"Id":"00000000-0000-0000-0000-000000000009","CompanyId":"00000000-0000-0000-0000-000000000000","CompanyName":"DCH-Audi of Oxnard","Address":"1600 Ventura Blvd1600 Ventura Blvd","City":null,"State":null,"Zip":null,"EmailAddress":null,"Phone":"(805) 288-3800","RepId":"00000000-0000-0000-0000-000000000000","BusinessTypeId":0,"PriorityId":0,"CreatedBy":"00000000-0000-0000-0000-000000000000","CreatedOn":"2020-10-14T19:08:55.187","Active":false,"Status":null,"AreaRegion":"00000000-0000-0000-0000-000000000000","VisitFrequency":null,"PreferredDayOfWeek":null,"PreferredTimeOfDay":null,"CurrentProduct":"00000000-0000-0000-0000-000000000000","DecisionMaker":"00000000-0000-0000-0000-000000000000","ApproachProcessList":"00000000-0000-0000-0000-000000000000","CurrentStage":"00000000-0000-0000-0000-000000000000","EstimatedAnnualSales":0.0},{"Id":"00000000-0000-0000-0000-000000000010","CompanyId":"00000000-0000-0000-0000-000000000000","CompanyName":"Galpin Honda","Address":"11151 Laurel Canyon Blvd11151 Laurel Canyon Blvd","City":null,"State":null,"Zip":null,"EmailAddress":null,"Phone":"(818)837-6144","RepId":"00000000-0000-0000-0000-000000000000","BusinessTypeId":0,"PriorityId":0,"CreatedBy":"00000000-0000-0000-0000-000000000000","CreatedOn":"2020-10-14T19:08:55.453","Active":false,"Status":null,"AreaRegion":"00000000-0000-0000-0000-000000000000","VisitFrequency":null,"PreferredDayOfWeek":null,"PreferredTimeOfDay":null,"CurrentProduct":"00000000-0000-0000-0000-000000000000","DecisionMaker":"00000000-0000-0000-0000-000000000000","ApproachProcessList":"00000000-0000-0000-0000-000000000000","CurrentStage":"00000000-0000-0000-0000-000000000000","EstimatedAnnualSales":0.0}];



import React, {useEffect, useState} from 'react';
import {
    StyleSheet,
    View,
    TouchableWithoutFeedback,
    FlatList, ScrollView,
} from 'react-native';
import {
    SPLASH_LOGO_HEIGHT,
    SPLASH_LOGO_WIDTH,
} from '../../resources/constants/dimensions';
import withLoadingSpinner from '../../components/HOC/withLoadingSpinner';
import withHttpsApiErrorHandling from '../../components/HOC/withHttpsApiErrorHandling';
import {connect} from 'react-redux';
import {customerListRequest, customerListToRedux, customerListRequestOnScroll, resetOnScrollRequest} from '../../store/Customer/customerAction';
import {validateRequiredField} from "../../utils/validators";
import {getCustomersListFromRealM} from "../../realm/Models/customerModel";
import UserBrandHeader from "../../components/Headers/UserBrandHeader";
import GenericButton from "../../components/Buttons/GenericButton";
import {onLogoutPressHandler} from "../../utils/LogoutHandlers";
import {resetAppData} from "../../services/onAuthService";

const SettingsScreen = (
    {
        navigation,
        routes,
        customerSearchResultList,
        customerApiSuccessResponse,
        customerOnScrollApiSuccess,
        customerListRequest: _customerListRequest,
        customerListToRedux:_customerListToRedux,
        customerListRequestOnScroll:_customerListRequestOnScroll,
        resetOnScrollRequest:_resetOnScrollRequest
    },
    prototype,
) => {
    const [customerList, setCustomerList] = useState([]);
    const [onScrollBoolean, setOnScrollBoolean] = useState(true);

    const getCustomerListFromRealM = async () => {
        let customerListFromRealM = await getCustomersListFromRealM();
        console.log('customer list on tab page insidde func', customerListFromRealM);
        if(validateRequiredField(customerListFromRealM) &&  customerListFromRealM.length > 0){
            console.log(customerListFromRealM.length);
            _customerListToRedux(customerListFromRealM);
            // updateCustomerListOnUI(customerListFromRealM);
        }
        else{
            _customerListRequest('id1', 'id2', 0, '');
        }
    }


    const callCustomerPagingOnScroll = () => {

    }

    return (
        <GenericTemplate
            style={{
                flex: 1,
                // flexDirection: 'row',
            }}
            navigation={navigation}
        //    keyboardAwareView={false}
        >
        {/*<View style={styles.container}>*/}
        {/*    <View style={{*/}
        {/*    //    height: 100*/}
        {/*    }}>*/}
            <UserBrandHeader
                navigation={navigation}
                headerNavigator={true}
                headerBackButton={true}
            />
            {/*</View>*/}
            <View style={{}}>
                <Text h1>Settings</Text>
            </View>
            <View style={{}}>
                <GenericButton
                    title="Sync application data"
                    titleStyle={{fontSize:30}}
                    containerStyle={{alignItems:'flex-start'}}
                    type={'clear'}
                    onPress={() => resetAppData(false)}
                />
            </View>
            <View style={{marginTop: 5}}>
                <GenericButton
                    title="Logout"
                    titleStyle={{fontSize:30}}
                   containerStyle={{alignItems:'flex-start'}}
                    //buttonStyle={{ alignItems:'flex-start'}}
                    type={'clear'}
                    onPress={() => onLogoutPressHandler(navigation)}
                />
            </View>

        {/*</View>*/}
        </GenericTemplate>
    );
};

const styles = StyleSheet.create({
    container: {
       // flex: 1,
        // justifyContent: 'center',
        // alignItems: 'center',
    },
    logo: {
        width: SPLASH_LOGO_WIDTH,
        height: SPLASH_LOGO_HEIGHT,
    },
});

const mapStateToProps = (reduxStore) => {
    return {
        customerApiSuccessResponse: reduxStore.customer.customerApiSuccessResponse,
        customerOnScrollApiSuccess: reduxStore.customer.customerOnScrollApiSuccess,
    };
};

export default withLoadingSpinner()(
    withHttpsApiErrorHandling()(
        connect(mapStateToProps, {customerListRequest, customerListToRedux, customerListRequestOnScroll, resetOnScrollRequest})(SettingsScreen),
    ),
);
