export const mcni360_blue_icon = require('./mcni360_logo_blue.png');
export const cards_image = require('./cards_image.png')
export const p_and_s = require('./p_and_s.png')
export const refresh = require('./refresh.png')
export const tick = require('./tick.png')
export const plus = require('./plus.png')
export const minus = require('./minus.png')
export const back = require('./back.png')
