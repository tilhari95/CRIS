export const menuApiResponse =
    [
        {
            "name": "Daily Processing",
            "is_active": true,
            "children_data": [
                {
                    "id": 1,
                    "parent_id": 0,
                    "name": "Sales & Growth",
                    "is_active": true,
                    "position": 1,
                    "level": 1,
                    'NavURL': 'SalesGrowthMenuStack',
                    "children_data": [
                        // {
                        //     "id": 2,
                        //     "parent_id": 1,
                        //     "name": "Sales & Growth Submenu 1",
                        //     "is_active": true,
                        //     "position": 0,
                        //     "level": 2,
                        //     'NavURL': '// Suyash will let you know',
                        //     "children_data": [
                        //         {
                        //             "id": 3,
                        //             "parent_id": 2,
                        //             "name": "Option 1 Sales & Growth",
                        //             "is_active": false,
                        //             "position": 0,
                        //             "level": 3,
                        //             "children_data": [],
                        //             'NavURL': 'inventory',
                        //         },
                        //         {
                        //             "id": 4,
                        //             "parent_id": 2,
                        //             "name": "Option 2 Sales & Growth",
                        //             "is_active": true,
                        //             "position": 0,
                        //             "level": 3,
                        //             'NavURL': 'inventory',
                        //             "children_data": []
                        //         }
                        //     ]
                        // },
                        // {
                        //     "id": 231,
                        //     "parent_id": 1,
                        //     "name": "Sales & Growth Submenu 2",
                        //     "is_active": true,
                        //     "position": 0,
                        //     "level": 2,
                        //     'NavURL': 'inventory',
                        //     "children_data": []
                        // }
                    ]
                },
                {
                    "id": 5,
                    "parent_id": 0,
                    "name": "Inventory Activities",
                    "is_active": true,
                    "position": 2,
                    "level": 1,
                    'NavURL': 'inventory',
                    "children_data": []
                },
                {
                    "id": 6,
                    "parent_id": 0,
                    "name": "Fulfilment",
                    "is_active": true,
                    "position": 3,
                    "level": 1,
                    'NavURL': '// Suyash will let you know',
                    "children_data": [
                        {
                            "id": 7,
                            "parent_id": 2,
                            "name": "option 1 Fulfilment Submenu",
                            "is_active": true,
                            "position": 0,
                            "level": 2,
                            "children_data": [],
                            'NavURL': 'inventory',
                        },
                        {
                            "id": 8,
                            "parent_id": 2,
                            "name": "Option2 Fulfilment Submenu",
                            "is_active": true,
                            "position": 0,
                            "level": 2,
                            'NavURL': 'inventory',
                            "children_data": []
                        }
                    ]
                }
            ]
        },

        {
            "name": "Maintenance",
            "is_active": true,
            "children_data": [
                {
                    "id": 1,
                    "parent_id": 0,
                    "name": "Goals & Results",
                    "is_active": true,
                    "position": 1,
                    "level": 1,
                    'NavURL': '// Suyash will let you know',
                    "children_data": [
                        {
                            "id": 2,
                            "parent_id": 1,
                            "name": "Goals & Results Submenu 1",
                            "is_active": true,
                            "position": 0,
                            "level": 2,
                            'NavURL': 'inventory',
                            "children_data": [
                                {
                                    "id": 3,
                                    "parent_id": 2,
                                    "name": "Option 1 Goals & Results",
                                    "is_active": true,
                                    "position": 0,
                                    "level": 3,
                                    "children_data": [],
                                    'NavURL': 'inventory',
                                },
                                {
                                    "id": 4,
                                    "parent_id": 2,
                                    "name": "Option 2 Goals & Results",
                                    "is_active": true,
                                    "position": 0,
                                    "level": 3,
                                    "children_data": [
                                        {
                                            "id": 319,
                                            "parent_id": 4,
                                            "name": "Further down ....",
                                            "is_active": true,
                                            "position": 0,
                                            "level": 4,
                                            "children_data": [],
                                            'NavURL': 'inventory',
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "id": 231,
                            "parent_id": 1,
                            "name": "Goals & Results Submenu 2",
                            "is_active": true,
                            "position": 0,
                            "level": 2,
                            'NavURL': 'inventory',
                            "children_data": []
                        }
                    ]
                },
                {
                    "id": 5,
                    "parent_id": 0,
                    "name": "Customers and Prospects",
                    "is_active": true,
                    "position": 2,
                    "level": 1,
                    'NavURL': 'inventory',
                    "children_data": []
                },
                {
                    "id": 6,
                    "parent_id": 0,
                    "name": "Inventory",
                    "is_active": true,
                    "position": 3,
                    "level": 1,
                    'NavURL': '// Suyash will let you know',
                    "children_data": [
                        {
                            "id": 7,
                            "parent_id": 2,
                            "name": "Option1 Inventory Submenu",
                            "is_active": true,
                            "position": 0,
                            "level": 2,
                            "children_data": [],
                            'NavURL': 'inventory',
                        },
                        {
                            "id": 8,
                            "parent_id": 2,
                            "name": "Option2 Inventory Submenu",
                            "is_active": true,
                            "position": 0,
                            "level": 2,
                            'NavURL': 'inventory',
                            "children_data": []
                        }
                    ]
                }
            ]
        },
    ];

// let serverResponse  ={
//     "code":"200",
//     "data":{
//     "response":{
//         "reasonCode":"1",
//             "reasonText":"SUCCESS",
//             "dataList":"[" +
//                 "{"MenuID":2,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Sales & Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""," +
//                 "{"MenuID":3,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Inventory","NavURL":"","IsActive":true,"ImageUrl":"Inventory.png","MenuSubText":""}," +
//                 "{"MenuID":4,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Fulfilment","NavURL":"","IsActive":true,"ImageUrl":"Fulfilment.png","MenuSubText":""}," +
//                 "{"MenuID":5,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Compliance","NavURL":"","IsActive":true,"ImageUrl":"Compliance.png","MenuSubText":""}," +
//                 "{"MenuID":6,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Reports","NavURL":"","IsActive":true,"ImageUrl":"Reports.png","MenuSubText":""}," +
//                 "{"MenuID":7,"ParentMenuID":0,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Tools","NavURL":"","IsActive":true,"ImageUrl":"Tools.png","MenuSubText":""}," +
//                 "{"MenuID":8,"ParentMenuID":2,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Sales","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""}," +
//                 "{"MenuID":9,"ParentMenuID":2,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""}," +
//                 "{"MenuID":10,"ParentMenuID":9,"DeviceId":null,"CompanyId":null,"UserId":null,"MenuName":"Customer Growth","NavURL":"","IsActive":true,"ImageUrl":"SalesAndGrowth.png","MenuSubText":""}]",
//             "error":"",
//             "token":null,
//             "isValid":null
//         }
//     }
// }


