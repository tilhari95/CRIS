import { cos } from "react-native-reanimated";

export const PASSWORD_ENTERED = "password_entered";
export const PHONE_CHANGED = "phone_changed";
export const LOGIN_REQUEST_FAIL = "login_request_fail";
export const LOGIN_REQUEST_SUCCESS = "login_request_success";
export const LOGOUT_SUCCESS = "logout_success";
export const LOGOUT_SPIFF_SUCCESS = "LOGOUT_SPIFF_SUCCESS";
export const LOGOUT_COMM_SUCCESS = "LOGOUT_COMM_SUCCESS";
export const LOGOUT_FAIL = "logout_fail";
export const SAVE_USER_ID = "save_user_id";
export const CLEAR_DATA_AFTER_LOGOUT = "clear_data_after_logout";
export const EMAIL_ENTERED = "email_entered";
export const SET_SESSION_AND_DATA_FROM_DB = "set_session_and_data_from_db";
export const LOGIN_REQUEST = "login_request";
export const LOGIN_REQUEST_LOADING = "login_request_loading";
export const USER_BRAND_REQUEST = "user_brand_request";
export const USER_SIDE_MENU_REQUEST = "user_side_menu_request";
export const BRAND_REQUEST_SUCCESS = "get_brand_success";
export const SIDE_MENU_REQUEST_SUCCESS = "side_menu_success";
export const BRAND_REQUEST_FAIL = "get_brand_fail";
export const SET_LOGIN_INITIAL_STATE = "set_login_redux_initial_state";
export const SET_INTERMEDDIATE_PAGE_INITIAL_STATE = "set_intermediate_page_redux_initial_state";

export const SET_LOGIN_INITIAL_STATE_ON_LOGOUT = "set_login_redux_initial_state_on_logout";
export const RESET_BRAND_SUCCESS_RESPONSE = "RESET_BRAND_SUCCESS_RESPONSE";
export const HTTP_API_ERROR = "http_login_error";
export const RESET_HTTP_API_ERROR = "reset_http_login_error";
export const RESET_INTERMEDIATE_PAGE_HTTP_API_ERROR = "reset_intermediate_page_http_login_error";

export const SET_USER_BRAND_DATA = "set_user_brand_data";
export const PRODUCT_API_REQUEST = "product_api_request";
export const SET_PRODUCT_LIST_DATA = "set_product_list_data";
export const PRODUCT_FORCE_UPDATE = "product_force_update";
export const PRODUCT_REQUEST_SUCCESS = "product_request_success";
export const RESET_PRODUCT_PAGE_REDUCER_ON_LOGOUT = "reset_product_page_redux_onlogout";
export const RESET_PRODUCT_PAGE_REDUCER_STATE = "reset_product_page_reducer_state";
export const RESET_USER_ASYNC_IN_REDUX = "RESET_USER_ASYNC_IN_REDUX";
export const SET_DATE_STRING = "set_date_string";
export const RESET_REQUEST_SUCCESS = "reset_request_success";
export const FETCH_CUSTOMER_REQUEST = "fetch_customer_request";
export const FETCH_ROUTES_REQUEST = "FETCH_ROUTES_REQUEST";
export const FETCH_CUSTOMER_ON_SCROLL_REQUEST = "fetch_customer_request_on_scroll";
export const SEARCH_CUSTOMER_REQUEST = "search_customer_request";
export const RESET_CUSTOMER_SEARCH_REQUEST = "reset_search_customer_request";
export const ADD_EDIT_ROUTE_REQUEST = "add_edit_route_request";
export const ROUTE_STOP_LIST = "route_stop_list";
export const SEARCH_CUSTOMER_ROUTE_STOP_REQUEST = "search_customer_route_stop_request";
export const ROUTE_STOP_ADD = "route_stop_add";

export const SEARCH_CUSTOMER_ROUTE_STOP_REQUEST_SUCCESS = "search_customer_route_stop_request_success";
export const RESET_SEARCH_CUSTOMER_ROUTE_STOP_REQUEST = "reset_search_customer_route_stop_request";
export const ADD_ROUTE_STOP_SUCCESS = "add_route_stop_success";
export const DELETE_ROUTE_STOP_SUCCESS = "delete_route_stop_success";
export const DELETE_ROUTE_STOP_REQUEST = "delete_route_stop_request";
export const ROUTE_STOP_LIST_REFRESH = "route_stop_list_refresh";
export const RESET_DELETE_STOP_SUCCESS = "RESET_DELETE_STOP_SUCCESS";


export const ADD_ROUTE_STOP_SUCCESS_RESET = "ADD_ROUTE_STOP_SUCCESS_RESET";


export const FETCH_PROSPECT_REQUEST = "fetch_prospect_request";
export const FETCH_PROSPECT_ON_SCROLL_REQUEST = "fetch_prospect_request_on_scroll";
export const SEARCH_PROSPECT_REQUEST = "search_prospect_request";
export const RESET_SEARCH_PROSPECT_REQUEST = "reset_search_prospect_request";

export const PROSPECT_ON_SCROLL_RESET = "prospect_on_scroll_reset";
export const PROSPECT_SEARCH_REQUEST_SUCCESS = "PROSPECT_SEARCH_REQUEST_SUCCESS";
export const HTTP_PROSPECT_API_ERROR = "HTTP_PROSPECT_API_ERROR";
export const PROSPECT_ON_SCROLL_REQUEST_SUCCESS = "PROSPECT_ON_SCROLL_REQUEST_SUCCESS";
export const PROSPECT_STAGE_SUCCESS = "prospect_stage_success";
export const PROSPECT_STAGE_REQUEST = "prospect_stage_request";
export const PROSPECT_DECISION_SUCCESS = "prospect_decision_success";
export const PROSPECT_HEADER_LIST_SUCCESS = "prospect_header_list_success";

export const PROSPECT_ADD_EDIT_REQUEST = "prospect_add_edit_request";
export const PROSPECT_DECISION_MAKER_REQUEST = "prospect_decision_maker_request";
export const PROSPECT_HEADER_LIST_REQUEST = "prospect_header_list_request";
export const PROSPECT_HEADER_LIST_RESET = "prospect_header_list_request_reset";
export const PROSPECT_DECISION_MAKER_RESET = "prospect_decision_maker_reset";

export const RESET_REQUEST_FAIL = "reset_request_fail";
export const HOME_SCREEN_REQUEST_FAIL = "home_screen_request_fail";
export const HOME_SCREEN_HTTP_FAIL_RESET = "home_screen_http_fail_reset";
export const SET_PASSWORD_INITIAL_STATE = "set_password_redux_initial_state";
export const HTTP_RESET_API_ERROR = "http_reset_api_error";
export const HTTP_LOGOUT_API_ERROR = "http_logout_api_error";
export const HTTP_LOGOUT_API_ERROR_SPIFF = "HTTP_LOGOUT_API_ERROR_SPIFF";
export const HTTP_LOGOUT_API_ERROR_COMM = "HTTP_LOGOUT_API_ERROR_COMM";


export const CUSTOMER_REQUEST_SUCCESS = "customer_api_req_success";
export const CUSTOMER_ON_SCROLL_REQUEST_SUCCESS = "customer_api_on_scroll_req_success";
export const CUSTOMER_SEARCH_REQUEST_SUCCESS = "customer_search_req_success";
export const CUSTOMER_GEOLOCATION_SUCCESS = "customer_geolocation_success";
export const CUSTOMER_ON_SCROLL_RESET = "customer_api_on_scroll_req_success";
export const CUSTOMER_REQUEST_FAIL = "customer_api_req_fail";
export const HTTP_CUSTOMER_API_ERROR = "http_customer_api_error11";
export const HTTP_ROUTE_STOP_API_ERROR = "http_route_stop_error";
export const HTTP_SALES_GROWTH_LANDING_SCREEN_API_ERROR = "http_ales_and_growth_landing_Screen_api_error";
export const HTTP_SALES_GROWTH_LANDING_SCREEN_API_ERROR_RESET = "http_ales_and_growth_landing_Screen_api_error_reset";
export const HTTP_CUSTOMER_API_ERROR_RESET = "http_customer_api_error_reset";
export const HTTP_PROSPECT_API_ERROR_RESET = "http_prospect_api_error_reset";
export const SET_CUSTOMER_REDUX_INITIAL_STATE = "set_customer_redux_initial_state";
export const SET_PROSPECT_REDUX_INITIAL_STATE = "set_prospect_redux_initial_state";
export const PROSPECT_REQUEST_SUCCESS = "prospect_request_success";
export const PROSPECT_REQUEST_FAIL = "prospect_request_fail";
export const PROSPECT_ADD_EDIT_SUCCESS = "prospect_add_edit_success";
export const RESET_PROSPECT_ADD_EDIT_STATE = "reset_prospect_add_edit_success";
export const SELECTED_CUSTOMER = "selected_customer";
export const RESET_SELECTED_CUSTOMER = "reset_selected_customer";

// Customer Detail
export const FETCH_CUSTOMER_DETAIL_DATA_REQUEST = "fetch_customer_detail_data_request";
export const CUSTOMER_DETAIL_DATA_REQUEST_SUCCESS = "customer_detail_data_request_success";
export const RESET_CUSTOMER_DETAIL_DATA_RESPONSE = "customer_detail_data_request_success";
export const CUSTOMER_DETAIL_DATA_REQUEST_FAIL = "customer_detail_data_request_success";
export const RESET_CUSTOMER_DETAIL_API_ERROR = "reset_customer_detail_api_error";
export const CUSTOMER_DETAIL_API_HTTP_ERROR = "customer_detail_api_http_error";
export const RESET_CUSTOMER_DETAIL_API_HTTP_ERROR = "reset_customer_detail_api_http_error";

//CustomerInfo API
export const CUSTOMER_INFO_API_REQ = "customer_info_api_req";
export const CUSTOMER_INFO_API_SUCCESS = "customer_info_api_success";
export const RESET_CUSTOMER_INFO_API_RESPONSE = "reset_customer_info_api_response";
export const CUSTOMER_INFO_API_ERR = "customer_info_api_err";
export const RESET_CUSTOMER_INFO_API_ERR = "reset_customer_info_api_arr";
export const CUSTOMER_INFO_API_HTTP_ERR = "customer_info_api_http_err";
export const RESET_CUSTOMER_INFO_API_HTTP_ERR = "reset_customer_info_http_err";

export const ROUTE_REQUEST_SUCCESS = "route_api_req_success";
export const ROUTE_STOP_REQUEST_SUCCESS = "route_stop_request_success";
export const ROUTE_ADD_EDIT_SUCCESS = "route_add_dit_success";
export const ROUTE_ON_SCROLL_REQUEST_SUCCESS = "route_api_on_scroll_req_success";
export const ROUTE_SEARCH_REQUEST_SUCCESS = "route_search_req_success";
export const ROUTE_ON_SCROLL_RESET = "route_api_on_scroll_req_success";
export const ROUTE_REQUEST_FAIL = "route_api_req_fail";
export const HTTP_ROUTE_API_ERROR = "http_route_api_error";
export const HTTP_ROUTE_API_ERROR_RESET = "http_route_api_error_reset";
export const HTTP_ROUTE_STOP_API_ERROR_RESET = "http_route_stop_api_error_reset";
export const SET_ROUTE_REDUX_INITIAL_STATE = "set_route_redux_initial_state";
export const SET_ROUTE_STOP_REDUX_INITIAL_STATE = "set_route_stop_redux_initial_state";
export const RESET_ROUTE_ADD_EDIT_STATE = "reset_route_add_edit_state";
export const ROUTE_STOP_RESET = "route_stop_reset";

export const CUSTOMER_GEOLOCATION_REQUEST = "customer_geo_location_req";

export const HTTP_RESET_API_ERROR_RESET = "reset_http_error_initial";
export const RESET_PASSWORD_REQUEST = "reset_password_request";
export const SPIFF_TRANSACTION_REQUEST = "spiff_transaction_request";
export const ORDER_HISTORY_LIST_REQUEST = "ORDER_HISTORY_LIST_REQUEST";
export const LOGOUT_REQUEST = "logout_request";
export const LOGOUT_ON_SESSION_INVALID = "LOGOUT_ON_SESSION_INVALID";
export const HTTP_PRODUCT_API_ERROR = "http_product_api_error";

export const RESET_HTTP_PRODUCT_API_ERROR = "reset_http_product_api_error";
export const LOGOUT = "logout";
export const LOGOUT_COMM_CENTER = "logout_comm_center";
export const LOGOUT_SPIFF = "logout_spiff";
export const RESET_HTTP_LOGOUT_API_ERROR = "reset_http_logout_api_error";
export const RESET_HTTP_LOGOUT_REQUEST = "reset_http_logout_request";

export const COMPANY_LIST_SUCCESS = "company_list_success";
export const TEMPLATE_LIST_SUCCESS = "tempelate_list_success";
export const INTERMEDIATE_PAGE_HTTP_ERROR = "intermediate_page_http_error";
export const COMAPANY_REQUEST = "COMAPANY_REQUEST";
export const TEMPLATE_REQUEST = "TEMPLATE_REQUEST";

export const UPDATE_CART_LIST = "update_cart_list";
export const DELETE_ITEM_FROM_CART_LIST = "delete_item_from_cart_list";
export const ADD_ITEM_TO_CART_LIST = "add_item_to_cart_list";
export const UPDATE_ITEM_TO_CART_LIST = "update_item_to_cart_list";
export const RESET_CART_LIST = "reset_cart_list";
export const UPDATE_CART_LIST_SUCCESS = "update_cart_list_success";
export const UPDATE_CART_ITEM_DELETE_SUCCESS = "update_cart_item_delete_success";
export const UPDATE_CART_ITEM_ADD_SUCCESS = "update_cart_item_add_success";
export const UPDATE_EXISTING_CART_ITEM_UPDATE_SUCCESS = "update_existing_cart_item_update_success";

export const SET_CART_REDUX_INITIAL_STATE = "set_cart_redux_initial_state";
export const SET_LOGOUT_REDUX_INITIAL_STATE = "SET_LOGOUT_REDUX_INITIAL_STATE";
export const SET_ORDER_HTTP_INITIAL_STATE = "set_order_http_initial_state";
export const TOGGLE_CART_UPDATER = "toogle_cart_updater";
export const INITIALIZE_CARTLIST_FROM_ASYNC = "initialize_cartlist_from_async";
export const RESET_CART_BADGE_VALUE = "reset_cart_badge_value";
export const CHECK_AND_PLACE_ORDER = "check_and_place_order";
export const SET_CART_BADGE_VALUE = "set_cart_badge_value";
export const PLACE_ORDER_FAIL = "place_order_fail";
export const PLACE_ORDER_SUCCESS = "place_order_success";
export const RESET_PLACE_ORDER_STATE = "reset_place_order_state";
export const PLACE_ORDER_MISMATCH = "place_order_mismatch";
export const HTTP_ORDER_API_ERROR = "http_order_api_error";
export const SEND_MESSAGE_FAIL = "send_message_fail";
export const SEND_MESSAGE_SUCCESS = "send_message_success";
export const GET_MESSAGE_FAIL = "get_message_fail";
export const GET_SPIFF_TRANSACTION_FAIL = "get_spiff_transaction_fail";
export const GET_MESSAGE_SUCCESS = "get_message_success";
export const GET_SPIFF_TRANCTION_SUCCESS = "get_spiff_tranaction_success";
export const GET_INVOICE_PDF_SUCCESS = "GET_INVOICE_PDF_SUCCESS";
export const GET_ORDER_HISTORY_SUCCESS = "get_order_history_success";
export const RESET_SPIFF_TRANCTION_BALANCE_API = "reset_spiff_tranaction_balace_api";
export const RESET_HTTP_MESSAGE_API_ERROR = "reset_http_message_api_error";
export const RESET_HTTP_ORDER_HISTORY_API_ERROR = "reset_http_order_history_api_error";
export const HTTP_ORDER_HISTORY_API_ERROR = "http_order_history_api_error";
export const RESET_MESSAGE_INDICATOR = "reset_message_indicator";
export const HTTP_MESSAGE_API_ERROR = "http_message_api_error";
export const RESET_MESSAGE_PAGE_REDUCER_STATE = "reset_message_page_reducer_state";
export const RESET_SPIFF_REDUCER_STATE = "reset_spiff_reducer_state";
export const RESET_ORDER_HISTORY_REDUCER_STATE = "reset_order_history_reducer_state";
export const FETCH_ORDER_INVOICE = "FETCH_ORDER_INVOICE";
export const HTTP_SPIFF_LANDING_PAGE_API_ERROR = "http_spiff_landing_page_api_error";
export const RESET_SPIFF_LANDING_PAGE_API_ERROR = "reset_http_spiff_landing_page_api_error";
export const RESET_SPIFF_PAYOUT_PAGE_API_ERROR = "reset_spiff_payout_page_http_error";
export const RESET_SPIFF_PAYOUT_API_RESPONSE = "RESET_SPIFF_PAYOUT_API_RESPONSE";
export const PAYOUT_FINAL_REQUEST_SUCCESS = "PAYOUT_FINAL_REQUEST_SUCCESS";
export const HTTP_SPIFF_PAYOUT_PAGE_API_ERROR = "http_spiff_payout_page_api_error";
export const SPIFF_PAYMENT_MODE_SUCCESS = "spiff_payment_mode_success";
export const REQUEST_PAYMENT_MODE_API = "request_payment_mode_api";
export const REQUEST_PAYOUT_API = "request_payout_api";


export const GET_MESSAGE_API_REQUEST = "get_message_api_request";
export const SEND_MESSAGE_API_REQUEST = "send_message_api_request";
export const SERVER_PUSH_MESSAGE_RECEIVED = "server_push_message_received";
export const SERVER_PUSH_MESSAGE_RESET = "server_push_message_reset";

//Customer Item Store
export const GET_ITEMS_API_REQUEST = "get_item_api_request";
export const GET_ITEMS_API_SUCCESS = "get_items_api_success";
export const RESET_ITEM_LIST = "reset_item_list";
export const GET_ITEMS_API_FAIL_ERROR = "get_items_api_fail";
export const RESET_GET_ITEM_API_ERROR = "reset_get_item_api_error";
export const GET_ITEM_HTTP_ERROR = "get_item_http_error";
export const RESET_GET_ITEM_HTTP_ERROR = "reset_get_item_http_error";
export const RESET_ITEM_REDUX_STATE = "reset_item_redux_state";
export const GET_ITEM_ON_SCROLL_REQUEST = "get_item_on_scroll_request";
export const GET_ITEM_ON_SCROLL_SUCCESS = "get_item_on_scroll_success";
export const RESET_GET_ITEM_ON_SCROLL = "reset_get_item_on_scroll";
export const ITEM_SEARCH_API_REQUEST = "item_search_api_request";
export const ITEM_SEARCH_API_SUCCESS = "item_search_api_success";
export const RESET_ITEM_SEARCH_LIST = "reset_item_search_list";

export const ITEM_DETAIL_API_REQUEST = "item_detail_api_request";
export const ITEM_DETAIL_API_SUCCESS = "item_detail_api_success";
export const RESET_API_DETAIL_API_RESPONSE = "reset_api_detail_api_response";
export const ITEM_DETAIL_API_ERROR = "item_detail_api_error";
export const RESET_ITEM_DETAIL_API_ERROR = "reset_item_detail_api_error";
export const ITEM_DETAIL_API_HTTP_ERROR = "item_detail_api_http_error";
export const RESET_ITEM_DETAIL_API_HTTP_ERROR = "reset_item_detail_http_error";

// Customer Item History Store
export const ITEM_HISTORY_API_REQUEST = "item_histry_api_request";
export const ITEM_HISTORY_API_SUCCESS = "item_history_api_success";
export const RESET_ITEM_HISTORY_API = "item_history_api_reset";
export const ITEM_HISTORY_API_ERROR = "item_history_api_error";
export const RESET_ITEM_HISTORY_API_ERROR = "reset_item_history_api_error";
export const ITEM_HISTORY_API_HTTP_ERROR = "item_history_api_http_error";
export const RESET_ITEM_HISTORY_API_HTTP_ERROR = "reset_item_history_api_http_error";
export const ITEM_HISTORY_ON_SCROLL_REQUEST = "item_history_on_scroll_request";
export const ITEM_HISTORY_ON_SCROLL_SUCCESS = "item_history_on_scroll_success";
export const RESET_ITEM_HISTORY_ON_SCROLL_LIST = "reset_item_history_on_scroll_list";
export const RESET_ITEM_HISTORY_REDUX_STATE = "reset_item_history_redux_state";

// HotKeys Items Store
export const HOTKEYS_LIST_API_REQUEST = "hotkeys_list_api_request";
export const HOTKEYS_LIST_API_SUCCESS = "hotkeys_list_api_success";
export const RESET_HOTKEYS_LIST = "reset_hotkeys_list";
export const HOTKEYS_LIST_API_ERROR = "hotkeys_list_api_error";
export const RESET_HOTKEYS_LIST_API_ERROR = "reset_hotkeys_list_api_error";
export const HOTKEYS_LIST_HTTP_ERROR = "hotkeys_list_http_error";
export const RESET_HOTKEYS_LIST_HTTP_ERROR = "reset_hotkeys_list_http_error";
export const HOTKEY_ITEMS_API_REQUEST = "hotkey_items_api_request";
export const HOTKEY_ITEMS_API_SUCCESS = "hotkey_items_api_success";
export const RESET_HOTKEY_ITEMS_API_RESPONSE = "reset_hotkey_items_api_response";
export const RESET_HOTKEYS_STORE = "reset_hotkeys_store";

// Template API Store
export const TEMPLATE_LIST_API_REQUEST = "template_list_api_request";
export const TEMPLATE_LIST_API_SUCCESS = "template_list_api_success";
export const RESET_TEMPLATE_LIST_API_RESPONSE = "reset_template_list_api_response";
export const TEMPLATE_LIST_API_ERROR = "template_list_api_error";
export const RESET_TEMPLATE_LIST_API_ERROR = "reset_template_list_api_error";
export const TEMPLATE_LIST_API_HTTP_ERROR = "template_list_api_http_error";
export const RESET_TEMPLATE_LIST_API_HTTP_ERROR = "reset_template_list_api_http_error";

export const TEMPLATE_ITEM_API_REQUEST = "template_item_api_request";
export const TEMPLATE_ITEM_API_SUCCESS = "template_item_api_success";
export const RESET_TEMPLATE_ITEM_API_RESPONSE = "reset_template_item_api_response";
export const TEMPLATE_ITEM_API_ERROR = "template_item_api_error";
export const RESET_TEMPLATE_ITEM_API_ERROR = "reset_template_item_api_error";
export const TEMPLATE_ITEM_API_HTTP_ERROR = "template_item_api_http_error";
export const RESET_TEMPLATE_ITEM_API_HTTP_ERROR = "reset_template_item_api_http_error";
export const RESET_TEMPLATE_STORE_TO_INITIAL = "reset_template_store_to_initial_State";

// Shipping Address Store
export const SHIP_TO_ADDRESS_LIST_REQUEST = "ship_to_address_list_request";
export const SHIP_TO_ADDRESS_LIST_SUCCESS = "ship_to_address_list_success";
export const RESET_SHIP_TO_ADDRESS_LIST_RESPONSE = "reset_ship_to_address_list_response";
export const SHIP_TO_ADDRESS_API_FAIL = "ship_to_address_api_fail";
export const RESET_SHIP_TO_ADDRESS_API_FAIL = "reset_ship_to_address_api_fail";
export const SHIP_TO_ADDRESS_HTTP_ERROR = 'ship_to_Address_http_error';
export const RESET_SHIP_TO_ADDRESS_HTTP_ERROR = "reset_ship_to_address_http_error";

export const UPDATE_SHIPPING_ADDRESS_API_REQ = "update_shipping_address_api_req";
export const UPDATE_SHIPPING_ADDRESS_API_SUCCESS = "update_shipping_address_api_success";
export const RESET_UPDATE_SHIPPING_ADDRESS_RESPONSE = 'reset_shipping_Address_response';
export const UPDATE_SHIPPING_ADDRESS_API_FAIL_ERR = "update_shipping_address_api_fail_err";
export const RESET_UPDATE_SHIPPING_ADDRESS_API_FAIL_ERR = "reset_update_shipping_address_api_fail_err";
export const UPDATE_SHIPPING_ADDRESS_API_HTTP_ERR = "update_shipping_Address_api_http_err";
export const RESET_UPDATE_SHIPPING_ADDRESS_API_HTTP_ERR = "reset_update_shipping_addtess_api_http_err";

export const OK = "1";
export const FAIL = "0";
export const SERVER_ISSUE = "server_issue";
export const RESPONSE_ISSUE = "response_issue";
export const REQUEST_ISSUE = "request_issue";
export const EXCEPTION_ISSUE = "exception_issue";
export const ASYNC_FAIL = "async_fail";
export const GENERIC_FAIL = "generic_fail";
export const PDF_LOAD_FAIL = "pdf_load_fail";

export const PRODUCT_MISMATCH = "Product mismatch";
export const RESPONSE_SESSION_EXP = "Session expired";
export const INVALID_TOKEN = "Invalid Token";
export const ERROR_401 = 401;
export const ERROR_UNKNOWN = 91919;
export const MOBILE_FLAG = "M";
export const SERVER_FLAG = "W";
export const REQUEST_ERROR = "Unable to request server. Check your network.";
export const SESSION_EXPIRED_MSG = "Session Expired! Please login Again.";
export const INTERNAL_SERVER_MSG = "Internal Server Error! Please try later.";
export const OOPS_WRONG = "Something went wrong! Please try later.";
export const PDF_ERROR = "Unable to load invoice or invoice not present.";
export const UNEXPECTED_ERROR = "Error Occurred! Please try later.";
export const SUCCESS_ORDER_PREFIX = "Your order is successfully placed! Please note following order number for further reference:" + "\n";

// OrderLine Redux Store
export const ORDER_LINE_API_REQ = "oder_line_api_req";
export const ORDER_LINE_API_SUCCESS = "order_line_api_success";
export const RESET_ORDER_LINE_API_RESPONSE = "reset_order_line_api_response";
export const ORDER_LINE_API_FAIL_ERR = "order_line_api_fail_err";
export const RESET_ORDER_LINE_API_FAIL_ERR = "reset_order_line_api_fail_err";
export const ORDER_LINE_API_HTTP_ERR = "order_line_api_http_err";
export const RESET_ORDER_LINE_API_HTTP_ERR = "reset_order_line_api_http_err";

export const ADD_ITEM_TO_CART = "add_item_to_cart";

// AddOrderHeader API
export const GET_ORDER_HEADER_API_REQ = "get_order_header_api_req";
export const GET_ORDER_HEADER_API_SUCCESS = "get_order_header_api_success";
export const RESET_ORDER_HEADER_API_RESPONSE = "reset_order_header_api_response";
export const ORDER_HEADER_API_FAIL_ERR = "order_header_api_fail_err";
export const RESET_ORDER_HEADER_API_FAIL_ERR = "reset_order_header_api_fail_err";
export const ORDER_HEADER_API_HTTP_ERR = "order_header_api_http_err";
export const RESET_ORDER_HEADER_API_HTTP_ERR = "reset_order_header_api_http_err";

// Delete Order line item
export const DELETE_ORDER_LINE_API_REQ = "delete_order_line_api_req";
export const DELETE_ORDER_LINE_API_SUCCESS = "delete_order_line_api_success";
export const RESET_DELETE_ORDER_LINE_API_RESPONSE = "reset_delete_order_line_api_response";
export const DELETE_ORDER_LINE_API_FAIL_ERR = "delete_order_line_api_fail_err";
export const RESET_DELETE_ORDER_API_FAIL_ERR = "reset_delete_order_line_api_fail_err";
export const DELETE_ORDER_LINE_API_HTTP_ERR = "delete_order_line_api_http_err";
export const RESET_DELETE_ORDER_LINE_API_HTTP_ERR = "reset_delete_order_line_api_http_err";
export const REMOVE_ORDER_LINE_ITEM_FROM_LIST = 'remove_order_line_api_from_list';

export const SET_ORDER_LINE_ITEM_LIST = 'set_order_line_item_list';
export const SET_CART_TOTAL = 'set_cart_total';
export const SET_CART_SUB_TOTAL = 'set_cart_sub_total';
export const SET_CART_TAX_PERCENT = 'set_cart_tax_percent';
export const SET_CART_TAX_VALUE = 'set_cart_tax_value';
export const SET_ORDER_ID = 'set_order_id';
export const SET_ORDER_NO = 'set_order_no';
export const SET_SEQUENCE = 'set_sequence';

export const SET_COUPON_CODE = 'set_coupon_code';
export const SET_REWARD_AMT = 'set_reward_amt';
export const SET_REWARD_ID = 'set_reward_id';
export const RESET_REWARD_ID = 'reset_reward_id';
export const SET_TOTAL_DUE_AFTER_REWARD = 'set_total_due_after_reward';
export const SET_AMOUNT_RECEIVED = 'set_amount_received';
export const SET_PAYMENT_MODE = 'set_payment_mode';
export const SET_BALANCE_DUE = 'set_balance_due';
export const SET_CHECK_AMOUNT = 'set_check_amount';
export const SET_CHECK_NO = 'set_check_number';
export const SET_CASH_RECEIVED = 'set_cash_received';
export const RESET_ALL_PAYMENT_SCREEN_DATA = 'reset_all_payment_Screen_data';
export const SET_PO_NO = 'set_po_no';

export const SET_SIGNATORY_NAME = 'set_signatory_name';
export const SET_SIGNATORY_IMAGE_DATA = 'set_signatory_image_data';

export const RESET_ORDER_LINE_STORE = 'reset_order_line_store';

export const LINE_ITEM_EDIT_API_REQ = 'line_item_edit_api_req';
export const LINE_ITEM_EDIT_API_RESPONSE = 'line_item_edit_api_response';
export const RESET_LINE_ITEM_EDIT_API_RESPONSE = 'reset_line_item_edit_api_response';
export const LINE_ITEM_EDIT_API_FAIL_ERR = 'line_item_edit_api_fail_err';
export const RESET_LINE_ITEM_EDIT_API_FAIL_ERR = 'reset_line_item_edit_api_fail_err';
export const LINE_ITEM_EDIT_API_HTTP_ERR = 'line_item_edit_api_http_err';
export const RESET_LINE_ITEM_EDIT_HTTP_ERR = 'reset_line_item_edit_http_err';

export const GET_ORDER_LINE_DATA_API_REQ = 'get_order_line_data_api_req';
export const GET_ORDER_LINE_DATA_API_RESPONSE = 'get_oder_line_data_api_response';
export const RESET_GET_ORDER_LINE_DATA_API_RESPONSE  = 'reset_get_oder_line_data_api_response';
export const GET_ORDER_LINE_API_FAIL_ERR = 'get_order_line_api_fail_err';
export const RESET_GET_ORDER_LINE_API_FAIL_ERR = 'reset_get_order_line_api_fail_err';
export const GET_ORDER_LINE_API_HTTP_ERR = 'get_order_line_api_http_err';
export const RESET_GET_ORDER_LINE_API_HTTP_ERR = 'reset_get_order_line_item_api_http_err';

// Reward store
export const GET_REWARD_AMOUNT_API_REQ = 'get_reward_amount_api_call';
export const GET_REWARD_AMOUNT_API_SUCCESS = 'get_reward_amount_api_success';
export const GET_REWARD_AMOUNT_API_FAIL_ERR = 'get_reward_amount_api_fail_err';
export const RESET_GET_REWARD_AMOUNT_API_FAIL_ERR = 'reset_get_reward_amount_api_fail_err';
export const GET_REWARD_AMOUNT_API_HTTP_ERR = 'get_reward_amount_api_http_err';
export const RESET_GET_REWARD_AMOUNT_API_HTTP_ERR = 'reset_get_reward_amount_api_http_err';
export const RESET_REWARD_REDUX_STATE = 'reset_reward_redux_state';