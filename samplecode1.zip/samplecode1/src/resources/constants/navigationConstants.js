export const NAVIGATION_TO_PRODUCT_SCREEN = 'Products';
export const NAVIGATION_TO_SPIFF_LANDING_SCREEN = 'Spiff landing';
export const NAVIGATION_TO_SPIFF_PAYOUT_SCREEN = 'Spiff payout';

export const NAVIGATION_TO_MESSAGE_SCREEN = 'Messages';
export const NAVIGATION_TO_SHOPPING_CART_SCREEN = 'Shopping Cart';
export const NAVIGATION_TO_SEARCH_SCREEN = 'Search Products';
export const NAVIGATION_TO_PRODUCT_DETAIL_SCREEN = 'Product detail screen';
export const NAVIGATION_TO_PLACE_ORDER_SCREEN = 'Place order screen';
export const NAVIGATION_TO_ORDER_HISTORY_SCREEN = 'order history screen';

export const ROUTE_STACK_ROOT = 'RootStack';
export const ROUTE_AUTH = 'Auth';
export const ROUTE_AUTH_SUCCESS = 'AfterAuthSuccess';
export const ROUTE_HOME = 'Home';
export const ROUTE_SALES_GROWTH_MENU = 'SalesGrowthMenuStack';
export const ROUTE_COMING_SOON = 'comingSoon';
export const ROUTE_SALES_GROWTH = 'salesAndGrowth';
export const ROUTE_CUSTOMER_DETAIL = 'customerDetailScreen';
export const ROUTE_CUSTOMER_DETAIL_FROM_HOME = 'customerDetailScreenFromHome';
export const ROUTE_SETTINGS = 'settingsscreen';
export const ROUTE_SPLASH = 'Splash';
export const ROUTE_STACK_AUTH = 'AuthStack';
export const ROUTE_STACK_PRODUCT = 'ProductStack';
export const ROUTE_STACK_SPIFF = 'SpiffStack';
export const ROUTE_STACK_PRODUCT_DETAIL = 'ProductDetailStack';
export const ROUTE_DRAWER = 'drawerStack';
export const ROUTE_BOTTOM_NAV = 'bottomNavStack';

export const ROUTE_COUSTOMER_INFO = 'CustomerInfo';
export const ROUTE_CUSTOMER_DETAILS_TAB = 'CustomerDetailsTab';
export const ROUTE_BILLING_TAB = 'BillingTab';

export const ROUTE_LOGIN = 'Login';
export const ROUTE_FORGET_PASSWORD = 'ForgetPassword';
export const ROUTE_LEARN_MORE = 'LearnMore';
export const ROUTE_INTERMEDIATE_LOGIN_PAGE = 'intermediateLoginPage';

// Invoice Module
export const ROUTE_INVOICE_SCREEN = 'InvoiceScreen';
export const ROUTE_ITEM_PROCESSING = 'RouteItemProcessing';
// export const ROUTE_PAYMENT = 'RoutePayment';

export const ROUTE_PAYMENT_SCREEN = 'paymentScreen';
export const ROUTE_PAYMENT_SIGNATURE_SCREEN = 'paymentSignatureScreen';
export const ROUTE_PAYMENT_EMAIL_SCREEN = 'paymentEmailScreen';
export const ROUTE_PAYMENT_SURVEY_SCREEN = 'paymentSurveyScreen';
export const ROUTE_TICKET_PROCESSING_MOBILE_VIEW = 'ticketProcessingMobileView';
