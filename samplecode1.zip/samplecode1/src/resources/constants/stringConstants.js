import {validateRequiredField} from "../../utils/validators";

export const FORGET_PASSWORD = 'Forget Password';
export const RESET_PASSWORD = 'Reset Password';
export const SELECT_COMAPANY ='Select Company and Department:'
export const RESET_PASSWORD_LINK = 'Send Reset Password Link';
export const PROCEED_TO_HOME = 'PROCEED TO HOME PAGE';

export const BACK_TO_LOGIN= 'Back to login';
export const LOGIN= 'Login';
export const LEARN_MORE= 'Learn more';

export const ORDER='Order';
export const PAYOUT_REQ='Payout Request';
export const ITEMS='Items';
export const TOTAL='Total';
export const PAYOUT_AMOUNT = 'Payout Amount'
export const ORDER_TOTAL='Order total';
export const PAY_VIA='Pay Via';
export const BACK = 'BACK';

export const SEND_BTN_TITLE ='Send';
export const SYNC_REPLY ='Sync Messages';
export const MESSAGES ='Messages';
export const NO_MESSAGE='No active message thread, Message for any support.';
export const AT = 'at';
export const MOBILE_SEND ='Send by You at';
export const SERVER_SEND ='Send by';
export const DASH = '-';
export const COLON = ':';
export const DOT ='.';
export const SINGLE_SPACE = ' ';
export const FORWARD_SLASH = '/';



export const OKAY= 'OKAY';
export const YES= 'YES';
export const NO= 'NO';
export const CANCEL ='CANCEL';
export const SAVE ='SAVE';
export const NO_MATCHING_PRODUCTS='No matching products found.';
export const NO_COMPANY_LIST='No company list.';
export const CART_EMPTY='Cart is empty.';
export const SPIFF_EMPTY='No Spiff Transactions.';
export const ORDER_HISTORY_EMPTY='No orders histoy found.';
export const REFRESH_CART_ALERT ='Refreshing product will clear your cart. Do you want to proceed?'

export const PROCEED_TEXT='PROCEED TO PLACE ORDER';
export const PAYOUT_TEXT='REQUEST PAYOUT';
export const REFRESH_TEXT='REFRESH';
export const TOTAL_AMOUNT='TOTAL AMOUNT';
export const BALANCE_AMOUNT='BALANCE';
export const DOLLAR_SYMBOL='$';
export const TAX_STRING='*Taxes may apply.';
export const BALANCE_STRING='Should be less than your balance amount.';
export const MISMATCH_WARNING_MSG = 'Following products are no longer available or have been updated hence removed from you cart. Please review your cart and add updated products or you can place order without them. '
export const PRODUCT_MISMATCH = 'PRODUCT_MISMATCH';
export const TYPE_PRODUCT_HERE='Type product name here...';
export const SEARCH_PLACEHOLDER = ' Type to search...'
export const NAV_PRODUCT_TITLE='Products';
export const SPIFF_PRODUCT_TITLE='Spiff Home';
export const NAV_SEARCH_TITLE='Search Products';
export const NAV_CART_TITLE='Cart';
export const NAV_MESSAGE_TITLE='Messages';

export const EMAIL_PLACEHOLDER = 'Enter Registered Email';
export const PAYOUT_AMOUNT_PLACEHOLDER = ' Enter amount.';
export const PASSWORD_PLACEHOLDER = 'Enter Password';
export const INVALID_CREDENTIALS = 'Invalid Credentials!';
export const INVALID_REG_EMAIL = 'This email address is invalid!'
export const RESET_EMAIL_SUCCESS_MSG = 'Password reset link successfully send on your email address.';
export const QUNATITY ='Quantity :';
export const DATA_VALID = "Data is valid";

export const NOTES ='Notes :';
export const NOTES_PLACEHOLDER='Add notes if any.';
export const PAYMENT_ID_PLACEHOLDER='Add payment mode Id or else email address.';

export const ADDRESS_PLACEHOLDER='Delivery address required.';
export const DELIVERY_ADDRESS ='Delivery Address';
export const ADDRESS ='Address';
export const ORDER_NOTES ='Order Notes';
export const PAYMENT_ID ='Payment Id';

export const PLACE_ORDER ='PLACE ORDER';
export const SUBMIT_PAYOUT_REQ ='SUMBIT PAYOUT REQUEST';
export const REVIEW_CART ='REVIEW CART';
export const ADD ='ADD';
export const UPDATE ='UPDATE';
export const DELETE ='DELETE';
export const PRICE = 'Price : $'
export const PRODUCT_UPDATE_SUCCESS='Products updated successfully.'
export const SPIFF_DROPDOWN_PLACEHOLDER ="Select payment mode";





// error strings
export const EMPTY_ERROR= 'This field cannot be empty.';
export const EMAIL_ERROR= 'Invalid email address.';
export const PHONE_ERROR='Invalid phone number';
export const AMOUNT_ERROR ='Invalid numerical value';


// json keys constants

export const PRODUCT_FOUND = 'productFound';
export const CART_PRODUCT_OBJ = 'cartProductObj';
export const QUANTITY_JSON = 'OrderQty';
export const NOTES_JSON = 'Notes';
export const ITEMNO_JSON = 'ItemNo';
export const PRICE_JSON = 'Price';
export const DESCRIPTION_JSON = 'Description';
export const ITEMID_JSON = 'ItemId';
export const ORDER_LINE_JSON = 'OrderLine';
export const TOTAL_SALES_JSON ='TotalSales';
export const ORDER_ADDRESS_JSON = 'OrderAddress';
export const ORDER_NOTES_JSON ='OrderNote';
export const ORDER_DATE_JSON = 'OrderDate';
export const ORDER_CNF_JSON = 'Confirmed';
export const SPIFF_PAYOUT_ID_JSON= 'emailAddress';
export const SPIFF_PAYOUT_AMOUNT_JSON= 'amount';
export const SPIFF_PAYOUT_NOTES_JSON= 'notes';
export const SPIFF_PAYOUT_TYPE_JSON= 'payoutMethod';

export const LOGOUT_SIDEMENU ='LOGOUT';
export const REFRESH_PRODUCTS_SIDEMENU ='REFRESH PRODUCTS';
export const ORDER_HISTORY_SIDEMENU ='ORDER HISTORY';

export const SPIFF_SUCCESS_STRING ='Spiff payout request has been submitted successfully!';



export const CART_BADGE_VALUE='cartBadgeValue';
export const CART_TOTAL_AMOUNT='cartTotalAmount';


export const LOGOUT_FROM_HOME = 'home_logout';
export const LOGOUT_FROM_SPIFF = 'logout_spiff';
export const LOGOUT_FROM_COMM = 'logout_comm';

export const freqMonth=[{label: 'N/A', value: '0'}, {label: '1', value: '1'}, {label: '2', value: '2'}, {label: '3', value: '3'}, {label: '4', value: '4'}, {label: '5', value: '5'},
    {label: '6', value: '6'},{label: '7', value: '7'},{label: '8', value: '8'},{label: '9', value: '9'},{label: '10', value: '10'},{label: '11', value: '11'},{label: '12', value: '12'}];
export const freqDay=[...freqMonth, {label: '13', value: '13'}, {label: '14', value: '14'},{label: '15', value: '15'},{label: '16', value: '16'},{label: '17', value: '17'},
    {label: '18', value: '18'},{label: '19', value: '19'},{label: '20', value: '20'}, {label: '21', value: '21'},{label: '22', value: '22'},{label: '23', value: '23'},
    {label: '24', value: '24'},{label: '25', value: '25'},{label: '26', value: '26'},{label: '27', value: '27'},{label: '28', value: '28'}, {label: '29', value: '29'},{label: '30', value: '30'},{label: '31', value: '31'}    ];
export const freqWeek=[...freqDay, {label: '32', value: '32'}, {label: '33', value: '33'}, {label: '34', value: '34'}, {label: '35', value: '35'}, {label: '36', value: '36'}, {label: '37', value: '37'},
    {label: '38', value: '38'},{label: '39', value: '39'},{label: '40', value: '40'},{label: '41', value: '41'},{label: '42', value: '42'},{label: '43', value: '43'},{label: '44', value: '44'},
    {label: '45', value: '45'},{label: '46', value: '46'},{label: '47', value: '47'},{label: '48', value: '48'},{label: '49', value: '49'},{label: '50', value: '50'},{label: '51', value: '51'},{label: '52', value: '52'}];


export const FORM_NAME ='NAME';
export const FORM_ADDRESS ='ADDRESS';
export const FORM_CITY ='CITY';
export const FORM_STATE ='STATE';
export const FORM_ZIP ='ZIP';
export const FORM_PHONE ='PHONE';
export const FORM_EMAIL ='EMAIL';
export const FORM_DECISION_MAKER ='DECISION_MAKER';
export const FORM_ESTIMATE_SALES ='ESTIMATE_SALES';


export const emptyUUID = '00000000-0000-0000-0000-000000000000';


