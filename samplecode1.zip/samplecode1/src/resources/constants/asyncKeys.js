export const AUTO_LOGGED_OUT ='auto_logged_out';
export const SIDE_MENU_RAW_JSON ='side_menu_raw_json';

