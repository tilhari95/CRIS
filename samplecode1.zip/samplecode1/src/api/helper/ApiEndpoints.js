export const loginAPIEndpoint = '/login/DeviceLogin';
export const forgetPasswordAPIEndpoint = '/Login/ForgotPassword';

//for live server -->>
// for development server IONOS-->>
// for staging server MCNI360 advance -->> http://198.71.61.66:8089
export const baseUrl = 'http://198.71.61.66:8089';
export const basePath = '/api';






export const userBrandAPIEndpoint = '/Login/GetCompanyData';
export const userSideMenuAPIEndpoint = '/Login/GetMenuItems';

export const productListAPIEndpoint = '/Item/GetClientAppItems';
export const resetPasswordAPIEndpoint = '/Login/ForgotPassword';
export const logoutAPIEndpoint = '/login/Logout';
export const getCustomerAPIEndpoint = '/Customer/GetCustomers';
export const getCustomerGeolocation = '/Customer/GetCustomerByGeoLocation';
export const getRoutesListApiEndpoint ='/Route/GetRouteList';
export const getProspectAPIEndpoint = '/Prospect/GetProspectList';
export const addEditRouteAPIEndpoint='/Route/AddEditRoute';
export const addEditProspectAPIEndpoint= '/Prospect/AddEditProspect';
export const prospectStageApi ='/Prospect/GetProcessSteps';
export const prospectDecisionMakerApiEndpoint ='/Prospect/GetDecisionMakers';
export const prospectStageHeaderListApiEndpoint = '/Prospect/GetProspectListHeader';

export const routeStopListApiEndpoint ='/Route/GetRouteStopsData';
export const addRouteStopApiEndpoint = "/Route/AddEditRouteStop";
export const routeStopDeleteApi ='/Route/DeleteRouteStops';

export const checkOrderDetilAPIEndpoint = '/Item/CheckOrderDetails';
export const placeOrderAPIEndpoint = '/Item/AddAppOrder';
export const getMessageAPIEndpoint = '/Messages/GetMessagesData';
export const sendMessageAPIEndpoint = '/Messages/AddMessages';
export const userTemplateAPIEndpoint = '/Login/GetTemplateData';
export const userCompanyAPIEndpoint = '/Login/GetCompanyData';

export const spiffPayoutTypesAPIEndpoint = '/Spiff/GetPayoutTypes';
export const spiffPayoutReqAPIEndpoint = '/Spiff/RequestPayout';
export const spiffTranactionAPIEndpoint = '/Spiff/GetSpiffTransactions';
export const spiffBalanceAPIEndpoint = '/Spiff/GetSpiffBalance';

export const orderHistoryListAPIEndpoint ='/Item/GetOrderList';
export const pdfDownloadEndpoint = '/download/download';

export const getCustomerDetailDataEndPoint = '/Customer/GetCustomerDetailData';
export const getItemsEndPoint = '/Item/GetItems';
export const getCustomerItemHistoryEndPoint = '/Item/GetCustomerItemHistory';
export const getCustomerInfoEndPoint = '/Customer/GetCustomerInfo'

export const getHotKeyGroupListEndPoint = '/HotKey/GetHotKeyGroupList';
export const getHotKeyItemsEndPoint = '/HotKey/GetHotKeyItems';

export const getTemplateListEndPoint = '/Template/GetTemplateList';
export const getTemplateItemListEndPoint = '/Template/GetTemplateItemsList';

export const getItemDetailEndPoint = '/Item/GetItemDetails';
export const shipToListEndPoint = '/Customer/GetShipToList';
export const addOrderLineEndPoint = '/Order/AddOrderLine';
export const addOrderHeaderEndPoint = '/Order/AddOrderHeader';
export const deleteOrderLineEndPoint = '/Order/DeleteOrderLine';
export const updateShippingAddressEndPoint = '/Customer/UpdateShippingAddress';
export const getRewardAmountEndPoint = '/Order/GetRewardAmount';
export const getOrderLineDataEndPoint = '/Order/GetOrderLineData';

export const companyListImageURL = 'https://mcni-logos.s3.us-east-2.amazonaws.com/';
export const genericImageURL = 'https://mcni-itemimages.s3.us-east-2.amazonaws.com/'; // for dev staging --> http://166.62.46.170:8089/ItemImages/
