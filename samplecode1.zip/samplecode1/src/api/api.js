import Request from './Request';
import {
  basePath,
  baseUrl,
  checkOrderDetilAPIEndpoint,
  getMessageAPIEndpoint,
  loginAPIEndpoint,
  logoutAPIEndpoint,
  orderHistoryListAPIEndpoint,
  pdfDownloadEndpoint,
  placeOrderAPIEndpoint,
  productListAPIEndpoint,
  resetPasswordAPIEndpoint,
  sendMessageAPIEndpoint,
  spiffBalanceAPIEndpoint,
  spiffPayoutReqAPIEndpoint,
  spiffPayoutTypesAPIEndpoint,
  spiffTranactionAPIEndpoint,
  userBrandAPIEndpoint,
  userCompanyAPIEndpoint,
  getCustomerAPIEndpoint,
  userTemplateAPIEndpoint,
  getCustomerGeolocation,
  getRoutesListApiEndpoint,
  getProspectAPIEndpoint,
  addEditRouteAPIEndpoint,
  prospectStageApi,
  addEditProspectAPIEndpoint,
  routeStopListApiEndpoint,
  addRouteStopApiEndpoint,
  routeStopDeleteApi,
  prospectDecisionMakerApi,
  prospectDecisionMakerApiEndpoint,
  prospectStageHeaderListApiEndpoint,
  getCustomerDetailDataEndPoint,
  getItemsEndPoint,
  getCustomerItemHistoryEndPoint,
  getHotKeyGroupListEndPoint,
  getHotKeyItemsEndPoint,
  getTemplateListEndPoint,
  getTemplateItemListEndPoint,
  getItemDetailEndPoint,
  shipToListEndPoint,
  userSideMenuAPIEndpoint,
  addOrderLineEndPoint,
  getCustomerInfoEndPoint,
  addOrderHeaderEndPoint,
  deleteOrderLineEndPoint,
  updateShippingAddressEndPoint,
  getRewardAmountEndPoint,
  getOrderLineDataEndPoint
} from './helper/ApiEndpoints';
import {validateRequiredField} from '../utils/validators';

// import fcmToken from '../services/PushNotifications/fcmToken';
// import AppAsyncStorage from './helper/AppAsyncStorage';
// import {FCM_TOKEN} from '../resources/constants/asyncKeys';
// import {Platform} from 'react-native';
// import store from '../store';
// import {validateRequiredField} from '../utils/validators';
// import RNFetchBlob from 'rn-fetch-blob';

// const getCompanyAndTemplateId = () => {
//   let brandSuccessResponse = store.getState().login.brandSuccessResponse;
//   let userBrandDataFromAsync = store.getState().productPage.userBrandDataFromAsync;
//
//   if(validateRequiredField(brandSuccessResponse)){
//     return ({companyId: brandSuccessResponse.responseData.CompanyId, templateId: brandSuccessResponse.responseData.AppTemplateHeaderId})
//   }
//   else if(validateRequiredField(userBrandDataFromAsync)){
//     return ({companyId: userBrandDataFromAsync.CompanyId, templateId: userBrandDataFromAsync.AppTemplateHeaderId})
//   }
//   else
//     return null
// }

/**
 * Class that exposes REST API endpoints
 */
class Api {
  constructor() {
    this.request = new Request();
  }

  loginApi(email, password) {
    const params = undefined;
    const data = {
      EmailAddress: email,
      Password: password,
    };
    return this.request.post(loginAPIEndpoint, params, data);
  }

  forgetPasswordApi(email) {
    const data = {
      EmailAddress: email,
    };
    return this.request.post(resetPasswordAPIEndpoint, undefined, data, false);
  }

  CustomerListApi(companyId, deviceId, cursorIndex, searchText) {
    if (!validateRequiredField(searchText)) {
      searchText = '';
    }
    let cursorI = cursorIndex + '';
    const data = {
      CompanyId: companyId,
      DeviceId: deviceId,
      CursorIndex: cursorI,
      SearchText: searchText,
    };
    return this.request.post(getCustomerAPIEndpoint, undefined, data, true);
  }

  ProspectListApi(ERPRepCode, cursorIndex, searchText) {
    if (!validateRequiredField(searchText)) {
      searchText = '';
    }
    let cursorI = cursorIndex + '';
    // console.log("cursorIndex",cursorI );
    // console.log("searchText", searchText );
    const data = {
      RepId: ERPRepCode,
      CursorIndex: cursorI,
      SearchText: searchText,
    };
    return this.request.post(getProspectAPIEndpoint, undefined, data, true);
  }

  customerGeolocationApi(lat, long, companyId, deviceId) {
    let latitude = lat + '';
    let longitude = long + '';
    let data = {
      CompanyId: companyId,
      DeviceId: deviceId,
      Longitude: longitude,
      Latitude: latitude,
    };
    return this.request.post(getCustomerGeolocation, undefined, data, true);
  }

  RouteListApi(companyId) {
    const data = {CompanyId: companyId};
    return this.request.post(getRoutesListApiEndpoint, undefined, data, true);
  }
  RouteStopListApi(Id) {
    const data = {Id: Id};
    return this.request.post(routeStopListApiEndpoint, undefined, data, true);
  }

  AddEditRouteApi(
    id,
    companyId,
    routeName,
    description,
    every,
    frequency,
    sequence,
  ) {
    const body = {
      Id: id,
      CompanyId: companyId,
      RouteName: routeName,
      Description: description,
      Every: every,
      Frequency: frequency,
      Sequence: sequence,
    };
    console.log('body is --> ', body);
    return this.request.post(addEditRouteAPIEndpoint, undefined, body, true);
  }

  AddEditProspectApi(payload) {
    const body = {
      Id: payload.Id,
      CompanyName: payload.CompanyName,
      Address: payload.Address,
      City: payload.City,
      State: payload.State,
      Zip: payload.Zip,
      Phone: payload.Phone,
      EmailAddress: payload.EmailAddress,
      DecisionMaker: payload.DecisionMaker,
      DecisionMakerName: payload.DecisionMakerName,
      EstimatedAnnualSales: payload.EstimatedAnnualSales,
      RepId: payload.RepId,
      CompanyId: payload.CompanyId,
      CurrentStage: payload.CurrentStage,
      ApproachProcessList: payload.ApproachProcessList,
    };

    console.log('body is --> ', body);
    return this.request.post(addEditProspectAPIEndpoint, undefined, body, true);
  }

  prospectStageApi(companyId) {
    const body = {CompanyId: companyId};
    return this.request.post(prospectStageApi, undefined, body, true);
  }

  prospectDecisionMakerApi(prospectId) {
    const body = {Id: prospectId};
    return this.request.post(
      prospectDecisionMakerApiEndpoint,
      undefined,
      body,
      true,
    );
  }

  prospectStageHeaderListApi(companyId) {
    const body = {CompanyId: companyId};
    return this.request.post(
      prospectStageHeaderListApiEndpoint,
      undefined,
      body,
      true,
    );
  }

  addRouteStopApi(Id, RouteId, CompanyId, Sequence, Location, CustomerId) {
    const body = {
      Id: Id,
      RouteId: RouteId,
      CompanyId: CompanyId,
      Sequence: Sequence,
      Location: Location,
      CustomerId: CustomerId,
    };
    return this.request.post(addRouteStopApiEndpoint, undefined, body, true);
  }

  deleteRouteStopApi(Id) {
    const body = {
      Id: Id,
    };
    return this.request.post(routeStopDeleteApi, undefined, body, true);
  }

  async userBrandApi() {
    return this.request.post(userBrandAPIEndpoint, undefined, undefined, true);
  }
  async userSideMenuApi(email) {
    let data = {Email: email};
    return this.request.post(userSideMenuAPIEndpoint, undefined, data, true);
  }

  getCustomerDetailData(companyId, repId, customerId) {
    const data = {
      CompanyId: companyId,
      RepId: repId,
      customerId: customerId,
    };
    return this.request.post(
      getCustomerDetailDataEndPoint,
      undefined,
      data,
      true,
    );
  }

  getCustomerInfoApi(customerId) {
    const data = {
      CustomerId: customerId,
    };

    return this.request.post(getCustomerInfoEndPoint, undefined, data, true);
  }

  getItemsApi(companyId, customerId, cursorIndex, searchText) {
    if (!validateRequiredField(searchText)) {
      searchText = '';
    }
    let cursorIdx = cursorIndex + '';

    const body = {
      CompanyId: companyId,
      CustomerId: customerId,
      CursorIndex: cursorIdx,
      SearchText: searchText,
    };
    return this.request.post(getItemsEndPoint, undefined, body, true);
  }

  getCustomerItemHistoryApi(companyId, customerId, cursorIndex) {
    let cursorIdx = cursorIndex + '';

    const body = {
      CompanyId: companyId,
      CustomerId: customerId,
      CursorIndex: cursorIdx,
    };
    return this.request.post(
      getCustomerItemHistoryEndPoint,
      undefined,
      body,
      true,
    );
  }

  getHotKeyGroupListApi(companyId) {
    const body = {
      CompanyId: companyId,
    };

    return this.request.post(getHotKeyGroupListEndPoint, undefined, body, true);
  }

  getHotKeyItemsApi(hotKeyHeaderId, companyId, customerId) {
    const body = {
      HotKeyHeaderId: hotKeyHeaderId,
      CompanyId: companyId,
      CustomerId: customerId,
    };

    return this.request.post(getHotKeyItemsEndPoint, undefined, body, true);
  }

  getTemplateListApi(companyId) {
    const body = {
      CompanyId: companyId,
    };

    return this.request.post(getTemplateListEndPoint, undefined, body, true);
  }

  getTemplateItemsListApi(templateId, companyId, customerId) {
    const body = {
      TemplateId: templateId,
      CompanyId: companyId,
      CustomerId: customerId,
    };

    return this.request.post(
      getTemplateItemListEndPoint,
      undefined,
      body,
      true,
    );
  }

  getItemDetailApi(itemId, customerId) {
    const body = {
      ItemId: itemId,
      CustomerId: customerId,
    };

    return this.request.post(getItemDetailEndPoint, undefined, body, true);
  }

  getShipToListApi(companyId, customerId) {
    const body = {
      CompanyId: companyId,
      CustomerId: customerId,
    };

    return this.request.post(shipToListEndPoint, undefined, body, true);
  }

  addOrderLineApi(
    orderLineId,
    orderNo,
    sequence,
    itemId,
    itemNo,
    description1,
    description2,
    price,
    orderQty,
    taxes,
    notes,
    sync,
    companyId,
    scanCode,
    uom,
    deviceId,
    customerNo,
    customerId,
    repId
  ) {
    const body = {
      OrderLineId: orderLineId,
      OrderNo: orderNo,
      Sequence: sequence,
      ItemId: itemId,
      ItemNo: itemNo,
      Description1: description1,
      Description2: description2,
      Price: price,
      OrderQty: orderQty,
      Taxes: taxes,
      Notes: notes,
      Sync: sync,
      CompanyId: companyId,
      ScanCode: scanCode,
      UOM: uom,
      DeviceId: deviceId,
      CustomerNo: customerNo,
      CustomerId: customerId,
      RepId: repId
    };

    return this.request.post(addOrderLineEndPoint, undefined, body, true);
  }

  addOrderHeaderApi(
    orderId,
    orderNo,
    companyId,
    orderStatus,
    customerNo,
    comment1,
    comment2,
    ponNumber,
    subTotal,
    taxes,
    discount,
    paidCash,
    paidCheck,
    paidCCard,
    shipToId,
    shipToName,
    checkNumber,
    customerType,
    emailAddress,
    orderType,
    createdDate,
    requestedShipDate,
    shipToAddress1,
    shipToCity,
    shipToState,
    shipToZip,
    isPRO,
    billToName,
    billToAddress,
    billToCity,
    billToState,
    billToZip,
    deviceId,
    customerId,
    taxScheduleId,
    customerName,
    customerFKey,
    taxSchedule,
    termsCode,
    rewardId,
  ) {
    let body = {
      OrderId: orderId,
      OrderNo: orderNo,
      CompanyId: companyId,
      OrderStatus: orderStatus,
      CustomerNo: customerNo,
      Comment1: comment1,
      Comment2: comment2,
      PONumber: ponNumber,
      SubTotal: subTotal,
      Taxes: taxes,
      Discount: discount,
      PaidCash: paidCash,
      PaidCheck: paidCheck,
      PaidCCard: paidCCard,
      ShipToId: shipToId,
      ShipToName: shipToName,
      CheckNumber: checkNumber,
      CustomerType: customerType,
      Emailaddress: emailAddress,
      OrderType: orderType,
      CreatedDate: createdDate,
      RequestedShipDate: requestedShipDate,
      ShipToAddress1: shipToAddress1,
      ShipToCity: shipToCity,
      ShipToState: shipToState,
      ShipToZip: shipToZip,
      IsPRO: isPRO,
      BillToName: billToName,
      BillToAddress: billToAddress,
      BillToCity: billToCity,
      BillToState: billToState,
      BillToZip: billToZip,
      DeviceId: deviceId,
      CustomerId: customerId,
      TaxScheduleId: taxScheduleId,
      CustomerName: customerName,
      CustomerFKey: customerFKey,
      TaxSchedule: taxSchedule,
      TermsCode: termsCode,
      RewardId: rewardId,
    };

    return this.request.post(addOrderHeaderEndPoint, undefined, body, true);
  }

  deleteOrderLineApi(orderLineId) {
    let body = {
      OrderLineId: orderLineId,
    };

    return this.request.post(deleteOrderLineEndPoint, undefined, body, true);
  }

  updateShippingAddressApi(shipToId, customerId) {
    let body = {
      ShipToId: shipToId,
      CustomerId: customerId,
    };

    return this.request.post(
      updateShippingAddressEndPoint,
      undefined,
      body,
      true,
    );
  }

  getRewardAmountApi(customerId, companyId, rewardCode) {
    let body = {
      CustomerId: customerId,
      CompanyId: companyId,
      RewardCode: rewardCode,
    };
    return this.request.post(getRewardAmountEndPoint, undefined, body, true);
  }

  getOrderLineDataApi(companyId, customerId, salesRepId) {
    let body = {
      CompanyId: companyId,
      CustomerId: customerId,
      SalesRepId: salesRepId
    };

    return this.request.post(getOrderLineDataEndPoint, undefined, body, true);
  }
}

let api = new Api();

export default api;
