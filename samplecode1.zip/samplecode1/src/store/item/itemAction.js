import {
  GET_ITEMS_API_REQUEST,
  GET_ITEMS_API_SUCCESS,
  RESET_ITEM_LIST,
  GET_ITEMS_API_FAIL_ERROR,
  RESET_GET_ITEM_API_ERROR,
  GET_ITEM_HTTP_ERROR,
  RESET_GET_ITEM_HTTP_ERROR,
  RESET_ITEM_REDUX_STATE,
  GET_ITEM_ON_SCROLL_SUCCESS,
  RESET_GET_ITEM_ON_SCROLL,
  GET_ITEM_ON_SCROLL_REQUEST,
  ITEM_SEARCH_API_REQUEST,
  ITEM_SEARCH_API_SUCCESS,
  RESET_ITEM_SEARCH_LIST,
  ITEM_DETAIL_API_REQUEST,
  ITEM_DETAIL_API_SUCCESS,
  RESET_API_DETAIL_API_RESPONSE,
  ITEM_DETAIL_API_ERROR,
  RESET_ITEM_DETAIL_API_ERROR,
  ITEM_DETAIL_API_HTTP_ERROR,
  RESET_ITEM_DETAIL_API_HTTP_ERROR,
} from '../../resources/constants/storeConstants';

export const getItemsRequest = (companyId, customerId, cursorIndex) => {
  let payload = {
    companyId,
    customerId,
    cursorIndex,
  };
  return {
    type: GET_ITEMS_API_REQUEST,
    payload: payload,
  };
};

export const getItemApiSuccess = (itemsList) => {
  return {
    type: GET_ITEMS_API_SUCCESS,
    payload: itemsList,
  };
};

export const resetItemList = () => {
  return {
    type: RESET_ITEM_LIST,
    payload: '',
  };
};

export const getItemApiFailError = (error) => {
  return {
    type: GET_ITEMS_API_FAIL_ERROR,
    payload: error,
  };
};

export const resetItemApiFailError = () => {
  return {
    type: RESET_GET_ITEM_API_ERROR,
    payload: '',
  };
};

export const getItemHttpError = (error) => {
  return {
    type: GET_ITEM_HTTP_ERROR,
    payload: error,
  };
};

export const resetGetItemHttpError = () => {
  return {
    type: RESET_GET_ITEM_HTTP_ERROR,
    payload: '',
  };
};

export const resetItemReduxStore = () => {
  return {
    type: RESET_ITEM_REDUX_STATE,
    payload: '',
  };
};

export const setItemListOnScrollSuccessAction = (itemList) => {
  return {
    type: GET_ITEM_ON_SCROLL_SUCCESS,
    payload: itemList,
  };
};

export const resetItemListOnScrollAction = () => {
  return {
    type: RESET_GET_ITEM_ON_SCROLL,
    payload: '',
  };
};

export const getItemOnScrollRequest = (companyId, customerId, cursorIndex) => {
  const data = {
    companyId,
    customerId,
    cursorIndex,
  };

  return {
    type: GET_ITEM_ON_SCROLL_REQUEST,
    payload: data,
  };
};

export const getItemOnSearchApiRequest = (
  companyId,
  customerId,
  cursorIndex,
  searchText,
) => {
  const data = {
    companyId,
    customerId,
    cursorIndex,
    searchText,
  };

  return {
    type: ITEM_SEARCH_API_REQUEST,
    payload: data,
  };
};

export const getItemOnSearchApiSuccess = (itemList) => {
  return {
    type: ITEM_SEARCH_API_SUCCESS,
    payload: itemList,
  };
};

export const resetItemSearchResponse = () => {
  return {
    type: RESET_ITEM_SEARCH_LIST,
    payload: '',
  };
};

export const itemDetailApiRequestAction = (itemId, customerId) => {
  let data = {itemId, customerId};

  return {
    type: ITEM_DETAIL_API_REQUEST,
    payload: data,
  };
};

export const itemDetailApiSuccessAction = (itemData) => {
  return {
    type: ITEM_DETAIL_API_SUCCESS,
    payload: itemData,
  };
};

export const resetItemDataResponseAction = () => {
  return {
    type: RESET_API_DETAIL_API_RESPONSE,
    payload: '',
  };
};

export const itemDetailApiErrorAction = (errorObj) => {
  return {
    type: ITEM_DETAIL_API_ERROR,
    payload: errorObj,
  };
};

export const resetItemDetailApiErrorAction = () => {
  return {
    type: RESET_ITEM_DETAIL_API_ERROR,
    payload: '',
  };
};

export const itemDetailApiHttpErrorAction = (errorObj) => {
  return {
    type: ITEM_DETAIL_API_HTTP_ERROR,
    payload: errorObj,
  };
};

export const resetItemDetailApiHttpErrorAction = () => {
  return {
    type: RESET_ITEM_DETAIL_API_HTTP_ERROR,
    payload: '',
  };
};
