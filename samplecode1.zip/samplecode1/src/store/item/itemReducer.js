import {
  GET_ITEMS_API_REQUEST,
  GET_ITEMS_API_SUCCESS,
  RESET_ITEM_LIST,
  GET_ITEMS_API_FAIL_ERROR,
  RESET_GET_ITEM_API_ERROR,
  GET_ITEM_HTTP_ERROR,
  RESET_GET_ITEM_HTTP_ERROR,
  RESET_ITEM_REDUX_STATE,
  GET_ITEM_ON_SCROLL_SUCCESS,
  RESET_GET_ITEM_ON_SCROLL,
  GET_ITEM_ON_SCROLL_REQUEST,
  ITEM_SEARCH_API_REQUEST,
  ITEM_SEARCH_API_SUCCESS,
  RESET_ITEM_SEARCH_LIST,
  ITEM_DETAIL_API_REQUEST,
  ITEM_DETAIL_API_SUCCESS,
  RESET_API_DETAIL_API_RESPONSE,
  ITEM_DETAIL_API_ERROR,
  RESET_ITEM_DETAIL_API_ERROR,
  ITEM_DETAIL_API_HTTP_ERROR,
  RESET_ITEM_DETAIL_API_HTTP_ERROR,
} from '../../resources/constants/storeConstants';

const initialState = {
  itemsList: null,
  getItemFailError: null,
  getItemHttpError: null,
  itemListOnScroll: null,
  itemListOnSearch: null,
  itemDetail: null,
  itemDetailFailError: null,
  itemDetailHttpError: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
    case GET_ITEMS_API_REQUEST:
      return {...state};

    case GET_ITEMS_API_SUCCESS:
      return {...state, itemsList: action.payload};

    case RESET_ITEM_LIST: {
      return {
        ...state,
        itemsList: null,
      };
    }

    case GET_ITEMS_API_FAIL_ERROR:
      return {...state, getItemFailError: action.payload};

    case RESET_GET_ITEM_API_ERROR: {
      return {...state, getItemFailError: null};
    }

    case GET_ITEM_HTTP_ERROR: {
      return {
        ...state,
        getItemHttpError: action.payload,
      };
    }

    case RESET_GET_ITEM_HTTP_ERROR: {
      return {
        ...state,
        getItemHttpError: null,
      };
    }

    case GET_ITEM_ON_SCROLL_SUCCESS: {
      return {
        ...state,
        itemListOnScroll: action.payload,
      };
    }

    case RESET_GET_ITEM_ON_SCROLL: {
      return {
        ...state,
        itemListOnScroll: null,
      };
    }

    case GET_ITEM_ON_SCROLL_REQUEST: {
      return {
        ...state,
      };
    }

    case ITEM_SEARCH_API_REQUEST: {
      return {
        ...state,
      };
    }

    case ITEM_SEARCH_API_SUCCESS: {
      return {
        ...state,
        itemListOnSearch: action.payload,
      };
    }

    case RESET_ITEM_SEARCH_LIST: {
      return {
        ...state,
        itemListOnSearch: null,
      };
    }

    case RESET_ITEM_REDUX_STATE: {
      return {
        initialState,
      };
    }

    case ITEM_DETAIL_API_REQUEST: {
      return {
        ...state,
      };
    }

    case ITEM_DETAIL_API_SUCCESS: {
      return {
        ...state,
        itemDetail: action.payload,
      };
    }

    case RESET_API_DETAIL_API_RESPONSE: {
      return {
        ...state,
        itemDetail: null,
      };
    }

    case ITEM_DETAIL_API_ERROR: {
      return {
        ...state,
        itemDetailFailError: action.payload,
      };
    }

    case RESET_ITEM_DETAIL_API_ERROR: {
      return {
        ...state,
        itemDetailFailError: null,
      };
    }

    case ITEM_DETAIL_API_HTTP_ERROR: {
      return {
        ...state,
        itemDetailHttpError: action.payload,
      };
    }

    case RESET_ITEM_DETAIL_API_HTTP_ERROR: {
      return {
        ...state,
        itemDetailHttpError: null,
      };
    }

    default:
      return state;
  }
};
