import {takeLatest, takeEvery, call, put} from 'redux-saga/effects';
import {api} from '../../api';
import {saveItemsToRealm} from '../../realm/Models/itemModel';

import {
  GET_ITEMS_API_REQUEST,
  GET_ITEMS_API_FAIL,
  GET_ITEMS_API_SUCCESS,
  OK,
  GET_ITEM_HTTP_ERROR,
  RESPONSE_ISSUE,
  GET_ITEM_ON_SCROLL_REQUEST,
  FAIL,
  ITEM_SEARCH_API_REQUEST,
  ITEM_DETAIL_API_REQUEST,
} from '../../resources/constants/storeConstants';
import {
  getItemApiSuccess,
  getItemApiFailError,
  getItemHttpError,
  setItemListOnScrollSuccessAction,
  getItemOnSearchApiSuccess,
  itemDetailApiSuccessAction,
  itemDetailApiErrorAction,
  itemDetailApiHttpErrorAction,
} from './itemAction';

function* fetchGetItemsRequest({
  payload: {companyId, customerId, cursorIndex},
}) {
  try {
    const response = yield call(
      {context: api, fn: api.getItemsApi},
      companyId,
      customerId,
      cursorIndex,
    );

    if (response.data.response.reasonCode === OK) {
      let itemList = JSON.parse(response.data.response.dataList);
      console.log(itemList);
      const saveItemListToRealm = yield call(saveItemsToRealm, itemList);

      if (saveItemListToRealm === true) {
        yield put(getItemApiSuccess(itemList));
      } else {
        console.log(
          'Error in saving item list in  realms [fetchGetItemsRequest Method]',
          saveItemListToRealm,
        );
      }
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(getItemApiFailError({errorType: RESPONSE_ISSUE}));
    }
  } catch (errorObj) {
    console.log('error in item api-->', errorObj);
    yield put(getItemHttpError({errorType: errorObj}));
  }
}

function* fetchItemOnScrollRequest({
  payload: {companyId, customerId, cursorIndex},
}) {
  try {
    const response = yield call(
      {context: api, fn: api.getItemsApi},
      companyId,
      customerId,
      cursorIndex,
    );

    if (response.data.response.reasonCode === OK) {
      let itemList = JSON.parse(response.data.response.dataList);
      console.log('New Item List >>', itemList);
      const saveItemListToRealm = yield call(saveItemsToRealm, itemList);

      if (saveItemListToRealm === true) {
        yield put(setItemListOnScrollSuccessAction(itemList));
      } else {
        console.log(
          'Error in saving Items list in Realm [fetchItemOnScrollRequest Method]',
        );
      }
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(getItemApiFailError({errorType: RESPONSE_ISSUE}));
    }
  } catch (errorObj) {
    console.log('Error in getItemOnscroll API/ Method');
    console.log(errorObj);
    yield put(getItemHttpError(errorObj));
  }
}

function* searchItemRequest({
  payload: {companyId, customerId, cursorIndex, searchText},
}) {
  try {
    const response = yield call(
      {context: api, fn: api.getItemsApi},
      companyId,
      customerId,
      cursorIndex,
      searchText,
    );

    if (response.data.response.reasonCode === OK) {
      let itemList = JSON.parse(response.data.response.dataList);
      console.log('Item Search list', itemList);
      yield put(getItemOnSearchApiSuccess(itemList));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(getItemApiFailError({errorType: RESPONSE_ISSUE}));
    }
  } catch (errorObj) {
    console.log('Error in getItem Search API Saga');
    console.log(errorObj);
    yield put(getItemHttpError(errorObj));
  }
}

function* fetchItemDetailApiRequest({payload: {itemId, customerId}}) {
  try {
    const response = yield call(
      {context: api, fn: api.getItemDetailApi},
      itemId,
      customerId
    );

    if (response.data.response.reasonCode === OK) {
      let itemDetail = JSON.parse(response.data.response.dataList);
      console.log('Item Detail - ', itemDetail);
      yield put(itemDetailApiSuccessAction(itemDetail));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(itemDetailApiErrorAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errorObj) {
    console.log('Error in getItemDetail api Saga');
    console.log(errorObj);
    yield put(itemDetailApiHttpErrorAction(errorObj));
  }
}

export default function* watcherSaga() {
  yield takeLatest(GET_ITEMS_API_REQUEST, fetchGetItemsRequest);
  yield takeLatest(GET_ITEM_ON_SCROLL_REQUEST, fetchItemOnScrollRequest);
  yield takeLatest(ITEM_SEARCH_API_REQUEST, searchItemRequest);
  yield takeLatest(ITEM_DETAIL_API_REQUEST, fetchItemDetailApiRequest);
}
