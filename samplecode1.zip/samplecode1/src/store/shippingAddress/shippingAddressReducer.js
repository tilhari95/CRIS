import {
  RESET_SHIP_TO_ADDRESS_API_FAIL,
  RESET_SHIP_TO_ADDRESS_HTTP_ERROR,
  RESET_SHIP_TO_ADDRESS_LIST_RESPONSE,
  RESET_UPDATE_SHIPPING_ADDRESS_API_FAIL_ERR,
  RESET_UPDATE_SHIPPING_ADDRESS_API_HTTP_ERR,
  SHIP_TO_ADDRESS_API_FAIL,
  SHIP_TO_ADDRESS_HTTP_ERROR,
  SHIP_TO_ADDRESS_LIST_REQUEST,
  SHIP_TO_ADDRESS_LIST_SUCCESS,
  UPDATE_SHIPPING_ADDRESS_API_FAIL_ERR,
  UPDATE_SHIPPING_ADDRESS_API_HTTP_ERR,
  UPDATE_SHIPPING_ADDRESS_API_REQ,
  UPDATE_SHIPPING_ADDRESS_API_SUCCESS,
  RESET_UPDATE_SHIPPING_ADDRESS_RESPONSE,
} from '../../resources/constants/storeConstants';

const initialState = {
  shipToAddressList: null,
  shipToAddressListApiFailErr: null,
  shipToAddressListApiHttpErr: null,
  updateShippingAddressApiResponse: null,
  updateShippingAddressApiFailErr: null,
  updateShippingAddressHttpErr: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
    case SHIP_TO_ADDRESS_LIST_REQUEST: {
      return {
        ...state,
      };
    }

    case SHIP_TO_ADDRESS_LIST_SUCCESS: {
      return {
        ...state,
        shipToAddressList: action.payload,
      };
    }

    case RESET_SHIP_TO_ADDRESS_LIST_RESPONSE: {
      return {
        ...state,
        shipToAddressList: null,
      };
    }

    case SHIP_TO_ADDRESS_API_FAIL: {
      return {
        ...state,
        shipToAddressListApiFailErr: action.payload,
      };
    }

    case RESET_SHIP_TO_ADDRESS_API_FAIL: {
      return {
        ...state,
        shipToAddressListApiFailErr: null,
      };
    }

    case SHIP_TO_ADDRESS_HTTP_ERROR: {
      return {
        ...state,
        shipToAddressListApiHttpErr: action.payload,
      };
    }

    case RESET_SHIP_TO_ADDRESS_HTTP_ERROR: {
      return {
        ...state,
        shipToAddressListApiHttpErr: null,
      };
    }

    case UPDATE_SHIPPING_ADDRESS_API_REQ: {
      return {
        ...state,
      };
    }

    case UPDATE_SHIPPING_ADDRESS_API_SUCCESS: {
      return {
        ...state,
        updateShippingAddressApiResponse: action.payload,
      };
    }

    case RESET_UPDATE_SHIPPING_ADDRESS_RESPONSE: {
      return {
        ...state,
        updateShippingAddressApiResponse: null,
      };
    };

    case UPDATE_SHIPPING_ADDRESS_API_FAIL_ERR: {
      return {
        ...state,
        updateShippingAddressApiFailErr: action.payload,
      };
    }

    case RESET_UPDATE_SHIPPING_ADDRESS_API_FAIL_ERR: {
      return {
        ...state,
        updateShippingAddressApiFailErr: null,
      };
    }

    case UPDATE_SHIPPING_ADDRESS_API_HTTP_ERR: {
      return {
        ...state,
        updateShippingAddressHttpErr: action.payload,
      };
    }

    case RESET_UPDATE_SHIPPING_ADDRESS_API_HTTP_ERR: {
      return {
        ...state,
        updateShippingAddressHttpErr: null,
      };
    }
    default:
      return state;
  }
};
