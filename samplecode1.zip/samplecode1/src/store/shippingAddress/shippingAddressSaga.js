import {takeLatest, call, put} from 'redux-saga/effects';
import {api} from '../../api';

import {
  SHIP_TO_ADDRESS_LIST_REQUEST,
  OK,
  FAIL,
  RESPONSE_ISSUE,
  UPDATE_SHIPPING_ADDRESS_API_REQ,
} from '../../resources/constants/storeConstants';

import {
  shipToAddressListApiReqAction,
  shipToAddressListApiSuccessAction,
  shipToAddressApiFailAction,
  shipToAddressHttpErrAction,
  updateShipToAddressApiReqSuccessAction,
  updateShippingAddressApiFailErrAction,
  updateShippingAddressApiHttpErrAction,
} from './shippingAddressAction';

function* fetchShipToListApiRequest({payload: {companyId, customerId}}) {
  try {
    const response = yield call(
      {context: api, fn: api.getShipToListApi},
      companyId,
      customerId,
    );

    if (response.data.response.reasonCode === OK) {
      let addressList = JSON.parse(response.data.response.dataList);
      yield put(shipToAddressListApiSuccessAction(addressList));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(shipToAddressApiFailAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errorObj) {
    console.log('Error in fetchShipToListApiRequest ', errorObj);
    yield put(shipToAddressHttpErrAction({errorType: errorObj}));
  }
}

function* updateShippingAddressApiRequest({payload: {shipToId, customerId}}) {
  const response = yield call(
    {context: api, fn: api.updateShippingAddressApi},
    shipToId,
    customerId,
  );

  try {
    if (response.data.response.reasonCode === OK) {
      let apiData = JSON.parse(response.data.response.dataList);
      console.log('UpdateShippingAddress api response -', apiData);
      yield put(updateShipToAddressApiReqSuccessAction(apiData));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(
        updateShippingAddressApiFailErrAction({errorType: RESPONSE_ISSUE}),
      );
    }
  } catch (errObj) {
    console.log('Error in UpdateShippingAddress Api Saga', errObj);
    yield put(updateShippingAddressApiHttpErrAction(errObj));
  }
}

export default function* watcherSaga() {
  yield takeLatest(SHIP_TO_ADDRESS_LIST_REQUEST, fetchShipToListApiRequest);
  yield takeLatest(
    UPDATE_SHIPPING_ADDRESS_API_REQ,
    updateShippingAddressApiRequest,
  );
}
