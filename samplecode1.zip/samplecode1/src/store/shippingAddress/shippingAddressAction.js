import {
  SHIP_TO_ADDRESS_LIST_REQUEST,
  SHIP_TO_ADDRESS_LIST_SUCCESS,
  RESET_SHIP_TO_ADDRESS_LIST_RESPONSE,
  SHIP_TO_ADDRESS_API_FAIL,
  RESET_SHIP_TO_ADDRESS_API_FAIL,
  SHIP_TO_ADDRESS_HTTP_ERROR,
  RESET_SHIP_TO_ADDRESS_HTTP_ERROR,
  UPDATE_SHIPPING_ADDRESS_API_REQ,
  UPDATE_SHIPPING_ADDRESS_API_SUCCESS,
  UPDATE_SHIPPING_ADDRESS_API_FAIL_ERR,
  RESET_UPDATE_SHIPPING_ADDRESS_API_FAIL_ERR,
  UPDATE_SHIPPING_ADDRESS_API_HTTP_ERR,
  RESET_UPDATE_SHIPPING_ADDRESS_API_HTTP_ERR,
  RESET_UPDATE_SHIPPING_ADDRESS_RESPONSE,
} from '../../resources/constants/storeConstants';

export const shipToAddressListApiReqAction = (companyId, customerId) => {
  const data = {
    companyId,
    customerId,
  };

  return {
    type: SHIP_TO_ADDRESS_LIST_REQUEST,
    payload: data,
  };
};

export const shipToAddressListApiSuccessAction = (addressList) => {
  return {
    type: SHIP_TO_ADDRESS_LIST_SUCCESS,
    payload: addressList,
  };
};

export const resetShipToAddressResponseAction = () => {
  return {
    type: RESET_SHIP_TO_ADDRESS_LIST_RESPONSE,
    payload: '',
  };
};

export const shipToAddressApiFailAction = (errorObj) => {
  return {
    type: SHIP_TO_ADDRESS_API_FAIL,
    payload: errorObj,
  };
};

export const resetShipToAddressFailAction = () => {
  return {
    type: RESET_SHIP_TO_ADDRESS_API_FAIL,
    payload: '',
  };
};

export const shipToAddressHttpErrAction = (errorObj) => {
  return {
    type: SHIP_TO_ADDRESS_HTTP_ERROR,
    payload: errorObj,
  };
};

export const resetShipToAddressHttpErrAction = () => {
  return {
    type: RESET_SHIP_TO_ADDRESS_HTTP_ERROR,
    payload: '',
  };
};

export const updateShippingAddressApiReqAction = (shipToId, customerId) => {
  let data = {
    shipToId,
    customerId,
  };

  return {
    type: UPDATE_SHIPPING_ADDRESS_API_REQ,
    payload: data,
  };
};

export const updateShipToAddressApiReqSuccessAction = (response) => {
  return {
    type: UPDATE_SHIPPING_ADDRESS_API_SUCCESS,
    payload: response,
  };
};

export const resetUpdateShippingAddressApiResponseAction = () => {
  return {
    type: RESET_UPDATE_SHIPPING_ADDRESS_RESPONSE,
    payload: null,
  };
};

export const updateShippingAddressApiFailErrAction = (errObj) => {
  return {
    type: UPDATE_SHIPPING_ADDRESS_API_FAIL_ERR,
    payload: errObj,
  };
};

export const resetUpdateShippingAddressApiFailErrAction = () => {
  return {
    type: RESET_UPDATE_SHIPPING_ADDRESS_API_FAIL_ERR,
    payload: null,
  };
};

export const updateShippingAddressApiHttpErrAction = (errObj) => {
  return {
    type: UPDATE_SHIPPING_ADDRESS_API_HTTP_ERR,
    payload: errObj,
  };
};

export const resetUpdateShippingAddressApiHttpErrAction = () => {
  return {
    type: RESET_UPDATE_SHIPPING_ADDRESS_API_HTTP_ERR,
    payload: null,
  };
};
