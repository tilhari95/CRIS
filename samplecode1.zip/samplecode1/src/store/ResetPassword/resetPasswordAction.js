import {
    HTTP_RESET_API_ERROR_RESET,
    RESET_PASSWORD_REQUEST, SET_PASSWORD_INITIAL_STATE,
} from '../../resources/constants/storeConstants';

export const resetPasswordRequest = (email) => {
    return({
        type: RESET_PASSWORD_REQUEST,
        payload: email });
};

export const setPasswordReduxInitialState = () => {
    return({
        type: SET_PASSWORD_INITIAL_STATE,
        payload:'' });
};


export const setHttpResetErrorToInitial =() =>{
    debugger;
    return({
        type: HTTP_RESET_API_ERROR_RESET,
        payload: ''
    });
}
