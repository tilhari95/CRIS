import {
  RESET_REQUEST_SUCCESS,
  RESET_REQUEST_FAIL,
  SET_PASSWORD_INITIAL_STATE,
  HTTP_RESET_API_ERROR,
  HTTP_RESET_API_ERROR_RESET,
} from '../../resources/constants/storeConstants';
import {Status} from '../../api';

const initialState = {
  resetSuccessResponse: null,
  resetFailError: null,
  status: Status.DEFAULT,
  resetPasswordHttpError: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
    case RESET_REQUEST_SUCCESS: {
      return {
        ...state,
        status: Status.SUCCESS,
        resetSuccessResponse: action.payload,
      };
    }
    case RESET_REQUEST_FAIL: {
      return {...state, status: Status.ERROR, resetFailError: action.payload};
    }
    case HTTP_RESET_API_ERROR: {
      return {...state, resetPasswordHttpError: action.payload};
    }
    case HTTP_RESET_API_ERROR_RESET:
      return {
        ...state,
        resetPasswordHttpError: null,
        resetSuccessResponse: null,
        resetFailError: null,
      };
    case SET_PASSWORD_INITIAL_STATE: {
      return {...state, ...initialState};
    }
    default:
      return state;
  }
};
