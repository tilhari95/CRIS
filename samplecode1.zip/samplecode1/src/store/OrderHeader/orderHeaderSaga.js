import {
  takeLatest,
  takeEvery,
  takeLeading,
  call,
  put,
} from 'redux-saga/effects';
import {api} from '../../api';

import {
  OK,
  FAIL,
  GET_ORDER_HEADER_API_REQ,
  RESPONSE_ISSUE,
} from '../../resources/constants/storeConstants';
import {
  getOrderHeaderApiSuccessAction,
  orderHeaderApiFailErrAction,
  orderHeaderApiHttpErrAction,
} from './orderHeaderAction';

function* fetchAddOrderHeaderApi({
  payload: {
    orderId,
    orderNo,
    companyId,
    orderStatus,
    customerNo,
    comment1,
    comment2,
    ponNumber,
    subTotal,
    taxes,
    discount,
    paidCash,
    paidCheck,
    paidCCard,
    shipToId,
    shipToName,
    checkNumber,
    customerType,
    emailAddress,
    orderType,
    createdDate,
    requestedShipDate,
    shipToAddress1,
    shipToCity,
    shipToState,
    shipToZip,
    isPRO,
    billToName,
    billToAddress,
    billToCity,
    billToState,
    billToZip,
    deviceId,
    customerId,
    taxScheduleId,
    customerName,
    customerFKey,
    taxSchedule,
    termsCode,
    rewardId
  },
}) {
  try {
    const response = yield call(
      {context: api, fn: api.addOrderHeaderApi},
      orderId,
      orderNo,
      companyId,
      orderStatus,
      customerNo,
      comment1,
      comment2,
      ponNumber,
      subTotal,
      taxes,
      discount,
      paidCash,
      paidCheck,
      paidCCard,
      shipToId,
      shipToName,
      checkNumber,
      customerType,
      emailAddress,
      orderType,
      createdDate,
      requestedShipDate,
      shipToAddress1,
      shipToCity,
      shipToState,
      shipToZip,
      isPRO,
      billToName,
      billToAddress,
      billToCity,
      billToState,
      billToZip,
      deviceId,
      customerId,
      taxScheduleId,
      customerName,
      customerFKey,
      taxSchedule,
      termsCode,
      rewardId
    );

    if (response.data.response.reasonCode === OK) {
      let ohResponse = JSON.parse(response.data.response.dataList);
      console.log('OrderHeader Response - ', ohResponse);
      yield put(getOrderHeaderApiSuccessAction(ohResponse));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(orderHeaderApiFailErrAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errObj) {
    console.log('Error in AddOrderHeaderApi', errObj);
    yield put(orderHeaderApiHttpErrAction(errObj));
  }
}

export default function* watcherSaga() {
  yield takeLatest(GET_ORDER_HEADER_API_REQ, fetchAddOrderHeaderApi);
}
