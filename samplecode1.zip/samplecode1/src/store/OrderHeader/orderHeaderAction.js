import {
  GET_ORDER_HEADER_API_REQ,
  GET_ORDER_HEADER_API_SUCCESS,
  RESET_ORDER_HEADER_API_RESPONSE,
  ORDER_HEADER_API_FAIL_ERR,
  RESET_ORDER_HEADER_API_FAIL_ERR,
  ORDER_HEADER_API_HTTP_ERR,
  RESET_ORDER_HEADER_API_HTTP_ERR,
} from '../../resources/constants/storeConstants';

export const getOrderHeaderAPiReqAction = (
  orderId,
  orderNo,
  companyId,
  orderStatus,
  customerNo,
  comment1,
  comment2,
  ponNumber,
  subTotal,
  taxes,
  discount,
  paidCash,
  paidCheck,
  paidCCard,
  shipToId,
  shipToName,
  checkNumber,
  customerType,
  emailAddress,
  orderType,
  createdDate,
  requestedShipDate,
  shipToAddress1,
  shipToCity,
  shipToState,
  shipToZip,
  isPRO,
  billToName,
  billToAddress,
  billToCity,
  billToState,
  billToZip,
  deviceId,
  customerId,
  taxScheduleId,
  customerName,
  customerFKey,
  taxSchedule,
  termsCode,
  rewardId,
) => {
  let data = {
    orderId,
    orderNo,
    companyId,
    orderStatus,
    customerNo,
    comment1,
    comment2,
    ponNumber,
    subTotal,
    taxes,
    discount,
    paidCash,
    paidCheck,
    paidCCard,
    shipToId,
    shipToName,
    checkNumber,
    customerType,
    emailAddress,
    orderType,
    createdDate,
    requestedShipDate,
    shipToAddress1,
    shipToCity,
    shipToState,
    shipToZip,
    isPRO,
    billToName,
    billToAddress,
    billToCity,
    billToState,
    billToZip,
    deviceId,
    customerId,
    taxScheduleId,
    customerName,
    customerFKey,
    taxSchedule,
    termsCode,
    rewardId,
  };

  return {
    type: GET_ORDER_HEADER_API_REQ,
    payload: data,
  };
};

export const getOrderHeaderApiSuccessAction = (response) => {
  return {
    type: GET_ORDER_HEADER_API_SUCCESS,
    payload: response,
  };
};

export const resetOrderHeaderApiResponseAction = () => {
  return {
    type: RESET_ORDER_HEADER_API_RESPONSE,
    payload: null,
  };
};

export const orderHeaderApiFailErrAction = (errObj) => {
  return {
    type: ORDER_HEADER_API_FAIL_ERR,
    payload: errObj,
  };
};

export const resetOrderHeaderApiFailErrAction = () => {
  return {
    type: RESET_ORDER_HEADER_API_FAIL_ERR,
    payload: null,
  };
};

export const orderHeaderApiHttpErrAction = (errObj) => {
  return {
    type: ORDER_HEADER_API_HTTP_ERR,
    payload: errObj,
  };
};

export const resetOrderHeaderApiHttpErrAction = () => {
  return {
    type: RESET_ORDER_HEADER_API_HTTP_ERR,
    payload: null,
  };
};
