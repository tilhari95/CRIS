import {
  GET_ORDER_HEADER_API_REQ,
  GET_ORDER_HEADER_API_SUCCESS,
  RESET_ORDER_HEADER_API_RESPONSE,
  ORDER_HEADER_API_FAIL_ERR,
  RESET_ORDER_HEADER_API_FAIL_ERR,
  ORDER_HEADER_API_HTTP_ERR,
  RESET_ORDER_HEADER_API_HTTP_ERR,
} from '../../resources/constants/storeConstants';

const initialState = {
  orderHeaderApiResponse: null,
  orderHeaderApiFailErr: null,
  orderHeaderApiHttpErr: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
    case GET_ORDER_HEADER_API_REQ: {
      return {
        ...state,
      };
    }

    case GET_ORDER_HEADER_API_SUCCESS: {
      return {
        ...state,
        orderHeaderApiResponse: action.payload,
      };
    }

    case RESET_ORDER_HEADER_API_RESPONSE: {
      return {
        ...state,
        orderHeaderApiResponse: null,
      };
    }

    case ORDER_HEADER_API_FAIL_ERR: {
      return {
        ...state,
        orderHeaderApiFailErr: action.payload,
      };
    }

    case RESET_ORDER_HEADER_API_FAIL_ERR: {
      return {
        ...state,
        orderHeaderApiFailErr: null,
      };
    }

    case ORDER_HEADER_API_HTTP_ERR: {
      return {
        ...state,
        orderHeaderApiHttpErr: action.payload,
      };
    }

    case RESET_ORDER_HEADER_API_HTTP_ERR: {
      return {
        ...state,
        orderHeaderApiHttpErr: null,
      };
    }

    default:
      return state;
  }
};
