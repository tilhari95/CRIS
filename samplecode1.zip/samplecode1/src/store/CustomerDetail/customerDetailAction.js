import {
  CUSTOMER_DETAIL_DATA_REQUEST_SUCCESS,
  CUSTOMER_DETAIL_DATA_REQUEST_FAIL,
  FETCH_CUSTOMER_DETAIL_DATA_REQUEST,
  RESET_CUSTOMER_DETAIL_API_ERROR,
  CUSTOMER_DETAIL_API_HTTP_ERROR,
  RESET_CUSTOMER_DETAIL_API_HTTP_ERROR,
  RESET_CUSTOMER_DETAIL_DATA_RESPONSE,
  CUSTOMER_INFO_API_REQ,
  CUSTOMER_INFO_API_SUCCESS,
  RESET_CUSTOMER_INFO_API_RESPONSE,
  CUSTOMER_INFO_API_ERR,
  RESET_CUSTOMER_INFO_API_ERR,
  CUSTOMER_INFO_API_HTTP_ERR,
  RESET_CUSTOMER_INFO_API_HTTP_ERR,
} from '../../resources/constants/storeConstants';

export const getCustomerDetailDataRequestAction = (
  companyId,
  repId,
  customerId,
) => {
  let payload = {companyId, repId, customerId};

  return {
    type: FETCH_CUSTOMER_DETAIL_DATA_REQUEST,
    payload: payload,
  };
};

export const custtomerdetailReqFailAction = (error) => {
  return {
    type: CUSTOMER_DETAIL_DATA_REQUEST_FAIL,
    payload: error,
  };
};

export const customerDetailDataToReduxAction = (data) => {
  return {
    type: CUSTOMER_DETAIL_DATA_REQUEST_SUCCESS,
    payload: data,
  };
};

export const setCustomerDetailHttpError = (error) => {
  return {
    type: CUSTOMER_DETAIL_API_HTTP_ERROR,
    payload: error,
  };
};

export const resetCustomerDetailDataApiError = () => {
  return {
    type: RESET_CUSTOMER_DETAIL_API_ERROR,
    payload: '',
  };
};

export const resetCustomerDetailApiResponse = () => {
  return {
    type: RESET_CUSTOMER_DETAIL_DATA_RESPONSE,
    payload: '',
  };
};

export const resetCustomerDetailApiHttpError = () => {
  return {
    type: RESET_CUSTOMER_DETAIL_API_HTTP_ERROR,
    payload: '',
  };
};

export const getCustomerInfoApiReqAction = (customerId) => {
  let data = {customerId};

  return {
    type: CUSTOMER_INFO_API_REQ,
    payload: data,
  };
};

export const getCustomerInfoApiSuccessAction = (response) => {
  return {
    type: CUSTOMER_INFO_API_SUCCESS,
    payload: response,
  };
};

export const resetCustomerInfoApiResponseAction = () => {
  return {
    type: RESET_CUSTOMER_INFO_API_RESPONSE,
    payload: null,
  };
};

export const customerInfoApiFailErrAction = (errObj) => {
  return {
    type: CUSTOMER_INFO_API_ERR,
    payload: errObj,
  };
};

export const resetCustomerInfoApiFailErrAction = () => {
  return {
    type: RESET_CUSTOMER_INFO_API_ERR,
    payload: null,
  };
};

export const customerInfoApiHttpErrAction = (errObj) => {
  return {
    type: CUSTOMER_INFO_API_HTTP_ERR,
    payload: errObj,
  };
};

export const resetCustomerInfoHttpErrAction = () => {
  return {
    type: RESET_CUSTOMER_INFO_API_HTTP_ERR,
    payload: null,
  };
};
