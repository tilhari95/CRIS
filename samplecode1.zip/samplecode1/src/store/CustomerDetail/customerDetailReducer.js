import {
  CUSTOMER_DETAIL_DATA_REQUEST_SUCCESS,
  CUSTOMER_DETAIL_DATA_REQUEST_FAIL,
  FETCH_CUSTOMER_DETAIL_DATA_REQUEST,
  RESET_CUSTOMER_DETAIL_API_ERROR,
  CUSTOMER_DETAIL_API_HTTP_ERROR,
  RESET_CUSTOMER_DETAIL_API_HTTP_ERROR,
  RESET_CUSTOMER_DETAIL_DATA_RESPONSE,
  CUSTOMER_INFO_API_REQ,
  CUSTOMER_INFO_API_SUCCESS,
  RESET_CUSTOMER_INFO_API_RESPONSE,
  CUSTOMER_INFO_API_ERR,
  RESET_CUSTOMER_INFO_API_ERR,
  CUSTOMER_INFO_API_HTTP_ERR,
  RESET_CUSTOMER_INFO_API_HTTP_ERR,
} from '../../resources/constants/storeConstants';

const initialState = {
  customerDetailApiSuccessResponse: null,
  customerDetailApiFailError: null,
  customerDetailApiHttpError: null,
  customerInfoApiResponse: null,
  customerInfoApiFailErr: null,
  customerInfoApiHttpErr: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
    case FETCH_CUSTOMER_DETAIL_DATA_REQUEST: {
      return {...state};
    }

    case CUSTOMER_DETAIL_DATA_REQUEST_SUCCESS: {
      return {
        ...state,
        customerDetailApiSuccessResponse: action.payload,
      };
    }

    case RESET_CUSTOMER_DETAIL_DATA_RESPONSE: {
      return {
        ...state,
        customerDetailApiSuccessResponse: null,
      };
    }

    case CUSTOMER_DETAIL_DATA_REQUEST_FAIL: {
      return {
        ...state,
        customerDetailApiFailError: action.payload,
      };
    }

    case RESET_CUSTOMER_DETAIL_API_ERROR: {
      return {
        ...state,
        customerDetailApiFailError: null,
      };
    }

    case CUSTOMER_DETAIL_API_HTTP_ERROR: {
      return {
        ...state,
        customerDetailApiHttpError: action.payload,
      };
    }

    case RESET_CUSTOMER_DETAIL_API_HTTP_ERROR: {
      return {
        ...state,
        customerDetailApiHttpError: null,
      };
    }

    case CUSTOMER_INFO_API_REQ: {
      return {
        ...state,
      };
    }

    case CUSTOMER_INFO_API_SUCCESS: {
      return {
        ...state,
        customerInfoApiResponse: action.payload,
      };
    }

    case RESET_CUSTOMER_INFO_API_RESPONSE: {
      return {
        ...state,
        customerInfoApiResponse: null,
      };
    }

    case CUSTOMER_INFO_API_ERR: {
      return {
        ...state,
        customerInfoApiFailErr: action.payload,
      };
    }

    case RESET_CUSTOMER_INFO_API_ERR: {
      return {
        ...state,
        customerInfoApiFailErr: null,
      };
    }

    case CUSTOMER_INFO_API_HTTP_ERR: {
      return {
        ...state,
        customerInfoApiHttpErr: action.payload,
      };
    }

    case RESET_CUSTOMER_INFO_API_HTTP_ERR: {
      return {
        ...state,
        customerInfoApiHttpErr: null,
      };
    }

    default:
      return state;
  }
};
