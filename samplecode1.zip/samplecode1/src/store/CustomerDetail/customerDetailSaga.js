import {
  takeLatest,
  takeEvery,
  takeLeading,
  call,
  put,
} from 'redux-saga/effects';
import {api} from '../../api';
import {
  OK,
  FAIL,
  FETCH_CUSTOMER_DETAIL_DATA_REQUEST,
  CUSTOMER_INFO_API_REQ,
  RESPONSE_ISSUE,
} from '../../resources/constants/storeConstants';
import {
  customerDetailDataToReduxAction,
  custtomerdetailReqFailAction,
  setCustomerDetailHttpError,
  getCustomerInfoApiSuccessAction,
  customerInfoApiFailErrAction,
  customerInfoApiHttpErrAction,
} from './customerDetailAction';

function* fetchGetCustomerDetailDataRequest({
  payload: {companyId, repId, customerId},
}) {
  try {
    const response = yield call(
      {
        context: api,
        fn: api.getCustomerDetailData,
      },
      companyId,
      repId,
      customerId,
    );

    if (response.data.response.reasonCode === OK) {
      let customerDetail = JSON.parse(response.data.response.dataList);
      yield put(customerDetailDataToReduxAction(customerDetail));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(custtomerdetailReqFailAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errorObj) {
    console.log('error on customer detail api--->>>>>v first dfetch');
    console.log(errorObj);
    yield put(setCustomerDetailHttpError(errorObj));
  }
}

function* fetchCustomerInfoApi({payload: {customerId}}) {
  try {
    const response = yield call(
      {context: api, fn: api.getCustomerInfoApi},
      customerId,
    );

    if (response.data.response.reasonCode === OK) {
      let customerInfo = JSON.parse(response.data.response.dataList);
      console.log('CustomerInfo - ', customerInfo);
      yield put(getCustomerInfoApiSuccessAction(customerInfo));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(customerInfoApiFailErrAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errObj) {
    console.log('Error in CustomerInfoApi', errObj);
    yield put(customerInfoApiHttpErrAction(errObj));
  }
}

export default function* watcherSaga() {
  yield takeLeading(
    FETCH_CUSTOMER_DETAIL_DATA_REQUEST,
    fetchGetCustomerDetailDataRequest,
  );
  yield takeLatest(CUSTOMER_INFO_API_REQ, fetchCustomerInfoApi);
}
