import {
    HTTP_SALES_GROWTH_LANDING_SCREEN_API_ERROR, HTTP_SALES_GROWTH_LANDING_SCREEN_API_ERROR_RESET,

} from '../../resources/constants/storeConstants';

const initialState = {
    salesGrowthScreenHttpError: null,
   };

export default (state = initialState, action) => {
    switch (action.type) {
        case HTTP_SALES_GROWTH_LANDING_SCREEN_API_ERROR: {
            return {...state, salesGrowthScreenHttpError: action.payload};
        }
        case HTTP_SALES_GROWTH_LANDING_SCREEN_API_ERROR_RESET:
            return {
                ...state,
                salesGrowthScreenHttpError: null,
            };
        default:
            return state;
    }
};
