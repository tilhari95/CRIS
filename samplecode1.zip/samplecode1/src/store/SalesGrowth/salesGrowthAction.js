import {HTTP_SALES_GROWTH_LANDING_SCREEN_API_ERROR_RESET} from "../../resources/constants/storeConstants";

export const resetSalesGrowthHttpApiError = () => {
    return({
        type: HTTP_SALES_GROWTH_LANDING_SCREEN_API_ERROR_RESET,
        payload:'' });
};
