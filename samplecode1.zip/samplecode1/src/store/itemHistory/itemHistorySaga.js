import {takeLatest, call, put} from 'redux-saga/effects';
import {api} from '../../api';

import {
  FAIL,
  ITEM_HISTORY_API_REQUEST,
  ITEM_HISTORY_ON_SCROLL_REQUEST,
  OK,
  RESPONSE_ISSUE,
} from '../../resources/constants/storeConstants';
import {
  itemHistoryApiErrorAction,
  itemHistoryApiHttpErrorAction,
  getItemHistoryApiSuccessAction,
  itemHistoryOnScrollSuccessAction
} from './itemHistoryAction';

function* fetchCustomerItemHistoryApi({
  payload: {companyId, customerId, cursorIndex},
}) {
  try {
    const response = yield call(
      {context: api, fn: api.getCustomerItemHistoryApi},
      companyId,
      customerId,
      cursorIndex,
    );

    if (response.data.response.reasonCode === OK) {
      let itemList = JSON.parse(response.data.response.dataList);
      yield put(getItemHistoryApiSuccessAction(itemList));
      console.log('Item Histry list', itemList);
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(itemHistoryApiErrorAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errorObj) {
    console.log('Error in fetchCustomerItemHistoryApi ', errorObj);
    yield put(itemHistoryApiHttpErrorAction(errorObj));
  }
}

function* FetchItemHistoryOnScrollApi({
  payload: {companyId, customerId, cursorIndex},
}) {
  try {
    const response = yield call(
      {context: api, fn: api.getCustomerItemHistoryApi},
      companyId,
      customerId,
      cursorIndex
    );

    if (response.data.response.reasonCode === OK) {
      let itemList = JSON.parse(response.data.response.dataList);
      yield put(itemHistoryOnScrollSuccessAction(itemList));
      console.log('Item Histry list', itemList);
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(itemHistoryApiErrorAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errorObj) {
    console.log('Error in FetchItemHistoryOnScrollApi ', errorObj);
    yield put(itemHistoryApiHttpErrorAction(errorObj));
  }
}

export default function* watcherSaga() {
  yield takeLatest(ITEM_HISTORY_API_REQUEST, fetchCustomerItemHistoryApi);
  yield takeLatest(ITEM_HISTORY_ON_SCROLL_REQUEST, FetchItemHistoryOnScrollApi);
}
