import {
  ITEM_HISTORY_API_REQUEST,
  ITEM_HISTORY_API_SUCCESS,
  RESET_ITEM_HISTORY_API,
  ITEM_HISTORY_API_ERROR,
  RESET_ITEM_HISTORY_API_ERROR,
  ITEM_HISTORY_API_HTTP_ERROR,
  RESET_ITEM_HISTORY_API_HTTP_ERROR,
  ITEM_HISTORY_ON_SCROLL_REQUEST,
  ITEM_HISTORY_ON_SCROLL_SUCCESS,
  RESET_ITEM_HISTORY_ON_SCROLL_LIST,
  RESET_ITEM_HISTORY_REDUX_STATE
} from '../../resources/constants/storeConstants';

export const getItemHistoryApiRequestAction = (
  companyId,
  customerId,
  cursorIndex,
) => {
  let data = {
    companyId,
    customerId,
    cursorIndex,
  };

  return {
    type: ITEM_HISTORY_API_REQUEST,
    payload: data,
  };
};

export const getItemHistoryApiSuccessAction = (itemList) => {
  return {
    type: ITEM_HISTORY_API_SUCCESS,
    payload: itemList,
  };
};

export const resetItemHistoryApiResponseAction = () => {
  return {
    type: RESET_ITEM_HISTORY_API,
    payload: '',
  };
};

export const itemHistoryApiErrorAction = (errorObj) => {
  return {
    type: ITEM_HISTORY_API_ERROR,
    payload: errorObj,
  };
};

export const resetItemHistoryApiErrorAction = () => {
  return {
    type: RESET_ITEM_HISTORY_API_ERROR,
    payload: '',
  };
};

export const itemHistoryApiHttpErrorAction = (errorObj) => {
  return {
    type: ITEM_HISTORY_API_HTTP_ERROR,
    payload: errorObj,
  };
};

export const resetItemHistoryApiHttpError = () => {
  return {
    type: RESET_ITEM_HISTORY_API_HTTP_ERROR,
    payload: '',
  };
};

export const itemHistoryOnScrollRequestAction = (
  companyId,
  customerId,
  cursorIndex,
) => {
  let data = {
    companyId,
    customerId,
    cursorIndex,
  };

  return {
    type: ITEM_HISTORY_ON_SCROLL_REQUEST,
    payload: data,
  };
};

export const itemHistoryOnScrollSuccessAction = (itemList) => {
  return {
    type: ITEM_HISTORY_ON_SCROLL_SUCCESS,
    payload: itemList,
  };
};

export const resetItemHistoryListOnScrollAction = () => {
  return {
    type: RESET_ITEM_HISTORY_ON_SCROLL_LIST,
    payload: '',
  };
};

export const resetItemHistoryReduxStataAction = () => {
  return {
    type: RESET_ITEM_HISTORY_REDUX_STATE,
    payload: ''
  }
}
