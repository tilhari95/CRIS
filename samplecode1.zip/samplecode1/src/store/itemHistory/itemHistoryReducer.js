import {
  ITEM_HISTORY_API_REQUEST,
  ITEM_HISTORY_API_SUCCESS,
  RESET_ITEM_HISTORY_API,
  ITEM_HISTORY_API_ERROR,
  RESET_ITEM_HISTORY_API_ERROR,
  ITEM_HISTORY_API_HTTP_ERROR,
  RESET_ITEM_HISTORY_API_HTTP_ERROR,
  ITEM_HISTORY_ON_SCROLL_REQUEST,
  ITEM_HISTORY_ON_SCROLL_SUCCESS,
  RESET_ITEM_HISTORY_ON_SCROLL_LIST,
  RESET_ITEM_HISTORY_REDUX_STATE
} from '../../resources/constants/storeConstants';

const initialState = {
  itemHistoryList: null,
  itemHistoryApiError: null,
  itemHistoryApiHttpError: null,
  itemHistoryListOnScroll: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
    case ITEM_HISTORY_API_REQUEST: {
      return {
        ...state,
      };
    }

    case ITEM_HISTORY_API_SUCCESS: {
      return {
        ...state,
        itemHistoryList: action.payload,
      };
    }

    case RESET_ITEM_HISTORY_API: {
      return {
        ...state,
        itemHistoryList: null,
      };
    }

    case ITEM_HISTORY_API_ERROR: {
      return {
        ...state,
        itemHistoryApiError: action.payload,
      };
    }

    case RESET_ITEM_HISTORY_API_ERROR: {
      return {
        ...state,
        itemHistoryApiError: null,
      };
    }

    case ITEM_HISTORY_API_HTTP_ERROR: {
      return {
        ...state,
        itemHistoryApiHttpError: action.payload,
      };
    }

    case RESET_ITEM_HISTORY_API_HTTP_ERROR: {
      return {
        ...state,
        itemHistoryApiHttpError: null,
      };
    }

    case ITEM_HISTORY_ON_SCROLL_REQUEST: {
      return {
        ...state,
      };
    }

    case ITEM_HISTORY_ON_SCROLL_SUCCESS: {
      return {
        ...state,
        itemHistoryListOnScroll: action.payload,
      };
    }

    case RESET_ITEM_HISTORY_ON_SCROLL_LIST: {
      return {
        ...state,
        itemHistoryListOnScroll: null,
      };
    }

    case RESET_ITEM_HISTORY_REDUX_STATE: {
      return {
        itemHistoryList: null,
        itemHistoryApiError: null,
        itemHistoryApiHttpError: null,
        itemHistoryListOnScroll: null,
      }
    }

    default:
      return state;
  }
};
