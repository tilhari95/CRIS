import {
  ORDER_LINE_API_REQ,
  ORDER_LINE_API_SUCCESS,
  RESET_ORDER_LINE_API_RESPONSE,
  ORDER_LINE_API_FAIL_ERR,
  RESET_ORDER_LINE_API_FAIL_ERR,
  ORDER_LINE_API_HTTP_ERR,
  RESET_ORDER_LINE_API_HTTP_ERR,
  ADD_ITEM_TO_CART,
  DELETE_ORDER_LINE_API_REQ,
  DELETE_ORDER_LINE_API_SUCCESS,
  RESET_DELETE_ORDER_LINE_API_RESPONSE,
  DELETE_ORDER_LINE_API_FAIL_ERR,
  RESET_DELETE_ORDER_API_FAIL_ERR,
  DELETE_ORDER_LINE_API_HTTP_ERR,
  RESET_DELETE_ORDER_LINE_API_HTTP_ERR,
  REMOVE_ORDER_LINE_ITEM_FROM_LIST,
  LINE_ITEM_EDIT_API_REQ,
  LINE_ITEM_EDIT_API_RESPONSE,
  RESET_LINE_ITEM_EDIT_API_RESPONSE,
  LINE_ITEM_EDIT_API_FAIL_ERR,
  RESET_LINE_ITEM_EDIT_API_FAIL_ERR,
  LINE_ITEM_EDIT_API_HTTP_ERR,
  RESET_LINE_ITEM_EDIT_HTTP_ERR,
  GET_ORDER_LINE_DATA_API_REQ,
  GET_ORDER_LINE_DATA_API_RESPONSE,
  RESET_GET_ORDER_LINE_DATA_API_RESPONSE,
  GET_ORDER_LINE_API_FAIL_ERR,
  RESET_GET_ORDER_LINE_API_FAIL_ERR,
  GET_ORDER_LINE_API_HTTP_ERR,
  RESET_GET_ORDER_LINE_API_HTTP_ERR,
  SET_CART_TOTAL,
  SET_CART_SUB_TOTAL,
  SET_CART_TAX_PERCENT,
  SET_CART_TAX_VALUE,
  SET_ORDER_ID,
  SET_COUPON_CODE,
  SET_REWARD_AMT,
  SET_TOTAL_DUE_AFTER_REWARD,
  SET_AMOUNT_RECEIVED,
  SET_PAYMENT_MODE,
  SET_BALANCE_DUE,
  SET_CHECK_AMOUNT,
  SET_CHECK_NO,
  SET_CASH_RECEIVED,
  SET_SIGNATORY_NAME,
  SET_SIGNATORY_IMAGE_DATA,
  RESET_ALL_PAYMENT_SCREEN_DATA,
  SET_REWARD_ID,
  RESET_REWARD_ID,
  SET_ORDER_NO,
  SET_SEQUENCE,
  RESET_ORDER_LINE_STORE,
  SET_ORDER_LINE_ITEM_LIST,
  SET_PO_NO
} from '../../resources/constants/storeConstants';

export const addOrderLineApiReqAction = (
  orderLineId,
  orderNo,
  sequence,
  itemId,
  itemNo,
  description1,
  description2,
  price,
  orderQty,
  taxes,
  notes,
  sync,
  companyId,
  scanCode,
  uom,
  deviceId,
  customerNo,
  customerId,
  repId,
) => {
  let data = {
    orderLineId,
    orderNo,
    sequence,
    itemId,
    itemNo,
    description1,
    description2,
    price,
    orderQty,
    taxes,
    notes,
    sync,
    companyId,
    scanCode,
    uom,
    deviceId,
    customerNo,
    customerId,
    repId,
  };

  return {
    type: ORDER_LINE_API_REQ,
    payload: data,
  };
};

export const addOrderLineApiSuccessAction = (response) => {
  return {
    type: ORDER_LINE_API_SUCCESS,
    payload: response,
  };
};

export const resetAddOrderLineApiResponseAction = () => {
  return {
    type: RESET_ORDER_LINE_API_RESPONSE,
    payload: '',
  };
};

export const addOrderLineApiErrAction = (apiErr) => {
  return {
    type: ORDER_LINE_API_FAIL_ERR,
    payload: apiErr,
  };
};

export const resetAddOrderLineApiErrAction = () => {
  return {
    type: RESET_ORDER_LINE_API_FAIL_ERR,
    payload: null,
  };
};

export const addOrderLineHttpErrAction = (httpErr) => {
  return {
    type: ORDER_LINE_API_HTTP_ERR,
    payload: httpErr,
  };
};

export const resetAddOrderLineHttpErrAction = () => {
  return {
    type: RESET_ORDER_LINE_API_HTTP_ERR,
    payload: '',
  };
};

export const addItemToCartAction = (item) => {
  return {
    type: ADD_ITEM_TO_CART,
    payload: item,
  };
};

export const deleteOrderLineApiReqAction = (orderLineId) => {
  let data = {
    orderLineId,
  };

  return {
    type: DELETE_ORDER_LINE_API_REQ,
    payload: data,
  };
};

export const deleteOrderlineApiSuccessAction = (response) => {
  return {
    type: DELETE_ORDER_LINE_API_SUCCESS,
    payload: response,
  };
};

export const resetDeleteOrderLineApiResponseAction = () => {
  return {
    type: RESET_DELETE_ORDER_LINE_API_RESPONSE,
    payload: null,
  };
};

export const deleteOrderlineApiFailAction = (errObj) => {
  return {
    type: DELETE_ORDER_LINE_API_FAIL_ERR,
    payload: errObj,
  };
};

export const resetDeleteOrderLineApiFailAction = () => {
  return {
    type: RESET_DELETE_ORDER_API_FAIL_ERR,
    payload: null,
  };
};

export const deleteOrderlineApiHttpErrAction = (errObj) => {
  return {
    type: DELETE_ORDER_LINE_API_HTTP_ERR,
    payload: errObj,
  };
};

export const resetDeleteOrderlineApiHttpErrAction = () => {
  return {
    type: RESET_DELETE_ORDER_LINE_API_HTTP_ERR,
    payload: null,
  };
};

export const removeOrderLineItemFromListAction = (orderLineId) => {
  return {
    type: REMOVE_ORDER_LINE_ITEM_FROM_LIST,
    payload: orderLineId,
  };
};

export const editLineItemApiReqAction = (
  orderLineId,
  orderNo,
  sequence,
  itemId,
  itemNo,
  description1,
  description2,
  price,
  orderQty,
  taxes,
  notes,
  sync,
  companyId,
  scanCode,
  uom,
  deviceId,
  customerNo,
) => {
  let data = {
    orderLineId,
    orderNo,
    sequence,
    itemId,
    itemNo,
    description1,
    description2,
    price,
    orderQty,
    taxes,
    notes,
    sync,
    companyId,
    scanCode,
    uom,
    deviceId,
    customerNo,
  };

  return {
    type: LINE_ITEM_EDIT_API_REQ,
    payload: data,
  };
};

export const editLineItemApiSuccessAction = (response) => {
  return {
    type: LINE_ITEM_EDIT_API_RESPONSE,
    payload: response,
  };
};

export const resetEditLineItemApiResponseAction = () => {
  return {
    type: RESET_LINE_ITEM_EDIT_API_RESPONSE,
    payload: null,
  };
};

export const editLineItemApiFailErrAction = (errObj) => {
  return {
    type: LINE_ITEM_EDIT_API_FAIL_ERR,
    payload: errObj,
  };
};

export const resetEditLineItemApiFailErrAction = () => {
  return {
    type: RESET_LINE_ITEM_EDIT_API_FAIL_ERR,
    payload: null,
  };
};

export const editLineItemApiHttpErrAction = (errObj) => {
  return {
    type: LINE_ITEM_EDIT_API_HTTP_ERR,
    payload: errObj,
  };
};

export const resetLineItemApiHttpErrAction = () => {
  return {
    type: RESET_LINE_ITEM_EDIT_HTTP_ERR,
    payload: null,
  };
};

export const getOrderLineItemApiReqAction = (
  companyId,
  customerId,
  salesRepId,
) => {
  let data = {
    companyId,
    customerId,
    salesRepId,
  };

  return {
    type: GET_ORDER_LINE_DATA_API_REQ,
    payload: data,
  };
};

export const getOrderLineItemApiResponseAction = (response) => {
  return {
    type: GET_ORDER_LINE_DATA_API_RESPONSE,
    payload: response,
  };
};

export const resetGetOrderLineItemApiResponseAction = () => {
  return {
    type: RESET_GET_ORDER_LINE_DATA_API_RESPONSE,
    payload: null,
  };
};

export const getOrderLineItemApiFailErrAction = (errObj) => {
  return {
    type: GET_ORDER_LINE_API_FAIL_ERR,
    payload: errObj,
  };
};

export const resetGetOrderLineItemFailErrAction = () => {
  return {
    type: RESET_GET_ORDER_LINE_API_FAIL_ERR,
    payload: null,
  };
};

export const getOrderLineItemHttpErrAction = (errObj) => {
  return {
    type: GET_ORDER_LINE_API_HTTP_ERR,
    payload: errObj,
  };
};

export const resetGetOrderLineItemHttpAction = () => {
  return {
    type: RESET_GET_ORDER_LINE_API_HTTP_ERR,
    payload: null,
  };
};

export const setOrderLineItemListAction = (itemList) => {
  return {
    type: SET_ORDER_LINE_ITEM_LIST,
    payload: itemList,
  };
};

export const setCartTotalAction = (cartTotal) => {
  return {
    type: SET_CART_TOTAL,
    payload: cartTotal,
  };
};

export const setCartSubTotalAction = (subTotal) => {
  return {
    type: SET_CART_SUB_TOTAL,
    payload: subTotal,
  };
};

export const setCartTaxPercentAction = (taxPercent) => {
  return {
    type: SET_CART_TAX_PERCENT,
    payload: taxPercent,
  };
};

export const setCartTaxValueAction = (taxValue) => {
  return {
    type: SET_CART_TAX_VALUE,
    payload: taxValue,
  };
};

export const setOrderIdAction = (orderId) => {
  return {
    type: SET_ORDER_ID,
    payload: orderId,
  };
};

export const setCouponCodeAction = (couponCode) => {
  return {
    type: SET_COUPON_CODE,
    payload: couponCode,
  };
};

export const setRewardAmountAction = (amount) => {
  return {
    type: SET_REWARD_AMT,
    payload: amount,
  };
};

export const setRewardIdAction = (id) => {
  return {
    type: SET_REWARD_ID,
    payload: id,
  };
};

export const resetRewardIdAction = () => {
  return {
    type: RESET_REWARD_ID,
    payload: null,
  };
};

export const setTotalDueAmtAfterRewardAction = (amount) => {
  return {
    type: SET_TOTAL_DUE_AFTER_REWARD,
    payload: amount,
  };
};

export const setAmountReceivedAction = (amount) => {
  return {
    type: SET_AMOUNT_RECEIVED,
    payload: amount,
  };
};

export const setPaymentModeAction = (paymentMode) => {
  return {
    type: SET_PAYMENT_MODE,
    payload: paymentMode,
  };
};

export const setBalanceDueAction = (dueAmt) => {
  return {
    type: SET_BALANCE_DUE,
    payload: dueAmt,
  };
};

export const setCheckAmountAction = (checkAmt) => {
  return {
    type: SET_CHECK_AMOUNT,
    payload: checkAmt,
  };
};

export const setCheckNoAction = (checkNo) => {
  return {
    type: SET_CHECK_NO,
    payload: checkNo,
  };
};

export const setCashReceivedAction = (cashAmt) => {
  return {
    type: SET_CASH_RECEIVED,
    payload: cashAmt,
  };
};

export const setPoNoAction = (poNo) => {
  return {
    type: SET_PO_NO,
    payload: poNo
  }
}

export const setSignatoryNameAction = (name) => {
  return {
    type: SET_SIGNATORY_NAME,
    payload: name,
  };
};

export const setSignatureImgDataAction = (imgData) => {
  return {
    type: SET_SIGNATORY_IMAGE_DATA,
    payload: imgData,
  };
};

export const resetPaymentScreenDataAction = () => {
  return {
    type: RESET_ALL_PAYMENT_SCREEN_DATA,
    payload: null,
  };
};

export const setOrderNoAction = (orderNo) => {
  return {
    type: SET_ORDER_NO,
    payload: orderNo,
  };
};

export const setSequenceAction = (sequence) => {
  return {
    type: SET_SEQUENCE,
    payload: sequence,
  };
};

export const resetOrderLineStoreAction = () => {
  return {
    type: RESET_ORDER_LINE_STORE,
    payload: null,
  };
};
