import {
  ORDER_LINE_API_REQ,
  ORDER_LINE_API_SUCCESS,
  RESET_ORDER_LINE_API_RESPONSE,
  ORDER_LINE_API_FAIL_ERR,
  RESET_ORDER_LINE_API_FAIL_ERR,
  ORDER_LINE_API_HTTP_ERR,
  RESET_ORDER_LINE_API_HTTP_ERR,
  ADD_ITEM_TO_CART,
  DELETE_ORDER_LINE_API_REQ,
  DELETE_ORDER_LINE_API_SUCCESS,
  RESET_DELETE_ORDER_LINE_API_RESPONSE,
  DELETE_ORDER_LINE_API_FAIL_ERR,
  RESET_DELETE_ORDER_API_FAIL_ERR,
  DELETE_ORDER_LINE_API_HTTP_ERR,
  RESET_DELETE_ORDER_LINE_API_HTTP_ERR,
  REMOVE_ORDER_LINE_ITEM_FROM_LIST,
  LINE_ITEM_EDIT_API_REQ,
  LINE_ITEM_EDIT_API_RESPONSE,
  RESET_LINE_ITEM_EDIT_API_RESPONSE,
  LINE_ITEM_EDIT_API_FAIL_ERR,
  RESET_LINE_ITEM_EDIT_API_FAIL_ERR,
  LINE_ITEM_EDIT_API_HTTP_ERR,
  RESET_LINE_ITEM_EDIT_HTTP_ERR,
  GET_ORDER_LINE_DATA_API_REQ,
  GET_ORDER_LINE_DATA_API_RESPONSE,
  RESET_GET_ORDER_LINE_DATA_API_RESPONSE,
  GET_ORDER_LINE_API_FAIL_ERR,
  RESET_GET_ORDER_LINE_API_FAIL_ERR,
  GET_ORDER_LINE_API_HTTP_ERR,
  RESET_GET_ORDER_LINE_API_HTTP_ERR,
  SET_ORDER_LINE_ITEM_LIST,
  SET_CART_TOTAL,
  SET_CART_TAX_PERCENT,
  SET_CART_TAX_VALUE,
  SET_CART_SUB_TOTAL,
  SET_ORDER_ID,
  SET_COUPON_CODE,
  SET_REWARD_AMT,
  SET_TOTAL_DUE_AFTER_REWARD,
  SET_AMOUNT_RECEIVED,
  SET_PAYMENT_MODE,
  SET_BALANCE_DUE,
  SET_CHECK_AMOUNT,
  SET_CHECK_NO,
  SET_CASH_RECEIVED,
  SET_SIGNATORY_NAME,
  SET_SIGNATORY_IMAGE_DATA,
  RESET_ALL_PAYMENT_SCREEN_DATA,
  SET_REWARD_ID,
  RESET_REWARD_ID,
  SET_ORDER_NO,
  SET_SEQUENCE,
  RESET_ORDER_LINE_STORE,
  SET_PO_NO
} from '../../resources/constants/storeConstants';

const initialState = {
  //Add Line Item
  addOrderLineResponse: null,
  addOrderLineApiErr: null,
  addOrderLineHttpErr: null,

  //Delete Line Item
  deleteOrderLineApiResponse: null,
  deleteOrderLineApiFailErr: null,
  deleteOrderLineApiHttErr: null,

  //Edit Line Item
  editLineItemApiResponse: null,
  editLineItemApiFailErr: null,
  editLineItemApiHttpErr: null,

  // GetOrderlineItem API
  getOrderLineItemApiResponse: null,
  getOrderLineItemApiFailErr: null,
  getOrderLineItemApiHttpErr: null,

  //Order related data
  addedItemsList: [],
  cartTotal: null,
  cartSubTotal: null,
  cartTaxPercent: null,
  cartTaxValue: null,
  orderId: null,
  orderNo: null,
  sequence: 1,

  //Payment/Reward Screen data
  couponCode: null,
  rewardAmount: null,
  rewardId: null,
  totalDueAfterReward: null,
  amountReceived: null,
  paymentMode: null,
  balanceDue: null,
  checkAmount: null,
  checkNo: null,
  cashReceived: null,
  poNo: null,

  //Signature screen data
  signatoryName: null,
  signatorImageData: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
    case ORDER_LINE_API_REQ:
      return {
        ...state,
      };

    case ORDER_LINE_API_SUCCESS: {
      return {
        ...state,
        addOrderLineResponse: action.payload,
      };
    }

    case RESET_ORDER_LINE_API_RESPONSE: {
      return {
        ...state,
        addOrderLineResponse: null,
      };
    }

    case ORDER_LINE_API_FAIL_ERR: {
      return {
        ...state,
        addOrderLineApiErr: action.payload,
      };
    }

    case RESET_ORDER_LINE_API_FAIL_ERR: {
      return {
        ...state,
        addOrderLineApiErr: null,
      };
    }

    case ORDER_LINE_API_HTTP_ERR: {
      return {
        ...state,
        addOrderLineHttpErr: action.payload,
      };
    }

    case RESET_ORDER_LINE_API_HTTP_ERR: {
      return {
        ...state,
        addOrderLineHttpErr: null,
      };
    }

    case ADD_ITEM_TO_CART: {
      return {
        ...state,
        addedItemsList: [...state.addedItemsList, action.payload],
      };
    }

    case DELETE_ORDER_LINE_API_REQ: {
      return {
        ...state,
      };
    }

    case DELETE_ORDER_LINE_API_SUCCESS: {
      return {
        ...state,
        deleteOrderLineApiResponse: action.payload,
      };
    }

    case RESET_DELETE_ORDER_LINE_API_RESPONSE: {
      return {
        ...state,
        deleteOrderLineApiResponse: null,
      };
    }

    case DELETE_ORDER_LINE_API_FAIL_ERR: {
      return {
        ...state,
        deleteOrderLineApiFailErr: action.payload,
      };
    }

    case RESET_DELETE_ORDER_API_FAIL_ERR: {
      return {
        ...state,
        deleteOrderLineApiFailErr: null,
      };
    }

    case DELETE_ORDER_LINE_API_HTTP_ERR: {
      return {
        ...state,
        deleteOrderLineApiHttErr: action.payload,
      };
    }

    case RESET_DELETE_ORDER_LINE_API_HTTP_ERR: {
      return {
        ...state,
        deleteOrderLineApiHttErr: null,
      };
    }

    case GET_ORDER_LINE_DATA_API_REQ: {
      return {
        ...state,
      };
    }

    case GET_ORDER_LINE_DATA_API_RESPONSE: {
      return {
        ...state,
        getOrderLineItemApiResponse: action.payload,
      };
    }

    case RESET_GET_ORDER_LINE_DATA_API_RESPONSE: {
      return {
        ...state,
        getOrderLineItemApiResponse: null,
      };
    }

    case GET_ORDER_LINE_API_FAIL_ERR: {
      return {
        ...state,
        getOrderLineItemApiFailErr: action.payload,
      };
    }

    case RESET_GET_ORDER_LINE_API_FAIL_ERR: {
      return {
        ...state,
        getOrderLineItemApiFailErrL: null,
      };
    }

    case GET_ORDER_LINE_API_HTTP_ERR: {
      return {
        ...state,
        getOrderLineItemApiHttpErr: action.payload,
      };
    }

    case RESET_GET_ORDER_LINE_API_HTTP_ERR: {
      return {
        ...state,
        getOrderLineItemApiHttpErr: null,
      };
    }

    case REMOVE_ORDER_LINE_ITEM_FROM_LIST: {
      return {
        ...state,
        addedItemsList: state.addedItemsList.filter(
          (item) => item.OrderLineId !== action.payload,
        ),
      };
    }

    case LINE_ITEM_EDIT_API_REQ: {
      return {
        ...state,
      };
    }

    case LINE_ITEM_EDIT_API_RESPONSE: {
      return {
        ...state,
        editLineItemApiResponse: action.payload,
      };
    }

    case RESET_LINE_ITEM_EDIT_API_RESPONSE: {
      return {
        ...state,
        editLineItemApiResponse: action.payload,
      };
    }

    case LINE_ITEM_EDIT_API_FAIL_ERR: {
      return {
        ...state,
        editLineItemApiFailErr: action.payload,
      };
    }

    case RESET_LINE_ITEM_EDIT_API_FAIL_ERR: {
      return {
        ...state,
        editLineItemApiFailErr: null,
      };
    }

    case LINE_ITEM_EDIT_API_HTTP_ERR: {
      return {
        ...state,
        editLineItemApiHttpErr: action.payload,
      };
    }

    case RESET_LINE_ITEM_EDIT_HTTP_ERR: {
      return {
        ...state,
        editLineItemApiHttpErr: null,
      };
    }

    case SET_ORDER_LINE_ITEM_LIST: {
      return {
        ...state,
        addedItemsList: action.payload,
      };
    }

    case SET_CART_TOTAL: {
      return {
        ...state,
        cartTotal: action.payload,
      };
    }

    case SET_CART_SUB_TOTAL: {
      return {
        ...state,
        cartSubTotal: action.payload,
      };
    }

    case SET_CART_TAX_PERCENT: {
      return {
        ...state,
        cartTaxPercent: action.payload,
      };
    }

    case SET_CART_TAX_VALUE: {
      return {
        ...state,
        cartTaxValue: action.payload,
      };
    }

    case SET_ORDER_ID: {
      return {
        ...state,
        orderId: action.payload,
      };
    }

    case SET_ORDER_NO: {
      return {
        ...state,
        orderNo: action.payload,
      };
    }

    case SET_SEQUENCE: {
      return {
        ...state,
        sequence: action.payload,
      };
    }

    case SET_COUPON_CODE: {
      return {
        ...state,
        couponCode: action.payload,
      };
    }

    case SET_REWARD_AMT: {
      return {
        ...state,
        rewardAmount: action.payload,
      };
    }

    case SET_REWARD_ID: {
      return {
        ...state,
        rewardId: action.payload,
      };
    }

    case RESET_REWARD_ID: {
      return {
        ...state,
        rewardId: null,
      };
    }

    case SET_TOTAL_DUE_AFTER_REWARD: {
      return {
        ...state,
        totalDueAfterReward: action.payload,
      };
    }

    case SET_AMOUNT_RECEIVED: {
      return {
        ...state,
        amountReceived: action.payload,
      };
    }

    case SET_PAYMENT_MODE: {
      return {
        ...state,
        paymentMode: action.payload,
      };
    }

    case SET_BALANCE_DUE: {
      return {
        ...state,
        balanceDue: action.payload,
      };
    }

    case SET_CHECK_AMOUNT: {
      return {
        ...state,
        checkAmount: action.payload,
      };
    }

    case SET_CHECK_NO: {
      return {
        ...state,
        checkNo: action.payload,
      };
    }

    case SET_CASH_RECEIVED: {
      return {
        ...state,
        cashReceived: action.payload,
      };
    }

    case SET_PO_NO: {
      return {
        ...state,
        poNo: action.payload,
      }
    }

    case SET_SIGNATORY_NAME: {
      return {
        ...state,
        signatoryName: action.payload,
      };
    }

    case SET_SIGNATORY_IMAGE_DATA: {
      return {
        ...state,
        signatorImageData: action.payload,
      };
    }

    case RESET_ALL_PAYMENT_SCREEN_DATA: {
      return {
        ...state,
        couponCode: null,
        rewardAmount: null,
        rewardId: null,
        totalDueAfterReward: null,
        amountReceived: null,
        paymentMode: null,
        balanceDue: null,
        checkAmount: null,
        checkNo: null,
        cashReceived: null,
      };
    }

    case RESET_ORDER_LINE_STORE: {
      return initialState;
    }

    default:
      return state;
  }
};
