import {takeLatest, takeLeading, call, put} from 'redux-saga/effects';
import {api} from '../../api';
import {
  addOrderLineApiSuccessAction,
  addOrderLineApiErrAction,
  addOrderLineHttpErrAction,
  deleteOrderlineApiSuccessAction,
  deleteOrderlineApiFailAction,
  deleteOrderlineApiHttpErrAction,
  editLineItemApiSuccessAction,
  editLineItemApiFailErrAction,
  editLineItemApiHttpErrAction,
  getOrderLineItemApiResponseAction,
  getOrderLineItemApiFailErrAction,
  getOrderLineItemHttpErrAction,
} from './orderLineAction';
import {
  OK,
  FAIL,
  ORDER_LINE_API_REQ,
  RESPONSE_ISSUE,
  DELETE_ORDER_LINE_API_REQ,
  GET_ORDER_LINE_DATA_API_REQ,
  LINE_ITEM_EDIT_API_REQ,
} from '../../resources/constants/storeConstants';

function* fetchAddOrderLineApiReq({
  payload: {
    orderLineId,
    orderNo,
    sequence,
    itemId,
    itemNo,
    description1,
    description2,
    price,
    orderQty,
    taxes,
    notes,
    sync,
    companyId,
    scanCode,
    uom,
    deviceId,
    customerNo,
    customerId,
    repId
  },
}) {
  try {
    const response = yield call(
      {context: api, fn: api.addOrderLineApi},
      orderLineId,
      orderNo,
      sequence,
      itemId,
      itemNo,
      description1,
      description2,
      price,
      orderQty,
      taxes,
      notes,
      sync,
      companyId,
      scanCode,
      uom,
      deviceId,
      customerNo,
      customerId,
      repId
    );

    if (response.data.response.reasonCode === OK) {
      let orderLineRes = JSON.parse(response.data.response.dataList);
      console.log('AddOrderLine API response - ', orderLineRes);
      yield put(addOrderLineApiSuccessAction(orderLineRes));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(addOrderLineApiErrAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errorObj) {
    console.log('Error in addOrderLine Api', errorObj);
    yield put(addOrderLineHttpErrAction(errorObj));
  }
}

function* deleteOrderLineApiRequest({payload: {orderLineId}}) {
  const response = yield call(
    {context: api, fn: api.deleteOrderLineApi},
    orderLineId,
  );

  try {
    if (response.data.response.reasonCode === OK) {
      let data = JSON.parse(response.data.response.dataList);
      console.log('DeleteOrderLine API response --', data);
      yield put(deleteOrderlineApiSuccessAction(data));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(deleteOrderlineApiFailAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errObj) {
    console.log('Error in deleteOrderLine api', errObj);
    yield put(deleteOrderlineApiHttpErrAction(errObj));
  }
}

function* editOrderLineItemApiRequest({
  payload: {
    orderLineId,
    orderNo,
    sequence,
    itemId,
    itemNo,
    description1,
    description2,
    price,
    orderQty,
    taxes,
    notes,
    sync,
    companyId,
    scanCode,
    uom,
    deviceId,
    customerNo,
  },
}) {
  try {
    const response = yield call(
      {context: api, fn: api.addOrderLineApi},
      orderLineId,
      orderNo,
      sequence,
      itemId,
      itemNo,
      description1,
      description2,
      price,
      orderQty,
      taxes,
      notes,
      sync,
      companyId,
      scanCode,
      uom,
      deviceId,
      customerNo,
    );

    if (response.data.response.reasonCode === OK) {
      let orderLineRes = JSON.parse(response.data.response.dataList);
      console.log('AddOrderLine API response - ', orderLineRes);
      yield put(editLineItemApiSuccessAction(orderLineRes));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(editLineItemApiFailErrAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errorObj) {
    console.log('Error in addOrderLine Api', errorObj);
    yield put(editLineItemApiHttpErrAction(errorObj));
  }
}

function* getOrderLineItemApiRequest({
  payload: {companyId, customerId, salesRepId},
}) {
  const response = yield call(
    {context: api, fn: api.getOrderLineDataApi},
    companyId,
    customerId,
    salesRepId,
  );

  try {
    if (response.data.response.reasonCode === OK) {
      let itemsList = JSON.parse(response.data.response.dataList);
      console.log('GerOrderLineData API response - ', itemsList);
      yield put(getOrderLineItemApiResponseAction(itemsList));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(getOrderLineItemApiFailErrAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errObj) {
    console.log('Error in getOrderLineData api', errObj);
    yield put(getOrderLineItemHttpErrAction(errObj));
  }
}

export default function* watcherSaga() {
  yield takeLatest(ORDER_LINE_API_REQ, fetchAddOrderLineApiReq);
  yield takeLatest(DELETE_ORDER_LINE_API_REQ, deleteOrderLineApiRequest);
  yield takeLatest(LINE_ITEM_EDIT_API_REQ, editOrderLineItemApiRequest);
  yield takeLatest(GET_ORDER_LINE_DATA_API_REQ, getOrderLineItemApiRequest);
}
