import {
  GET_REWARD_AMOUNT_API_REQ,
  GET_REWARD_AMOUNT_API_SUCCESS,
  GET_REWARD_AMOUNT_API_FAIL_ERR,
  RESET_GET_REWARD_AMOUNT_API_FAIL_ERR,
  GET_REWARD_AMOUNT_API_HTTP_ERR,
  RESET_GET_REWARD_AMOUNT_API_HTTP_ERR,
  RESET_REWARD_REDUX_STATE
} from '../../resources/constants/storeConstants';

export const getRewardAmountApiReqAction = (
  customerId,
  companyId,
  rewardCode,
) => {
  let data = {
    customerId,
    companyId,
    rewardCode,
  };

  return {
    type: GET_REWARD_AMOUNT_API_REQ,
    payload: data,
  };
};

export const getRewardApiSuccessAction = (response) => {
  return {
    type: GET_REWARD_AMOUNT_API_SUCCESS,
    payload: response,
  };
};

export const getRewardApiFailErrAction = (errObj) => {
  return {
    type: GET_REWARD_AMOUNT_API_FAIL_ERR,
    payload: errObj,
  };
};

export const resetGetAmountApiFailErrAction = () => {
  return {
    type: RESET_GET_REWARD_AMOUNT_API_FAIL_ERR,
    payload: null,
  };
};

export const getRewardApiHttpErrAction = (errObj) => {
  return {
    type: GET_REWARD_AMOUNT_API_HTTP_ERR,
    payload: errObj,
  };
};

export const resetRewardApiHttpErrAction = () => {
  return {
    type: RESET_GET_REWARD_AMOUNT_API_HTTP_ERR,
    payload: null,
  };
};

export const resetRewardReduxStateAction = () => {
  return {
    type: RESET_REWARD_REDUX_STATE,
    payload: null
  }
}
