import {
  GET_REWARD_AMOUNT_API_REQ,
  GET_REWARD_AMOUNT_API_SUCCESS,
  GET_REWARD_AMOUNT_API_FAIL_ERR,
  RESET_GET_REWARD_AMOUNT_API_FAIL_ERR,
  GET_REWARD_AMOUNT_API_HTTP_ERR,
  RESET_GET_REWARD_AMOUNT_API_HTTP_ERR,
  RESET_REWARD_REDUX_STATE
} from '../../resources/constants/storeConstants';

const initialState = {
  getRewardApiResponse: null,
  getRewardApiHttpErr: null,
  getRewardApiFailErr: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
    case GET_REWARD_AMOUNT_API_REQ:
      return state;

    case GET_REWARD_AMOUNT_API_SUCCESS: {
      return {
        ...state,
        getRewardApiResponse: action.payload,
      };
    }

    case GET_REWARD_AMOUNT_API_FAIL_ERR: {
      return {
        ...state,
        getRewardApiFailErr: action.payload,
      };
    }

    case RESET_GET_REWARD_AMOUNT_API_FAIL_ERR: {
      return {
        ...state,
        getRewardApiFailErr: null,
      };
    }

    case GET_REWARD_AMOUNT_API_HTTP_ERR: {
      return {
        ...state,
        getRewardApiHttpErr: action.payload,
      };
    }

    case RESET_GET_REWARD_AMOUNT_API_HTTP_ERR: {
      return {
        ...state,
        getRewardApiHttpErr: null,
      };
    }

    case RESET_REWARD_REDUX_STATE: {
      return {
        initialState
      }
    }

    default:
      return state;
  }
};
