import {takeLatest, takeLeading, call, put} from 'redux-saga/effects';
import {api} from '../../api';

import {
  getRewardApiSuccessAction,
  getRewardApiFailErrAction,
  getRewardApiHttpErrAction,
} from '../Reward/rewardAction';
import {
  GET_REWARD_AMOUNT_API_REQ,
  OK,
  FAIL,
  RESPONSE_ISSUE,
} from '../../resources/constants/storeConstants';

function* fetchGetRewardAmountApi({
  payload: {customerId, companyId, rewardCode},
}) {
  const response = yield call(
    {context: api, fn: api.getRewardAmountApi},
    customerId,
    companyId,
    rewardCode,
  );

  try {
    if (response.data.response.reasonCode === OK) {
      let rewardRespone = JSON.parse(response.data.response.dataList);
      console.log('GetRewardAmout API response -', rewardRespone);
      yield put(getRewardApiSuccessAction(rewardRespone));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(getRewardApiFailErrAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errObj) {
    console.log('Error in getRewardAmount Api saga', errObj);
    yield put(getRewardApiHttpErrAction(errObj));
  }
}

export default function* watcherSaga() {
  yield takeLatest(GET_REWARD_AMOUNT_API_REQ, fetchGetRewardAmountApi);
}
