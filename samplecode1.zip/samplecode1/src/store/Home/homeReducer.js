import {HOME_SCREEN_HTTP_FAIL_RESET, HOME_SCREEN_REQUEST_FAIL} from "../../resources/constants/storeConstants";
const initialState = {
   homeScreenApiError: null,
};

export default (state = initialState, action) => {
    switch (action.type) {
        case HOME_SCREEN_REQUEST_FAIL: {
            return {...state, homeScreenApiError: action.payload };
        }
        case HOME_SCREEN_HTTP_FAIL_RESET: {
            return {...state, homeScreenApiError: null };
        }
        default:
            return state;
    }
};
