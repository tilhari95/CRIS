import {HOME_SCREEN_HTTP_FAIL_RESET} from "../../resources/constants/storeConstants";

export const resetHomeHttpApiError = () => {
    return({
        type: HOME_SCREEN_HTTP_FAIL_RESET,
        payload:'' });
};
