import {
  CUSTOMER_GEOLOCATION_REQUEST,
  CUSTOMER_ON_SCROLL_RESET,
  CUSTOMER_REQUEST_SUCCESS,
  FETCH_CUSTOMER_ON_SCROLL_REQUEST,
  FETCH_CUSTOMER_REQUEST,
  HTTP_CUSTOMER_API_ERROR_RESET,
  RESET_CUSTOMER_SEARCH_REQUEST,
  SEARCH_CUSTOMER_REQUEST,
  SET_CUSTOMER_REDUX_INITIAL_STATE,
  SELECTED_CUSTOMER,
  RESET_SELECTED_CUSTOMER,
} from '../../resources/constants/storeConstants';

export const customerListRequest = (
  companyId,
  deviceId,
  cursorIndex,
  searchText,
) => {
  let payload = {companyId, deviceId, cursorIndex, searchText};
  return {
    type: FETCH_CUSTOMER_REQUEST,
    payload: payload,
  };
};

export const customerListRequestOnScroll = (
  companyId,
  deviceId,
  cursorIndex,
  searchText = '',
) => {
  let payload = {companyId, deviceId, cursorIndex, searchText};
  return {
    type: FETCH_CUSTOMER_ON_SCROLL_REQUEST,
    payload: payload,
  };
};

export const resetOnScrollRequest = () => {
  return {
    type: CUSTOMER_ON_SCROLL_RESET,
    payload: '',
  };
};

export const customerSearchRequest = (
  companyId,
  deviceId,
  cursorIndex,
  searchText,
) => {
  let payload = {companyId, deviceId, cursorIndex, searchText};
  return {
    type: SEARCH_CUSTOMER_REQUEST,
    payload: payload,
  };
};

export const resetCustomerSearchRequest = () => {
  let payload = '';
  return {
    type: RESET_CUSTOMER_SEARCH_REQUEST,
    payload: payload,
  };
};

export const customerListToRedux = (list) => {
  return {
    type: CUSTOMER_REQUEST_SUCCESS,
    payload: list,
  };
};

export const resetCustomerRedux = () => {
  return {
    type: SET_CUSTOMER_REDUX_INITIAL_STATE,
    payload: '',
  };
};

export const requestCustomerGeoLocation = (lat, long, companyId, deviceId) => {
  let payload = {lat, long, companyId, deviceId};
  return {
    type: CUSTOMER_GEOLOCATION_REQUEST,
    payload: payload,
  };
};

export const resetCustomerHttpApiError = () => {
  return {
    type: HTTP_CUSTOMER_API_ERROR_RESET,
    payload: '',
  };
};

export const selectCustomerAction = (customer) => {
  return {
    type: SELECTED_CUSTOMER,
    payload: customer,
  };
};

export const resetSelectedCustomerAction = () => {
  return {
    type: RESET_SELECTED_CUSTOMER,
    payload: '',
  };
};
