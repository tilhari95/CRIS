import {
  CUSTOMER_REQUEST_SUCCESS,
  CUSTOMER_REQUEST_FAIL,
  HTTP_CUSTOMER_API_ERROR,
  HTTP_CUSTOMER_API_ERROR_RESET,
  SET_CUSTOMER_REDUX_INITIAL_STATE,
  CUSTOMER_ON_SCROLL_RESET,
  CUSTOMER_ON_SCROLL_REQUEST_SUCCESS,
  CUSTOMER_SEARCH_REQUEST_SUCCESS,
  CUSTOMER_GEOLOCATION_SUCCESS, RESET_CUSTOMER_SEARCH_REQUEST,
  SELECTED_CUSTOMER,
  RESET_SELECTED_CUSTOMER
} from '../../resources/constants/storeConstants';
import {Status} from '../../api';

const initialState = {
  customerApiSuccessResponse: null,
  customerApiFailError: null,
  customerApiHttpError: null,
  customerOnScrollApiSuccess: null,
  customerOnScrollApiFail: null,
  customerSearchList: null,
  customerGeolocationSuccess: null,
  selectedCustomer: null
};

export default (state = initialState, action) => {
  switch (action.type) {
    case CUSTOMER_REQUEST_SUCCESS: {
      return {
        ...state,
        customerApiSuccessResponse: action.payload,
      };
    }
    case CUSTOMER_REQUEST_FAIL: {
      return {...state, customerApiFailError: action.payload};
    }
    case HTTP_CUSTOMER_API_ERROR: {
      return {...state, customerApiHttpError: action.payload};
    }
    case CUSTOMER_ON_SCROLL_REQUEST_SUCCESS: {
      return {
        ...state,
        customerOnScrollApiSuccess: action.payload,
      };
    }
    case CUSTOMER_ON_SCROLL_RESET: {
      return {
        ...state,
        customerOnScrollApiSuccess: null,
      };
    }
    case HTTP_CUSTOMER_API_ERROR_RESET:
      return {
        ...state,
        customerApiHttpError: null,
      };
    case CUSTOMER_SEARCH_REQUEST_SUCCESS:
      return {
        ...state,
        customerSearchList: action.payload,
      };
    case SET_CUSTOMER_REDUX_INITIAL_STATE: {
      return {...state, ...initialState};
    }
    case CUSTOMER_GEOLOCATION_SUCCESS: {
      return {...state, customerGeolocationSuccess: action.payload};
    }
    case RESET_CUSTOMER_SEARCH_REQUEST:{
      return{...state, customerSearchList: null}
    }
    case SELECTED_CUSTOMER: {
      return {
        ...state,
        selectedCustomer: action.payload
      }
    }
    case RESET_SELECTED_CUSTOMER: {
      return {
        ...state,
        selectedCustomer: null
      }
    }
    default:
      return state;
  }
};
