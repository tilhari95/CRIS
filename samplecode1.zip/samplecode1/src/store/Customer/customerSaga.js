import {takeLatest, takeEvery,takeLeading, call, put} from 'redux-saga/effects';
import {api} from '../../api';
import {
    OK,
    FAIL,
    FETCH_CUSTOMER_REQUEST,
    CUSTOMER_REQUEST_SUCCESS,
    FETCH_CUSTOMER_ON_SCROLL_REQUEST,
    CUSTOMER_ON_SCROLL_REQUEST_SUCCESS,
    SEARCH_CUSTOMER_REQUEST,
    CUSTOMER_GEOLOCATION_REQUEST,
    CUSTOMER_SEARCH_REQUEST_SUCCESS,
    CUSTOMER_GEOLOCATION_SUCCESS, HOME_SCREEN_REQUEST_FAIL, ASYNC_FAIL, RESPONSE_ISSUE, HTTP_CUSTOMER_API_ERROR
} from '../../resources/constants/storeConstants';
import {saveCustomersToRealM} from "../../realm/Models/customerModel";

function* fetchCustomerRequest({payload: {companyId, deviceId, cursorIndex, searchText} }) {
    try {
        const response = yield call(
            {context: api, fn: api.CustomerListApi},
            companyId, deviceId, cursorIndex, searchText
        );
        if (response.data.response.reasonCode === OK) {
            let CustomerList= JSON.parse(response.data.response.dataList);
            console.log(CustomerList);
            const saveCustomerListToRealM= yield call(saveCustomersToRealM, CustomerList);
            if(saveCustomerListToRealM === true)
                yield put({type: CUSTOMER_REQUEST_SUCCESS, payload: CustomerList});
            else
                console.log('error in saving customer list in realM');
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_CUSTOMER_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log("error on customer api--->>>>>v first dfetch");
        console.log(errorObj);
       yield put({type: HTTP_CUSTOMER_API_ERROR, payload: errorObj});
    }
}


function* fetchCustomerOnScrollRequest({ payload: {companyId, deviceId, cursorIndex} }) {
    try {
        const response = yield call(
            {context: api, fn: api.CustomerListApi},companyId, deviceId, cursorIndex
        );
        if (response.data.response.reasonCode === OK) {
            let CustomerList= JSON.parse(response.data.response.dataList);
            console.log('new customer list', CustomerList);
           const saveCustomerListToRealM= yield call(saveCustomersToRealM, CustomerList);
            if(saveCustomerListToRealM === true)
                yield put({type: CUSTOMER_ON_SCROLL_REQUEST_SUCCESS, payload: CustomerList});
            else
                console.log('error in saving customer list in realM');
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_CUSTOMER_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log("error on customer api 3333");
        console.log(errorObj);
        yield put({type: HTTP_CUSTOMER_API_ERROR, payload: errorObj});
    }
}
function* searchCustomerRequest({ payload: {companyId, deviceId, cursorIndex, searchText} }) {
    try {
        const response = yield call(
            {context: api, fn: api.CustomerListApi},companyId, deviceId, cursorIndex, searchText
        );
        if (response.data.response.reasonCode === OK) {
            let searchedCustomerList= JSON.parse(response.data.response.dataList);
            console.log('searched customer list', searchedCustomerList);
            yield put({type: CUSTOMER_SEARCH_REQUEST_SUCCESS, payload: searchedCustomerList});
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_CUSTOMER_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log("error on customer api 7878787");
        console.log(errorObj);
        yield put({type: HTTP_CUSTOMER_API_ERROR, payload: errorObj});
    }
}

function* customerGeolocationRequest({ payload: {lat, long, companyId, deviceId} }) {
    try {
        const response = yield call(
            {context: api, fn: api.customerGeolocationApi}, lat, long, companyId, deviceId);
        if (response.data.response.reasonCode === OK){
            let customerGeolocationList= JSON.parse(response.data.response.dataList);
            console.log('customer geodata -->', customerGeolocationList);
            yield put({type: CUSTOMER_GEOLOCATION_SUCCESS, payload: customerGeolocationList});
        } else if(response.data.response.reasonCode === FAIL){
            yield put({type: HOME_SCREEN_REQUEST_FAIL, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log("error on customer api 4444");//TODO
        console.log(errorObj);
         yield put({type: HOME_SCREEN_REQUEST_FAIL, payload: errorObj});
    }
}


export default function* watcherSaga() {
    yield takeLeading(FETCH_CUSTOMER_REQUEST, fetchCustomerRequest);
    yield takeLatest(FETCH_CUSTOMER_ON_SCROLL_REQUEST, fetchCustomerOnScrollRequest);
    yield takeLatest(SEARCH_CUSTOMER_REQUEST, searchCustomerRequest);
    yield takeLatest(CUSTOMER_GEOLOCATION_REQUEST, customerGeolocationRequest);

}
