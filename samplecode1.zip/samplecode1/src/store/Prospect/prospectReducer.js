import {
    PROSPECT_REQUEST_SUCCESS,
    PROSPECT_REQUEST_FAIL,
    SET_PROSPECT_REDUX_INITIAL_STATE,
    HTTP_PROSPECT_API_ERROR_RESET,
    PROSPECT_ON_SCROLL_RESET,
    HTTP_PROSPECT_API_ERROR,
    PROSPECT_ON_SCROLL_REQUEST_SUCCESS,
    PROSPECT_SEARCH_REQUEST_SUCCESS,
    RESET_SEARCH_PROSPECT_REQUEST,
    PROSPECT_STAGE_SUCCESS,
    RESET_ROUTE_ADD_EDIT_STATE,
    RESET_PROSPECT_ADD_EDIT_STATE,
    PROSPECT_ADD_EDIT_SUCCESS,
    PROSPECT_DECISION_SUCCESS,
    PROSPECT_HEADER_LIST_SUCCESS, PROSPECT_DECISION_MAKER_RESET, PROSPECT_HEADER_LIST_RESET

} from '../../resources/constants/storeConstants';

const initialState = {
    prospectApiSuccessResponse: null,
    prospectApiFailError: null,
    prospectApiHttpError: null,
    prospectOnScrollApiSuccess: null,
    prospectOnScrollApiFail: null,
    prospectSearchList: null,
    prospectStage: null,
    prospectAddEditSuccess: null,
    decisionMakerSuccess:null,
    prospectHeaderListSuccess: null

};

export default (state = initialState, action) => {
    switch (action.type) {
        case PROSPECT_REQUEST_SUCCESS: {
            return {
                ...state,
                prospectApiSuccessResponse: action.payload,
            };
        }
        case PROSPECT_REQUEST_FAIL: {
            return {...state, prospectApiFailError: action.payload};
        }
        case HTTP_PROSPECT_API_ERROR: {
            return {...state, prospectApiHttpError: action.payload};
        }
        case PROSPECT_ON_SCROLL_REQUEST_SUCCESS: {
            return {
                ...state,
                prospectOnScrollApiSuccess: action.payload,
            };
        }
        case PROSPECT_ON_SCROLL_RESET: {
            return {
                ...state,
                prospectOnScrollApiSuccess: null,
            };
        }
        case HTTP_PROSPECT_API_ERROR_RESET:
            return {
                ...state,
                prospectApiHttpError: null,
            };
        case PROSPECT_SEARCH_REQUEST_SUCCESS:
            return {
                ...state,
                prospectSearchList: action.payload,
            };
        case RESET_SEARCH_PROSPECT_REQUEST:
            return{
            ...state,
                prospectSearchList: null
        }
        case SET_PROSPECT_REDUX_INITIAL_STATE: {
            return {...state, prospectApiSuccessResponse: null,
                prospectApiFailError: null,
                prospectApiHttpError: null,
                prospectOnScrollApiSuccess: null,
                prospectOnScrollApiFail: null,
                prospectSearchList: null,};
        };
        case PROSPECT_STAGE_SUCCESS:{
            return {...state, prospectStage: action.payload};
        }
        case PROSPECT_ADD_EDIT_SUCCESS:{
            return {...state, prospectAddEditSuccess: action.payload};
        }
        case RESET_PROSPECT_ADD_EDIT_STATE:{
            return { ...state, prospectAddEditSuccess: null }
        }
        case PROSPECT_DECISION_SUCCESS:{
            return {...state, decisionMakerSuccess: action.payload};
        }
        case PROSPECT_HEADER_LIST_SUCCESS:{
            return {...state, prospectHeaderListSuccess: action.payload};
        }
        case PROSPECT_HEADER_LIST_RESET:{
            return {...state, prospectHeaderListSuccess: null};
        }
        case PROSPECT_DECISION_MAKER_RESET:{
            return {...state, decisionMakerSuccess: null};
        }


        default:
            return state;
    }
};
