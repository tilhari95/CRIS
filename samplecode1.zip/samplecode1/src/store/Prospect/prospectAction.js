import {
    FETCH_PROSPECT_REQUEST,
    SEARCH_PROSPECT_REQUEST,
    FETCH_PROSPECT_ON_SCROLL_REQUEST,
    PROSPECT_ON_SCROLL_RESET,
    HTTP_PROSPECT_API_ERROR_RESET,
    SET_PROSPECT_REDUX_INITIAL_STATE,
    PROSPECT_REQUEST_SUCCESS,
    RESET_SEARCH_PROSPECT_REQUEST,
    PROSPECT_STAGE_REQUEST,
    PROSPECT_ADD_EDIT_REQUEST,
    RESET_PROSPECT_ADD_EDIT_STATE,
    PROSPECT_HEADER_LIST_REQUEST,
    PROSPECT_DECISION_MAKER_REQUEST,
    PROSPECT_HEADER_LIST_RESET,
    PROSPECT_DECISION_MAKER_RESET

} from "../../resources/constants/storeConstants";

export const prospectListRequest = (ERPRepCode, cursorIndex, searchText) => {
    let payload= { ERPRepCode, cursorIndex, searchText};
    return({
        type: FETCH_PROSPECT_REQUEST,
        payload:payload });
};

export const prospectListRequestOnScroll = (ERPRepCode, cursorIndex, searchText='') => {
    let payload= { ERPRepCode, cursorIndex, searchText};
    return({
        type: FETCH_PROSPECT_ON_SCROLL_REQUEST,
        payload:payload });
};

export const resetProspectOnScrollRequest = () => {
    return({
        type: PROSPECT_ON_SCROLL_RESET,
        payload: '' });
};

export const prospectSearchRequest = (ERPRepCode, cursorIndex, searchText) => {
    let payload= { ERPRepCode, cursorIndex, searchText};
    return({
        type: SEARCH_PROSPECT_REQUEST,
        payload: payload });
};

export const prospectStageRequest = (companyId) => {
    let payload= { companyId};
    return({
        type: PROSPECT_STAGE_REQUEST,
        payload: payload });
};

export const resetProspectSearchRequest = () => {
    let payload='';
    return({
        type: RESET_SEARCH_PROSPECT_REQUEST,
        payload: payload });
};


export const prospectListToRedux = (list) => {
    return({
        type: PROSPECT_REQUEST_SUCCESS,
        payload:list });
};

export const resetProspectRedux = () => {
    return({
        type:SET_PROSPECT_REDUX_INITIAL_STATE,
        payload:'' });
}

export const addEditProspectRequest = (prospectObj) => {
    return({
        type:PROSPECT_ADD_EDIT_REQUEST,
        payload:prospectObj });
}


export const resetProspectAddEditSuccess =() =>{
    return({
        type:RESET_PROSPECT_ADD_EDIT_STATE,
        payload:'' });
}


export const resetProspectHttpApiError = () => {
    return({
        type: HTTP_PROSPECT_API_ERROR_RESET,
        payload:'' });
};


export const prospectHeaderListRequest = (companyId) =>{
    let payload= { companyId};
    return({
        type: PROSPECT_HEADER_LIST_REQUEST,
        payload: payload
    })
}



export const decisionMakerApiRequest = (prospectId) =>{
    let payload= { prospectId};
    return({
        type: PROSPECT_DECISION_MAKER_REQUEST,
        payload: payload
    })
}


export const resetProspectHeaderState = () =>{
    return({
        type: PROSPECT_HEADER_LIST_RESET,
        payload: ''
    })
}

export const resetDecisionMakerState = () =>{
    return({
        type: PROSPECT_DECISION_MAKER_RESET,
        payload: ''
    })
}
