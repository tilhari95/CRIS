import {takeLatest, takeEvery,takeLeading, call, put} from 'redux-saga/effects';
import {api} from '../../api';
import {
    OK,
    FAIL,
    FETCH_PROSPECT_ON_SCROLL_REQUEST,
    FETCH_PROSPECT_REQUEST,
    SEARCH_PROSPECT_REQUEST,
    PROSPECT_REQUEST_SUCCESS,
    RESPONSE_ISSUE,
    HTTP_PROSPECT_API_ERROR,
    PROSPECT_ON_SCROLL_REQUEST_SUCCESS,
    PROSPECT_SEARCH_REQUEST_SUCCESS,
    PROSPECT_STAGE_SUCCESS,
    PROSPECT_STAGE_REQUEST,
    ROUTE_ADD_EDIT_SUCCESS,
    HTTP_ROUTE_API_ERROR,
    PROSPECT_ADD_EDIT_REQUEST,
    PROSPECT_ADD_EDIT_SUCCESS,
    PROSPECT_DECISION_MAKER_REQUEST,
    PROSPECT_DECISION_SUCCESS, PROSPECT_HEADER_LIST_SUCCESS, PROSPECT_HEADER_LIST_REQUEST

} from '../../resources/constants/storeConstants';
import {saveProspectToRealM} from "../../realm/Models/prospectModel";

function* fetchProspectRequest({payload: { ERPRepCode, cursorIndex, searchText} }) {
    try {
        const response = yield call(
            {context: api, fn: api.ProspectListApi},
            ERPRepCode, cursorIndex, searchText
        );
        if (response.data.response.reasonCode === OK) {
            let ProspectList= JSON.parse(response.data.response.dataList);
            console.log(ProspectList);
            const saveProspectListToRealM= yield call(saveProspectToRealM, ProspectList);
            if(saveProspectListToRealM === true){
                yield put({type: PROSPECT_REQUEST_SUCCESS, payload: ProspectList});
            }
           else{
                console.log('error in saving prospect 1st req list in realM');
            }
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_PROSPECT_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log("error on customer api prsopect 1111");
        console.log(errorObj);
         yield put({type: HTTP_PROSPECT_API_ERROR, payload: errorObj});
    }
}


function* fetchProspectOnScrollRequest({ payload: {ERPRepCode, cursorIndex} }) {
    try {
        const response = yield call(
            {context: api, fn: api.ProspectListApi},ERPRepCode, cursorIndex
        );
        if (response.data.response.reasonCode === OK) {
            let ProspectList= JSON.parse(response.data.response.dataList);
            console.log('new customer list', ProspectList);
            const saveProspectListToRealM= yield call(saveProspectToRealM, ProspectList);
            if(saveProspectListToRealM === true){
                yield put({type: PROSPECT_ON_SCROLL_REQUEST_SUCCESS, payload: ProspectList});
            }
            else
                console.log('error in saving prospect on scroll list in realM');
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_PROSPECT_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log("error on customer api prsopect 22");
        console.log(errorObj);
        yield put({type: HTTP_PROSPECT_API_ERROR, payload: errorObj});
    }
}



function* searchProspectRequest({ payload: {ERPRepCode, cursorIndex, searchText} }) {
    try {
        console.log('inside searchProspectRequest function');
        const response = yield call(
            {context: api, fn: api.ProspectListApi},ERPRepCode, cursorIndex, searchText
        );
        if (response.data.response.reasonCode === OK) {
            let searchedProspectList= JSON.parse(response.data.response.dataList);
            console.log('searched customer list', searchedProspectList);
            yield put({type: PROSPECT_SEARCH_REQUEST_SUCCESS, payload: searchedProspectList});
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_PROSPECT_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log("error on customer api prospect 33");
        console.log(errorObj);
        yield put({type: HTTP_PROSPECT_API_ERROR, payload: errorObj});
    }
}


function* prospectStageRequest({ payload: {companyId} }) {
    try {
        const response = yield call(
            {context: api, fn: api.prospectStageApi},companyId);
        if (response.data.response.reasonCode === OK) {
            let prospectStageList= JSON.parse(response.data.response.dataList);
            //console.log('prospect stage list', prospectStageList);
            yield put({type: PROSPECT_STAGE_SUCCESS, payload: prospectStageList});
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_PROSPECT_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log("error on api prospect stage");
        console.log(errorObj);
       // yield put({type: HTTP_PROSPECT_API_ERROR, payload: errorObj});
    }
}

function* addEditProspectRequest(obj) {
    try {
        let payload= obj.payload;
        // console.log("addEditRouteRequestsaga", payload.id + " " + payload.companyId + " " +  payload.routeName  + " " +  payload.description  + " " +  payload.every
        //     + " " + payload.frequency  + " " +  payload.sequence);
        const response = yield call(
            {context: api, fn: api.AddEditProspectApi}, payload
        );
        if (response.data.response.reasonCode === OK) {
            //let RouteList= JSON.parse(response.data.response.dataList);
            //console.log(RouteList);
            yield put({type: PROSPECT_ADD_EDIT_SUCCESS, payload: response.data.response});
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_PROSPECT_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log("error on prospect add edit api");
        console.log(errorObj);
        yield put({type: HTTP_PROSPECT_API_ERROR, payload: errorObj});
    }
}

function* prospectDecisionMakerRequest({ payload: {prospectId} }) {
    try {
        const response = yield call(
            {context: api, fn: api.prospectDecisionMakerApi},prospectId);
        if (response.data.response.reasonCode === OK) {
            let dMList= JSON.parse(response.data.response.dataList);
            yield put({type: PROSPECT_DECISION_SUCCESS, payload: dMList});
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_PROSPECT_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log("error on api prospect DECISION");
        console.log(errorObj);
        yield put({type: HTTP_PROSPECT_API_ERROR, payload: errorObj});
    }
}

function* prospectStepHeaderRequest({ payload: {companyId} }) {
    try {
        const response = yield call(
            {context: api, fn: api.prospectStageHeaderListApi},companyId);
        if (response.data.response.reasonCode === OK) {
            let prospectHeaderList= JSON.parse(response.data.response.dataList);
            console.log('prospect prospectHeaderList list', prospectHeaderList);
            yield put({type: PROSPECT_HEADER_LIST_SUCCESS, payload: prospectHeaderList});
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_PROSPECT_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log("error on api prospectStepHeaderRequest ");
        console.log(errorObj);
        yield put({type: HTTP_PROSPECT_API_ERROR, payload: errorObj});
    }
}



export default function* watcherSaga() {
    yield takeLeading(FETCH_PROSPECT_REQUEST, fetchProspectRequest);
    yield takeLatest(FETCH_PROSPECT_ON_SCROLL_REQUEST, fetchProspectOnScrollRequest);
    yield takeLatest(SEARCH_PROSPECT_REQUEST, searchProspectRequest);
    yield takeLeading(PROSPECT_STAGE_REQUEST, prospectStageRequest);
    yield takeLatest(PROSPECT_ADD_EDIT_REQUEST, addEditProspectRequest);
    yield takeLatest(PROSPECT_DECISION_MAKER_REQUEST, prospectDecisionMakerRequest);
    yield takeLatest(PROSPECT_HEADER_LIST_REQUEST, prospectStepHeaderRequest);




}
