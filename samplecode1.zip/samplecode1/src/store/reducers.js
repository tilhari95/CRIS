import {combineReducers} from "redux";
import loginReducer from "./Login/loginReducer";
import resetPasswordReducer from "./ResetPassword/resetPasswordReducer";
import customerReducer from "./Customer/customerReducer";
import homeReducer from "./Home/homeReducer";
import salesGrowthReducer from "./SalesGrowth/salesGrowthReducer";
import routeReducer from "./Route/routeReducer";
import prospectReducer from "./Prospect/prospectReducer";
import routeStopReducer from "./Route/routeStopReducer";
import customerDetailReducer from './CustomerDetail/customerDetailReducer';
import itemReducer from './item/itemReducer';
import itemHistoryReducer from './itemHistory/itemHistoryReducer';
import hotKeysReducer from './hotKeys/hotKeysReducer'
import templateReducer from './template/templateReducer';
import shippingAddressReducer from './shippingAddress/shippingAddressReducer';
import orderLineReducer from './OrderLine/orderLineReducer';
import orderHeaderReducer from './OrderHeader/orderHeaderReducer';
import rewardReducer from './Reward/rewardReducer';

export default combineReducers({
     login: loginReducer,
     resetPassword: resetPasswordReducer,
     customer: customerReducer,
     home: homeReducer,
     salesGrowth: salesGrowthReducer,
     route:  routeReducer,
     prospect: prospectReducer,
     routeStop: routeStopReducer,
     customerDetail: customerDetailReducer,
     items: itemReducer,
     itemsHistory: itemHistoryReducer,
     hotKeys: hotKeysReducer,
     template: templateReducer,
     shippingAddress: shippingAddressReducer,
     orderLine: orderLineReducer,
     orderHeader: orderHeaderReducer,
     reward: rewardReducer
     // productPage: productPageReducer,
    // cart: cartReducer,
    // message: messageReducer,
    // logout:logoutReducer,
    // spiff: spiffReducer,
    // loginIntermediate: loginIntermediateReducer,
    // orderHistory: orderHistoryReducer
});
