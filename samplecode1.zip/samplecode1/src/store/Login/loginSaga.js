/* eslint-disable prettier/prettier */
import { takeLatest, takeEvery, call, put } from 'redux-saga/effects';
import { api } from '../../api';
import {
    LOGIN_REQUEST_LOADING,
    LOGIN_REQUEST_SUCCESS,
    LOGIN_REQUEST_FAIL,
    LOGIN_REQUEST,
    USER_BRAND_REQUEST,
    GET_BRAND_SUCCESS,
    OK,
    FAIL,
    HTTP_API_ERROR,
    ASYNC_FAIL,
    GENERIC_FAIL,
    INTERMEDIATE_PAGE_HTTP_ERROR,
    BRAND_REQUEST_FAIL,
    BRAND_REQUEST_SUCCESS,
    SIDE_MENU_REQUEST_SUCCESS, USER_SIDE_MENU_REQUEST
} from '../../resources/constants/storeConstants';
import {checkAndUpdateSessionToken, checkAndUpdateUserBrandData} from "../../realm/Models/loginModel";
import AppAsyncStorage from '../../api/helper/AppAsyncStorage';
// import {
//     CART_LIST, LAST_PRODUCT_UPDATE_DATE,
//     LOGGED_IN_EMAIL,
//     PRODUCT_LIST,
//     SESSION_TOKEN,
//     USER_BRAND_DATA,
// } from '../../resources/constants/asyncKeys';
import {validateRequiredField} from '../../utils/validators';
import {AUTO_LOGGED_OUT, SIDE_MENU_RAW_JSON} from "../../resources/constants/asyncKeys";
import {NO} from "../../resources/constants/stringConstants";
import {resetAppData} from "../../services/onAuthService";



const checkAndSetUserAsync = async() =>{
    try{
        await AppAsyncStorage.setValue(AUTO_LOGGED_OUT, NO);
        return true;
    }
    catch(error){
        console.log(error);
        return false;
    }
}
const setSideMenuToAsync = async (sideMenuData) =>{
    try{
        await AppAsyncStorage.setValue(SIDE_MENU_RAW_JSON, sideMenuData);
        console.log('menu item is saved successfully in async');
        return true;
    }
    catch(error){
        console.log(error);
        return false;
    }
}

const wfunc = async (email, token) =>{
    let bool = await checkAndUpdateSessionToken(email, token);
    console.log('bool is ---> ' + bool);
    return bool;
}


// const saveBrandAsync= async(brandData, companyId, templateId) =>{
//     try {
//         let prevLoginBrandData = await AppAsyncStorage.getValue(USER_BRAND_DATA);
//         debugger;
//         if (validateRequiredField(prevLoginBrandData)) {
//         debugger;
//             // to check if user logged out due to sesionexpire or any way and now again logging with same id company and temp -->
//             // dont reset its cart and product list in that case, reset only when new diffrent useror company or template
//             let prevBrandData = JSON.parse(prevLoginBrandData);
//             debugger;
//             if ((prevBrandData.CompanyId && prevBrandData.CompanyId !== companyId) ||
//                 (prevBrandData.AppTemplateHeaderId && prevBrandData.AppTemplateHeaderId !== templateId)) {
//                 await AppAsyncStorage.setValue(PRODUCT_LIST, '');
//                 await AppAsyncStorage.setValue(CART_LIST, '');
//                 await AppAsyncStorage.setValue(LAST_PRODUCT_UPDATE_DATE, '');
//             }
//         }
//             await AppAsyncStorage.setValue(USER_BRAND_DATA, brandData);
//             return true;
//     }
//     catch{
//         console.log(error);
//         return false;
//     }
//
// }

// worker saga: Fetch Trending repositories when watcher saga sees the action
function* fetchLoginRequest({ payload: { email, password } }) {
    try {
        //debugger;
       // yield put({ type: LOGIN_REQUEST_LOADING });
        const response = yield call({ context: api, fn: api.loginApi }, email, password);
         if(response.data.response.reasonCode === OK){
             const loginRealMFlags= yield call(checkAndUpdateSessionToken, email, response.data.response.token );
             console.log('saveSessionToRealM    ', loginRealMFlags)
         if(loginRealMFlags.savedSuccess === true){
                console.log("key is safed---->>>");
                console.log(response.data.response.token);
                if(loginRealMFlags.userChanged === true){
                    let resetBool = yield call(resetAppData(false));
                }
                let userAsyncBool = yield call(checkAndSetUserAsync);

                if(userAsyncBool){
                    yield put({type: LOGIN_REQUEST_SUCCESS, payload: {responseData: response.data.response}});

                }
                }
             else{
                 yield put({ type: HTTP_API_ERROR, payload:  {errorType: ASYNC_FAIL} });
             }
       }
         else if(response.data.response.reasonCode === FAIL){
             yield put({type: LOGIN_REQUEST_FAIL, payload: {responseData: response.data.response}});
         }
         // todo code for internal server error went wrong if reasoncode is 0 but reasonText is some other server internal error
    }
    catch (errorObj) {
        console.log('error in login api-->')
        yield put({ type: HTTP_API_ERROR, payload: errorObj });
    }
}

function* fetchUserBrandRequest({ payload: { email } }) {
    try {
        debugger;
        const response = yield call({ context: api, fn: api.userBrandApi });
        if(response.data.response.reasonCode === OK ){
            // debugger;
            let userBrandData= JSON.parse(response.data.response.dataList);
            console.log(userBrandData);
            const saveBrandDataToRealM= yield call(checkAndUpdateUserBrandData, email, userBrandData);
            console.log('saveBrandDataToRealM    ' + saveBrandDataToRealM);
          if(saveBrandDataToRealM === true) {
              yield put({type: BRAND_REQUEST_SUCCESS, payload: userBrandData});
           }
            else{
              yield put({ type: HTTP_API_ERROR, payload:  {errorType: ASYNC_FAIL} });
            }
        }
        else{
            yield put({type: BRAND_REQUEST_FAIL, payload: {responseData: response.data.response}});
        }
    }
    catch (errorObj) {
    //debugger;
        yield put({ type: HTTP_API_ERROR, payload: errorObj });
    }

}

function* fetchUserSideMenuRequest({ payload: { email } }) {
    try {
    debugger;
        const response = yield call({ context: api, fn: api.userSideMenuApi }, email);
        if(response.data.response.reasonCode === OK ){
            // debugger;
            let userSideMenuData= JSON.parse(response.data.response.dataList);
            console.log('raw side menu data' + userSideMenuData);
            let sideMenuAsyncBool = yield call(setSideMenuToAsync, response.data.response.dataList);
            if(sideMenuAsyncBool === true) {
                yield put({type: SIDE_MENU_REQUEST_SUCCESS, payload: userSideMenuData});
            }
            else{
                yield put({ type: HTTP_API_ERROR, payload:  {errorType: ASYNC_FAIL} });
            }
        }
        else{
           // yield put({type: HTTP_API_ERROR, payload: );
        }
    }
    catch (errorObj) {
        //debugger;
        yield put({ type: HTTP_API_ERROR, payload: errorObj });
    }
}




// watcher saga: watches for actions dispatched to the store, starts worker saga
export default function* watcherSaga() {
    yield takeLatest(LOGIN_REQUEST, fetchLoginRequest);
    yield takeLatest(USER_BRAND_REQUEST, fetchUserBrandRequest);
    yield takeLatest(USER_SIDE_MENU_REQUEST, fetchUserSideMenuRequest);
}


// const response = yield call({ context: api, fn: api.loginApi }, date);
