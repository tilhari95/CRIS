/* eslint-disable prettier/prettier */

import {
    PASSWORD_ENTERED,
    LOGIN_REQUEST_SUCCESS,
    LOGIN_REQUEST_FAIL,
    EMAIL_ENTERED,
    LOGIN_REQUEST_LOADING,
    BRAND_REQUEST_SUCCESS,
    BRAND_REQUEST_FAIL,
    SET_LOGIN_INITIAL_STATE,
    HTTP_API_ERROR, RESET_HTTP_API_ERROR, SET_LOGIN_INITIAL_STATE_ON_LOGOUT, RESET_BRAND_SUCCESS_RESPONSE,
    SET_SESSION_AND_DATA_FROM_DB, SIDE_MENU_REQUEST_SUCCESS,
} from '../../resources/constants/storeConstants';

const initialState = {
    loginSuccessResponse: null,
    loginFailError: null,
    password: null,
    email:null,
    brandSuccessResponse: null,
    brandFailError: null,
    httpError:null,
    sessionToken:null,
    sideMenuDataResponseSuccess: null
};

export default (state = initialState, action) => {
    switch (action.type) {
        case SET_SESSION_AND_DATA_FROM_DB:
            return{...state, sessionToken: action.payload.userBData.sessionToken, brandSuccessResponse: action.payload.userBData,
                sideMenuDataResponseSuccess: action.payload.sideMData}
        case EMAIL_ENTERED:
            return {...state, email: action.payload}
        case PASSWORD_ENTERED:
            return { ...state, password: action.payload };
        case LOGIN_REQUEST_SUCCESS: {
            // console.log(state.sessionToken);
            // console.log(action.payload);
            return { ...state, sessionToken: action.payload.responseData.token, loginSuccessResponse: action.payload, };
        }
        case LOGIN_REQUEST_FAIL: {
            return { ...state, loginFailError: action.payload};
        }
        case LOGIN_REQUEST_LOADING: {
            return {...state, }
        }
        case BRAND_REQUEST_SUCCESS: {
            return { ...state, brandSuccessResponse: action.payload };
        }
        case BRAND_REQUEST_FAIL: {
            return { ...state, brandFailError: action.payload };
        }
        case HTTP_API_ERROR:{
            return { ...state, httpError: action.payload }
        }
        case RESET_HTTP_API_ERROR:{
            return { ...state, httpError: null }
        }
        case SET_LOGIN_INITIAL_STATE:{
            return {...state, ...initialState};
        }
        case SIDE_MENU_REQUEST_SUCCESS:{
            return {...state, sideMenuDataResponseSuccess: action.payload}
        }
        case SET_LOGIN_INITIAL_STATE_ON_LOGOUT:{
            return {...state, loginSuccessResponse: null,
                loginFailError: null,
                password: null,
                email:null,
                status: Status.DEFAULT,
                brandFailError: null,
                httpError:null,
                sessionToken:null,
            //    sideMenuDataResponseSuccess:null
            };
        }
        case RESET_BRAND_SUCCESS_RESPONSE:{
            return {...state, brandSuccessResponse: null, };
        }
        default:
            return state;
    }
};
