import {takeLatest, call, put} from 'redux-saga/effects';
import {api} from '../../api';

import {
  FAIL,
  HOTKEYS_LIST_API_REQUEST,
  OK,
  RESPONSE_ISSUE,
  HOTKEY_ITEMS_API_REQUEST,
} from '../../resources/constants/storeConstants';

import {
  hotKeysListApiErrorAction,
  hotKeysListApiHttpErrorAction,
  hotKeysListApiSuccessAction,
  getHotKeyItemsApiSuccessAction
} from '../hotKeys/hotKeysAction';

function* fetchHotKeysListApiRequest({payload: {companyId}}) {
  try {
    const response = yield call(
      {context: api, fn: api.getHotKeyGroupListApi},
      companyId,
    );

    if (response.data.response.reasonCode === OK) {
      let hotKeysList = JSON.parse(response.data.response.dataList);
      console.log('HotKeys Group List', hotKeysList);
      yield put(hotKeysListApiSuccessAction(hotKeysList));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(hotKeysListApiErrorAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errorObj) {
    console.log('Error in fetchHotKeysListApiRequest', errorObj);
    yield put(hotKeysListApiHttpErrorAction(errorObj));
  }
}

function* fetchHotKeyItemsApiRequest({
  payload: {hotKeyHeaderId, companyId, customerId},
}) {
  try {
    const response = yield call(
      {context: api, fn: api.getHotKeyItemsApi},
      hotKeyHeaderId,
      companyId,
      customerId,
    );

    if (response.data.response.reasonCode === OK) {
      let hotKeyItems = JSON.parse(response.data.response.dataList);
      console.log('HotKey Items List', hotKeyItems);
      yield put(getHotKeyItemsApiSuccessAction(hotKeyItems));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(hotKeysListApiErrorAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errorObj) {
    console.log('Error in fetchHotKeysListApiRequest', errorObj);
    yield put(hotKeysListApiHttpErrorAction(errorObj));
  }
}

export default function* watcherSaga() {
  yield takeLatest(HOTKEYS_LIST_API_REQUEST, fetchHotKeysListApiRequest);
  yield takeLatest(HOTKEY_ITEMS_API_REQUEST, fetchHotKeyItemsApiRequest);
}
