import {
  HOTKEYS_LIST_API_REQUEST,
  HOTKEYS_LIST_API_SUCCESS,
  RESET_HOTKEYS_LIST,
  HOTKEYS_LIST_API_ERROR,
  RESET_HOTKEYS_LIST_API_ERROR,
  HOTKEYS_LIST_HTTP_ERROR,
  RESET_HOTKEYS_LIST_HTTP_ERROR,
  HOTKEY_ITEMS_API_REQUEST,
  HOTKEY_ITEMS_API_SUCCESS,
  RESET_HOTKEY_ITEMS_API_RESPONSE,
  RESET_HOTKEYS_STORE
} from '../../resources/constants/storeConstants';

export const getHotKeysListApiReqAction = (companyId) => {
  let data = {
    companyId,
  };

  return {
    type: HOTKEYS_LIST_API_REQUEST,
    payload: data,
  };
};

export const hotKeysListApiSuccessAction = (hotKeysList) => {
  return {
    type: HOTKEYS_LIST_API_SUCCESS,
    payload: hotKeysList,
  };
};

export const resetHotKeysListAction = () => {
  return {
    type: RESET_HOTKEYS_LIST,
    payload: '',
  };
};

export const hotKeysListApiErrorAction = (errorObj) => {
  return {
    type: HOTKEYS_LIST_API_ERROR,
    payload: errorObj,
  };
};

export const resetHotKeysApiErrorAction = () => {
  return {
    type: RESET_HOTKEYS_LIST_API_ERROR,
    payload: '',
  };
};

export const hotKeysListApiHttpErrorAction = (errorObj) => {
  return {
    type: HOTKEYS_LIST_HTTP_ERROR,
    payload: errorObj,
  };
};

export const resetHotKeysApiHttpErrorAction = () => {
  return {
    type: RESET_HOTKEYS_LIST_HTTP_ERROR,
    payload: '',
  };
};

export const getHotKeyItemsApiRequestAction = (
  hotKeyHeaderId,
  companyId,
  customerId,
) => {
  let data = {
    hotKeyHeaderId,
    companyId,
    customerId,
  };

  return {
    type: HOTKEY_ITEMS_API_REQUEST,
    payload: data,
  };
};

export const getHotKeyItemsApiSuccessAction = (hotKeyItems) => {
  return {
    type: HOTKEY_ITEMS_API_SUCCESS,
    payload: hotKeyItems,
  };
};

export const resetHotKeyItemResponseAction = () => {
  return {
    type: RESET_HOTKEY_ITEMS_API_RESPONSE,
    payload: '',
  };
};

export const resetHotkeysStore = () => {
  return {
    type: RESET_HOTKEYS_STORE,
    payload: ''
  }
}