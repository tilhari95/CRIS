import {
  HOTKEYS_LIST_API_REQUEST,
  HOTKEYS_LIST_API_SUCCESS,
  RESET_HOTKEYS_LIST,
  HOTKEYS_LIST_API_ERROR,
  RESET_HOTKEYS_LIST_API_ERROR,
  HOTKEYS_LIST_HTTP_ERROR,
  RESET_HOTKEYS_LIST_HTTP_ERROR,
  HOTKEY_ITEMS_API_REQUEST,
  HOTKEY_ITEMS_API_SUCCESS,
  RESET_HOTKEY_ITEMS_API_RESPONSE,
  RESET_HOTKEYS_STORE
} from '../../resources/constants/storeConstants';

const initialState = {
  hotKeysList: null,
  hotKeysListApiError: null,
  hotKeysListHttpError: null,
  hotKeyItems: null
};

export default (state = initialState, action) => {
  switch (action.type) {
    case HOTKEYS_LIST_API_REQUEST: {
      return {
        ...state,
      };
    }

    case HOTKEYS_LIST_API_SUCCESS: {
      return {
        ...state,
        hotKeysList: action.payload,
      };
    }

    case RESET_HOTKEYS_LIST: {
      return {
        ...state,
        hotKeysList: null,
      };
    }

    case HOTKEYS_LIST_API_ERROR: {
      return {
        ...state,
        hotKeysListApiError: action.payload,
      };
    }

    case RESET_HOTKEYS_LIST_API_ERROR: {
      return {
        ...state,
        hotKeysListApiError: null,
      };
    }

    case HOTKEYS_LIST_HTTP_ERROR: {
      return {
        ...state,
        hotKeysListHttpError: action.payload,
      };
    }

    case RESET_HOTKEYS_LIST_HTTP_ERROR: {
      return {
        ...state,
        hotKeysListHttpError: null,
      };
    }

    case HOTKEY_ITEMS_API_REQUEST: {
      return {
        ...state
      }
    }

    case HOTKEY_ITEMS_API_SUCCESS: {
      return {
        ...state,
        hotKeyItems: action.payload
      }
    }

    case RESET_HOTKEY_ITEMS_API_RESPONSE: {
      return {
        ...state,
        hotKeysList: null
      }
    }

    case RESET_HOTKEYS_STORE: {
      return {
        initialState
      }
    }

    default:
      return state;
  }
};
