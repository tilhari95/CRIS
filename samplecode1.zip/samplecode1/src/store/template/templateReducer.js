import {
  TEMPLATE_LIST_API_REQUEST,
  TEMPLATE_LIST_API_SUCCESS,
  RESET_TEMPLATE_LIST_API_RESPONSE,
  TEMPLATE_LIST_API_ERROR,
  RESET_TEMPLATE_LIST_API_ERROR,
  TEMPLATE_LIST_API_HTTP_ERROR,
  RESET_TEMPLATE_LIST_API_HTTP_ERROR,
  TEMPLATE_ITEM_API_REQUEST,
  TEMPLATE_ITEM_API_SUCCESS,
  RESET_TEMPLATE_ITEM_API_RESPONSE,
  TEMPLATE_ITEM_API_ERROR,
  RESET_TEMPLATE_ITEM_API_ERROR,
  TEMPLATE_ITEM_API_HTTP_ERROR,
  RESET_TEMPLATE_ITEM_API_HTTP_ERROR,
  RESET_TEMPLATE_STORE_TO_INITIAL
} from '../../resources/constants/storeConstants';

const initialState = {
  templateList: null,
  templateListApiFailError: null,
  templateListApiHttpError: null,

  templateItemList: null,
  templateItemApiFailError: null,
  templateItemHttpApiError: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
    case TEMPLATE_LIST_API_REQUEST: {
      return {
        ...state,
      };
    }

    case TEMPLATE_LIST_API_SUCCESS: {
      return {
        ...state,
        templateList: action.payload,
      };
    }

    case RESET_TEMPLATE_LIST_API_RESPONSE: {
      return {
        ...state,
        templateList: null,
      };
    }

    case TEMPLATE_LIST_API_ERROR: {
      return {
        ...state,
        templateListApiFailError: action.payload,
      };
    }

    case RESET_TEMPLATE_LIST_API_ERROR: {
      return {
        ...state,
        templateListApiFailError: null,
      };
    }

    case TEMPLATE_LIST_API_HTTP_ERROR: {
      return {
        ...state,
        templateListApiHttpError: action.payload,
      };
    }

    case RESET_TEMPLATE_LIST_API_HTTP_ERROR: {
      return {
        ...state,
        templateListApiHttpError: null,
      };
    }

    case TEMPLATE_ITEM_API_REQUEST: {
      return {
        ...state,
      };
    }

    case TEMPLATE_ITEM_API_SUCCESS: {
      return {
        ...state,
        templateItemList: action.payload,
      };
    }

    case RESET_TEMPLATE_ITEM_API_RESPONSE: {
      return {
        ...state,
        templateItemList: null,
      };
    }

    case TEMPLATE_ITEM_API_ERROR: {
      return {
        ...state,
        templateItemApiFailError: payload.action,
      };
    }

    case RESET_TEMPLATE_ITEM_API_ERROR: {
      return {
        ...state,
        templateItemApiFailError: null,
      };
    }

    case TEMPLATE_ITEM_API_HTTP_ERROR: {
      return {
        ...state,
        templateItemHttpApiError: action.payload,
      };
    }

    case RESET_TEMPLATE_ITEM_API_HTTP_ERROR: {
      return {
        ...state,
        templateItemHttpApiError: null,
      };
    }

    case RESET_TEMPLATE_STORE_TO_INITIAL: {
      return {
        initialState
      }
    }

    default:
      return state;
  }
};
