import {takeLatest, call, put} from 'redux-saga/effects';
import {api} from '../../api';

import {
  FAIL,
  FETCH_ORDER_INVOICE,
  OK,
  RESPONSE_ISSUE,
  TEMPLATE_LIST_API_REQUEST,
  TEMPLATE_ITEM_API_REQUEST,
} from '../../resources/constants/storeConstants';

import {
  getTemplateListApiSuccessAction,
  templateListApiFailAction,
  templateListApiHttpErrorAction,
  templateItemApiHttpErrorAction,
  templateItemApiFailFrrorAction,
  templateItemApiRequestSuccessAction,
} from '../template/templateAction';

function* fetchTemplateListApiRequest({payload: {companyId}}) {
  try {
    const response = yield call(
      {context: api, fn: api.getTemplateListApi},
      companyId,
    );

    if (response.data.response.reasonCode === OK) {
      let templateList = JSON.parse(response.data.response.dataList);
      console.log('Template List - ', templateList);
      yield put(getTemplateListApiSuccessAction(templateList));
    } else if (response.data.response.reasonCode == FAIL) {
      yield put(templateListApiFailAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errorObj) {
    console.log('Error in fetchTemplateListApiRequest', errorObj);
    yield put(templateListApiHttpErrorAction(errorObj));
  }
}

function* fetchTemplateItemApiRequest({
  payload: {templateId, companyId, customerId},
}) {
  try {
    const response = yield call(
      {context: api, fn: api.getTemplateItemsListApi},
      templateId,
      companyId,
      customerId,
    );

    if (response.data.response.reasonCode === OK) {
      let templateItem = JSON.parse(response.data.response.dataList);
      console.log('Template Item - ', templateItem);
      yield put(templateItemApiRequestSuccessAction(templateItem));
    } else if (response.data.response.reasonCode === FAIL) {
      yield put(templateItemApiFailFrrorAction({errorType: RESPONSE_ISSUE}));
    }
  } catch (errorObj) {
    console.log('Error in fetchTemplateItemApiRequest', errorObj);
    yield put(templateItemApiHttpErrorAction(errorObj));
  }
}

export default function* watcherSaga() {
  yield takeLatest(TEMPLATE_LIST_API_REQUEST, fetchTemplateListApiRequest);
  yield takeLatest(TEMPLATE_ITEM_API_REQUEST, fetchTemplateItemApiRequest);
}
