import {
  TEMPLATE_LIST_API_REQUEST,
  TEMPLATE_LIST_API_SUCCESS,
  RESET_TEMPLATE_LIST_API_RESPONSE,
  TEMPLATE_LIST_API_ERROR,
  RESET_TEMPLATE_LIST_API_ERROR,
  TEMPLATE_LIST_API_HTTP_ERROR,
  RESET_TEMPLATE_LIST_API_HTTP_ERROR,
  TEMPLATE_ITEM_API_REQUEST,
  TEMPLATE_ITEM_API_SUCCESS,
  RESET_TEMPLATE_ITEM_API_RESPONSE,
  TEMPLATE_ITEM_API_ERROR,
  RESET_TEMPLATE_ITEM_API_ERROR,
  TEMPLATE_ITEM_API_HTTP_ERROR,
  RESET_TEMPLATE_ITEM_API_HTTP_ERROR,
  RESET_TEMPLATE_STORE_TO_INITIAL
} from '../../resources/constants/storeConstants';

export const getTemplateListApiRequestAction = (companyId) => {
  let data = {
    companyId,
  };

  return {
    type: TEMPLATE_LIST_API_REQUEST,
    payload: data,
  };
};

export const getTemplateListApiSuccessAction = (templateList) => {
  return {
    type: TEMPLATE_LIST_API_SUCCESS,
    payload: templateList,
  };
};

export const resetTemplateListResponseAction = () => {
  return {
    type: RESET_TEMPLATE_LIST_API_RESPONSE,
    payload: '',
  };
};

export const templateListApiFailAction = (errorObj) => {
  return {
    type: TEMPLATE_LIST_API_ERROR,
    payload: errorObj,
  };
};

export const resetTemplateListApiFailAction = () => {
  return {
    type: RESET_TEMPLATE_LIST_API_ERROR,
    payload: '',
  };
};

export const templateListApiHttpErrorAction = (errorObj) => {
  return {
    type: TEMPLATE_LIST_API_HTTP_ERROR,
    payload: errorObj,
  };
};

export const resetTemplateListApiHttpErrorAction = () => {
  return {
    type: RESET_TEMPLATE_LIST_API_HTTP_ERROR,
    payload: '',
  };
};

export const templateItemApiRequestAction = (
  templateId,
  companyId,
  customerId,
) => {
  let data = {
    templateId,
    companyId,
    customerId,
  };
  return {
    type: TEMPLATE_ITEM_API_REQUEST,
    payload: data,
  };
};

export const templateItemApiRequestSuccessAction = (itemList) => {
  return {
    type: TEMPLATE_ITEM_API_SUCCESS,
    payload: itemList,
  };
};

export const resetTemplateItemRequestSuccessAction = () => {
  return {
    type: RESET_TEMPLATE_ITEM_API_RESPONSE,
    payload: '',
  };
};

export const templateItemApiFailFrrorAction = (errorObj) => {
  return {
    type: TEMPLATE_ITEM_API_ERROR,
    payload: errorObj,
  };
};

export const resetTemplateItemApiFailErrorAction = () => {
  return {
    type: RESET_TEMPLATE_ITEM_API_ERROR,
    payload: '',
  };
};

export const templateItemApiHttpErrorAction = (errorObj) => {
  return {
    type: TEMPLATE_ITEM_API_HTTP_ERROR,
    payload: errorObj,
  };
};

export const resetTemplateItemApiHttpErrorAction = () => {
  return {
    type: RESET_TEMPLATE_ITEM_API_HTTP_ERROR,
    payload: '',
  };
};

export const resetTemplateToInitialStateAction = () => {
  return {
    type: RESET_TEMPLATE_STORE_TO_INITIAL,
    payload: ''
  }
}
