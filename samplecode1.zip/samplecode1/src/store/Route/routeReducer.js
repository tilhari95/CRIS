/* eslint-disable prettier/prettier */

import {
    HTTP_ROUTE_API_ERROR, HTTP_ROUTE_API_ERROR_RESET, RESET_ROUTE_ADD_EDIT_STATE, ROUTE_ADD_EDIT_SUCCESS,
    ROUTE_REQUEST_SUCCESS, ROUTE_STOP_REQUEST_SUCCESS, ROUTE_STOP_RESET,
    SET_ROUTE_REDUX_INITIAL_STATE,
} from '../../resources/constants/storeConstants';

const initialState = {
    routeSuccessResponse: null,
    httpRouteApiError:null,
    routeAddEditSuccess: null,
    routeStopSuccess:null,
};

export default (state = initialState, action) => {
    switch (action.type) {
        case ROUTE_REQUEST_SUCCESS: {
            return { ...state, routeSuccessResponse: action.payload, };
        }
        case ROUTE_ADD_EDIT_SUCCESS: {
            return { ...state, routeAddEditSuccess: action.payload, };
        }
        case HTTP_ROUTE_API_ERROR:{
            return { ...state, httpRouteApiError: action.payload }
        }
        case HTTP_ROUTE_API_ERROR_RESET:{
            return { ...state, httpRouteApiError: null }
        }
        case SET_ROUTE_REDUX_INITIAL_STATE:{
            return {...state, ...initialState};
        }
        case RESET_ROUTE_ADD_EDIT_STATE:{
            return { ...state, routeAddEditSuccess: null }
        }
        case ROUTE_STOP_REQUEST_SUCCESS:{
            return { ...state, routeStopSuccess: action.payload }
        }
        case ROUTE_STOP_RESET:{
            return { ...state, routeStopSuccess: null }
        }
        default:
            return state;
    }
};
