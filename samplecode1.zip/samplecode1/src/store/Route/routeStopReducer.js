/* eslint-disable prettier/prettier */

import {
    ADD_ROUTE_STOP_SUCCESS, ADD_ROUTE_STOP_SUCCESS_RESET, DELETE_ROUTE_STOP_SUCCESS,
    HTTP_ROUTE_STOP_API_ERROR, HTTP_ROUTE_STOP_API_ERROR_RESET, RESET_DELETE_STOP_SUCCESS,
    RESET_ROUTE_ADD_EDIT_STATE, RESET_SEARCH_CUSTOMER_ROUTE_STOP_REQUEST,
    SEARCH_CUSTOMER_ROUTE_STOP_REQUEST_SUCCESS,
    SET_ROUTE_REDUX_INITIAL_STATE, SET_ROUTE_STOP_REDUX_INITIAL_STATE,
} from '../../resources/constants/storeConstants';

const initialState = {
    httpRouteStopApiError:null,
    routeStopCustomerSearchSuccess:null,
    addRouteStopSuccess:null,
    deleteRouteSuccess:null,
};

export default (state = initialState, action) => {
    switch (action.type) {
        case SEARCH_CUSTOMER_ROUTE_STOP_REQUEST_SUCCESS: {
            return { ...state, routeStopCustomerSearchSuccess: action.payload, };
        }
        case RESET_SEARCH_CUSTOMER_ROUTE_STOP_REQUEST:{
            return { ...state, routeStopCustomerSearchSuccess: null, };
        }
        case HTTP_ROUTE_STOP_API_ERROR:{
            return { ...state, httpRouteStopApiError: action.payload }
        }
        case HTTP_ROUTE_STOP_API_ERROR_RESET:{
            return { ...state, httpRouteStopApiError: null }
        }
        case SET_ROUTE_STOP_REDUX_INITIAL_STATE:{
            return {...state, ...initialState};
        }
        case ADD_ROUTE_STOP_SUCCESS:{
            return { ...state, addRouteStopSuccess: action.payload }
        }
        case ADD_ROUTE_STOP_SUCCESS_RESET:{
            return { ...state, addRouteStopSuccess:null }
        }
        case DELETE_ROUTE_STOP_SUCCESS:{
            return { ...state, deleteRouteSuccess:action.payload }
        }
        // imp-->
        case RESET_DELETE_STOP_SUCCESS:{
            return { ...state, deleteRouteSuccess:null }
        }

        default:
            return state;
    }
};
