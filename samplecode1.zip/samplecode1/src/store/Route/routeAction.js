import {
    ADD_EDIT_ROUTE_REQUEST, ADD_ROUTE_STOP_SUCCESS_RESET, DELETE_ROUTE_STOP_REQUEST,
    FETCH_ROUTES_REQUEST,
    HTTP_ROUTE_API_ERROR_RESET, HTTP_ROUTE_STOP_API_ERROR_RESET, RESET_DELETE_STOP_SUCCESS,
    RESET_ROUTE_ADD_EDIT_STATE, RESET_SEARCH_CUSTOMER_ROUTE_STOP_REQUEST,
    ROUTE_REQUEST_SUCCESS, ROUTE_STOP_ADD,
    ROUTE_STOP_LIST,
    ROUTE_STOP_RESET,
    SEARCH_CUSTOMER_REQUEST,
    SEARCH_CUSTOMER_ROUTE_STOP_REQUEST,
    SET_ROUTE_REDUX_INITIAL_STATE
} from "../../resources/constants/storeConstants";

export const routesListRequest = (companyId) => {
    let payload= { companyId};
    return({
        type: FETCH_ROUTES_REQUEST,
        payload:payload });
};

export const resetRouteHttpApiError = () => {
    return({
        type: HTTP_ROUTE_API_ERROR_RESET,
        payload:'' });
};

export const routeListToRedux = (list) => {
    return({
        type: ROUTE_REQUEST_SUCCESS,
        payload:list });
};
export const resetRouteRedux = () => {
    return({
        type:SET_ROUTE_REDUX_INITIAL_STATE,
        payload:'' });
}
export const resetRouteAddEditSuccess = () => {
    return({
        type:RESET_ROUTE_ADD_EDIT_STATE,
        payload:'' });
}

export const addEditRouteApiRequest = (routeObj) => {
    return({
        type:ADD_EDIT_ROUTE_REQUEST,
        payload:routeObj });
}

export const routeStopApiRequest = (routeObj) => {
    return({
        type: ROUTE_STOP_LIST,
        payload:routeObj
    });
}

export const routeStopApiReset = () => {
    return({
        type: ROUTE_STOP_RESET,
        payload:'' });
}

export const customerSearchRouteStopRequest = (companyId, deviceId, cursorIndex, searchText) => {
    let payload= { companyId, deviceId, cursorIndex, searchText};
    return({
        type: SEARCH_CUSTOMER_ROUTE_STOP_REQUEST,
        payload: payload });
};

export const searchCustomerRouteStopApiReset = () => {
    return({
        type: RESET_SEARCH_CUSTOMER_ROUTE_STOP_REQUEST,
        payload:'' });
}

export const addRouteStopRequest = (routeStopObj) =>{
    return({
        type: ROUTE_STOP_ADD,
        payload: routeStopObj });
}

export const resetRouteStopHttpApiError = () => {
    return({
        type: HTTP_ROUTE_STOP_API_ERROR_RESET,
        payload: '' });
};


export const resetAddRouteStopSuccess = () =>{
    return({
        type: ADD_ROUTE_STOP_SUCCESS_RESET,
        payload: '' });

};

export const deleteRouteRequest = (deleteObj) =>{
    return({
        type: DELETE_ROUTE_STOP_REQUEST,
        payload: deleteObj });
}


export const resetDeleteRouteStopSuccess =() =>{
    return({
               type: RESET_DELETE_STOP_SUCCESS,
               payload: '' })
}




