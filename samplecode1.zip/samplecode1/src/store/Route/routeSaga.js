import {takeLatest, takeEvery,takeLeading, call, put} from 'redux-saga/effects';
import {api} from '../../api';
import {
    OK,
    FAIL,
    CUSTOMER_REQUEST_SUCCESS,
    RESPONSE_ISSUE,
    HTTP_CUSTOMER_API_ERROR,
    FETCH_ROUTES_REQUEST,
    ROUTE_REQUEST_SUCCESS,
    HTTP_ROUTE_API_ERROR,
    ADD_EDIT_ROUTE_REQUEST,
    ROUTE_ADD_EDIT_SUCCESS,
    ROUTE_STOP_LIST,
    ROUTE_STOP_REQUEST_SUCCESS,
    CUSTOMER_SEARCH_REQUEST_SUCCESS,
    SEARCH_CUSTOMER_ROUTE_STOP_REQUEST,
    SEARCH_CUSTOMER_ROUTE_STOP_REQUEST_SUCCESS,
    HTTP_ROUTE_STOP_API_ERROR,
    ROUTE_STOP_ADD,
    ADD_ROUTE_STOP_SUCCESS,
    DELETE_ROUTE_STOP_SUCCESS, DELETE_ROUTE_STOP_REQUEST, ROUTE_STOP_LIST_REFRESH
} from '../../resources/constants/storeConstants';
import {saveRouteToRealM} from "../../realm/Models/routeModel";

function* fetchRouteRequest({payload: {companyId} }) {
    try {
        const response = yield call(
            {context: api, fn: api.RouteListApi},
            companyId
        );
        if (response.data.response.reasonCode === OK) {
            let RouteList= JSON.parse(response.data.response.dataList);
            console.log(RouteList);
            const saveRouteListToRealM= yield call(saveRouteToRealM, RouteList);
            if(saveRouteListToRealM === true)
                yield put({type: ROUTE_REQUEST_SUCCESS, payload: RouteList});
            else
                console.log('error in saving customer list in realM');
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_ROUTE_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log("error on route api--->>>>>v first dfetch");
        console.log(errorObj);
        yield put({type: HTTP_ROUTE_API_ERROR, payload: errorObj});
    }
}
function* addEditRouteRequest(obj) {
    try {
        let payload= obj.payload;
        console.log("addEditRouteRequestsaga", payload.id + " " + payload.companyId + " " +  payload.routeName  + " " +  payload.description  + " " +  payload.every
            + " " + payload.frequency  + " " +  payload.sequence);
        const response = yield call(
            {context: api, fn: api.AddEditRouteApi},
            payload.id, payload.companyId, payload.routeName, payload.description, payload.every, payload.frequency, payload.sequence
        );
        if (response.data.response.reasonCode === OK) {
            //let RouteList= JSON.parse(response.data.response.dataList);
            //console.log(RouteList);
            yield put({type: ROUTE_ADD_EDIT_SUCCESS, payload: response.data.response});
        }
        else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_ROUTE_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log("error on route api--->>>>>v first dfetch");
        console.log(errorObj);
        yield put({type: HTTP_ROUTE_API_ERROR, payload: errorObj});
    }
}

function* fetchRouteStopList({payload: {Id} }) {
    try {
        const response = yield call(
            {context: api, fn: api.RouteStopListApi},
            Id
        );
        if (response.data.response.reasonCode === OK) {
            let RouteStopList= JSON.parse(response.data.response.dataList);
            yield put({type: ROUTE_STOP_REQUEST_SUCCESS, payload: RouteStopList});
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_ROUTE_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log("error on route stop api--->>>");
        console.log(errorObj);
        yield put({type: HTTP_ROUTE_API_ERROR, payload: errorObj});
    }
}
function* searchRouteStopCustomerRequest({ payload: {companyId, deviceId, cursorIndex, searchText} }) {
    try {
        const response = yield call(
            {context: api, fn: api.CustomerListApi},companyId, deviceId, cursorIndex, searchText
        );
        if (response.data.response.reasonCode === OK) {
            let searchedCustomerList= JSON.parse(response.data.response.dataList);
            console.log('searched customer list', searchedCustomerList);
            yield put({type: SEARCH_CUSTOMER_ROUTE_STOP_REQUEST_SUCCESS, payload: searchedCustomerList});
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_ROUTE_STOP_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log(errorObj);
        yield put({type: HTTP_ROUTE_STOP_API_ERROR, payload: errorObj});
    }
}

function* addRouteStopRequest({ payload: {Id, RouteId, CompanyId, Sequence, Location, CustomerId} }) {
    try {
        const response = yield call(
            {context: api, fn: api.addRouteStopApi},Id, RouteId, CompanyId, Sequence, Location, CustomerId
        );
        if (response.data.response.reasonCode === OK) {
            let newSequencedRouteStopList= JSON.parse(response.data.response.dataList);
            //console.log('new sequenced routestop list', newSequencedRouteStopList);
            yield put({type: ADD_ROUTE_STOP_SUCCESS, payload: newSequencedRouteStopList});
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_ROUTE_STOP_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log(errorObj);
        yield put({type: HTTP_ROUTE_STOP_API_ERROR, payload: errorObj});
    }
}

function* deleteRouteStopRequest({ payload: {Id} }) {
    try {
        const response = yield call(
            {context: api, fn: api.deleteRouteStopApi},Id
        );
        if (response.data.response.reasonCode === OK) {
            yield put({type: DELETE_ROUTE_STOP_SUCCESS, payload: response.data.response});
        } else if (response.data.response.reasonCode === FAIL) {
            yield put({type: HTTP_ROUTE_STOP_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
        }
    } catch (errorObj) {
        console.log(errorObj);
        yield put({type: HTTP_ROUTE_STOP_API_ERROR, payload: errorObj});
    }
}



// function* fetchRouteStopListRefresh({payload: {Id} }) {
//     try {
//         const response = yield call(
//             {context: api, fn: api.RouteStopListApi},
//             Id
//         );
//         if (response.data.response.reasonCode === OK) {
//             let RouteStopList= JSON.parse(response.data.response.dataList);
//             yield put({type: ROUTE_STOP_REQUEST_SUCCESS, payload: RouteStopList});
//         } else if (response.data.response.reasonCode === FAIL) {
//             yield put({type: HTTP_ROUTE_API_ERROR, payload: {errorType: RESPONSE_ISSUE}});
//         }
//     } catch (errorObj) {
//         console.log("error on route stop api--->>>");
//         console.log(errorObj);
//         yield put({type: HTTP_ROUTE_API_ERROR, payload: errorObj});
//     }
// }







export default function* watcherSaga() {
    yield takeLeading(FETCH_ROUTES_REQUEST, fetchRouteRequest);
    yield takeLatest(ADD_EDIT_ROUTE_REQUEST, addEditRouteRequest);
    yield takeLatest(ROUTE_STOP_LIST, fetchRouteStopList);
    yield takeLatest(SEARCH_CUSTOMER_ROUTE_STOP_REQUEST, searchRouteStopCustomerRequest);
    yield takeLatest(ROUTE_STOP_ADD, addRouteStopRequest);
    yield takeLatest(DELETE_ROUTE_STOP_REQUEST, deleteRouteStopRequest);
    // yield takeLatest(ROUTE_STOP_LIST_REFRESH, fetchRouteStopListRefresh);






}
