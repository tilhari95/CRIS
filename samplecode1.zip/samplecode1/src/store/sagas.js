
import loginSaga from "./Login/loginSaga";
import resetPasswordSaga from "./ResetPassword/resetPasswordSaga";
import customerSaga from "./Customer/customerSaga";
import { fork } from 'redux-saga/effects';
import prospectSaga from "./Prospect/prospectSaga";
import routeSaga from "./Route/routeSaga";
import customerDetailSaga from '../store/CustomerDetail/customerDetailSaga';
import itemSaga from './item/itemSaga';
import itemHistorySaga from './itemHistory/itemHistorySaga';
import hotKeysSaga from './hotKeys/hotKeysSaga';
import templateSaga from './template/templateSaga';
import shippingAdrressSaga from './shippingAddress/shippingAddressSaga';
import orderLineSaga from './OrderLine/orderLineSaga';
import orderHeaderSaga from './OrderHeader/orderHeaderSaga';
import rewardSaga from './Reward/rewardSaga';

export default function* rootSaga() {
    yield fork(loginSaga)
    yield fork(resetPasswordSaga)
    yield fork(customerSaga)
    yield fork(prospectSaga)
    yield fork(routeSaga)
    yield fork(customerDetailSaga)
    yield fork(itemSaga)
    yield fork(itemHistorySaga)
    yield fork(hotKeysSaga)
    yield fork(templateSaga)
    yield fork(shippingAdrressSaga)
    yield fork(orderLineSaga)
    yield fork(orderHeaderSaga)
    yield fork(rewardSaga)
    // yield fork(someOtherSagas)
}
