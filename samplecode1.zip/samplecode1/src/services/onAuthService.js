import {resetAuthTable} from "../realm/Models/loginModel";
import {resetCustomerTable} from "../realm/Models/customerModel";
import store from "../store/store";
import {SET_CUSTOMER_REDUX_INITIAL_STATE} from "../resources/constants/storeConstants";
import {resetProspectTable} from "../realm/Models/prospectModel";
import {resetRouteTable} from "../realm/Models/routeModel";
import {resetItemTable} from '../realm/Models/itemModel';
import {resetItemReduxStore} from '../store/item/itemAction';

export const resetAppData = async (clearAuth) => {
    let flag = false;
    try{
        if(clearAuth === true){
            await resetAuthTable();
        }
        await resetCustomerTable();
        await resetProspectTable();
        await resetRouteTable();
        await resetItemTable();

        await store.dispatch({type: SET_CUSTOMER_REDUX_INITIAL_STATE, payload: ''});
        await store.dispatch(resetItemReduxStore());
        flag = true;
    }catch (e) {
        console.log('ERROR ON LOGOUT APP DATA RESET', e);
    }
    finally {
        return flag;
    }
}
