import React, {useEffect, useState} from 'react';
import {StyleSheet, ScrollView, View,} from 'react-native';
import {GenericButton, GenericTemplate, TextInput} from '../../components';
import {Icon, Text} from 'react-native-elements';
import UserBrandHeader from '../../components/Headers/UserBrandHeader';
import {
    DEVICE_WIDTH, HEIGHT_100, HEIGHT_250, HEIGHT_40, ICON_30, IMAGE_MAX_HEIGHT,
    IMAGE_MAX_WIDTH, SPACING_10, SPACING_15,
    TEXT_SIZE_15, TEXT_SIZE_18, TEXT_SIZE_20, WIDTH_100, WIDTH_250, WIDTH_80,
} from '../../resources/constants/dimensions';
import {
    FIELD_BORDER_WIDTH, GENERIC_BACKGROUND_COLOR,
    GREY_ICON_COLOR, HEADER_FONT_WEIGHT, INPUT_FIELD_BORDER_COLOR,
    PRODUCT_HEADER_BG_COLOR,
    PRODUCT_NAME_COLOR,
} from '../../resources/constants/themeConstant';
import FastImage from 'react-native-fast-image';
import {genericImageURL} from '../../api/helper/ApiEndpoints';
import {
    ADD,
    NOTES, NOTES_PLACEHOLDER,
    PRICE,
    NOTES_JSON,
    QUANTITY_JSON,
    QUNATITY,
    UPDATE,
} from '../../resources/constants/stringConstants';
import {connect} from 'react-redux';
import AsyncImage from '../../components/AsyncImage/AsyncImage';
import {
    addItemToCart,
    updateItemInCartList,
} from '../../store/Cart/cartAction';
import {
    cartScreenInputValidator,
} from '../../utils/validators';
import {roundToTwo} from '../../utils/cartHelpers';

const ProductDetailScreen = ({
     navigation,
     route,
     dateString,
     cartList,
     addItemToCart:_addItemToCart,
     updateItemInCartList:_updateItemInCartList,
     userBrandDataFromAsync,
     brandSuccessResponse
}) => {
    const [productCartDetails, setproductCartDetails] =useState({quantity: '', notes: '', buttonTitle: ADD});
    const [buttonDisable,  setButtonDisable] =useState(true);
    let productDetails= route.params.productDetails.productObj;
    let isFromCart =route.params.productDetails.productFoundInCart;
    let index= route.params.productDetails.index;
    let priceWithDeimalCorrection = roundToTwo(productDetails.Price);
    // one time run on page load to check --> if current product is fetched from cart, pre-populate input fields.
    useEffect(() =>{
        if(isFromCart){
            let prevCartDetails={quantity: 0, notes: '', buttonTitle: UPDATE};
            prevCartDetails.quantity=productDetails.OrderQty;
            prevCartDetails.notes=productDetails.Notes;
            setproductCartDetails(prevCartDetails);
        }
    },[]);

    // on adding product to cart.
    const onAddToCartPress= async () =>{
        // update product in cartList if already added before.
        if(isFromCart){
            // make duplicate of current product object.
            let cartObj = JSON.parse(JSON.stringify(productDetails));
            //console.log(productDetails);
            const prevCartQuantity = productDetails.OrderQty;
            cartObj.OrderQty=productCartDetails.quantity;
            cartObj.Notes=productCartDetails.notes;
            //console.log(cartObj);
            cartList.splice(index,1, cartObj);
            console.log(cartList);
            // ACTION to update product in cart.
            await  _updateItemInCartList(cartList, prevCartQuantity, cartObj.OrderQty, cartObj.Price );

        }
        //else create new object and add it to cartList.
        else{
            // O(1) logic to add item to cart.
            let cartObj = JSON.parse(JSON.stringify(productDetails));
            cartObj[QUANTITY_JSON]=productCartDetails.quantity;
            cartObj[NOTES_JSON]= productCartDetails.notes;
            //console.log(cartObj);
            cartList.push(cartObj);
            //console.log(cartList);
            // ACTION to add new product to cartList.
            await  _addItemToCart(cartList, productCartDetails.quantity, cartObj.Price);
        }
        navigation.pop();

    }

    // function which watches qunatity input change and validates it.
    const onQuantityInputChange = (input) => {
        if(!cartScreenInputValidator(productCartDetails.notes, input, isFromCart, productDetails)){
            setButtonDisable(true);
        }
        else
            setButtonDisable(false);

        input = input.replace(/^0+/, '');
        setproductCartDetails({...productCartDetails, quantity: input});
    }

    // function which watches product notes change and further valication.
    const onNotesInputChange = (text) =>{
        if(!cartScreenInputValidator(text, productCartDetails.quantity, isFromCart, productDetails)){
            setButtonDisable(true);
        }
        else
            setButtonDisable(false);

        setproductCartDetails({...productCartDetails, notes: text});
    }

    return (
    <GenericTemplate navigation={navigation} keyboardAwareView={true} keyboardTapPersist='always'>
        <UserBrandHeader navigation={navigation} headerBackButton={true}/>
        <View style={styles.bodyStyle}>
            <View style={[styles.bodyItemHeader, {}]}>
                <Text style={styles.productNameStyle}>{productDetails.ItemDescription}</Text>
            </View>
            <ScrollView  horizontal={true} showsHorizontalScrollIndicator={true} style={{ marginTop: SPACING_10,}} bounces={false}>
            {
            productDetails.ImageList.map((eachImage, i) => {
                let imageCompletePath=genericImageURL+eachImage.ImagePath+'?date='+dateString;
                //console.log(imageCompletePath);
                return (
                <View>
                    <View style={styles.imageContainerStyle}>
                        <View style={[styles.bodyElementStyle, {width: '10%'}]}>
                            <Icon
                                name='chevron-left'
                                type='MaterialCommunityIcons'
                                color={GREY_ICON_COLOR}
                                size={ICON_30}
                            />
                        </View>
                        <AsyncImage
                            targetURL={imageCompletePath}
                            allowDynamicSizing={false}
                            resizeMode={FastImage.resizeMode.stretch}
                            imageStyle={styles.imageStyle}
                        />
                        <View style={[styles.bodyElementStyle, { width: '10%'}]}>
                            <Icon
                                name='chevron-right'
                                type='MaterialCommunityIcons'
                                color={GREY_ICON_COLOR}
                                size={ICON_30}
                            />
                        </View>
                    </View>
                    <ScrollView nestedScrollEnabled={true} style={{height: HEIGHT_100, marginTop: SPACING_10, borderWidth:1, borderColor:INPUT_FIELD_BORDER_COLOR}}>
                        <View style={{width: DEVICE_WIDTH,}}>
                            <Text style={styles.imageDescriptionStyle}>
                                {eachImage.Description}
                            </Text>
                        </View>
                    </ScrollView>
                </View>
                );
            })
            }
            </ScrollView>
            {/*<Text>{productCartDetails.quantity}</Text>*/}
            {/*<Text>{productCartDetails.notes}</Text>*/}
            <View style={styles.priceBox}>
                <Text style={[styles.productNameStyle,{color: 'black'}]}>{PRICE}{priceWithDeimalCorrection}</Text>
            </View>
            {
            ((brandSuccessResponse !== null && brandSuccessResponse.responseData.ViewShoppingCart === true)
                || (userBrandDataFromAsync !== null && userBrandDataFromAsync.ViewShoppingCart === true))?
            <View style={styles.quantityBox}>
            <View style={{ flexDirection: 'row'}}>
                <View style={{width: "30%", justifyContent:'center'}}>
                    <Text style={[styles.productNameStyle,{color: 'black'}]}>{NOTES}</Text>
                </View>
                <View style={[styles.quantityControlItem,{width: '70%'}]}>
                    <TextInput
                        placeholder={NOTES_PLACEHOLDER}
                        value={productCartDetails.notes}
                        onChangeText={onNotesInputChange}
                        containerStyle={styles.inputBoxContainerStyle}
                        inputContainerStyle={styles.notesInputContainerStyle}
                    />
                </View>
            </View>
            <View style={styles.qunatityControlView}>
                <View style={{width: "30%", justifyContent:'center'}}>
                    <Text style={[styles.productNameStyle,{color: 'black'}]}>{QUNATITY}</Text>
                </View>
                <View style={[styles.quantityControlItem,{ width:'45%',}]}>
                    <TextInput
                        placeholder='0'
                        value={ productCartDetails.quantity }
                        containerStyle={[styles.inputBoxContainerStyle,]}
                        inputContainerStyle={styles.qunatityInputContainerStyle}
                        onChangeText={onQuantityInputChange}
                        keyboardType='numeric'
                    />
                </View>
                <View style={[styles.quantityControlItem,{ width:'25%',marginRight:SPACING_15 }]}>
                    <GenericButton disabled={buttonDisable}
                                   onPress={() => onAddToCartPress()}
                                   containerStyle={{ paddingRight: SPACING_10, minWidth:WIDTH_80}}
                                   title={productCartDetails.buttonTitle}>
                    </GenericButton>
                </View>
            </View>
            </View>
                :
                null
            }
        </View>
    </GenericTemplate>
    );
};


const styles = StyleSheet.create({
    bodyStyle:{
        alignItems: 'center',
        width: DEVICE_WIDTH,
    },
    quantityControlItem:{
        alignItems:'flex-end',
        justifyContent:'center'
    },
    bodyItemHeader:{
        justifyContent:'center',
        marginTop:SPACING_10,
        height: HEIGHT_40,
        backgroundColor:PRODUCT_HEADER_BG_COLOR,
        width: DEVICE_WIDTH
    },
    priceBox:{
        alignItems:'flex-end',
        justifyContent:'center',
        height: HEIGHT_40,
        width: DEVICE_WIDTH,
        paddingRight: SPACING_10
    },
    quantityBox:{
        justifyContent:'center',
        marginTop:SPACING_15,
        backgroundColor:PRODUCT_HEADER_BG_COLOR,
        width: DEVICE_WIDTH
    },
    bodyElementStyle:{
        justifyContent: 'center',
    },
    imageContainerStyle:{
        flexDirection:'row',
        width:DEVICE_WIDTH,
        alignItems:"center",
        justifyContent:'center'
    },
    productNameStyle: {
        justifyContent:'center',
        fontWeight:HEADER_FONT_WEIGHT,
        paddingLeft:SPACING_15,
        fontSize: TEXT_SIZE_18,
        color:PRODUCT_NAME_COLOR
    },
    imageStyle:{
        paddingEnd:2,
        height: HEIGHT_250, width: WIDTH_250,
        maxWidth:IMAGE_MAX_WIDTH,
        maxHeight: IMAGE_MAX_HEIGHT,
    },

    inputBoxContainerStyle:{
        height:50,
        paddingTop:5,
    },
    notesInputContainerStyle:{
        height:HEIGHT_40
    },
    qunatityInputContainerStyle:{
        backgroundColor:GENERIC_BACKGROUND_COLOR,
        borderBottomWidth:FIELD_BORDER_WIDTH,
        borderWidth:FIELD_BORDER_WIDTH,
        borderStyle:"solid",
        borderColor:INPUT_FIELD_BORDER_COLOR,
        height: HEIGHT_40,
        padding:SPACING_10,
    },
    qunatityControlView:{
        flexDirection: 'row',
        marginTop: SPACING_10,
        marginBottom: SPACING_10
    },
    inputBoxStyle:{
        backgroundColor:'yellow',
        width:WIDTH_100,
        paddingRight:0

    },
    imageDescriptionStyle:{
        paddingLeft: SPACING_10,
        fontSize: TEXT_SIZE_15
    }
});

const mapStateToProps = (reduxStore) => {
    return {
        dateString: reduxStore.productPage.dateString,
        cartList: reduxStore.cart.cartList,
        isForceUpdate: reduxStore.productPage.isForceUpdate,
        brandSuccessResponse: reduxStore.login.brandSuccessResponse,
        userBrandDataFromAsync: reduxStore.productPage.userBrandDataFromAsync
    };
}
;
export default connect(mapStateToProps, {
    addItemToCart,
    updateItemInCartList,
    })(ProductDetailScreen);
