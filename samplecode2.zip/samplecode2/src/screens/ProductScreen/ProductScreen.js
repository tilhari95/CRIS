import DeviceInfo from 'react-native-device-info';
import AppAsyncStorage from '../../api/helper/AppAsyncStorage';
import React, {useEffect, useState} from 'react';
import {
    FIELD_BORDER_WIDTH,
    GENERIC_BACKGROUND_COLOR,
    GREY_ICON_COLOR, HEADER_FONT_WEIGHT,
    INPUT_FIELD_BORDER_COLOR, MODAL_BACKDROP_OPACITY, PRODUCT_BORDER_COLOR,
    PRODUCT_NAME_COLOR,
} from '../../resources/constants/themeConstant';
import {Text} from'react-native-elements';
import {StyleSheet, View, TouchableWithoutFeedback, Dimensions, FlatList} from 'react-native';
import {GenericButton, GenericTemplate, UserBrandHeader} from '../../components';
import {Icon, Overlay} from 'react-native-elements';
import FastImage from 'react-native-fast-image';
import {genericImageURL} from '../../api/helper/ApiEndpoints';
import {
    SPACING_30,
    DEVICE_WIDTH,
    DEVICE_HEIGHT,
    ICON_30,
    IMAGE_MAX_HEIGHT,
    IMAGE_MAX_WIDTH,
    CONTAINER_HEIGHT,
    TEXT_SIZE_15,
    MODAL_CONTAINER_WIDTH,
    AUTH_STACK_CONTAINER_WIDTH,
} from '../../resources/constants/dimensions';
import {
    CART_LIST,
    LAST_PRODUCT_UPDATE_DATE,
    PRODUCT_LIST,
    PRODUCT_TAG_LIST,
    SESSION_TOKEN,
} from '../../resources/constants/asyncKeys';
import {connect} from 'react-redux';
import {
    productListRequest,
    setProductListFromAsync,
    setDateStringFromAsync,
    setIsForceUpdate,
    resetHttpProductApiError
} from '../../store/ProductPage/productPageAction';
import {NAVIGATION_TO_PRODUCT_DETAIL_SCREEN,} from '../../resources/constants/navRouteKeys';
import {tokenValidator} from '../../utils/validators';
import {LOGOUT_FROM_HOME, OKAY, YES, NO, REFRESH_CART_ALERT} from '../../resources/constants/stringConstants';
import {getModalErrorText, logoutOnError, logoutUser} from '../../utils/errorHandlers';
import {SESSION_EXPIRED_MSG} from '../../resources/constants/storeConstants';
import AsyncImage from '../../components/AsyncImage/AsyncImage';
import {resetCartReduxInitialState, updateCartListAsync} from '../../store/Cart/cartAction';
import {cartCalculationsOnAsyncFetch, getProductFromCart} from '../../utils/cartHelpers';
import {resetHttpLogoutApiError, triggerLogoutRequest} from '../../store/Logout/logoutAction';
const deviceWidth80 = DEVICE_WIDTH*.85;
const deviceHeight = DEVICE_HEIGHT;

const ProductScreen = ({
       navigation,
       productSuccessResponse,
       dateString,
       isForceUpdate,
       productHttpError,
       cartList,
       logoutHttpError,
       logoutRequested,
       logoutSuccessResponse,
       productListRequest: _productListRequest,
       setProductListFromAsync: _setProductListFromAsync,
       setDateStringFromAsync:_setDateStringFromAsync,
       setIsForceUpdate:_setIsForceUpdate,
       resetHttpProductApiError: _resetHttpProductApiError,
       updateCartListAsync: _updateCartListAsync,
       resetCartReduxInitialState:_resetCartReduxInitialState,
       resetHttpLogoutApiError:_resetHttpLogoutApiError,
       triggerLogoutRequest:_triggerLogoutRequest,
   }) => {
    const [productList, setProductList] =useState([]);
    const [overlayLoaderVisibility, setOverlayLoaderVisibility]=useState(false);
    const [date,setdate] =useState('');
    const [httpModalVisibility, setHttpModalVisibility] =useState(false);
    const [httpModalText, setHttpModalText] =useState('');
    const [refreshAlerBoxVisibility, setRefreshAlertBoxVisibility] = useState(false);

    // fetch product list from reducer or async as per requirement.
    useEffect(()=>{
        setOverlayLoaderVisibility(false);
        //debugger;
        if(productSuccessResponse == null){
            getProductListFromAsync(false); // fetch from async without force update.
        }
        else{
            if(isForceUpdate){
                setOverlayLoaderVisibility(false);
                debugger;
                //showUpdateModal(PRODUCT_UPDATE_SUCCESS); //TODO phase 2.
                _setIsForceUpdate(false);
            }
            debugger;
            setProductList(productSuccessResponse);
            // console.log('alright 2.0-->>>');
            // console.log(productSuccessResponse);
            // console.log(cartList);

        }

    },[productSuccessResponse]);

    // handle and change view on rejection of API
    useEffect( () =>{
        if(productHttpError != null){
            setOverlayLoaderVisibility(false);
            showhttpErrorModal(productHttpError);
            _resetHttpProductApiError();
            _setIsForceUpdate(false);
        }
    },[productHttpError]);

    // check for force update redux state.
    useEffect(()=>{
    //debugger;
        if(isForceUpdate === true) {
            getProductListFromAsync(true);
        }
    },[isForceUpdate]);

    useEffect(()=>{
        //debugger;
        if(logoutRequested === true) {
            let logoutProp = LOGOUT_FROM_HOME;
            setOverlayLoaderVisibility(true);
            _triggerLogoutRequest(logoutProp);
        }
    },[logoutRequested]);

    useEffect(()=>{
        debugger;
        if(logoutSuccessResponse!== null) {
            setOverlayLoaderVisibility(false);
            logoutUser(navigation);
        }
    },[logoutSuccessResponse]);

    useEffect( () =>{
        if(logoutHttpError != null){
            setOverlayLoaderVisibility(false);
            showhttpErrorModal(logoutHttpError);
            _resetHttpLogoutApiError();
        }
    },[logoutHttpError]);

    // fetch date string of last product update from async/redux.
    useEffect(()=>{
        if(dateString == null){
            AppAsyncStorage.getValue(LAST_PRODUCT_UPDATE_DATE)
                .then(date =>{
                    _setDateStringFromAsync(date);
                });
        }
        else{
            setdate(dateString);
        }
    },[dateString])

    // inplate page with products by fetching it from redux/async/API/forceUpdate
    const getProductListFromAsync= async (isForce) =>{
        let token = await AppAsyncStorage.getValue(SESSION_TOKEN);
        if(tokenValidator(token)){
            if(!isForce){ // check for force product update if not proceed -->
                let productList = await AppAsyncStorage.getValue(PRODUCT_LIST);
                let searchTagList = await AppAsyncStorage.getValue(PRODUCT_TAG_LIST);
                if(productList === '' ||productList === undefined || productList === null ||
                    searchTagList === '' ||searchTagList === undefined || searchTagList === null ){
                    callProductAPI();
                }
                else{
                    // set cart list from async, otherwise to empty array
                    let cartL = await AppAsyncStorage.getValue(CART_LIST);
                    if(cartL == '' || cartL == undefined || cartL == null){
                        let cart = [];
                        _updateCartListAsync(cart, 0, 0);
                    }
                    else{
                        let parsedCartL =JSON.parse(cartL);
                        let cartCalObj = cartCalculationsOnAsyncFetch(parsedCartL);
                        _updateCartListAsync(parsedCartL, cartCalObj.badgeCount, cartCalObj.cartTotalAmount);

                    }
                    console.log(JSON.parse(searchTagList));
                    _setProductListFromAsync(JSON.parse(productList), JSON.parse(searchTagList));

                }
            }
            else{
                setRefreshAlertBoxVisibility(true);
                // _resetCartReduxInitialState(); //reset cart redux state
                // callProductAPI();
            }

        }
    };

    const onProductPress = (productObj) =>{ // handle specific product press and open detail page.
        console.log(DeviceInfo.isTablet());
        let productDetails = getProductFromCart(productObj, cartList);
        navigation.navigate(NAVIGATION_TO_PRODUCT_DETAIL_SCREEN, {productDetails: productDetails})
    };

    const callProductAPI= () =>{
        setOverlayLoaderVisibility(true);
        _productListRequest();
    }

    const showhttpErrorModal =(errorObj) =>{
        let errorText = getModalErrorText(errorObj);
        setHttpModalText(errorText);
        setOverlayLoaderVisibility(false);
        setHttpModalVisibility(true);
    }

    const showUpdateModal = (text) =>{
        setHttpModalText(text);
        setOverlayLoaderVisibility(false);
        setHttpModalVisibility(true);
    }

    // logout on session expire error.
    const httpModalOnPress = () => {
        setHttpModalVisibility(false);
        if(httpModalText === SESSION_EXPIRED_MSG){
            setHttpModalText('');
            logoutOnError(navigation);
        }
        else
            setHttpModalText('');
    }

    const onRefreshAlertBoxPress = (bool) => {
        setRefreshAlertBoxVisibility(false);
        _setIsForceUpdate(false);
         if(bool){
            _resetCartReduxInitialState(); //reset cart redux state
            setTimeout(()=> {callProductAPI();}, 500)
        }

    }


    return (
        <GenericTemplate navigation={navigation} keyboardAwareView={false} overlayLoaderVisibility={overlayLoaderVisibility}>
            <UserBrandHeader headerStyle={{height:'18%'}} navigation={navigation}/>
            <View
                style={styles.bodyStyle}>
                <View style={[styles.bodyElementStyle, {
                    justifyContent: 'center', width: '10%'
                }]}>
                    <Icon
                        name='chevron-left'
                        type='MaterialCommunityIcons'
                        color={GREY_ICON_COLOR}
                        size={ICON_30}
                    />
                </View>
                {
                (productList !== '' && productList.length > 0) ?
                    <View style={[styles.bodyElementStyle, {width: "80%", paddingLeft: 0}]}>
                        <FlatList
                            //showsHorizontalScrollIndicator={true}
                            horizontal={true}
                            data={productList}
                            renderItem={({item, index, separators}) => {
                                let imageList = item.ImageList;
                                let imageCompletePath = genericImageURL + imageList[0].ImagePath + '?date=' + date;
                                return (
                                (item.FeaturedProduct === true)?
                                    <TouchableWithoutFeedback
                                        onPress={() => onProductPress(item)}>
                                        <View style={styles.imageContainerStyle}>
                                            <AsyncImage
                                                targetURL={imageCompletePath}
                                                allowDynamicSizing={false}
                                                resizeMode={FastImage.resizeMode.stretch}
                                                imageStyle={styles.imageStyle}
                                            />
                                            <Text style={styles.productDescriptionStyle}>{item.ItemDescription}</Text>
                                        </View>
                                    </TouchableWithoutFeedback>
                                    :
                                    null
                                )
                            }
                            }
                        />
                    </View>
                    :
                    <View style={[styles.bodyElementStyle, {width: "80%", paddingLeft: 0, justifyContent: 'center', alignItems: "center"}]}>
                        <Text>No products available</Text>
                    </View>
                }
                <View style={[styles.bodyElementStyle, {
                    justifyContent: 'center', width: '10%'
                }]}>
                    <Icon
                        name='chevron-right'
                        type='MaterialCommunityIcons'
                        color={GREY_ICON_COLOR}
                        size={ICON_30}
                    />
                </View>
            </View>

            <Overlay
                backdropStyle={styles.overlay}
                isVisible={httpModalVisibility}
                overlayStyle={styles.overlayModalStyle}
            >
                <View>
                    <Text h3 h3Style={styles.modalErrorStyle}>{httpModalText}</Text>
                    <GenericButton title={OKAY} onPress={httpModalOnPress}></GenericButton>
                </View>
            </Overlay>


            <Overlay
                backdropStyle={styles.overlay}
                isVisible={refreshAlerBoxVisibility}
                overlayStyle={styles.refreshAlertOverlayModalStyle}
            >
                <View>
                    <Text h3 h3Style={styles.modalErrorStyle}>{REFRESH_CART_ALERT}</Text>
                    <View style={{flexDirection:'row',}}>
                    <View style={{width:'50%', paddingRight:5}}>
                        <GenericButton title={YES} onPress={() => {onRefreshAlertBoxPress(true)}} ></GenericButton>
                    </View>
                    <View  style={{width:'50%'}}>
                        <GenericButton title={NO} onPress={() => {onRefreshAlertBoxPress(false)}} ></GenericButton>
                    </View>
                </View>
                </View>
            </Overlay>

        </GenericTemplate>
    );
}


const styles = StyleSheet.create({
    bodyStyle:{
        alignItems: 'center',
        width: Dimensions.get('window').width,
        flexDirection: 'row',
        height: CONTAINER_HEIGHT,
    },
    bodyElementStyle:{
        height: CONTAINER_HEIGHT
    },
    imageContainerStyle:{
        borderColor:PRODUCT_BORDER_COLOR,
        borderRightWidth:1,
        width:deviceWidth80,
        alignItems:"center",
        height: CONTAINER_HEIGHT,
        justifyContent:'center'
    },
    productDescriptionStyle: {
        fontWeight:'bold',
        marginTop:SPACING_30,
        fontSize: TEXT_SIZE_15,
        color:PRODUCT_NAME_COLOR
    },
    imageStyle:{
        paddingEnd:2,
        height: deviceHeight*.4, width: DEVICE_WIDTH*.75,
        maxWidth:IMAGE_MAX_WIDTH,
        maxHeight: IMAGE_MAX_HEIGHT,
    },
    overlay:{
        backgroundColor: GENERIC_BACKGROUND_COLOR,
        opacity: MODAL_BACKDROP_OPACITY
    },
    overlayModalStyle:{
        borderWidth:FIELD_BORDER_WIDTH,
        borderColor:INPUT_FIELD_BORDER_COLOR,
        width:MODAL_CONTAINER_WIDTH,

    },
    refreshAlertOverlayModalStyle:{
        borderWidth:FIELD_BORDER_WIDTH,
        borderColor:INPUT_FIELD_BORDER_COLOR,
        width:AUTH_STACK_CONTAINER_WIDTH,

    },
    modalErrorStyle:{
        fontWeight:HEADER_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
        textAlign:'center',
        marginBottom: SPACING_30,

    },
});

const mapStateToProps = (reduxStore) => {
    return {
        productSuccessResponse: reduxStore.productPage.productSuccessResponse,
        dateString: reduxStore.productPage.dateString,
        loggedIn: reduxStore.login.loggedIn,
        isForceUpdate: reduxStore.productPage.isForceUpdate,
        productHttpError: reduxStore.productPage.productHttpError,
        cartList: reduxStore.cart.cartList,
        logoutHttpError:reduxStore.logout.logoutHttpError,
        logoutRequested:reduxStore.logout.logoutRequested,
        logoutSuccessResponse: reduxStore.logout.logoutSuccessResponse

    };
};

export default connect(mapStateToProps, {
    productListRequest,
    setProductListFromAsync,
    setDateStringFromAsync,
    setIsForceUpdate,
    resetHttpProductApiError,
    updateCartListAsync,
    resetCartReduxInitialState,
    triggerLogoutRequest,
    resetHttpLogoutApiError,
})(ProductScreen);








// {/*<FastImage*/}
// {/*    source={{uri:imageCompletePath}}*/}
// {/*    style={styles.imageStyle}*/}
// {/*    resizeMode={FastImage.resizeMode.stretch}/>*/}

