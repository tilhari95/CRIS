import React, {useEffect, useState} from 'react';
import {FlatList, StyleSheet, TouchableWithoutFeedback, View} from 'react-native';
import {Overlay, Text} from 'react-native-elements';
import {GenericTemplate} from '../../components';
import {connect} from 'react-redux';
import {
    BOLD_FONT_WEIGHT, FIELD_BORDER_WIDTH, GENERIC_BACKGROUND_COLOR, HEADER_FONT_WEIGHT,
    INPUT_FIELD_BORDER_COLOR, MODAL_BACKDROP_OPACITY,
    PRODUCT_NAME_COLOR,
} from '../../resources/constants/themeConstant';
import UserBrandHeader from '../../components/Headers/UserBrandHeader';
import {OKAY, ORDER_HISTORY_EMPTY, PAYOUT_TEXT} from '../../resources/constants/stringConstants';
import GenericButton from '../../components/Buttons/GenericButton';
import {
    MODAL_CONTAINER_WIDTH,
    SPACING_30,
    SPACING_5,
    TEXT_SIZE_15,
} from '../../resources/constants/dimensions';
import {useFocusEffect} from '@react-navigation/core';
import {getModalErrorText, logoutOnError} from '../../utils/errorHandlers';
import {SESSION_EXPIRED_MSG} from '../../resources/constants/storeConstants';
import {
    fetchOrderInvoice,
    orderHistoryListRequest,
    resetOrderHistoryApiError,
    resetOrderHistoryRedux,
} from '../../store/OrderHistory/orderHistoryAction';
import OrderHistoryListTemplate from '../../components/GenericTemplate/OrderHistoryListTemplate';
import RNFetchBlob from 'rn-fetch-blob'

const OrderHistoryScreen = ({
    navigation,
    orderHistoryListSuccessResponse,
    orderHistoryPageHttpError,
    invoicePdfSuccessResponse,
    resetOrderHistoryRedux: _resetOrderHistoryRedux,
    resetOrderHistoryApiError: _resetOrderHistoryApiError,
    orderHistoryListRequest: _orderHistoryListRequest,
    fetchOrderInvoice: _fetchOrderInvoice
}) => {
    const [overlayLoaderVisibility, setOverlayLoaderVisibility]=useState(false);
    const [httpModalVisibility, setHttpModalVisibility] =useState(false);
    const [httpModalText, setHttpModalText] =useState('');
    const [orderHistoryList, setOrderHistoryList] =useState([]);

    useFocusEffect(
        React.useCallback(() => {
            setOverlayLoaderVisibility(true);
            _orderHistoryListRequest();
        },[])
    );

    useEffect(() => {
        if(orderHistoryListSuccessResponse !== null){
            setOverlayLoaderVisibility(false);
            setOrderHistoryList(orderHistoryListSuccessResponse);
        }
    },[orderHistoryListSuccessResponse])

    useEffect(()=>{

        //debugger;
        if(invoicePdfSuccessResponse !== null){
            debugger;
            setOverlayLoaderVisibility(false);
            setTimeout(() => {
                openPdfIntent(invoicePdfSuccessResponse);
            }, 500)

        }

    },[invoicePdfSuccessResponse]);

    //handle and change view on rejection of API
    useEffect( () =>{
        if(orderHistoryPageHttpError !== null){
            setOverlayLoaderVisibility(false);
            showhttpErrorModal(orderHistoryPageHttpError);
            _resetOrderHistoryApiError();
        }
    },[orderHistoryPageHttpError]);

    const showhttpErrorModal =(errorObj) =>{
        let errorText = getModalErrorText(errorObj);
        setHttpModalText(errorText);
        setOverlayLoaderVisibility(false);
        setHttpModalVisibility(true);
    }

    const httpModalOnPress = () => {
        setHttpModalVisibility(false);
        if(httpModalText === SESSION_EXPIRED_MSG){
            setHttpModalText('');
            logoutOnError(navigation);
        }
        else
            setHttpModalText('');
    }

    const openPdfIntent = (pdfResponse) => {
        const android = RNFetchBlob.android;
        // the path of downloaded file
        console.log('The file saved to ', pdfResponse.path());
        if (Platform.OS === "ios") {
            RNFetchBlob.ios.openDocument(pdfResponse.data);
        }
        else{
            android.actionViewIntent(pdfResponse.path(), 'application/pdf')
        }
    }

    const downloadAndOpenPdf = (item) =>{
        setOverlayLoaderVisibility(true);
        _fetchOrderInvoice(item);
    };

    return(
        <GenericTemplate navigation={navigation} keyboardAwareView={false} overlayLoaderVisibility={overlayLoaderVisibility} style={styles.genericTemplateStyle}>
            <UserBrandHeader headerStyle={{height:'18%'}} navigation={navigation} headerNavigator={true} customOnBackPress={() => {_resetOrderHistoryRedux();}} headerBackButton={true}/>
            {
                (orderHistoryList.length !== 0)?
                    <View style={{height:'82%'}}>
                        <FlatList
                            data={orderHistoryList}
                            renderItem={({item, index, separators}) => (
                                <View>
                                    <OrderHistoryListTemplate
                                        itemData={item}
                                        onPdfIconPress={() => downloadAndOpenPdf(item)}
                                    />
                                </View>
                            )}
                        />
                    </View>
                    :
                    <View style={styles.noProductStyle}>
                        <Text style={styles.emptyContentStyle}>{ORDER_HISTORY_EMPTY}</Text>
                    </View>
            }
            <Overlay
                backdropStyle={styles.overlay}
                isVisible={httpModalVisibility}
                overlayStyle={styles.overlayModalStyle}
            >
                <View>
                    <Text h3 h3Style={styles.modalErrorStyle}>{httpModalText}</Text>
                    <GenericButton title={OKAY} onPress={httpModalOnPress}></GenericButton>
                </View>
            </Overlay>
        </GenericTemplate>
    )};

const styles = StyleSheet.create({
    noProductStyle:{
        height:'74%',
        alignItems:'center',
        justifyContent:'center'
    },
    genericTemplateStyle:{
        flex: 1,
        flexDirection:"column"
    },
    totalAmountStyle: {
        textAlign: 'center',
        color: PRODUCT_NAME_COLOR,
        fontWeight: BOLD_FONT_WEIGHT,
        fontSize: TEXT_SIZE_15,
    },
    proceedButtonStyle:{
        flexDirection:'row',
        justifyContent:'center',
        alignItems:'center',
        width:"65%",
        paddingLeft:SPACING_5,
        paddingRight:SPACING_5,
        // backgroundColor: 'red'
    },
    emptyContentStyle:{
        color:PRODUCT_NAME_COLOR, fontSize:TEXT_SIZE_15
    },
    overlay:{
        backgroundColor: GENERIC_BACKGROUND_COLOR,
        opacity: MODAL_BACKDROP_OPACITY
    },
    overlayModalStyle:{
        borderWidth:FIELD_BORDER_WIDTH,
        borderColor:INPUT_FIELD_BORDER_COLOR,
        width:MODAL_CONTAINER_WIDTH,

    },
    modalErrorStyle:{
        fontWeight:HEADER_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
        textAlign:'center',
        marginBottom: SPACING_30,

    },
});

const mapStateToProps = (reduxStore) => {
    return {
        orderHistoryListSuccessResponse: reduxStore.orderHistory.orderHistoryListSuccessResponse,
        orderHistoryPageHttpError: reduxStore.orderHistory.orderHistoryPageHttpError,
        invoicePdfSuccessResponse: reduxStore.orderHistory.invoicePdfSuccessResponse
    };
};


export default connect(mapStateToProps,
    {
        resetOrderHistoryRedux,
        resetOrderHistoryApiError,
        orderHistoryListRequest,
        fetchOrderInvoice

    })(OrderHistoryScreen);
