import {connect} from 'react-redux';

const products = [
    {
        name: 'aproduct 1',
        avatar: 'https://s3.amazonaws.com/uifaces/faces/twitter/brynn/128.jpg',
        price:'$40'
    },
    {
        name: 'aproduct 2',
        avatar: 'https://s3.amazonaws.com/uifaces/faces/twitter/brynn/128.jpg',
        price:'$50'
    },
    {
        name: 'bproduct 3',
        avatar: 'https://s3.amazonaws.com/uifaces/faces/twitter/brynn/128.jpg',
        price:'$90'
    },
    {
        name: 'cproduct 4',
        avatar: 'https://s3.amazonaws.com/uifaces/faces/twitter/brynn/128.jpg',
        price:'$70'
    }
    // ... // more users here
];

import React, {useState, useEffect} from 'react';
import {FlatList, ScrollView, StyleSheet, Text, TouchableWithoutFeedback, View} from 'react-native';
import {GenericTemplate} from '../../components';
import {SearchBar} from 'react-native-elements';
import UserBrandHeader from '../../components/Headers/UserBrandHeader';
import {
    NAVIGATION_TO_MESSAGE_SCREEN,
    NAVIGATION_TO_PRODUCT_DETAIL_SCREEN, ROUTE_BOTTOM_NAV, ROUTE_DRAWER, ROUTE_HOME,
} from '../../resources/constants/navRouteKeys';
import {BLACK_COLOR, GENERIC_BACKGROUND_COLOR, PRODUCT_NAME_COLOR} from '../../resources/constants/themeConstant';
import {DEVICE_HEIGHT, MAX_HEIGHT_70, TEXT_SIZE_15} from '../../resources/constants/dimensions';
import ScrollViewTemplate from '../../components/GenericTemplate/ScrollViewTemplate';
import {NO_MATCHING_PRODUCTS, TYPE_PRODUCT_HERE} from '../../resources/constants/stringConstants';
import {getProductFromCart} from '../../utils/cartHelpers';
import {navigationHook} from '../../navigation/navigatorHook';
import {validateRequiredField} from '../../utils/validators';

const SearchScreen = ({
    navigation,
    productList,
    dateString,
    cartList,
    tagList
  }) => {
    const [productArray, setProductArray] = useState([]);
    const [filteredArray, setFilteredArray] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    useEffect(() => {

        const delayDebounceFn = setTimeout(() => {
            debugger;
            console.log(searchTerm);
            if(searchTerm == '' && productList != null)
            {
                setFilteredArray(productList);
            }
            else{
                let filteredData = searchLogic(searchTerm);
                setFilteredArray(filteredData);
            }
            //debugger;
            // Send Axios request here
        }, 800)

        return () => clearTimeout(delayDebounceFn)
    }, [searchTerm]);

    useEffect(() =>{
        if(productList !=null){
            setProductArray(productList);
            setFilteredArray(productList);
        }

    },[productList])

    const searchLogic=(searchKeyword) =>{
        // debugger;
        console.log(searchKeyword);
        const searchText = searchKeyword.toLowerCase();
        let newData = [];
        let searchedTag = '';
        if (searchText.length > 0) {
            if (validateRequiredField(tagList)) {
                for (let item = 0; item < tagList.length; item++){
                    if (tagList[item].TagName.toLowerCase() === searchText) {
                        searchedTag = tagList[item];
                        break;
                    }
                }
            }
        }
        if(searchedTag!== ''){
            console.log(searchedTag);
            productArray.filter((eachProduct) => {
                if (eachProduct.TagsList.length > 0) {
                    eachProduct.TagsList.filter((eachTag) => {
                        if (eachTag.Id === searchedTag.Id) {
                            newData.push(eachProduct);
                        }
                    })
                }
            });
        }
        else {
            productArray.filter((item) => {
                if (item.ItemDescription.toLowerCase().indexOf(searchText) !== -1) {
                    newData.push(item);
                }
            });
        }

        return(newData);
    }


    const updateSearch = search => {
        setSearchTerm(search);
    };

    const onProductPress = (productObj) =>{
    debugger;
        let productDetails = getProductFromCart(productObj, cartList);
      // navigationHook(NAVIGATION_TO_MESSAGE_SCREEN, {});
      //   navigationHook(ROUTE_HOME, {
      //       screen: ROUTE_DRAWER,
      //       params: {
      //           screen: ROUTE_BOTTOM_NAV,
      //           params:{
      //               screen: NAVIGATION_TO_MESSAGE_SCREEN
      //           }
      //       }
      //   });
       navigation.navigate(NAVIGATION_TO_PRODUCT_DETAIL_SCREEN, {productDetails: productDetails})
    };


    return(
    <GenericTemplate style={styles.genericTemplateStyle} keyboardAwareView={true}>
        <UserBrandHeader headerStyle={{height:'18%'}}
                         navigation={navigation} headerNavigator={false} headerBackButton={true}/>
        <View style={{height:'12%', maxHeight:MAX_HEIGHT_70}}>
        <SearchBar
          containerStyle={{ height: '100%', justifyContent:'center'}}
          inputContainerStyle={{backgroundColor: GENERIC_BACKGROUND_COLOR,}}
          placeholder={TYPE_PRODUCT_HERE}
          inputStyle={{color: BLACK_COLOR}}
          onChangeText={updateSearch}
          value={searchTerm}
          lightTheme
      />
        </View>
        {
        (filteredArray.length !== 0)?
        <View style={{height:'70%'}}>
            <FlatList
                data={filteredArray}
                renderItem={({item, index, separators}) => (
                    <TouchableWithoutFeedback
                        onPress={() => onProductPress(item)}>
                        <View>
                            <ScrollViewTemplate itemData={item} dateString={dateString}/>
                        </View>
                    </TouchableWithoutFeedback>
                )}
            />
        </View>
        :
        <View style={styles.noProductStyle}>
            <Text style={styles.emptyContentStyle}>{NO_MATCHING_PRODUCTS}</Text>
        </View>
        }
    </GenericTemplate>
)};

const styles = StyleSheet.create({
    genericTemplateStyle:{
    flex: 1,
    flexDirection:"column"
    },
    noProductStyle:{
        height:'70%', alignItems:'center', justifyContent:'center'
    },
    emptyContentStyle:{
        color:PRODUCT_NAME_COLOR, fontSize:TEXT_SIZE_15
    }
});
const mapStateToProps = (reduxStore) => {
        return {
            productList: reduxStore.productPage.productSuccessResponse,
            dateString: reduxStore.productPage.dateString,
            cartList: reduxStore.cart.cartList,
            tagList: reduxStore.productPage.tagList
        };
    };
export default connect(mapStateToProps, {})(SearchScreen);

