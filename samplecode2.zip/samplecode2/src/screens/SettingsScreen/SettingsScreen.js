import React from 'react';
import {StyleSheet, Text} from 'react-native';
import {GenericTemplate} from '../../components';

const SettingsScreen = () => (
  <GenericTemplate>
    <Text>Settings Screen</Text>
  </GenericTemplate>
);

const styles = StyleSheet.create({});

export default SettingsScreen;
