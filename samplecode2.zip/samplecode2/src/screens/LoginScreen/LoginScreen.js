import React, {useState, useEffect} from 'react';
import {StyleSheet, View} from 'react-native';
import {GenericTemplate,TextInput, GenericButton} from '../../components';
import {
    passwordEntered,
    emailEntered,
    loginRequest,
    userBrandRequest,
    resetHttpApiError, resetBrandSuccessResponse,
} from '../../store/Login/loginAction';
import {connect} from 'react-redux';
import {Overlay, Text} from 'react-native-elements';
import {validateEmail, validateRequiredField, passwordFormatter, tokenValidator} from '../../utils/validators';
import base64 from 'react-native-base64';
import AppAsyncStorage from '../../api/helper/AppAsyncStorage';
import {mcni_go_icon} from '../../resources/images';
import {
    TEXT_SIZE_15, AUTH_STACK_LOGO_WIDTH, AUTH_STACK_LOGO_HEIGHT, AUTH_STACK_CONTAINER_WIDTH,
    INPUT_FIELD_HEIGHT, SPACING_30, SPACING_15, SPACING_10, MODAL_CONTAINER_WIDTH,
} from '../../resources/constants/dimensions';
import {
    FORGET_PASSWORD, EMAIL_ERROR, EMPTY_ERROR, LOGIN,
    PASSWORD_PLACEHOLDER, EMAIL_PLACEHOLDER, INVALID_CREDENTIALS, OKAY,
} from '../../resources/constants/stringConstants';
import {
    HEADER_FONT_WEIGHT,
    INPUT_FIELD_BORDER_COLOR,
    TEXT_FONT_WEIGHT,
    ERROR_COLOR,
    FIELD_BORDER_RADIUS,
    FIELD_BORDER_WIDTH,
    GENERIC_BACKGROUND_COLOR, MODAL_BACKDROP_OPACITY,
} from '../../resources/constants/themeConstant';
import {LOGGED_IN_EMAIL, SESSION_TOKEN} from '../../resources/constants/asyncKeys';
import {ROUTE_FORGET_PASSWORD, ROUTE_HOME, ROUTE_INTERMEDIATE_LOGIN_PAGE} from '../../resources/constants/navRouteKeys';
import FastImage from 'react-native-fast-image';
import {getModalErrorText, logoutOnError} from '../../utils/errorHandlers';
import {SESSION_EXPIRED_MSG} from '../../resources/constants/storeConstants';
import {resetBrandAsyncFromRedux} from '../../store/ProductPage/productPageAction';
import {getTemplateCompanyData} from '../../store/Login/loginIntermediateAction';

const LoginScreen = ({
    navigation,
    // reducers state variables:
    loginSuccessResponse,
    brandSuccessResponse,
    loginFailError,
    httpError,
    comapanyListSuccessResponse,
    // actions functions:
    passwordEntered: _passwordEntered,
    emailEntered: _emailEntered,
    loginRequest: _loginRequest,
    userBrandRequest: _userBrandRequest,
    resetHttpApiError: _resetHttpApiError,
    resetBrandSuccessResponse:_resetBrandSuccessResponse,
    resetBrandAsyncFromRedux:_resetBrandAsyncFromRedux,
    getTemplateCompanyData:_getTemplateCompanyData
    }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [emailErrorMsg, setEmailErrorMsg] = useState('');
    const [passwordErrorMsg, setPasswordErrorMsg] = useState('');
    const [overlayLoaderVisibility, setOverlayLoaderVisibility] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [secureTextEntry, setSecureTextEntry] = useState(true);
    const [loginFail, setloginFail] = useState(false);
    const [httpModalVisibility, setHttpModalVisibility] =useState(false);
    const [httpModalText, setHttpModalText] =useState('');

    useEffect( () => {
        prefillEmailFromLastLogin();
    }, []);

    useEffect(() => {
         if(loginSuccessResponse!= null && loginSuccessResponse.responseData.token != null) {
             getUserAssociatedCompanyList();
         }
         else if(loginFailError!=null){
             showCredentialError();
         }
     }, [loginSuccessResponse,loginFailError]);


    useEffect(() => {
        if(comapanyListSuccessResponse!== null) {
            navigateToIntermediatePage();
        }
    }, [comapanyListSuccessResponse]);


    useEffect(() => {
    debugger;
       if(httpError!=null){
           setOverlayLoaderVisibility(false);
           showhttpErrorModal(httpError);
           _resetHttpApiError();
       }
    }, [httpError]);


    const prefillEmailFromLastLogin = async () =>{
        let prefilledEmail = await AppAsyncStorage.getValue(LOGGED_IN_EMAIL);
        if(validateRequiredField(prefilledEmail)){
            setEmail(prefilledEmail);
        }
    }


    const onPress = () =>{
        _resetBrandSuccessResponse();
        _resetBrandAsyncFromRedux();
        let fieldChecked = true;
        setloginFail(false);
        debugger;
        if(!validateRequiredField(email)){
            setEmailErrorMsg(EMPTY_ERROR);
            fieldChecked =false;
        }
        else if(!validateEmail(email)){
            setEmailErrorMsg(EMAIL_ERROR);
            fieldChecked =false;
        }

        if(!validateRequiredField(password)){
            setPasswordErrorMsg(EMPTY_ERROR);
            fieldChecked =false;
        }
        if(fieldChecked){
            let formattedPassword = passwordFormatter(password);
            let encodedPassword = base64.encode(formattedPassword);
            console.log(encodedPassword);
            setOverlayLoaderVisibility(true);
            _emailEntered(email);
            _loginRequest(email, encodedPassword);
        }
    };
    const rightIconOnPress = () =>{
        (showPassword)?(setShowPassword(false), setSecureTextEntry(true)):
            ((setShowPassword(true), setSecureTextEntry(false)));
    };

    const onTextInputChange = (input) => {
        setEmail(input);
        (!validateRequiredField(input))? setEmailErrorMsg(EMPTY_ERROR) :
        (!validateEmail(input))? setEmailErrorMsg(EMAIL_ERROR):setEmailErrorMsg("");

    }
    const onPasswordInputChange = (input) => {
        setPassword(input);
        (!validateRequiredField(input)) ? setPasswordErrorMsg(EMPTY_ERROR) : setPasswordErrorMsg("");
    }

    const getUserAssociatedCompanyList = () => {
        _getTemplateCompanyData();
    }

    // used till phase 2A -->
    const callUserBrandRequest =() => {
        //debugger;
        AppAsyncStorage.getValue(SESSION_TOKEN)
            .then(token => {
                debugger;
                if(tokenValidator(token))
                {
                    _userBrandRequest();
                }
            })
    }

    const showCredentialError = () =>{
        setloginFail(true);
        setOverlayLoaderVisibility(false);
    }

    const navigateToIntermediatePage = () => {
         if (overlayLoaderVisibility == true) {
             setOverlayLoaderVisibility(false);
         }
        console.log(comapanyListSuccessResponse);
        navigation.navigate(ROUTE_INTERMEDIATE_LOGIN_PAGE);
    }


    const showhttpErrorModal =(errorObj) =>{
    debugger;
        let errorText = getModalErrorText(errorObj);
        setHttpModalText(errorText);
        setOverlayLoaderVisibility(false);
        setHttpModalVisibility(true);
    }


    const httpModalOnPress = () =>{
    debugger;
        setHttpModalVisibility(false);
        //setHttpModalText('');  // khatara ba!!!
        if(httpModalText === SESSION_EXPIRED_MSG){
            setHttpModalText('');
            logoutOnError(navigation);
        }
        else
            setHttpModalText('');
    }


    return(
    <GenericTemplate navigation={navigation} style={styles.container} overlayLoaderVisibility={overlayLoaderVisibility}>
        <View style={{alignItems: 'center',}}>
            <FastImage source={mcni_go_icon} style={styles.authStackLogo}/>
        </View>
        <Text h3 h3Style={styles.authHeaderStyle}>{LOGIN}</Text>
        <View style={{marginTop:SPACING_30, width:AUTH_STACK_CONTAINER_WIDTH}}>
            <TextInput
                value={email}
                placeholder={EMAIL_PLACEHOLDER}
                onChangeText={onTextInputChange}
                errorStyle={{ color: ERROR_COLOR }}
                errorMessage={emailErrorMsg}
                containerStyle={{paddingLeft:0}}
                inputContainerStyle={styles.inputContainerStyle}
            />
            <TextInput
                placeholder={PASSWORD_PLACEHOLDER}
                rightIconType={showPassword?'eye-off-outline':'eye-off'}
                rightIconOnPress={rightIconOnPress}
                onChangeText={onPasswordInputChange}
                secureTextEntry={secureTextEntry}
                errorStyle={{ color: ERROR_COLOR }}
                errorMessage={passwordErrorMsg}
                containerStyle={{paddingLeft:0,}}
                inputContainerStyle={styles.inputContainerStyle}
            />
            <GenericButton title={LOGIN} onPress={onPress} titleStyle={{fontWeight:HEADER_FONT_WEIGHT,}}/>
        <View>
            <Text h4 h4Style={styles.ForgetPassStyle} onPress={() => navigation.push(ROUTE_FORGET_PASSWORD)}>{FORGET_PASSWORD}?</Text>
        </View>
        <View>
            {
                (loginFail)?
                    <Text h4 h4Style={styles.errorStyle}>{INVALID_CREDENTIALS}</Text> : null
            }
        </View>
        </View>
        <Overlay
            backdropStyle={styles.overlay}
            isVisible={httpModalVisibility}
            overlayStyle={styles.overlayModalStyle}>
            <View>
                <Text h3 h3Style={styles.modalErrorStyle}>{httpModalText}</Text>
                <GenericButton title={OKAY} onPress={httpModalOnPress}></GenericButton>
            </View>
        </Overlay>
    </GenericTemplate>
    );
};

const styles = StyleSheet.create({
    authStackLogo:{
        width:AUTH_STACK_LOGO_WIDTH,
        height:AUTH_STACK_LOGO_HEIGHT,
        alignItems:'center'
    },
    container: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    inputContainerStyle:{
        borderBottomWidth:FIELD_BORDER_WIDTH,
        borderWidth:FIELD_BORDER_WIDTH,
        borderStyle:"solid",
        borderColor:INPUT_FIELD_BORDER_COLOR,
        height: INPUT_FIELD_HEIGHT,
        padding:SPACING_10,
        width:AUTH_STACK_CONTAINER_WIDTH,
        borderRadius:FIELD_BORDER_RADIUS
    },
    authHeaderStyle:{
        fontWeight:HEADER_FONT_WEIGHT,
        textAlign:'center',
        marginTop:SPACING_30
    },
    ForgetPassStyle:{
        fontWeight:TEXT_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
        textAlign:'right',
        textDecorationLine: 'underline',
        marginTop: SPACING_15
    },
    errorStyle:{
        fontWeight:HEADER_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
        textAlign:'center',
        color:ERROR_COLOR,
        marginTop: SPACING_30
    },
    overlay:{
        backgroundColor: GENERIC_BACKGROUND_COLOR,
        opacity: MODAL_BACKDROP_OPACITY
    },
    overlayModalStyle:{
        borderWidth:FIELD_BORDER_WIDTH,
        borderColor:INPUT_FIELD_BORDER_COLOR,
        width:MODAL_CONTAINER_WIDTH
    },
    modalErrorStyle:{
        fontWeight:HEADER_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
        textAlign:'center',
        //color:ERROR_COLOR,
        marginBottom: SPACING_30
    },
});

const mapStateToProps = (reduxStore) => {
    return {
        passwordText: reduxStore.login.password,
        emailText: reduxStore.login.email,
        loginSuccessResponse: reduxStore.login.loginSuccessResponse,
        loginFailError: reduxStore.login.loginFailError,
        brandSuccessResponse: reduxStore.login.brandSuccessResponse,
        httpError: reduxStore.login.httpError,
        comapanyListSuccessResponse:reduxStore.loginIntermediate.comapanyListSuccessResponse
    };
};
export default connect(mapStateToProps, { passwordEntered, emailEntered,
    loginRequest, userBrandRequest, resetHttpApiError, resetBrandSuccessResponse, resetBrandAsyncFromRedux, getTemplateCompanyData })(LoginScreen);

{/*<Image*/}
{/*    style={{width: 66, height: 66}}*/}
{/*    source={{uri: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADMAAAAzCAYAAAA6oTAqAAAAEXRFWHRTb2Z0d2FyZQBwbmdjcnVzaEB1SfMAAABQSURBVGje7dSxCQBACARB+2/ab8BEeQNhFi6WSYzYLYudDQYGBgYGBgYGBgYGBgYGBgZmcvDqYGBgmhivGQYGBgYGBgYGBgYGBgYGBgbmQw+P/eMrC5UTVAAAAABJRU5ErkJggg=='}}*/}
{/*/>*/}


