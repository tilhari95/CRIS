import React, {useEffect, useState} from 'react';
import { FlatList, StyleSheet, TouchableWithoutFeedback, View} from 'react-native';
import {Overlay, Text} from 'react-native-elements';
import {GenericTemplate,TextInput, GenericButton} from '../../components';
import {mcni_go_icon} from '../../resources/images';
import {
    AUTH_STACK_CONTAINER_WIDTH,
    AUTH_STACK_LOGO_HEIGHT,
    AUTH_STACK_LOGO_WIDTH,
    INPUT_FIELD_HEIGHT, MODAL_CONTAINER_WIDTH, SPACING_10, SPACING_15, SPACING_30, TEXT_SIZE_15,
} from '../../resources/constants/dimensions';
import {
    BACK_TO_LOGIN,
    OKAY,
    SELECT_COMAPANY,
    PROCEED_TO_HOME, NO_COMPANY_LIST,
} from '../../resources/constants/stringConstants';
import {
    ERROR_COLOR, FIELD_BORDER_RADIUS, FIELD_BORDER_WIDTH, GENERIC_BACKGROUND_COLOR,
    HEADER_FONT_WEIGHT,
    INPUT_FIELD_BORDER_COLOR, MODAL_BACKDROP_OPACITY, PRODUCT_BORDER_COLOR,
    TEXT_FONT_WEIGHT,
} from '../../resources/constants/themeConstant';
import FastImage from 'react-native-fast-image';
import {connect} from 'react-redux';
import {getModalErrorText} from '../../utils/errorHandlers';
import DropDownPicker from "react-native-dropdown-picker";
import {ROUTE_HOME} from '../../resources/constants/navRouteKeys';
import {userBrandRequest} from '../../store/Login/loginAction';
import {
    callTemplateApi,
    resetIntermediatePageHttpError,
    resetIntermediatePageRedux,
} from '../../store/Login/loginIntermediateAction';
import ComapanyListTemplate from '../../components/GenericTemplate/CompanyListTemplate';


const LoginIntermediateScreen = ({
     navigation,
     comapanyListSuccessResponse,
     brandSuccessResponse,
     intermediatePageHttpError,
     templateListSuccessResponse,
     userBrandRequest:_userBrandRequest,
     resetIntermediatePageHttpError:_resetIntermediatePageHttpError,
     callTemplateApi:_callTemplateApi,
     resetIntermediatePageRedux:_resetIntermediatePageRedux
 }) => {


    const [proceedButtonDisable, setProceedButtonDisable]=useState(true);
    const [companyList, setCompanyList] = useState([]);
    const [templateList, setTemplateList] = useState([{label:'Select Company', value:null}]);
    const [userSelection, setUserSelection] = useState({CompanyId: '', TemplateId:''})
    const [httpModalVisibility, setHttpModalVisibility] =useState(false);
    const [htttpModalText, setHtttpModalText] =useState('');
    const [overlayLoaderVisibility, setOverlayLoaderVisibility] = useState(false);

    let dropDownController;

    useEffect(() => {
        //debugger;
        if(comapanyListSuccessResponse!== null) {
           let adjCompanyList = getCompanyListArray(comapanyListSuccessResponse);
           setCompanyList(adjCompanyList);
        }
    }, [comapanyListSuccessResponse]);

    useEffect(() => {
        if(templateListSuccessResponse!== null) {
            setOverlayLoaderVisibility(false);
            let adjTemplateList = getTemplateListArray(templateListSuccessResponse);
            setTemplateList(adjTemplateList);
        }
    }, [templateListSuccessResponse]);


    useEffect(() => {
        //debugger;
        if(brandSuccessResponse!== null) {
            navigateToHome();
        }
    }, [brandSuccessResponse]);


    useEffect(() => {
    debugger;
        if(intermediatePageHttpError!= null){
            setOverlayLoaderVisibility(false);
            showhttpErrorModal(intermediatePageHttpError);
            _resetIntermediatePageHttpError();
        }
    },[intermediatePageHttpError]);


    const getCompanyListArray = (companyList) => {
        let companyListArray =[];
        for(let item = 0; item < companyList.length; item ++){
            let obj = { isSelected: false, ...companyList[item] }
            companyListArray.push(obj);
        }
        console.log(companyListArray);
        return companyListArray
    }

    const onCompanyPress = (item, index) => {
        let dupList = JSON.parse(JSON.stringify(companyList));
      for(let i =0; i < dupList.length; i++){
          debugger;
          if( i === index){
              dupList[i].isSelected =true;
          }
          else{
              dupList[i].isSelected =false;
          }
      }
      setCompanyList(dupList);
      setUserSelection({...userSelection, CompanyId: item.CompanyId, TemplateId: '' });
      setProceedButtonDisable(true);
      dropDownController.close();
      setOverlayLoaderVisibility(true)
      _callTemplateApi(item.CompanyId);
    };


    const getTemplateListArray = (templateList) => {
        let templateDropDownArray =[]
        for(let item = 0; item < templateList.length; item ++){
            let obj = {label: templateList[item].TemplateName, value: templateList[item].TemplateName, ...templateList[item] }
            templateDropDownArray.push(obj);
        }
        console.log(templateDropDownArray);
        setUserSelection({...userSelection, TemplateId:templateList[0].Id })
        setProceedButtonDisable(false);
        return templateDropDownArray
    }


    const onTemplateListChange = (selectedTemp) => {
        setUserSelection({...userSelection, TemplateId: selectedTemp.Id })
        if(userSelection.CompanyId !== '' && selectedTemp.Id !== ''){
            setProceedButtonDisable(false);
        }
        else
            setProceedButtonDisable(true);
    };


    const onPress = () => {
        console.log(userSelection);
         setOverlayLoaderVisibility(true);
        _userBrandRequest(userSelection.CompanyId, userSelection.TemplateId);

    };

    const navigateToHome = () => {
        setOverlayLoaderVisibility(false);
        navigation.replace(ROUTE_HOME);
    }


    const showhttpErrorModal =(errorObj) =>{
    debugger;
        let errorText = getModalErrorText(errorObj);
        setHtttpModalText(errorText);
        setOverlayLoaderVisibility(false);
        setHttpModalVisibility(true);
    };


    const httpModalOnPress = () =>{
    debugger;
        setHttpModalVisibility(false);
        setHtttpModalText('');
    };

    const onBackPress =() =>{

        _resetIntermediatePageRedux();
        navigation.pop();
    }

    return(
        <GenericTemplate style={styles.container} overlayLoaderVisibility={overlayLoaderVisibility}>
            <View style={{alignItems: 'center'}}>
                <FastImage source={mcni_go_icon} style={styles.authStackLogo}/>
            </View>
            <View>
                <Text h4 h4Style={styles.authHeaderStyle}>{SELECT_COMAPANY}</Text>
            </View>
            {
            (companyList.length >0)?
            <View style={{maxHeight:250, width:AUTH_STACK_CONTAINER_WIDTH, borderWidth:1, borderColor:PRODUCT_BORDER_COLOR ,marginTop:10}}>
                <FlatList
                    data={companyList}
                    showsVerticalScrollIndicator={false}
                    contentContainerStyle={{
                    }}
                    renderItem={({item, index, separators}) => (
                        <TouchableWithoutFeedback
                            onPress={() => onCompanyPress(item, index)}>
                            <View style={{borderColor:'green',}}>
                                <ComapanyListTemplate itemData={item} />
                            </View>
                        </TouchableWithoutFeedback>
                    )}
            />
            </View>
            :
            <View style={styles.noProductStyle}>
                <Text style={styles.emptyContentStyle}>{NO_COMPANY_LIST}</Text>
            </View>
            }
            <View style={[{marginTop:SPACING_30, width:AUTH_STACK_CONTAINER_WIDTH},(Platform.OS !== 'android' && {
                zIndex: 100 // required for modal dropdown select issue on ios
            })]}>
                <DropDownPicker
                    controller={instance => dropDownController = instance}
                    items={templateList}
                    placeholder="Select Department"
                    defaultValue={templateList[0].value}
                    disabled={(templateList.length > 0 )? false:true}
                    containerStyle={{height: INPUT_FIELD_HEIGHT}}
                    dropDownStyle={{}}
                    itemStyle={{
                        justifyContent: 'flex-start'
                    }}
                    onChangeItem={(item) => onTemplateListChange(item)}
                />
            </View>
            <View style={{marginTop:SPACING_30}}>
                <GenericButton
                    title={PROCEED_TO_HOME}
                    onPress={onPress}
                    titleStyle={{fontWeight:HEADER_FONT_WEIGHT,}}
                    disabled={proceedButtonDisable}
                />
                <View>
                    <Text h4 h4Style={styles.ForgetPassStyle} onPress={onBackPress}>{BACK_TO_LOGIN}</Text>
                </View>
            </View>
            <Overlay
                backdropStyle={styles.overlay}
                isVisible={httpModalVisibility}
                overlayStyle={styles.overlayModalStyle}>
                <View>
                    <Text h3 h3Style={styles.modalErrorStyle}>{htttpModalText}</Text>
                    <GenericButton title={OKAY} onPress={httpModalOnPress}></GenericButton>
                </View>
            </Overlay>
        </GenericTemplate>
    );
};

const styles = StyleSheet.create({
    authStackLogo:{
        width:AUTH_STACK_LOGO_WIDTH,
        height:AUTH_STACK_LOGO_HEIGHT,
        alignItems:'center'
    },
    container: {
        //flex: 0.55,
        justifyContent: 'center',
        alignItems: 'center',
    },
    inputContainerStyle:{
        borderBottomWidth:FIELD_BORDER_WIDTH,
        borderWidth:FIELD_BORDER_WIDTH,
        borderStyle:"solid",
        borderColor:INPUT_FIELD_BORDER_COLOR,
        height: INPUT_FIELD_HEIGHT,
        padding:SPACING_10,
        width:AUTH_STACK_CONTAINER_WIDTH,
        borderRadius:FIELD_BORDER_RADIUS
    },
    authHeaderStyle:{
        fontSize:20,
        fontWeight:HEADER_FONT_WEIGHT,
        textAlign:'left',
        marginTop:SPACING_30
    },
    ForgetPassStyle:{
        fontWeight:TEXT_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
        textAlign:'right',
        textDecorationLine: 'underline',
        marginTop: SPACING_15
    },
    errorStyle:{
        fontWeight:HEADER_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
        textAlign:'center',
        color:ERROR_COLOR,
        marginTop: SPACING_30
    },
    overlay:{
        backgroundColor: GENERIC_BACKGROUND_COLOR,
        opacity: MODAL_BACKDROP_OPACITY
    },
    overlayModalStyle:{
        borderWidth:FIELD_BORDER_WIDTH,
        borderColor:INPUT_FIELD_BORDER_COLOR,
        width:MODAL_CONTAINER_WIDTH
    },
    modalErrorStyle:{
        fontWeight:HEADER_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
        textAlign:'center',
        //color:ERROR_COLOR,
        marginBottom: SPACING_30
    },
});


const mapStateToProps = (reduxStore) => {
    return {
        brandSuccessResponse: reduxStore.login.brandSuccessResponse,
        intermediatePageHttpError:reduxStore.loginIntermediate.intermediatePageHttpError,
        comapanyListSuccessResponse:reduxStore.loginIntermediate.comapanyListSuccessResponse,
        templateListSuccessResponse:reduxStore.loginIntermediate.templateListSuccessResponse

    }
}


export default connect(mapStateToProps,
    {
    userBrandRequest,
    resetIntermediatePageHttpError,
    callTemplateApi,
    resetIntermediatePageRedux
})(LoginIntermediateScreen);
