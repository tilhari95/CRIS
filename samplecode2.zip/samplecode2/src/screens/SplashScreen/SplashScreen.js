import React, {useEffect} from 'react';
import {StyleSheet} from 'react-native';
import {GenericTemplate} from '../../components';
import  {mcni_go_icon} from '../../resources/images';
import {connect} from 'react-redux';
import AppAsyncStorage from '../../api/helper/AppAsyncStorage';
import {SPLASH_LOGO_WIDTH, SPLASH_LOGO_HEIGHT} from '../../resources/constants/dimensions';
import {SESSION_TOKEN, USER_BRAND_DATA} from '../../resources/constants/asyncKeys';
import {ROUTE_AUTH, ROUTE_HOME} from '../../resources/constants/navRouteKeys';
import FastImage from 'react-native-fast-image';
import {setUserDataFromAsync} from '../../store/ProductPage/productPageAction';
import {tokenValidator, validateRequiredField} from '../../utils/validators';

const SplashScreen = ({navigation, setUserDataFromAsync:_setUserDataFromAsync}) => {
    setTimeout( function(){
        AppAsyncStorage.getValue(SESSION_TOKEN)
            .then(key => {
                if(tokenValidator(key)){
                    AppAsyncStorage.getValue(USER_BRAND_DATA)
                        .then(asyncUserData => {
                            if(validateRequiredField(asyncUserData)){ // to check if user has selected compony and tempelate
                                let data = JSON.parse(asyncUserData);
                                debugger;
                                _setUserDataFromAsync(data);
                                navigation.replace(ROUTE_HOME);
                            }
                            else{
                                navigation.replace(ROUTE_AUTH);
                            }
                        });
                }
                else{
                    navigation.replace(ROUTE_AUTH);
                }
        });
        }
        ,2000);
    return(
        <GenericTemplate style={styles.container}>
            <FastImage source={mcni_go_icon} style={styles.logo}/>
        </GenericTemplate>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 0.75,
        justifyContent: 'center',
        alignItems: 'center',
    },
    logo: {
        width: SPLASH_LOGO_WIDTH,
        height: SPLASH_LOGO_HEIGHT,
    },
});

const mapStateToProps = (reduxStore) => {
    return {
        //loginSuccessResponse: reduxStore.login.loginSuccessResponse
    };
};
export default connect(mapStateToProps, { setUserDataFromAsync})(SplashScreen);

