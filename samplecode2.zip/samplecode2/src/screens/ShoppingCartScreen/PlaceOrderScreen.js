import React, {useEffect, useState} from 'react';
import {FlatList, StyleSheet, View} from 'react-native';
import {Overlay, Text} from 'react-native-elements';
import {GenericTemplate} from '../../components';
import {NAVIGATION_TO_PRODUCT_SCREEN, NAVIGATION_TO_SHOPPING_CART_SCREEN} from '../../resources/constants/navRouteKeys';
import UserBrandHeader from '../../components/Headers/UserBrandHeader';
import {
    AUTH_STACK_CONTAINER_WIDTH, CONTAINER_HEIGHT_400,
    HEIGHT_100,
    HEIGHT_40,
    MODAL_CONTAINER_WIDTH,
    SPACING_10,
    SPACING_30, SPACING_5,
    TEXT_SIZE_15, WIDTH_200,
} from '../../resources/constants/dimensions';
import {
    ADD,
    ADDRESS_PLACEHOLDER, DELIVERY_ADDRESS, DOLLAR_SYMBOL,
    ITEMS,
    LOGIN, MISMATCH_WARNING_MSG,
    NOTES_PLACEHOLDER, OKAY,
    ORDER, ORDER_NOTES,
    ORDER_TOTAL, PLACE_ORDER, PRODUCT_UPDATE_SUCCESS, REVIEW_CART, TAX_STRING,
    TOTAL,
} from '../../resources/constants/stringConstants';
import {
    BOLD_FONT_WEIGHT, ERROR_COLOR, FIELD_BORDER_WIDTH, GENERIC_BACKGROUND_COLOR,
    HEADER_FONT_WEIGHT,
    INPUT_FIELD_BORDER_COLOR, MODAL_BACKDROP_OPACITY, PRODUCT_HEADER_BG_COLOR, PRODUCT_NAME_COLOR,
    TEXT_FONT_WEIGHT,
} from '../../resources/constants/themeConstant';
import TextInput from '../../components/FieldInputs/TextInput';
import GenericButton from '../../components/Buttons/GenericButton';
import {connect} from 'react-redux';
import { validateRequiredField} from '../../utils/validators';
import {
    checkAndPlaceOrder,
    resetCartReduxInitialState,
    resetCartResponseState, resetHttpOrderError,
    updateCartListAsync,
} from '../../store/Cart/cartAction';
import {getModalErrorText, logoutOnError} from '../../utils/errorHandlers';
import {PRODUCT_MISMATCH, SESSION_EXPIRED_MSG, SUCCESS_ORDER_PREFIX} from '../../resources/constants/storeConstants';
import ScrollViewTemplate from '../../components/GenericTemplate/ScrollViewTemplate';
import {cartCalculationsOnAsyncFetch, removeUpdatedProductsFromCart} from '../../utils/cartHelpers';
import {cartListToAsync} from '../../store/Cart/cartSaga';

const PlaceOrderScreen = ({
    navigation,
    cartQunatity,
    cartTotalAmount,
    httpOrderError,
    placeOrderSuccess,
    orderMismatch,
    cartList,
    userBrandDataFromAsync,
    brandSuccessResponse,
    checkAndPlaceOrder: _checkAndPlaceOrder,
    resetCartReduxInitialState:_resetCartReduxInitialState,
    resetCartResponseState:_resetCartResponseState,
    updateCartListAsync:_updateCartListAsync,
    resetHttpOrderError:_resetHttpOrderError
  }) => {
    const [orderDetails, setOrderDetails] = useState({address: '', orderNotes: ''});
    const [buttonDisable, setButtonDisable]=useState(false);
    const [overlayLoaderVisibility, setOverlayLoaderVisibility] = useState(false);
    const [httpModalVisibility, setHttpModalVisibility] =useState(false);
    const [httpModalText, setHttpModalText] =useState('');
    const [responseModalVisibility, setResponseModalVisibility] =useState(false);
    const [responseModalText, setResponseModalText] =useState('');
    const [productMismatchModal, setProductMismatchModal] =useState({visibility:false, mismatchArray: []});

    useEffect(() => {
        if(placeOrderSuccess !== null){
            setOverlayLoaderVisibility(false);
            showPlaceOrderSuccessModal(SUCCESS_ORDER_PREFIX + placeOrderSuccess.orderNumber);
        }
    },[placeOrderSuccess])

    useEffect(() => {
        if((!cartQunatity.isNaN) && cartQunatity <= 0){
            setButtonDisable(true);
        }
        else
            setButtonDisable(false);
    },[cartQunatity])


    useEffect(() => {
        if(httpOrderError!=null){
            setOverlayLoaderVisibility(false);
            showhttpErrorModal(httpOrderError);
            _resetHttpOrderError();
        }
    }, [httpOrderError]);

    useEffect(() => {
        if(orderMismatch!=null){
            setOverlayLoaderVisibility(false);
            showProductMismatchModal(orderMismatch)
        }
    }, [orderMismatch]);


    const onAddressInputChange = (address) => {
        if(!validateRequiredField(address)){
            setButtonDisable(true);
        }
        else {setButtonDisable(false);
        }
        setOrderDetails({...orderDetails, address: address});
    }

    const onOrderNotesInputChange = (text) =>{
        setOrderDetails({...orderDetails, orderNotes: text});
    }


    const onPlaceOrderPress=() =>{
        setOverlayLoaderVisibility(true);
        _checkAndPlaceOrder(orderDetails);

    }

    const showPlaceOrderSuccessModal = (text) =>{
        setResponseModalText(text);
        //setOverlayLoaderVisibility(false);
        setResponseModalVisibility(true);
    }

    const showProductMismatchModal = (mismatchArray) =>{
        //remove mismatch products
        let updateCartArray = removeUpdatedProductsFromCart(mismatchArray,cartList);
        //get new qunatity and total for updatde cart
        let cartCalObj = cartCalculationsOnAsyncFetch(updateCartArray);
        // update in redux
        _updateCartListAsync(updateCartArray, cartCalObj.badgeCount, cartCalObj.cartTotalAmount);
        // show the mismatch modal
        setProductMismatchModal({ visibility: true, mismatchArray: mismatchArray })
        //update in async Storage
        cartListToAsync(updateCartArray);
    }

    const showhttpErrorModal =(errorObj) =>{
        let errorText = getModalErrorText(errorObj);
        setHttpModalText(errorText);
        setOverlayLoaderVisibility(false);
        setHttpModalVisibility(true);
    }


    const httpModalOnPress = () =>{
        setHttpModalVisibility(false);
        setHttpModalText('');
        if(httpModalText === SESSION_EXPIRED_MSG){
            setHttpModalText('');
            logoutOnError(navigation);
        }
        else
            setHttpModalText('');
    }

    const responseModalOnPress = () =>{
        setResponseModalVisibility(false);
        setResponseModalText('');
        //clear cart redux
        _resetCartReduxInitialState();
        //back to home screen
        navigation.navigate(NAVIGATION_TO_PRODUCT_SCREEN);
    }

    const mismatchModalOnPress = () =>{
        setProductMismatchModal({ visibility: false, mismatchArray: [] });
        _resetCartResponseState();

    }

    return (
        <GenericTemplate navigation={navigation} overlayLoaderVisibility={overlayLoaderVisibility}>
            <UserBrandHeader navigation={navigation} headerBackButton={true}/>
            <View style={styles.viewBodyStyle}>
                <Text h4 h4Style={styles.totalHeaderStyle}>{ORDER}</Text>
                <View style={styles.bodyItemStyle}>
                    <View style={{width: '30%',}}>
                        <Text h4 h4Style={styles.columnLeftTextStyle}>{ITEMS}</Text>
                    </View>
                    <View style={{width: '70%', borderWidth: 1, borderColor: INPUT_FIELD_BORDER_COLOR}}>
                        <Text h4 h4Style={styles.columnRightTextStyle}>{cartQunatity}</Text>
                    </View>
                </View>
                <View style={styles.bodyItemStyle}>
                    <View style={{width: '30%',}}>
                        <Text h4 h4Style={styles.columnLeftTextStyle}>{TOTAL}</Text>
                    </View>
                    <View style={{width: '70%', borderWidth: 1, borderColor: INPUT_FIELD_BORDER_COLOR}}>
                        <Text h4 h4Style={styles.columnRightTextStyle}>{DOLLAR_SYMBOL}{cartTotalAmount}</Text>
                    </View>
                </View>
                <Text style={styles.taxTextStyle}>{TAX_STRING}</Text>
                <View style={styles.bodyItemStyle}>
                    <View style={{width: '30%',}}>
                        <Text h4 h4Style={styles.columnLeftTextStyle}>{ORDER_TOTAL}</Text>
                    </View>
                    <View style={{width: '70%', borderWidth: 1, borderColor: INPUT_FIELD_BORDER_COLOR}}>
                        <Text h4 h4Style={styles.columnRightTextStyle}>{DOLLAR_SYMBOL}{cartTotalAmount}</Text>
                    </View>
                </View>
                <View style={{marginTop: SPACING_10}}>
                    <Text h4 h4Style={[styles.columnLeftTextStyle, {marginBottom: SPACING_10}]}>{DELIVERY_ADDRESS}</Text>
                    {
                        (userBrandDataFromAsync) ?
                            <View>
                                <Text>{userBrandDataFromAsync.Address}</Text>
                                <Text>{userBrandDataFromAsync.City}, {userBrandDataFromAsync.State}</Text>
                                <Text>{userBrandDataFromAsync.Zip}</Text>
                            </View>
                            :
                            <View>
                                <Text>{brandSuccessResponse.responseData.Address}</Text>
                                <Text>{brandSuccessResponse.responseData.City}, {brandSuccessResponse.responseData.State}</Text>
                                <Text>{brandSuccessResponse.responseData.Zip}</Text>
                            </View>
                    }
                    {/*<TextInput placeholder={ADDRESS_PLACEHOLDER}*/}
                    {/*    //value={productCartDetails.notes}*/}
                    {/*    onChangeText={onAddressInputChange}*/}
                    {/*/>*/}

                </View>
                <View style={{marginTop: SPACING_10}}>
                    <Text h4 h4Style={styles.columnLeftTextStyle}>{ORDER_NOTES}</Text>
                    <TextInput placeholder={NOTES_PLACEHOLDER}
                        //value={productCartDetails.notes}
                        onChangeText={onOrderNotesInputChange}
                    />
                </View>
                <View style={{flexDirection: 'row',}}>
                    <View style={{width: '40%', paddingRight: 5}}>
                        <GenericButton onPress={()=> navigation.navigate(NAVIGATION_TO_SHOPPING_CART_SCREEN)} title={REVIEW_CART} type='outline'/>
                    </View>
                    <View style={{width: '60%', borderColor: INPUT_FIELD_BORDER_COLOR}}>
                        <GenericButton disabled={buttonDisable} onPress={()=> onPlaceOrderPress()} title={PLACE_ORDER}/>
                    </View>
                </View>
            </View>
            <Overlay
                backdropStyle={styles.overlay}
                isVisible={httpModalVisibility}
                overlayStyle={styles.overlayModalStyle}>
                <View>
                    <Text h3 h3Style={styles.modalErrorStyle}>{httpModalText}</Text>
                    <GenericButton title={OKAY} onPress={httpModalOnPress}></GenericButton>
                </View>
            </Overlay>
            <Overlay // for order place success
                backdropStyle={styles.overlay}
                isVisible={responseModalVisibility}
                overlayStyle={styles.overlayResponseModalStyle}>
                <View>
                    <Text h3 h3Style={styles.modalResponseStyle}>{responseModalText}</Text>
                    <GenericButton containerStyle={{alignItems:'center'}}
                                   buttonStyle={{width:WIDTH_200}}
                                   title={OKAY}
                                   onPress={responseModalOnPress}
                    />
                </View>
            </Overlay>
            <Overlay // mismatch order
                backdropStyle={styles.overlay}
                isVisible={productMismatchModal.visibility}
                overlayStyle={styles.overlayMismatchModalStyle}>
                <View style={{flexDirection:'column', height: CONTAINER_HEIGHT_400, }}>
                    <View style={{height:'30%',}}>
                        <Text h3 h3Style={[styles.mismatchModalStyle,{fontWeight: BOLD_FONT_WEIGHT,}]}>{PRODUCT_MISMATCH}</Text>
                        <Text h3 h3Style={styles.mismatchModalStyle}>{MISMATCH_WARNING_MSG}</Text>
                    </View>
                    <View style={{height: '60%'}}>
                    <FlatList
                        data={productMismatchModal.mismatchArray}
                        renderItem={({item, index, separators}) => (
                            <View style={styles.mismatchProductStyleView}>
                                <Text h3 h3Style={styles.mismatchProductStyle}>{item.ItemDescription}</Text>
                            </View>
                        )}
                    />
                    </View>
                    <View style={{height: '10%',}}>
                    <GenericButton title={OKAY} onPress={mismatchModalOnPress}></GenericButton>
                    </View>
                </View>
            </Overlay>
        </GenericTemplate>
    );
}

const styles = StyleSheet.create({
        totalHeaderStyle: {
            //fontWeight: BOLD_FONT_WEIGHT,
            //textAlign: 'center',
            //marginTop: SPACING_30
        },
        columnRightTextStyle: {
            paddingLeft: 10,
            textAlign: 'left',
            fontWeight: HEADER_FONT_WEIGHT,
            marginTop: SPACING_10,
            fontSize: TEXT_SIZE_15
        },
        columnLeftTextStyle: {
            //marginLeft:SPACING_10,
            textAlign: 'left',
            fontWeight: '400',
            marginTop: SPACING_10,
            fontSize: TEXT_SIZE_15
        },
        viewBodyStyle: {
            marginRight: SPACING_10,
            marginLeft: SPACING_10
        },
        bodyItemStyle: {
            flexDirection: 'row',
            height: HEIGHT_40,
            marginTop: SPACING_10
        },
        overlay: {
            backgroundColor: GENERIC_BACKGROUND_COLOR,
            opacity: MODAL_BACKDROP_OPACITY
        },
        overlayModalStyle: {
            borderWidth: FIELD_BORDER_WIDTH,
            borderColor: INPUT_FIELD_BORDER_COLOR,
            width: MODAL_CONTAINER_WIDTH
        },
        modalErrorStyle: {
            fontWeight: HEADER_FONT_WEIGHT,
            fontSize: TEXT_SIZE_15,
            textAlign: 'center',
            //color:ERROR_COLOR,
            marginBottom: SPACING_30
        },
        mismatchModalStyle: {
            fontWeight: HEADER_FONT_WEIGHT,
            fontSize: TEXT_SIZE_15,
            textAlign: 'center',
            // color:'grey',
            //marginBottom: SPACING_30
        },
        mismatchProductStyle: {
            fontWeight: HEADER_FONT_WEIGHT,
            fontSize: TEXT_SIZE_15,
            textAlign: 'center',
            //marginBottom: SPACING_30
        },
        overlayResponseModalStyle: {
            borderWidth: FIELD_BORDER_WIDTH,
            borderColor: INPUT_FIELD_BORDER_COLOR,
            width: AUTH_STACK_CONTAINER_WIDTH
        },
        overlayMismatchModalStyle: {
            borderWidth: FIELD_BORDER_WIDTH,
            borderColor: INPUT_FIELD_BORDER_COLOR,
            width: AUTH_STACK_CONTAINER_WIDTH,
            //height:400
        },
        modalResponseStyle: {
            fontWeight: BOLD_FONT_WEIGHT,
            fontSize: TEXT_SIZE_15,
            textAlign: 'center',
            //color:ERROR_COLOR,
            marginBottom: SPACING_30
        },
        taxTextStyle: {textAlign: 'right', color: 'red'},
        mismatchProductStyleView: {
            borderWidth: 1,
            backgroundColor: PRODUCT_HEADER_BG_COLOR,
            borderColor: INPUT_FIELD_BORDER_COLOR,
            paddingTop: SPACING_5,
            paddingBottom: SPACING_5,
            height: HEIGHT_40,
            justifyContent: 'center',
            marginBottom: SPACING_5
        }
    });

const mapStateToProps = (reduxStore) => {
    return {
        cartList: reduxStore.cart.cartList,
        cartQunatity: reduxStore.cart.cartBadgeValue,
        cartTotalAmount: reduxStore.cart.cartTotalAmount,
        httpOrderError: reduxStore.cart.httpOrderError,
        placeOrderSuccess: reduxStore.cart.placeOrderSuccess,
        orderMismatch: reduxStore.cart.orderMismatch,
        userBrandDataFromAsync: reduxStore.productPage.userBrandDataFromAsync,
        brandSuccessResponse: reduxStore.login.brandSuccessResponse

    };
};

export default connect(mapStateToProps, {checkAndPlaceOrder,
    updateCartListAsync,
    resetCartReduxInitialState,
    resetCartResponseState,
    resetHttpOrderError}) (PlaceOrderScreen);
