import React, {useEffect, useState} from 'react';
import {FlatList, StyleSheet, TouchableWithoutFeedback, View} from 'react-native';
import {Text} from 'react-native-elements';
import {GenericTemplate} from '../../components';
import {connect} from 'react-redux';
import {
    NAVIGATION_TO_PLACE_ORDER_SCREEN,
    NAVIGATION_TO_PRODUCT_DETAIL_SCREEN,
} from '../../resources/constants/navRouteKeys';
import ScrollViewTemplate from '../../components/GenericTemplate/ScrollViewTemplate';
import {
    BOLD_FONT_WEIGHT,
    INPUT_FIELD_BORDER_COLOR,
    PRODUCT_NAME_COLOR,
} from '../../resources/constants/themeConstant';
import {deleteItemFromCart, toggleCartUpdater} from '../../store/Cart/cartAction';
import AppAsyncStorage from '../../api/helper/AppAsyncStorage';
import {CART_LIST} from '../../resources/constants/asyncKeys';
import UserBrandHeader from '../../components/Headers/UserBrandHeader';
import {CART_EMPTY, DOLLAR_SYMBOL, PROCEED_TEXT, TOTAL_AMOUNT} from '../../resources/constants/stringConstants';
import GenericButton from '../../components/Buttons/GenericButton';
import {SPACING_10, SPACING_5, TEXT_SIZE_10, TEXT_SIZE_12, TEXT_SIZE_15} from '../../resources/constants/dimensions';

const ShoppingCartScreen = ({
    navigation,
    cartList,
    triggerCartUpdate,
    cartTotalAmount,
    cartBadgeValue,
    dateString,toggleCartUpdater:_toggleCartUpdater,
    deleteItemFromCart:_deleteItemFromCart
}) => {
    const [cartArray, setCartArray] = useState([]);


    useEffect(() =>{
        //debugger;
        if(cartList !=null && cartList.length > 0){
            setCartArray(cartList);
        }
        else if(cartList !=null && cartList.length === 0){
            setCartArray([]);
        }
        //debugger;
        if(triggerCartUpdate){
            _toggleCartUpdater(false);
        }
    },[cartList,triggerCartUpdate])

    const onItemUpdatePress = (item, index) =>{
        //debugger;
        let returnObj = {productFoundInCart: true, productObj: item, index: index }
        navigation.navigate(NAVIGATION_TO_PRODUCT_DETAIL_SCREEN, {productDetails: returnObj})
        console.log('update');
    }
    const onItemDeletePress = async (item, index) =>{
        //debugger;
        if (index > -1) {
            let diffarray = JSON.parse(JSON.stringify(cartArray));
            let quantityToDelete= diffarray[index].OrderQty;
            let priceToDelete= diffarray[index].Price;
            diffarray.splice(index, 1);
            setCartArray(diffarray);
            await _deleteItemFromCart(diffarray, quantityToDelete, priceToDelete);
        }
        console.log(cartArray);
    }

    return(
      <GenericTemplate style={styles.genericTemplateStyle}>
          <UserBrandHeader headerStyle={{height:'18%'}} navigation={navigation} headerNavigator={false}/>
          {
          (cartArray.length != 0)?
          <View style={{height:'74%'}}>
              <FlatList
              data={cartArray}
              renderItem={({item, index, separators}) => (
                  <View>
                      <ScrollViewTemplate
                          itemData={item}
                          dateString={dateString}
                          fromCart={true}
                          onUpdatePress={() =>onItemUpdatePress(item,index)}
                          onDeletePress={() =>onItemDeletePress(item, index)}
                      />
                  </View>
              )}
              />
          </View>
          :
          <View style={styles.noProductStyle}>
              <Text style={styles.emptyContentStyle}>{CART_EMPTY}</Text>
          </View>
          }
          <View style={{height:'8%', borderTopWidth:1, borderColor:INPUT_FIELD_BORDER_COLOR }}>
              <View style={{flexDirection:'row', height:'100%'}}>
                  <View style={{width:'35%',justifyContent:'center',}}>
                     <Text h4 h4Style={styles.totalAmountStyle}>{TOTAL_AMOUNT}</Text>
                     <Text h4 h4Style={styles.totalAmountStyle}>{DOLLAR_SYMBOL}{cartTotalAmount}</Text>
                  </View>
                  <View style={styles.proceedButtonStyle}>
                     <GenericButton
                         disabled={(cartBadgeValue > 0)? false: true} // enable even if products of 0 price added
                         onPress={() => navigation.navigate(NAVIGATION_TO_PLACE_ORDER_SCREEN)}
                         containerStyle={{}}
                         titleStyle={{fontSize: TEXT_SIZE_15}}
                         title={PROCEED_TEXT} />
                  </View>
              </View>
          </View>
      </GenericTemplate>
    )};

const styles = StyleSheet.create({
    noProductStyle:{
        height:'74%',
        alignItems:'center',
        justifyContent:'center'
    },
    genericTemplateStyle:{
        flex: 1,
        flexDirection:"column"
    },
    totalAmountStyle: {
        textAlign: 'center',
        color: PRODUCT_NAME_COLOR,
        fontWeight: BOLD_FONT_WEIGHT,
        fontSize: TEXT_SIZE_15,
    },
    proceedButtonStyle:{
        justifyContent:'center',
        width:"65%",
        paddingLeft:SPACING_5,
        paddingRight:SPACING_5
    },
    emptyContentStyle:{
        color:PRODUCT_NAME_COLOR, fontSize:TEXT_SIZE_15
    }
});

const mapStateToProps = (reduxStore) => {
    return {
        dateString: reduxStore.productPage.dateString,
        cartList: reduxStore.cart.cartList,
        triggerCartUpdate: reduxStore.cart.triggerCartUpdate,
        cartTotalAmount: reduxStore.cart.cartTotalAmount,
        cartBadgeValue: reduxStore.cart.cartBadgeValue
    };
};


export default connect(mapStateToProps, {toggleCartUpdater, deleteItemFromCart})(ShoppingCartScreen);
