import React, {useEffect, useState} from 'react';
import {FlatList, StyleSheet, View} from 'react-native';
import {Overlay, Text} from 'react-native-elements';
import {GenericTemplate} from '../../components';
import {
    NAVIGATION_TO_PRODUCT_SCREEN,
    NAVIGATION_TO_SHOPPING_CART_SCREEN,
    NAVIGATION_TO_SPIFF_LANDING_SCREEN,
} from '../../resources/constants/navRouteKeys';
import UserBrandHeader from '../../components/Headers/UserBrandHeader';
import {
    AUTH_STACK_CONTAINER_WIDTH, CONTAINER_HEIGHT_400,
    HEIGHT_100,
    HEIGHT_40, INPUT_FIELD_HEIGHT,
    MODAL_CONTAINER_WIDTH,
    SPACING_10,
    SPACING_30, SPACING_5, TEXT_SIZE_10,
    TEXT_SIZE_15, WIDTH_200,
} from '../../resources/constants/dimensions';
import {
    ADD,
    ADDRESS,
    ADDRESS_PLACEHOLDER,
    BACK, BALANCE_STRING,
    DELIVERY_ADDRESS,
    DOLLAR_SYMBOL, EMAIL_PLACEHOLDER,
    ITEMS,
    LOGIN,
    MISMATCH_WARNING_MSG,
    NOTES_PLACEHOLDER,
    OKAY,
    ORDER,
    ORDER_NOTES,
    ORDER_TOTAL,
    PAY_VIA, PAYMENT_ID, PAYMENT_ID_PLACEHOLDER, PAYMENTID,
    PAYOFF_AMOUNT, PAYOUT_AMOUNT, PAYOUT_AMOUNT_PLACEHOLDER,
    PAYOUT_REQ,
    PLACE_ORDER,
    PRODUCT_UPDATE_SUCCESS,
    REVIEW_CART, SPIFF_DROPDOWN_PLACEHOLDER, SPIFF_SUCCESS_STRING,
    SUBMIT_PAYOUT_REQ,
    TAX_STRING,
    TOTAL,
} from '../../resources/constants/stringConstants';
import {
    BOLD_FONT_WEIGHT, ERROR_COLOR, FIELD_BORDER_RADIUS, FIELD_BORDER_WIDTH, GENERIC_BACKGROUND_COLOR, GREY_ICON_COLOR,
    HEADER_FONT_WEIGHT,
    INPUT_FIELD_BORDER_COLOR, MODAL_BACKDROP_OPACITY, PRODUCT_HEADER_BG_COLOR, PRODUCT_NAME_COLOR,
    TEXT_FONT_WEIGHT,
} from '../../resources/constants/themeConstant';
import TextInput from '../../components/FieldInputs/TextInput';
import GenericButton from '../../components/Buttons/GenericButton';
import {connect} from 'react-redux';
import {spiffAmountValidator, validateRequiredField} from '../../utils/validators';
import {getModalErrorText, logoutOnError} from '../../utils/errorHandlers';
import {PRODUCT_MISMATCH, SESSION_EXPIRED_MSG, SUCCESS_ORDER_PREFIX} from '../../resources/constants/storeConstants';
import {cartListToAsync} from '../../store/Cart/cartSaga';
import DropDownPicker from 'react-native-dropdown-picker';
import Icon from 'react-native-vector-icons/RNIMigration';
import {useFocusEffect} from '@react-navigation/core';
import {
    requestFinalSpiffPayout,
    requestPaymentMode,
    resetHttpSpiffPayoutApiError,
    resetPayoutSuccess,
    resetSpiffCompleteRedux,
} from '../../store/Spiff/spiffAction';
const SpiffPayoutScreen = ({
    navigation,
   payoutTypesApiSuccess,
   spiffPayoutPageHttpError,
   getSpiffTranctionSuccessResponse,
   payoutFinalRequestSuccess,
   userBrandDataFromAsync,
   brandSuccessResponse,

   requestPaymentMode:_requestPaymentMode,
   resetPayoutSuccess:_resetPayoutSuccess,
   resetHttpSpiffPayoutApiError:_resetHttpSpiffPayoutApiError,
   resetSpiffCompleteRedux:_resetSpiffCompleteRedux,
   requestFinalSpiffPayout:_requestFinalSpiffPayout
    }) => {
    const [payoutModes, setPayoutModes] = useState([{label: 'none', value:''}]);
    const [payoutRequestObj, setPayoutRequestObj] = useState({payoutId: '', payoutAmount: '', payoutNotes: '', payoutMethod:''})
    const [buttonDisable, setButtonDisable]=useState(true);
    const [overlayLoaderVisibility, setOverlayLoaderVisibility] = useState(false);
    const [httpModalVisibility, setHttpModalVisibility] =useState(false);
    const [httpModalText, setHttpModalText] =useState('');
    const [responseModalVisibility, setResponseModalVisibility] =useState(false);
    const [responseModalText, setResponseModalText] =useState('');

    useFocusEffect(
        React.useCallback(() => {
           setOverlayLoaderVisibility(true);
            _requestPaymentMode();
        },[])
    );

    useEffect(() => {
        if(payoutTypesApiSuccess !== null){
            setOverlayLoaderVisibility(false);
            debugger;
          //  console.log(payoutTypesApiSuccess);
            let payoutArray = getDropDownListArray(payoutTypesApiSuccess);
            setPayoutModes(payoutArray);
        }
    },[payoutTypesApiSuccess])


    useEffect(() => {
        if(spiffPayoutPageHttpError!==null){
            setOverlayLoaderVisibility(false);
            showhttpErrorModal(spiffPayoutPageHttpError);
            _resetHttpSpiffPayoutApiError();
        }
    }, [spiffPayoutPageHttpError]);

    useEffect(() => {
        if(payoutFinalRequestSuccess !== null){
            setOverlayLoaderVisibility(false);
            showSpiffPayoutSuccessModal(SPIFF_SUCCESS_STRING);
        }
    },[payoutFinalRequestSuccess])

    const onPayoutAmountChange = (amount) => {
        debugger;
        let validBool = spiffAmountValidator(amount, getSpiffTranctionSuccessResponse.spiffBalance);
        if(validBool){
            setPayoutRequestObj({...payoutRequestObj, payoutAmount: amount});
            toggleButtonFunc(payoutRequestObj.payoutMethod, payoutRequestObj.payoutId, amount);
        }
        else
            setButtonDisable(true);
    }

    const onPayoutIdInputChange = (payoutId) => {
        setPayoutRequestObj({...payoutRequestObj, payoutId: payoutId});
        toggleButtonFunc(payoutRequestObj.payoutMethod, payoutId, payoutRequestObj.payoutAmount);
    }

    const onOrderNotesInputChange = (text) => {
        setPayoutRequestObj({...payoutRequestObj, payoutNotes: text});
    }

    const onDropDownListChange = (item) => {
            setPayoutRequestObj({...payoutRequestObj, payoutMethod:item.value});
            toggleButtonFunc(item.value, payoutRequestObj.payoutId, payoutRequestObj.payoutAmount );
    }

    const toggleButtonFunc = (payoutMethod, payoutId, payoutAmount) =>{
       // console.log(payoutMethod + '  ' +  payoutId + '  ' + payoutAmount);
        if(validateRequiredField(payoutId)
            && validateRequiredField(payoutAmount)
            && validateRequiredField(payoutMethod)){
            setButtonDisable(false);
        }
        else
            setButtonDisable(true);
    }

    const onRequestPayoutPress=() => {
        setOverlayLoaderVisibility(true);
        _requestFinalSpiffPayout(payoutRequestObj);
    }

    const showSpiffPayoutSuccessModal = (text) => {
        setResponseModalText(text);
        setResponseModalVisibility(true);
    }

    const showhttpErrorModal =(errorObj) =>{
        let errorText = getModalErrorText(errorObj);
        setHttpModalText(errorText);
        setOverlayLoaderVisibility(false);
        setHttpModalVisibility(true);
    }

    const httpModalOnPress = () =>{
        setHttpModalVisibility(false);
        setHttpModalText('');
        if(httpModalText === SESSION_EXPIRED_MSG){
            setHttpModalText('');
            logoutOnError(navigation);
        }
        else {
            setHttpModalText('');
            onBackPress();
        }
    }

    const responseModalOnPress = () =>{
        setResponseModalVisibility(false);
        setResponseModalText('');
        //clear spiff redux
        _resetSpiffCompleteRedux()
        //back to spiff landing screen
        navigation.pop();
    }

    const onBackPress = ()  => {
        _resetPayoutSuccess(); navigation.pop();
    };

    const getDropDownListArray = (payoutList) =>{
       let payoutDropDownArray =[]
        for(let item = 0; item < payoutList.length; item ++){
            let obj = {label: payoutList[item].PayoutType, value: payoutList[item].PayoutType}
            payoutDropDownArray.push(obj);
        }
        console.log(payoutDropDownArray);
        return payoutDropDownArray
    }

    return (
        <GenericTemplate navigation={navigation} overlayLoaderVisibility={overlayLoaderVisibility}>
            <UserBrandHeader navigation={navigation}  customOnBackPress={() => {_resetPayoutSuccess();}} headerBackButton={true} />
            <View style={styles.viewBodyStyle}>
                <View>
                    <Text h4 h4Style={styles.totalHeaderStyle}>{PAYOUT_REQ}</Text>
                </View>
                <View style={styles.bodyItemStyle}>
                    <View style={{width: '30%',}}>
                        <Text h4 h4Style={styles.columnLeftTextStyle}>{PAYOUT_AMOUNT}</Text>
                    </View>
                    <View style={{width: '70%', flexDirection:'row',borderWidth: 1, borderColor: INPUT_FIELD_BORDER_COLOR}}>
                        <View style={{width:'10%', justifyContent:'center', alignItems:'center'}}>
                            <Text style={{fontSize:20}}>{DOLLAR_SYMBOL}</Text>
                        </View>
                        <View style={{width:'90%'}}>
                        <TextInput
                            keyboardType={'numeric'}
                            placeholder={PAYOUT_AMOUNT_PLACEHOLDER}
                            inputStyle={{fontSize:15}}
                            onChangeText={onPayoutAmountChange}
                            containerStyle={{paddingLeft:0}}
                            inputContainerStyle={styles.inputContainerStyle}
                        />
                        </View>
                    </View>
                </View>
                <View>
                    <Text style={styles.payoutTextStyle}>{BALANCE_STRING}</Text>
                </View>
                <View style={[styles.bodyItemStyle,(Platform.OS !== 'android' && {
                    zIndex: 10 // required for modal dropdown select issue on ios
                })]}>
                    <View style={{width: '30%',}}>
                        <Text h4 h4Style={styles.columnLeftTextStyle}>{PAY_VIA}</Text>
                    </View>
                    <View style={{width: '70%', }}>
                        <DropDownPicker
                            items={payoutModes}
                            placeholder={SPIFF_DROPDOWN_PLACEHOLDER}
                            style={{}}
                           // defaultValue={ {label: 'Venmo', value: 'uk'}}
                            containerStyle={{height: INPUT_FIELD_HEIGHT}}
                            dropDownStyle={{}}
                            itemStyle={{
                                justifyContent: 'flex-start'
                            }}
                            onChangeItem={(item) => onDropDownListChange(item)}
                        />
                    </View>
                </View>
                <View style={{marginTop: SPACING_10}}>
                    <Text h4 h4Style={styles.columnLeftTextStyle}>{PAYMENT_ID}</Text>
                    <TextInput placeholder={PAYMENT_ID_PLACEHOLDER}
                    //value={productCartDetails.notes}
                    onChangeText={onPayoutIdInputChange} />
                </View>
                <View style={{marginTop: SPACING_10}}>
                    <Text h4 h4Style={styles.columnLeftTextStyle}>{ORDER_NOTES}</Text>
                    <TextInput placeholder={NOTES_PLACEHOLDER}
                    //value={productCartDetails.notes}
                    onChangeText={onOrderNotesInputChange}/>
                </View>
                <View style={{marginBottom: SPACING_10}}>
                    <Text h4 h4Style={[styles.columnLeftTextStyle, {marginBottom: SPACING_10}]}>{ADDRESS}</Text>
                    {
                        (userBrandDataFromAsync) ?
                            <View>
                                <Text>{userBrandDataFromAsync.Address}</Text>
                                <Text>{userBrandDataFromAsync.City}, {userBrandDataFromAsync.State}</Text>
                                <Text>{userBrandDataFromAsync.Zip}</Text>
                            </View>
                            :
                            <View>
                                <Text>{brandSuccessResponse.responseData.Address}</Text>
                                <Text>{brandSuccessResponse.responseData.City}, {brandSuccessResponse.responseData.State}</Text>
                                <Text>{brandSuccessResponse.responseData.Zip}</Text>
                            </View>
                    }
                </View>
                <View style={{flexDirection: 'row',}}>
                    <View style={{width: '30%', paddingRight: 5}}>
                        <GenericButton onPress={onBackPress} title={BACK} type='outline'/>
                    </View>
                    <View style={{width: '70%', borderColor: INPUT_FIELD_BORDER_COLOR}}>
                        <GenericButton disabled={buttonDisable} onPress={()=> onRequestPayoutPress()} title={SUBMIT_PAYOUT_REQ}/>
                    </View>
                </View>
            </View>
            <Overlay
                backdropStyle={styles.overlay}
                isVisible={httpModalVisibility}
                overlayStyle={styles.overlayModalStyle}>
                <View>
                    <Text h3 h3Style={styles.modalErrorStyle}>{httpModalText}</Text>
                    <GenericButton title={OKAY} onPress={httpModalOnPress}></GenericButton>
                </View>
            </Overlay>
            <Overlay // for spiff request success
                backdropStyle={styles.overlay}
                isVisible={responseModalVisibility}
                overlayStyle={styles.overlayResponseModalStyle}>
                <View>
                    <Text h3 h3Style={styles.modalResponseStyle}>{responseModalText}</Text>
                    <GenericButton containerStyle={{alignItems:'center'}}
                                   buttonStyle={{width:WIDTH_200}}
                                   title={OKAY}
                                   onPress={responseModalOnPress}
                    />
                </View>
            </Overlay>
        </GenericTemplate>
    );
}

const styles = StyleSheet.create({
    totalHeaderStyle: {
       // fontWeight: '300',
        //textAlign: 'center',
        //marginTop: SPACING_30
    },
    columnRightTextStyle: {
        paddingLeft: 10,
        textAlign: 'left',
        fontWeight: HEADER_FONT_WEIGHT,
        marginTop: SPACING_10,
        fontSize: TEXT_SIZE_15
    },
    columnLeftTextStyle: {
        //marginLeft:SPACING_10,
        textAlign: 'left',
        fontWeight: '400',
        marginTop: SPACING_10,
        fontSize: TEXT_SIZE_15
    },
    viewBodyStyle: {
        marginRight: SPACING_10,
        marginLeft: SPACING_10
    },
    bodyItemStyle: {
        flexDirection: 'row',
        height: HEIGHT_40,
        marginTop: SPACING_10
    },
    overlay: {
        backgroundColor: GENERIC_BACKGROUND_COLOR,
        opacity: MODAL_BACKDROP_OPACITY
    },
    overlayModalStyle: {
        borderWidth: FIELD_BORDER_WIDTH,
        borderColor: INPUT_FIELD_BORDER_COLOR,
        width: MODAL_CONTAINER_WIDTH
    },
    modalErrorStyle: {
        fontWeight: HEADER_FONT_WEIGHT,
        fontSize: TEXT_SIZE_15,
        textAlign: 'center',
        //color:ERROR_COLOR,
        marginBottom: SPACING_30
    },
    overlayResponseModalStyle: {
        borderWidth: FIELD_BORDER_WIDTH,
        borderColor: INPUT_FIELD_BORDER_COLOR,
        width: AUTH_STACK_CONTAINER_WIDTH
    },
    modalResponseStyle: {
        fontWeight: BOLD_FONT_WEIGHT,
        fontSize: TEXT_SIZE_15,
        textAlign: 'center',
        //color:ERROR_COLOR,
        marginBottom: SPACING_30
    },
    payoutTextStyle: {textAlign: 'right', fontSize:TEXT_SIZE_10, color:GREY_ICON_COLOR},
    DropDownStyle: {
        // color: 'red',
      //  placeholderColor: 'gray',
    },
    inputContainerStyle:{
        //borderBottomWidth:FIELD_BORDER_WIDTH,
        //borderWidth:FIELD_BORDER_WIDTH,
        //borderStyle:"solid",
        //borderColor:INPUT_FIELD_BORDER_COLOR,
        height: INPUT_FIELD_HEIGHT,
        //padding:SPACING_10,
        //  width:AUTH_STACK_CONTAINER_WIDTH,
        borderRadius:FIELD_BORDER_RADIUS
    },
});

const mapStateToProps = (reduxStore) => {
    return {
        payoutTypesApiSuccess: reduxStore.spiff.payoutTypesApiSuccess,
        spiffPayoutPageHttpError: reduxStore.spiff.spiffPayoutPageHttpError,
        getSpiffTranctionSuccessResponse: reduxStore.spiff.getSpiffTranctionSuccessResponse,
        payoutFinalRequestSuccess: reduxStore.spiff.payoutFinalRequestSuccess,
        brandSuccessResponse: reduxStore.login.brandSuccessResponse,
        userBrandDataFromAsync: reduxStore.productPage.userBrandDataFromAsync,

    };
};

export default connect(mapStateToProps, {
    requestPaymentMode,
    resetPayoutSuccess,
    resetHttpSpiffPayoutApiError,
    resetSpiffCompleteRedux,
    requestFinalSpiffPayout}) (SpiffPayoutScreen);
