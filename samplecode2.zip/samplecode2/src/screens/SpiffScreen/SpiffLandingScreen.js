import React, {useEffect, useState} from 'react';
import {FlatList, StyleSheet, TouchableWithoutFeedback, View} from 'react-native';
import {Overlay, Text} from 'react-native-elements';
import {GenericTemplate} from '../../components';
import {connect} from 'react-redux';
import {
    NAVIGATION_TO_PLACE_ORDER_SCREEN,
    NAVIGATION_TO_PRODUCT_DETAIL_SCREEN, NAVIGATION_TO_SPIFF_PAYOUT_SCREEN,
} from '../../resources/constants/navRouteKeys';
import ScrollViewTemplate from '../../components/GenericTemplate/ScrollViewTemplate';
import {
    BOLD_FONT_WEIGHT, FIELD_BORDER_WIDTH, GENERIC_BACKGROUND_COLOR, HEADER_FONT_WEIGHT,
    INPUT_FIELD_BORDER_COLOR, MODAL_BACKDROP_OPACITY,
    PRODUCT_NAME_COLOR,
} from '../../resources/constants/themeConstant';
import {deleteItemFromCart, toggleCartUpdater} from '../../store/Cart/cartAction';
import AppAsyncStorage from '../../api/helper/AppAsyncStorage';
import {CART_LIST, SESSION_TOKEN} from '../../resources/constants/asyncKeys';
import UserBrandHeader from '../../components/Headers/UserBrandHeader';
import {
    BALANCE_AMOUNT,
    CART_EMPTY,
    DOLLAR_SYMBOL, LOGOUT_FROM_HOME, LOGOUT_FROM_SPIFF, OKAY,
    PAYOUT_TEXT,
    PROCEED_TEXT, REFRESH_TEXT, SPIFF_EMPTY,
    TOTAL_AMOUNT,
} from '../../resources/constants/stringConstants';
import GenericButton from '../../components/Buttons/GenericButton';
import {
    MODAL_CONTAINER_WIDTH,
    SPACING_10, SPACING_30,
    SPACING_5,
    TEXT_SIZE_10,
    TEXT_SIZE_12,
    TEXT_SIZE_15,
} from '../../resources/constants/dimensions';
import SpiffSheetTemplate from '../../components/GenericTemplate/SpiffSheetTemplate';
import {getModalErrorText, logoutOnError, logoutUser} from '../../utils/errorHandlers';
import {LOGOUT_SPIFF, SESSION_EXPIRED_MSG} from '../../resources/constants/storeConstants';
import {
    refreshSpiffBalanceAndTranaction,
    resetHttpSpiffLandingApiError,
    spiffTransactionRequest,
} from '../../store/Spiff/spiffAction';
import {roundToTwo} from '../../utils/cartHelpers';
import {resetLogoutReduxState, triggerLogoutRequest} from '../../store/Logout/logoutAction';
import {tokenValidator} from '../../utils/validators';

const SpiffLandingScreen = ({
    navigation,
    getSpiffTranctionSuccessResponse,
    SpiffLandingPageHttpError,
    logoutRequestedFromSpiff,
    logoutSuccessResponseFromSpiff,
    logoutHttpErrorSpiff,
    spiffTransactionRequest:_spiffTransactionRequest,
    resetHttpSpiffLandingApiError:_resetHttpSpiffLandingApiError,
    refreshSpiffBalanceAndTranaction:_refreshSpiffBalanceAndTranaction,
    triggerLogoutRequest:_triggerLogoutRequest,
    resetLogoutReduxState:_resetLogoutReduxState
    }) => {

    const [spiffTransactionList, setSpiffTransactionList] =useState([]);
    const [spiffBalance, setSpiffBalance] =useState(0.00);
    const [overlayLoaderVisibility, setOverlayLoaderVisibility]=useState(false);
    const [httpModalVisibility, setHttpModalVisibility] =useState(false);
    const [httpModalText, setHttpModalText] =useState('');

    useEffect(()=>{
        setOverlayLoaderVisibility(false);
        //debugger;
        if(getSpiffTranctionSuccessResponse === null || getSpiffTranctionSuccessResponse === undefined){
            requestSpiffTranctions(); // fetch from async without force update.
        }
        else{
            console.log(getSpiffTranctionSuccessResponse);
            setSpiffTransactionList(getSpiffTranctionSuccessResponse.parserSpiffTransactionList);
            setSpiffBalance(roundToTwo(getSpiffTranctionSuccessResponse.spiffBalance));
        }
    },[getSpiffTranctionSuccessResponse]);

    // handle and change view on rejection of API
    useEffect( () =>{
        if(SpiffLandingPageHttpError !== null){
            setOverlayLoaderVisibility(false);
            showhttpErrorModal(SpiffLandingPageHttpError);
            _resetHttpSpiffLandingApiError();
        }
    },[SpiffLandingPageHttpError]);

    useEffect( () =>{
        if(logoutRequestedFromSpiff === true){
            let logoutProp = LOGOUT_FROM_SPIFF;
            setOverlayLoaderVisibility(true);
            _triggerLogoutRequest(logoutProp);

        }
    },[logoutRequestedFromSpiff]);

    useEffect(()=>{
    debugger;
        if(logoutSuccessResponseFromSpiff!== null) {
            setOverlayLoaderVisibility(false);
            logoutUser(navigation);
        }
    },[logoutSuccessResponseFromSpiff]);

    useEffect( () =>{
        if(logoutHttpErrorSpiff != null){
            setOverlayLoaderVisibility(false);
            showhttpErrorModal(logoutHttpErrorSpiff);
            _resetLogoutReduxState();
        }
    },[logoutHttpErrorSpiff]);


    const requestSpiffTranctions = async () => {
        let token = await AppAsyncStorage.getValue(SESSION_TOKEN);
        if(tokenValidator(token)){
            setOverlayLoaderVisibility(true);
            _spiffTransactionRequest();
        }

    }

    const refreshTransactions = () => {
        debugger;
        // in case redux variable is already null --> to handle no internet multiple refresh click
        if(getSpiffTranctionSuccessResponse === null){
            requestSpiffTranctions();
        }
        else
            _refreshSpiffBalanceAndTranaction();
    }

    const showhttpErrorModal =(errorObj) =>{
        let errorText = getModalErrorText(errorObj);
        setHttpModalText(errorText);
        setOverlayLoaderVisibility(false);
        setHttpModalVisibility(true);
    }

    const httpModalOnPress = () => {
        setHttpModalVisibility(false);
        if(httpModalText === SESSION_EXPIRED_MSG){
            setHttpModalText('');
            logoutOnError(navigation);
        }
        else
            setHttpModalText('');
    }
    return(
        <GenericTemplate navigation={navigation} keyboardAwareView={false} overlayLoaderVisibility={overlayLoaderVisibility} style={styles.genericTemplateStyle}>
            <UserBrandHeader headerStyle={{height:'18%'}} navigation={navigation} headerNavigator={true}/>
            {
                (spiffTransactionList.length != 0)?
                    <View style={{height:'74%'}}>
                        <FlatList
                            data={spiffTransactionList}
                            renderItem={({item, index, separators}) => (
                                <View>
                                    <SpiffSheetTemplate
                                        itemData={item}
                                    />
                                </View>
                            )}
                        />
                    </View>
                    :
                    <View style={styles.noProductStyle}>
                        <Text style={styles.emptyContentStyle}>{SPIFF_EMPTY}</Text>
                    </View>
            }
            <View style={{height:'8%', borderTopWidth:1, borderColor:INPUT_FIELD_BORDER_COLOR }}>
                <View style={{flexDirection:'row', height:'100%'}}>
                    <View style={{width:'35%',justifyContent:'center',}}>
                        <Text h4 h4Style={styles.totalAmountStyle}>{BALANCE_AMOUNT}</Text>
                        <Text h4 h4Style={styles.totalAmountStyle}>{DOLLAR_SYMBOL}{spiffBalance}</Text>
                    </View>
                    <View style={styles.proceedButtonStyle}>
                        <View style={{width:'20%'}}>
                        <GenericButton
                            type='clear'
                           // disabled={(spiffBalance > 0)? false: true} // enable even if products of 0 price added
                            onPress={refreshTransactions}
                            icon='refresh'
                            size={25}
                            iconColor='black'
                            //containerStyle={{}}
                            //titleStyle={{fontSize: TEXT_SIZE_15}}
                            //title={REFRESH_TEXT}
                        />
                        </View>
                        <View style={{width:'80%'}}>
                        <GenericButton
                            disabled={(spiffBalance > 0)? false: true} // enable if balance > 0
                            onPress={() => navigation.navigate(NAVIGATION_TO_SPIFF_PAYOUT_SCREEN)}
                            containerStyle={{}}
                            titleStyle={{fontSize: TEXT_SIZE_15}}
                            title={PAYOUT_TEXT} />
                        </View>

                    </View>
                </View>
            </View>
            <Overlay
                backdropStyle={styles.overlay}
                isVisible={httpModalVisibility}
                overlayStyle={styles.overlayModalStyle}
            >
                <View>
                    <Text h3 h3Style={styles.modalErrorStyle}>{httpModalText}</Text>
                    <GenericButton title={OKAY} onPress={httpModalOnPress}></GenericButton>
                </View>
            </Overlay>
        </GenericTemplate>
    )};

const styles = StyleSheet.create({
    noProductStyle:{
        height:'74%',
        alignItems:'center',
        justifyContent:'center'
    },
    genericTemplateStyle:{
        flex: 1,
        flexDirection:"column"
    },
    totalAmountStyle: {
        textAlign: 'center',
        color: PRODUCT_NAME_COLOR,
        fontWeight: BOLD_FONT_WEIGHT,
        fontSize: TEXT_SIZE_15,
    },
    proceedButtonStyle:{
        flexDirection:'row',
        justifyContent:'center',
        alignItems:'center',
        width:"65%",
        paddingLeft:SPACING_5,
        paddingRight:SPACING_5,
       // backgroundColor: 'red'
    },
    emptyContentStyle:{
        color:PRODUCT_NAME_COLOR, fontSize:TEXT_SIZE_15
    },
    overlay:{
        backgroundColor: GENERIC_BACKGROUND_COLOR,
        opacity: MODAL_BACKDROP_OPACITY
    },
    overlayModalStyle:{
        borderWidth:FIELD_BORDER_WIDTH,
        borderColor:INPUT_FIELD_BORDER_COLOR,
        width:MODAL_CONTAINER_WIDTH,

    },
    modalErrorStyle:{
        fontWeight:HEADER_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
        textAlign:'center',
        marginBottom: SPACING_30,

    },
});

const mapStateToProps = (reduxStore) => {
    return {
        getSpiffTranctionSuccessResponse: reduxStore.spiff.getSpiffTranctionSuccessResponse,
        SpiffLandingPageHttpError: reduxStore.spiff.SpiffLandingPageHttpError,
        logoutRequestedFromSpiff: reduxStore.logout.logoutRequestedFromSpiff,
        logoutHttpErrorSpiff: reduxStore.logout.logoutHttpErrorSpiff,
        logoutSuccessResponseFromSpiff: reduxStore.logout.logoutSuccessResponseFromSpiff
    };
};


export default connect(mapStateToProps,
    {spiffTransactionRequest, resetHttpSpiffLandingApiError, refreshSpiffBalanceAndTranaction, triggerLogoutRequest, resetLogoutReduxState})(SpiffLandingScreen);
