import React, {useEffect, useState} from 'react';
import { StyleSheet, View} from 'react-native';
import {Overlay, Text} from 'react-native-elements';
import {GenericTemplate,TextInput, GenericButton} from '../../components';
import {validateRequiredField, validateEmail} from '../../utils/validators';
import {mcni_go_icon} from '../../resources/images';
import {
    AUTH_STACK_CONTAINER_WIDTH,
    AUTH_STACK_LOGO_HEIGHT,
    AUTH_STACK_LOGO_WIDTH,
    INPUT_FIELD_HEIGHT, MODAL_CONTAINER_WIDTH, SPACING_10, SPACING_15, SPACING_30, TEXT_SIZE_15,
} from '../../resources/constants/dimensions';
import {
    EMAIL_ERROR,
    RESET_PASSWORD,
    RESET_PASSWORD_LINK,
    BACK_TO_LOGIN,
    EMPTY_ERROR, EMAIL_PLACEHOLDER, INVALID_REG_EMAIL, RESET_EMAIL_SUCCESS_MSG, OKAY,
} from '../../resources/constants/stringConstants';
import {
    ERROR_COLOR, FIELD_BORDER_RADIUS, FIELD_BORDER_WIDTH, GENERIC_BACKGROUND_COLOR,
    HEADER_FONT_WEIGHT,
    INPUT_FIELD_BORDER_COLOR, MODAL_BACKDROP_OPACITY,
    TEXT_FONT_WEIGHT,
} from '../../resources/constants/themeConstant';
import FastImage from 'react-native-fast-image';
import {connect} from 'react-redux';
import {
    resetPasswordRequest,
    setHttpResetErrorToInitial,
    setPasswordReduxInitialState,
} from '../../store/ResetPassword/resetPasswordAction';
import {ROUTE_AUTH, ROUTE_FORGET_PASSWORD, ROUTE_LOGIN} from '../../resources/constants/navRouteKeys';
import {
    ERROR_401, EXCEPTION_ISSUE,
    INTERNAL_SERVER_MSG, OOPS_WRONG, REQUEST_ERROR,
    REQUEST_ISSUE, RESPONSE_ISSUE,
    SERVER_ISSUE,
    SESSION_EXPIRED_MSG, SET_LOGIN_INITIAL_STATE,
} from '../../resources/constants/storeConstants';
import AppAsyncStorage from '../../api/helper/AppAsyncStorage';
import {SESSION_TOKEN} from '../../resources/constants/asyncKeys';
import store from '../../store';
import {getModalErrorText} from '../../utils/errorHandlers';


const ResetPasswordScreen = ({
     navigation,
     resetPasswordRequest:_resetPasswordRequest,
     setPasswordReduxInitialState: _setPasswordReduxInitialState,
     setHttpResetErrorToInitial: _setHttpResetErrorToInitial,
     resetSuccessResponse,
     resetFailError,
     resetPasswordHttpError
}) => {
    const [email, setEmail] = useState('');
    const [inputErrorMsg, setInputErrorMsg] =useState('');
    const [emailErrorMsg, setEmailErrorMsg] = useState(false);
    const [emailSuccessMsg, setEmailSuccessMsg] = useState(false);
    const [httpModalVisibility, setHttpModalVisibility] =useState(false);
    const [htttpModalText, setHtttpModalText] =useState('');
    const [overlayLoaderVisibility, setOverlayLoaderVisibility] = useState(false);

    const onTextInputChange = (input) => {
        setEmail(input);
        (!validateRequiredField(input))? setInputErrorMsg(EMPTY_ERROR) :
            (!validateEmail(input))? setInputErrorMsg(EMAIL_ERROR):setInputErrorMsg("");
    };

    useEffect(() => {
         debugger;
        if(resetSuccessResponse!= null) {
            showResetSuccessMsg();
        }
        else if(resetFailError!=null){
            showCredentialError();
        }
    }, [resetSuccessResponse,resetFailError]);


    useEffect(() =>{
        debugger;
        if(resetPasswordHttpError!= null){
            setOverlayLoaderVisibility(false);
            showhttpErrorModal(resetPasswordHttpError);
            _setHttpResetErrorToInitial();
        }
    },[resetPasswordHttpError]);

    const onPress = () => {
        let emptyFieldChecked=true;
        _setHttpResetErrorToInitial();
        debugger;
        setEmailErrorMsg(false);
        setEmailSuccessMsg(false);
        if(!validateRequiredField(email)){
            setInputErrorMsg(EMPTY_ERROR);
            emptyFieldChecked =false;
        }
        else if(!validateEmail(email)){
            setInputErrorMsg(EMAIL_ERROR);
            emptyFieldChecked =false;
        }
        if(emptyFieldChecked){
            setOverlayLoaderVisibility(true);
            _resetPasswordRequest(email);

        }
    };


    const showhttpErrorModal =(errorObj) =>{
    debugger;
        let errorText = getModalErrorText(errorObj);
        setHtttpModalText(errorText);
        setOverlayLoaderVisibility(false);
        setHttpModalVisibility(true);
    };


    const httpModalOnPress = () =>{
    debugger;
        setHttpModalVisibility(false);
        setHtttpModalText('');
    };

    const onBackPress =() =>{

        _setPasswordReduxInitialState();
        navigation.pop();
    }

    const showResetSuccessMsg = () =>{
        debugger;
        setOverlayLoaderVisibility(false);
        setEmailSuccessMsg(true);
    }

    const showCredentialError = () =>{
        setOverlayLoaderVisibility(false);
        setEmailErrorMsg(true);
    }

    return(
        <GenericTemplate style={styles.container} overlayLoaderVisibility={overlayLoaderVisibility}>
            <View style={{alignItems: 'center',}}>
                <FastImage source={mcni_go_icon} style={styles.authStackLogo}/>
            </View>
            <Text h4 h4Style={styles.authHeaderStyle}>{RESET_PASSWORD}</Text>
            <View style={{marginTop:SPACING_30, width:AUTH_STACK_CONTAINER_WIDTH}}>
                <TextInput
                    placeholder={EMAIL_PLACEHOLDER}
                    onChangeText={onTextInputChange}
                    errorStyle={{ color: ERROR_COLOR }}
                    errorMessage={inputErrorMsg}
                    containerStyle={{paddingLeft:0}}
                    inputContainerStyle={styles.inputContainerStyle}
                />
                <GenericButton title={RESET_PASSWORD_LINK} onPress={onPress} titleStyle={{fontWeight:HEADER_FONT_WEIGHT,}}/>
                <View>
                    <Text h4 h4Style={styles.ForgetPassStyle} onPress={onBackPress}>{BACK_TO_LOGIN}</Text>
                </View>
            </View>
            <View>
                {
                    (emailErrorMsg)?
                        <Text h4 h4Style={styles.errorStyle}>{INVALID_REG_EMAIL}</Text> : null
                }
            </View>
            <View style={{width:AUTH_STACK_CONTAINER_WIDTH}}>
                {
                    (emailSuccessMsg)?
                        <Text h4 h4Style={[styles.errorStyle,{color: 'green'} ]}>{RESET_EMAIL_SUCCESS_MSG}</Text> : null
                }
            </View>
            <Overlay
                backdropStyle={styles.overlay}
                isVisible={httpModalVisibility}
                overlayStyle={styles.overlayModalStyle}>
                <View>
                    <Text h3 h3Style={styles.modalErrorStyle}>{htttpModalText}</Text>
                    <GenericButton title={OKAY} onPress={httpModalOnPress}></GenericButton>
                </View>
            </Overlay>
        </GenericTemplate>
    );
};

const styles = StyleSheet.create({
    authStackLogo:{
        width:AUTH_STACK_LOGO_WIDTH,
        height:AUTH_STACK_LOGO_HEIGHT,
        alignItems:'center'
    },
    container: {
        //flex: 0.55,
        justifyContent: 'center',
        alignItems: 'center',
    },
    inputContainerStyle:{
        borderBottomWidth:FIELD_BORDER_WIDTH,
        borderWidth:FIELD_BORDER_WIDTH,
        borderStyle:"solid",
        borderColor:INPUT_FIELD_BORDER_COLOR,
        height: INPUT_FIELD_HEIGHT,
        padding:SPACING_10,
        width:AUTH_STACK_CONTAINER_WIDTH,
        borderRadius:FIELD_BORDER_RADIUS
    },
    authHeaderStyle:{
        fontWeight:HEADER_FONT_WEIGHT,
        textAlign:'center',
        marginTop:SPACING_30
    },
    ForgetPassStyle:{
        fontWeight:TEXT_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
        textAlign:'right',
        textDecorationLine: 'underline',
        marginTop: SPACING_15
    },
    errorStyle:{
        fontWeight:HEADER_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
        textAlign:'center',
        color:ERROR_COLOR,
        marginTop: SPACING_30
    },
    overlay:{
        backgroundColor: GENERIC_BACKGROUND_COLOR,
        opacity: MODAL_BACKDROP_OPACITY
    },
    overlayModalStyle:{
        borderWidth:FIELD_BORDER_WIDTH,
        borderColor:INPUT_FIELD_BORDER_COLOR,
        width:MODAL_CONTAINER_WIDTH
    },
    modalErrorStyle:{
        fontWeight:HEADER_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
        textAlign:'center',
        //color:ERROR_COLOR,
        marginBottom: SPACING_30
    },
});


const mapStateToProps = (reduxStore) => {
    return {
        resetSuccessResponse: reduxStore.resetPassword.resetSuccessResponse,
        resetFailError: reduxStore.resetPassword.resetFailError,
        resetPasswordHttpError: reduxStore.resetPassword.resetPasswordHttpError

    }
}


export default connect(mapStateToProps, {resetPasswordRequest, setPasswordReduxInitialState,
    setHttpResetErrorToInitial
})(ResetPasswordScreen);
