import {
    LOGOUT_FROM_COMM,
    LOGOUT_FROM_SPIFF,
    MESSAGES,
    NO_MESSAGE,
    OKAY,
    ORDER,
    SEND_BTN_TITLE, SYNC_REPLY,
} from '../../resources/constants/stringConstants';

const messageThread = [
    {
        threadName:'some name',
        senderSource: 'server',
        senderName:'John',
        message:'I\'m interested \n in trying out barrel Is it possible to come for a trial class?',
        date:'',
        time: ''
    },
    {
        threadName:'some name',
        senderSource: 'mobile',
        senderName:'John',
        message:'I\'m interested in trying out barrel Is it possible to come for a trial class?',
        date:'',
        time: ''
    },
    {
        threadName:'some name',
        senderSource: 'server',
        senderName:'John',
        message:'I\'m interested in trying out barrel Is it possible to come for a trial class?',
        date:'',
        time: ''
    },
    {
        threadName:'some name',
        senderSource: 'mobile',
        senderName:'John',
        message:'I\'m interested in trying out barrel Is it possible to come for a trial class?',
        date:'',
        time: ''
    },
    {
        threadName:'some name',
        senderSource: 'server',
        senderName:'John',
        message:'I\'m interested in trying out barrel Is it possible to come for a trial class?',
        date:'',
        time: ''
    },
    {
        threadName:'some name',
        senderSource: 'mobile',
        senderName:'John',
        message:'I\'m interested in trying out barrel Is it possible to come for a trial class?',
        date:'',
        time: ''
    },
    {
        threadName:'some name',
        senderSource: 'server',
        senderName:'John',
        message:'I\'m interested in trying out barrel Is it possible to come for a trial class?',
        date:'',
        time: ''
    },
    {
        threadName:'some name',
        senderSource: 'mobile',
        senderName:'John',
        message:'I\'m interested in trying out barrel Is it possible to come for a trial class?',
        date:'',
        time: ''
    },
    {
        threadName:'some name',
        senderSource: 'server',
        senderName:'John',
        message:'I\'m interested in trying out barrel Is it possible to come for a trial class?',
        date:'',
        time: ''
    },
    {
        threadName:'some name',
        senderSource: 'mobile',
        senderName:'John',
        message:'I\'m interested in trying out barrel Is it possible to come for a trial class?',
        date:'',
        time: ''
    },
    {
        threadName:'some name',
        senderSource: 'server',
        senderName:'John',
        message:'?',
        date:'',
        time: ''
    },
    {
        threadName:'some name',
        senderSource: 'mobile',
        senderName:'John',
        message:'I\'m interested in trying out barrel Is it possible to come for a trial class?',
        date:'',
        time: ''
    },
    // ... // more users here
];



import React, {useEffect, useState} from 'react';
import {FlatList, StyleSheet, View} from 'react-native';
import {Overlay, Text} from 'react-native-elements';
import {GenericTemplate, MessageViewTemplate, TextInput} from '../../components';
import UserBrandHeader from '../../components/Headers/UserBrandHeader';
import {
    BOLD_FONT_WEIGHT, BORDER_WIDTH_1,
    FIELD_BORDER_WIDTH, GENERIC_BACKGROUND_COLOR, HEADER_FONT_WEIGHT, INPUT_FIELD_BORDER_COLOR, MODAL_BACKDROP_OPACITY,
    PRODUCT_BORDER_COLOR,
    PRODUCT_NAME_COLOR,
} from '../../resources/constants/themeConstant';
import {
    HEIGHT_40,
    HEIGHT_50, MODAL_CONTAINER_WIDTH, SPACING_1,
    SPACING_10, SPACING_2, SPACING_30,
    SPACING_5,
    TEXT_SIZE_10,
    TEXT_SIZE_15, TEXT_SIZE_20,
} from '../../resources/constants/dimensions';
import GenericButton from '../../components/Buttons/GenericButton';
import {connect} from 'react-redux';
import {
    getMessageRequest,
    resetMessageHttpError, resetMessageIndicator,
    resetReceivedSeverPushNotification,
    sendMessageRequest,
} from '../../store/Message/messageAction';
import {useFocusEffect} from '@react-navigation/core';
import {getModalErrorText, logoutOnError, logoutUser} from '../../utils/errorHandlers';
import {MOBILE_FLAG, SESSION_EXPIRED_MSG} from '../../resources/constants/storeConstants';
import {parseNotficationData} from '../../services/PushNotifications/parseNotificationData';
import {resetLogoutReduxState, triggerLogoutRequest} from '../../store/Logout/logoutAction';

const MessageScreen = ({
    navigation,
    getMessageSuccessResponse,
    sendMessageSuccessResponse,
    getMessageFailResponse,
    sendMessageFailResponse,
    logoutRequestedFromComm,
    logoutHttpErrorComm,
    logoutSuccessResponseFromComm,
    messageIndicator,
    messageFromSeverPushNotification,
    messageHttpError,
    getMessageRequest:_getMessageRequest,
    sendMessageRequest:_sendMessageRequest,
    resetMessageHttpError:_resetMessageHttpError,
    resetReceivedSeverPushNotification:_resetReceivedSeverPushNotification,
    resetMessageIndicator:_resetMessageIndicator,
    triggerLogoutRequest:_triggerLogoutRequest,
    resetLogoutReduxState:_resetLogoutReduxState
}) => {
    let initialScrollHeght =0;
    const [msgSend, setMsgSend] = useState('');
    const [sendButtonDisable, setSendButtonDisable] = useState(true);
    const [messageArray, setMesaageArray] = useState([]);
    const [overlayLoaderVisibility, setOverlayLoaderVisibility] = useState(false);
    const [httpModalVisibility, setHttpModalVisibility] =useState(false);
    const [httpModalText, setHttpModalText] =useState('');

    const msgScrollRef = React.createRef();
    useFocusEffect(
        React.useCallback(() => {
            if(messageIndicator){
                _resetMessageIndicator();
            }
        },[messageIndicator])
    );

    useEffect(()=> {
    debugger;
        _getMessageRequest();
        setOverlayLoaderVisibility(true);
    },[]);

    useEffect(()=>{
        debugger;
        if(getMessageSuccessResponse !== null){
            setOverlayLoaderVisibility(false);
            setMesaageArray(getMessageSuccessResponse);
        }
        else{
          //  setOverlayLoaderVisibility(true)
         //   _getMessageRequest();
        }

    },[getMessageSuccessResponse]);

    useEffect(() => {
    debugger;
        if(messageHttpError!=null){
            setOverlayLoaderVisibility(false);
            showhttpErrorModal(messageHttpError);
            _resetMessageHttpError();
        }
    }, [messageHttpError]);

    useEffect(() => {
    debugger;
        if(messageFromSeverPushNotification!=null){
            let diffArray = JSON.parse(JSON.stringify(messageArray));
            diffArray.push(messageFromSeverPushNotification)
            setMesaageArray(diffArray);
            _resetReceivedSeverPushNotification();

        }
    }, [messageFromSeverPushNotification]);

    useEffect( () =>{
        if(logoutRequestedFromComm === true){
            let logoutProp = LOGOUT_FROM_COMM;
            setOverlayLoaderVisibility(true);
            _triggerLogoutRequest(logoutProp);

        }
    },[logoutRequestedFromComm]);

    useEffect(()=>{
    debugger;
        if(logoutSuccessResponseFromComm!== null) {
            setOverlayLoaderVisibility(false);
            logoutUser(navigation);
        }
    },[logoutSuccessResponseFromComm]);

    useEffect( () =>{
        if(logoutHttpErrorComm != null){
            setOverlayLoaderVisibility(false);
            showhttpErrorModal(logoutHttpErrorComm);
            _resetLogoutReduxState();
        }
    },[logoutHttpErrorComm]);

    const trimMessageToSend = (msg) => {
        let trimmedMsg = msg.replace(/^\s+|\s+$/g, '');
        return trimmedMsg
    }

    const onSendPress =() => {
        let trimmedMsg=trimMessageToSend(msgSend);
        _sendMessageRequest(trimmedMsg);
        let diffArray = JSON.parse(JSON.stringify(messageArray));

        const date = new Date();
        const time = date.getUTCHours()+':'+date.getUTCMinutes() + ' UTC';
        diffArray.push({DateInfo:time,MessageSource:MOBILE_FLAG,MessageText:trimmedMsg})
        setMesaageArray(diffArray);
        setMsgSend('');
        setSendButtonDisable(true);
    };
    const onRefreshPress =() => {
        setOverlayLoaderVisibility(true)
        _getMessageRequest();
    };
    const onMsgChange =(msg) => {
        debugger;
        setMsgSend(msg);
        if(trimMessageToSend(msg) !== '')
        {
            setSendButtonDisable(false);
        }
        else
            setSendButtonDisable(true);

    }


    const showhttpErrorModal =(errorObj) =>{
    debugger;
        let errorText = getModalErrorText(errorObj);
        setHttpModalText(errorText);
        setOverlayLoaderVisibility(false);
        setHttpModalVisibility(true);
    }

    const httpModalOnPress = () => {
    debugger;
        setHttpModalVisibility(false);
        if(httpModalText === SESSION_EXPIRED_MSG){
            setHttpModalText('');
            logoutOnError(navigation);
        }
        else
            setHttpModalText('');
    }

    const onContentSizeChange = (cw, ch) => {
        debugger;
        if(initialScrollHeght - ch > 8 || ch - initialScrollHeght > 8){
            initialScrollHeght = ch
            console.log('content width ' + cw);
            console.log('content height ' + ch);
            msgScrollRef.current.scrollToEnd();

        }

    }


    return (
        <GenericTemplate style={styles.genericTemplateStyle} keyboardAwareView={true} overlayLoaderVisibility={overlayLoaderVisibility}>
        <UserBrandHeader headerStyle={{height:'18%'}}
                         navigation={navigation} headerNavigator={true} headerBackButton={false}/>
        {(messageArray.length > 0)?
            <View style={styles.messageHeaderStyle}>
                <Text h4 h4Style={styles.messageTextStyle}>{MESSAGES}</Text>
                <FlatList
                showsVerticalScrollIndicator={false}
                data={messageArray}
                ref={msgScrollRef}
                onContentSizeChange={(contentWidth, contentHeight)=> {onContentSizeChange(contentWidth, contentHeight)}}
                renderItem={({item, index, separators}) => (
                        <MessageViewTemplate messageData={item} />
                )}
            />
        </View>
            :
        <View style={styles.messageHeaderStyle}>
            <Text h4 h4Style={styles.messageTextStyle}>{MESSAGES}</Text>
            <View style={{alignItems: 'center', justifyContent:'center'}}>
                <Text>{NO_MESSAGE}</Text>
            </View>
        </View>
        }
        <View style={styles.bottomViewStyle}>
            <TextInput
                containerStyle={styles.inputBoxStyle}
                inputContainerStyle={styles.inputContainerStyle}
                multiline={true}
                numberOfLines={2}
                inputStyle={styles.inputTextStyle}
                onChangeText={onMsgChange}
                value={msgSend}
            />
            <View style={{flexDirection: 'row', marginTop:SPACING_2}}>
                <View style={{width:'50%'}}>
                <GenericButton
                    title={SYNC_REPLY}
                    containerStyle={{width:'50%'}}
                    titleStyle={{fontSize: TEXT_SIZE_10}}
                    type='outline'
                    onPress={onRefreshPress}
                />
                </View>
                <View style={{width:'50%', alignItems: 'flex-end'}}>
                <GenericButton
                    containerStyle={{width:'50%',}}
                    title={SEND_BTN_TITLE}
                    titleStyle={{fontSize: TEXT_SIZE_10}}
                    onPress={onSendPress}
                    disabled={sendButtonDisable}
                />
                </View>
            </View>
        </View>
        <Overlay
            backdropStyle={styles.overlay}
            isVisible={httpModalVisibility}
            overlayStyle={styles.overlayModalStyle}
        >
            <View>
                <Text h3 h3Style={styles.modalErrorStyle}>{httpModalText}</Text>
                <GenericButton title={OKAY} onPress={httpModalOnPress}></GenericButton>
            </View>
        </Overlay>
    </GenericTemplate>
    )
};

const styles = StyleSheet.create({
    messageTextStyle:{
        marginBottom:SPACING_5,
        fontSize: TEXT_SIZE_20,
        fontWeight:BOLD_FONT_WEIGHT
    },
    messageHeaderStyle:{
        height:'65%',
        marginRight: SPACING_5,
        marginLeft: SPACING_5
    },
    inputTextStyle:{
        fontSize: TEXT_SIZE_15,
        marginTop:0,
        paddingTop:SPACING_1,
        paddingBottom:SPACING_1
    },
    inputContainerStyle:{
        paddingTop:0,
        marginTop:0,
        borderWidth:BORDER_WIDTH_1,
        borderColor:INPUT_FIELD_BORDER_COLOR
    },
    inputBoxStyle:{
        height:HEIGHT_50,
        paddingRight:0,
        paddingLeft:0
    },
    bottomViewStyle:{
        height:'17%',
        marginRight:SPACING_5,
        marginLeft:SPACING_5,
        paddingTop:2,
        justifyContent:'center'
    },
    genericTemplateStyle:{
        flex: 1,
        flexDirection:"column",
    },
    overlay:{
        backgroundColor: GENERIC_BACKGROUND_COLOR,
        opacity: MODAL_BACKDROP_OPACITY
    },
    overlayModalStyle:{
        borderWidth:FIELD_BORDER_WIDTH,
        borderColor:INPUT_FIELD_BORDER_COLOR,
        width:MODAL_CONTAINER_WIDTH,
    },
    modalErrorStyle:{
        fontWeight:HEADER_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
        textAlign:'center',
        marginBottom: SPACING_30,
    },
});

const mapStateToProps = (reduxStore) => {
    return {
        getMessageSuccessResponse: reduxStore.message.getMessageSuccessResponse,
        getMessageFailResponse: reduxStore.message.getMessageFailResponse,
        sendMessageFailResponse: reduxStore.message.sendMessageFailResponse,
        sendMessageSuccessResponse: reduxStore.message.sendMessageSuccessResponse,
        messageHttpError: reduxStore.message.messageHttpError,
        messageFromSeverPushNotification: reduxStore.message.messageFromSeverPushNotification,
        messageIndicator: reduxStore.message.messageIndicator,
        logoutRequestedFromComm: reduxStore.logout.logoutRequestedFromComm,
        logoutHttpErrorComm: reduxStore.logout.logoutHttpErrorComm,
        logoutSuccessResponseFromComm: reduxStore.logout.logoutSuccessResponseFromComm

    };
};

export default connect(mapStateToProps,
    {   getMessageRequest,
        sendMessageRequest,
        resetMessageHttpError,
        resetReceivedSeverPushNotification,
        resetMessageIndicator,
        triggerLogoutRequest, resetLogoutReduxState
    })(MessageScreen);
