import * as React from 'react';

export const navigationRef = React.createRef();

export function navigationHook(name, params) {
    console.log(navigationRef);
    navigationRef.current?.navigate(name, params);
}
