import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {LoginScreen,LoginIntermediateScreen, ResetPasswordScreen} from '../screens';
import {
    ROUTE_FORGET_PASSWORD,
    ROUTE_INTERMEDIATE_LOGIN_PAGE,
    ROUTE_LOGIN,
} from '../resources/constants/navRouteKeys';

const AuthStack = createStackNavigator();

const AuthStackNavigator = () => (
        <AuthStack.Navigator  headerMode="none" initialRouteName={ROUTE_LOGIN}>
            <AuthStack.Screen name={ROUTE_LOGIN} component={LoginScreen} />
            <AuthStack.Screen name={ROUTE_FORGET_PASSWORD} component={ResetPasswordScreen} />
            <AuthStack.Screen name={ROUTE_INTERMEDIATE_LOGIN_PAGE} component={LoginIntermediateScreen} />
        </AuthStack.Navigator>
);

export default AuthStackNavigator;

