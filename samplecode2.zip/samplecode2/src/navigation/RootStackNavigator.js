/* eslint-disable prettier/prettier */
import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import AuthStackNavigator from './AuthStackNavigator';
import HomeStackNavigator from './HomeStackNavigator';
import {SplashScreen} from '../screens';
import {ROUTE_AUTH, ROUTE_HOME, ROUTE_SPLASH, ROUTE_STACK_ROOT} from '../resources/constants/navRouteKeys';
import {navigationRef} from './navigatorHook';

const RootStack = createStackNavigator();
const RootStackNavigator =() => {
    return (
        <NavigationContainer ref={navigationRef}>
            <RootStack.Navigator name={ROUTE_STACK_ROOT} headerMode="none" initialRouteName={ROUTE_SPLASH}
            >
                <RootStack.Screen name={ROUTE_SPLASH} component={SplashScreen}/>
                <RootStack.Screen name={ROUTE_AUTH} options={{gestureEnabled: false}} component={AuthStackNavigator}/>
                <RootStack.Screen name={ROUTE_HOME} options={{gestureEnabled: false}} component={HomeStackNavigator}
                />
            </RootStack.Navigator>
        </NavigationContainer>
    );
}


export default RootStackNavigator;

