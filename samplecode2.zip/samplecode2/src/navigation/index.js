import RootStackNavigator from './RootStackNavigator';

export default RootStackNavigator;
