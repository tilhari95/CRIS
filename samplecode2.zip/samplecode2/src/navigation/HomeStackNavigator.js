/* eslint-disable prettier/prettier */

import store from '../store';
import {createDrawerNavigator,DrawerContentScrollView, DrawerItemList, DrawerItem} from '@react-navigation/drawer';
import {
    NAVIGATION_TO_ORDER_HISTORY_SCREEN,
    NAVIGATION_TO_PLACE_ORDER_SCREEN,
    NAVIGATION_TO_PRODUCT_DETAIL_SCREEN,
    NAVIGATION_TO_PRODUCT_SCREEN, ROUTE_BOTTOM_NAV, ROUTE_DRAWER,
} from '../resources/constants/navRouteKeys';
import BottomTabNavigator from './BottomTabNavigator';
import {createStackNavigator} from '@react-navigation/stack';
import React from 'react';

import {
    LOGOUT, LOGOUT_COMM_CENTER, LOGOUT_SPIFF,
    PRODUCT_FORCE_UPDATE,
} from '../resources/constants/storeConstants';
import { OrderHistoryScreen, ProductDetailScreen } from '../screens';
import PlaceOrderScreen from '../screens/ShoppingCartScreen/PlaceOrderScreen';
import {
    LOGOUT_SIDEMENU,
    ORDER_HISTORY_SIDEMENU,
    REFRESH_PRODUCTS_SIDEMENU,
} from '../resources/constants/stringConstants';

const Drawer = createDrawerNavigator();

const DrawerNavigator = () => (
    <Drawer.Navigator initialRouteName={NAVIGATION_TO_PRODUCT_SCREEN}
      drawerContent={props => <CustomDrawerContent {...props} />}
      //swipeEnabled={false}
      // options={({navigation}) => ({
      //     swipeEnabled: false,
      // })}
    >
        <Drawer.Screen name={ROUTE_BOTTOM_NAV} options={{ swipeEnabled: false, }} component={BottomTabNavigator} />
    </Drawer.Navigator>
);

const HomeStack = createStackNavigator();

const HomeStackNavigator = () => (
    <HomeStack.Navigator headerMode="none" initialRouteName={ROUTE_DRAWER}>
        <HomeStack.Screen name={ROUTE_DRAWER}  options={{ gestureEnabled: false }} component={DrawerNavigator} />
        <HomeStack.Screen name={NAVIGATION_TO_PRODUCT_DETAIL_SCREEN}  options={{ gestureEnabled: false }} component={ProductDetailScreen} />
        <HomeStack.Screen name={NAVIGATION_TO_PLACE_ORDER_SCREEN}  options={{ gestureEnabled: false }} component={PlaceOrderScreen} />
        <HomeStack.Screen name={NAVIGATION_TO_ORDER_HISTORY_SCREEN}  options={{ gestureEnabled: false }} component={OrderHistoryScreen} />
    </HomeStack.Navigator>
);


const CustomDrawerContent =(props) => {
    let brandSuccessResponse = store.getState().login.brandSuccessResponse;
    let userBrandDataFromAsync = store.getState().productPage.userBrandDataFromAsync;
    return (
        <DrawerContentScrollView {...props}>
        {
        ((brandSuccessResponse !== null && brandSuccessResponse.responseData.OrderProducts === true)
        || (userBrandDataFromAsync !== null && userBrandDataFromAsync.OrderProducts === true))?
            <DrawerItem label={REFRESH_PRODUCTS_SIDEMENU} onPress={
                async () => {
                debugger;
                    await store.dispatch({type:PRODUCT_FORCE_UPDATE, payload: true});
                    props.navigation.closeDrawer();
                debugger;
                }
            }/>
                : null
        }
        <DrawerItem label={ORDER_HISTORY_SIDEMENU}
                    onPress={() => {
                    props.navigation.closeDrawer();
                    props.navigation.navigate(NAVIGATION_TO_ORDER_HISTORY_SCREEN)}}/>
        <DrawerItem label={LOGOUT_SIDEMENU} onPress={
            async () => {
                debugger;
                // await AppAsyncStorage.deleteValue(SESSION_TOKEN);
                // await store.dispatch({type:SET_LOGIN_INITIAL_STATE, payload:''});
                // await store.dispatch({type:RESET_PRODUCT_PAGE_REDUCER_STATE, payload:''});
                // await store.dispatch({type:SET_CART_REDUX_INITIAL_STATE, payload:''});

                props.navigation.closeDrawer();
                // TODO:  --> convert logout handling to HOC
                if((brandSuccessResponse !== null && brandSuccessResponse.responseData.OrderProducts === true)
                    || (userBrandDataFromAsync !== null && userBrandDataFromAsync.OrderProducts === true)){
                    await store.dispatch({type:LOGOUT, payload:''});

                }
                else if ((brandSuccessResponse !== null && brandSuccessResponse.responseData.OrderProducts === false && brandSuccessResponse.responseData.ManageSpiff === true)
                    || (userBrandDataFromAsync !== null && userBrandDataFromAsync.OrderProducts === false && userBrandDataFromAsync.ManageSpiff === true)){
                    await store.dispatch({type:LOGOUT_SPIFF, payload:''});
                }
                else if ((brandSuccessResponse !== null && brandSuccessResponse.responseData.CommCenter === true)
                    || (userBrandDataFromAsync !== null && userBrandDataFromAsync.CommCenter === true)){
                    await store.dispatch({type:LOGOUT_COMM_CENTER, payload:''});
                }

                // setTimeout( function(){
                //         props.navigation.replace(ROUTE_AUTH);
                //     }
                //     ,500);
            }
        } />
        </DrawerContentScrollView>
    );
}



export default HomeStackNavigator;
