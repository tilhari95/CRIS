import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {ShoppingCartScreen} from '../../screens/';
import {HeaderLeft, HeaderRight} from './common/CommonHeader';
import {NAVIGATION_TO_SHOPPING_CART_SCREEN} from '../../resources/constants/navRouteKeys';

const Stack = createStackNavigator();

const ShoppingCartStackNavigator = () => (
    <Stack.Navigator headerMode="none">
    <Stack.Screen
      component={ShoppingCartScreen}
      name={NAVIGATION_TO_SHOPPING_CART_SCREEN}
    />
  </Stack.Navigator>
);

export default ShoppingCartStackNavigator;
