import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {SearchScreen} from '../../screens';
import {NAVIGATION_TO_SEARCH_SCREEN} from '../../resources/constants/navRouteKeys';
import {HeaderLeft} from './common/CommonHeader';

const Stack = createStackNavigator();

const SearchScreenStackNavigator = () => (
  <Stack.Navigator headerMode="none">
    <Stack.Screen component={SearchScreen} name={NAVIGATION_TO_SEARCH_SCREEN} />
  </Stack.Navigator>
);

export default SearchScreenStackNavigator;
