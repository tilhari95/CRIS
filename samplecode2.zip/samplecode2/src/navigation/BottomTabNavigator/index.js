import React, {useEffect, useState} from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import DeviceInfo from 'react-native-device-info';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import ProductsScreenStackNavigator from './ProductsScreenStackNavigator';
import ShoppingCartStackNavigator from './ShoppingCartStackNavigator';
import SearchScreenStackNavigator from './SearchScreenStackNavigator';
import MessageScreenStackNavigator from './MessageScreenStackNavigator';
import {
    NAVIGATION_TO_PRODUCT_SCREEN,
    NAVIGATION_TO_SEARCH_SCREEN,
    NAVIGATION_TO_MESSAGE_SCREEN,
    NAVIGATION_TO_SHOPPING_CART_SCREEN, NAVIGATION_TO_SPIFF_LANDING_SCREEN,
} from '../../resources/constants/navRouteKeys';
import {
    BADGE_HEIGHT,
    BADGE_LEFT,
    BADGE_LEFT_TABLET,
    BADGE_TOP,
    BADGE_TOP_TABLET,
    TEXT_SIZE_10,
    WIDTH_100,
    WIDTH_60,
    WIDTH_80,
} from '../../resources/constants/dimensions';
import {Badge} from 'react-native-elements';
import {StyleSheet, View} from 'react-native';
import {connect} from 'react-redux';
import {
    APP_BLUE_COLOR,
} from '../../resources/constants/themeConstant';
import {
    NAV_CART_TITLE,
    NAV_MESSAGE_TITLE,
    NAV_PRODUCT_TITLE,
    NAV_SEARCH_TITLE, SPIFF_PRODUCT_TITLE,
} from '../../resources/constants/stringConstants';
import AppAsyncStorage from '../../api/helper/AppAsyncStorage';
import {USER_BRAND_DATA} from '../../resources/constants/asyncKeys';
import SettingsScreen from '../../screens/SettingsScreen/SettingsScreen';
import SpiffScreenStackNavigator from './SpiffScreenStackNavigator';

const Tab = createBottomTabNavigator();

const BottomTabNavigator = ({
    cartBadgeValue,
    messageIndicator,
    brandSuccessResponse,
    userBrandDataFromAsync,
}) => {
    console.log(brandSuccessResponse);
    console.log(userBrandDataFromAsync);
    return(
        <Tab.Navigator>
        {
            ((brandSuccessResponse !== null && brandSuccessResponse.responseData.OrderProducts === false && brandSuccessResponse.responseData.ManageSpiff === true)
                || (userBrandDataFromAsync !== null && userBrandDataFromAsync.OrderProducts === false && userBrandDataFromAsync.ManageSpiff === true))?
                <Tab.Screen
                    component={SpiffScreenStackNavigator}
                    name={NAVIGATION_TO_SPIFF_LANDING_SCREEN}
                    options={{
                        tabBarLabel: SPIFF_PRODUCT_TITLE,
                        tabBarIcon: ({focused, color, size}) => (
                            <Icon
                                name={focused ? 'home' : 'home-outline'}
                                color={APP_BLUE_COLOR}
                                size={size}
                            />
                        ),
                    }}
                />
                :
                null
        }
        {
            ((brandSuccessResponse !== null && brandSuccessResponse.responseData.OrderProducts === true)
            || (userBrandDataFromAsync !== null && userBrandDataFromAsync.OrderProducts === true))?
            <Tab.Screen
                component={ProductsScreenStackNavigator}
                name={NAVIGATION_TO_PRODUCT_SCREEN}
                options={{
                    tabBarLabel: NAV_PRODUCT_TITLE,
                    tabBarIcon: ({focused, color, size}) => (
                        <Icon
                            name={focused ? 'home' : 'home-outline'}
                            color={APP_BLUE_COLOR}
                            size={size}
                        />
                    ),
                }}
            />
             :
            null
            }
            {
            ((brandSuccessResponse !== null && brandSuccessResponse.responseData.OrderProducts === true)
                || (userBrandDataFromAsync !== null && userBrandDataFromAsync.OrderProducts === true))?
            <Tab.Screen
                component={SearchScreenStackNavigator}
                name={NAVIGATION_TO_SEARCH_SCREEN}
                options={{
                    tabBarLabel: NAV_SEARCH_TITLE,
                    tabBarIcon: ({focused, color, size}) => (
                        <Icon
                            name={focused ? 'feature-search' : 'feature-search-outline'}
                            color={APP_BLUE_COLOR}
                            size={size}
                        />
                    ),
                }}
            />
            :
            null
            }
            {
            ((brandSuccessResponse !== null && brandSuccessResponse.responseData.OrderProducts === true
                && brandSuccessResponse.responseData.ViewShoppingCart === true)
                || (userBrandDataFromAsync !== null && userBrandDataFromAsync.OrderProducts === true
                && userBrandDataFromAsync.ViewShoppingCart === true))?
                <Tab.Screen
                component={ShoppingCartStackNavigator}
                name={NAVIGATION_TO_SHOPPING_CART_SCREEN}
                options={{
                    tabBarLabel: NAV_CART_TITLE,
                    tabBarIcon: ({focused, color, size}) => {
                        return(
                            <View style={(DeviceInfo.isTablet())?(cartBadgeValue>999)?{width:WIDTH_80,}: {width: WIDTH_60} : {}}>
                                <Icon name={focused ? 'cart' : 'cart-outline'} color={APP_BLUE_COLOR} size={size} />
                                <Badge value={cartBadgeValue}
                                       badgeStyle={styles.badgeStyle}
                                       textStyle={styles.badgeTextStyle}
                                       containerStyle={styles.badgeContainerStyle}
                                />
                            </View>
                        )},
                }}
            />
            :
            null
            }
            {
            ((brandSuccessResponse !== null && brandSuccessResponse.responseData.CommCenter === true)
                || (userBrandDataFromAsync !== null && userBrandDataFromAsync.CommCenter === true))?
            <Tab.Screen
                component={MessageScreenStackNavigator}
                name={NAVIGATION_TO_MESSAGE_SCREEN}
                options={{
                    tabBarLabel: NAV_MESSAGE_TITLE,
                    tabBarIcon: ({focused, color, size}) => (
                        <View>
                            <Icon
                                name={focused ? 'message-text' : 'message-text-outline'}
                                color={APP_BLUE_COLOR}
                                size={size}
                            />
                            {(!focused && messageIndicator)?
                                <Badge
                                    badgeStyle={[{height:BADGE_HEIGHT, backgroundColor:APP_BLUE_COLOR},{width: BADGE_HEIGHT, borderRadius:10}] }
                                    containerStyle={{
                                        position: 'absolute',
                                        top: (DeviceInfo.isTablet())? BADGE_TOP_TABLET : BADGE_TOP,
                                        right: (DeviceInfo.isTablet())? BADGE_TOP_TABLET: BADGE_TOP
                                    }}
                                />
                                :
                                null
                            }
                        </View>
                    ),
                }}
            />
                    :
                    null
            }
        </Tab.Navigator>
    );
}

const styles = StyleSheet.create({
    badgeStyle:{height:BADGE_HEIGHT, backgroundColor:APP_BLUE_COLOR},
    badgeContainerStyle:{
        position: 'absolute',
        top: (DeviceInfo.isTablet())? BADGE_TOP_TABLET :BADGE_TOP,
        left: (DeviceInfo.isTablet())? BADGE_LEFT_TABLET:BADGE_LEFT
    },
    badgeTextStyle:{color:'white', fontSize:TEXT_SIZE_10}
});
const mapStateToProps = (reduxStore) => {
    return {
        cartBadgeValue: reduxStore.cart.cartBadgeValue,
        messageIndicator: reduxStore.message.messageIndicator,
        brandSuccessResponse: reduxStore.login.brandSuccessResponse,
        userBrandDataFromAsync: reduxStore.productPage.userBrandDataFromAsync,
    };
};
export default connect(mapStateToProps,{}) (BottomTabNavigator);
