import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {MessageScreen} from '../../screens';
import {NAVIGATION_TO_MESSAGE_SCREEN} from '../../resources/constants/navRouteKeys';
import {HeaderLeft} from './common/CommonHeader';

const Stack = createStackNavigator();

const MessageScreenStackNavigator = () => (
  <Stack.Navigator headerMode="none">
    <Stack.Screen
      component={MessageScreen}
      name={NAVIGATION_TO_MESSAGE_SCREEN}
    />
  </Stack.Navigator>
);

export default MessageScreenStackNavigator;


//screenOptions={({navigation}) => ({
//       headerLeft: () => <HeaderLeft navigation={navigation} />,
//     })}
