/* eslint-disable prettier/prettier */
import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {SpiffPayoutScreen, SpiffLandingScreen} from '../../screens';
import {
    NAVIGATION_TO_PRODUCT_SCREEN,
    NAVIGATION_TO_PRODUCT_DETAIL_SCREEN,
    ROUTE_LOGIN,
    ROUTE_STACK_PRODUCT,
    ROUTE_STACK_SPIFF,
    NAVIGATION_TO_SPIFF_LANDING_SCREEN,
    ROUTE_DRAWER,
    NAVIGATION_TO_SPIFF_PAYOUT_SCREEN,
} from '../../resources/constants/navRouteKeys';

const Stack = createStackNavigator();

const SpiffScreenStackNavigator =  () => {

    return(
        <Stack.Navigator name={ROUTE_STACK_SPIFF} headerMode="none" initialRouteName={NAVIGATION_TO_SPIFF_LANDING_SCREEN}>
            <Stack.Screen name={NAVIGATION_TO_SPIFF_LANDING_SCREEN} component={SpiffLandingScreen} options={{ gestureEnabled: false }} />
            <Stack.Screen name={NAVIGATION_TO_SPIFF_PAYOUT_SCREEN} component={SpiffPayoutScreen} options={{ gestureEnabled: false }} />

        </Stack.Navigator>
    );
}

export default SpiffScreenStackNavigator;


//// screenOptions={({navigation}) => ({
//         //   headerLeft: () => <HeaderLeft navigation={navigation} />,
//         //   headerRight: () => <HeaderRight />,
//         //   headerTitle: <HeaderTitle />,
//         //   headerStyle: {height: 150, backgroundColor:'green'},
//         //   headerTitleAlign: 'center'
//         // })}
