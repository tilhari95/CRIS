/* eslint-disable prettier/prettier */
import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {ProductScreen, ProductDetailScreen} from '../../screens';
import {HeaderLeft, HeaderRight, HeaderTitle} from './common/CommonHeader';
import {
    NAVIGATION_TO_PRODUCT_SCREEN,
    NAVIGATION_TO_PRODUCT_DETAIL_SCREEN,
    ROUTE_LOGIN, ROUTE_STACK_PRODUCT,
} from '../../resources/constants/navRouteKeys';

const Stack = createStackNavigator();

const ProductsScreenStackNavigator =  () => {

    return(
      <Stack.Navigator name={ROUTE_STACK_PRODUCT} headerMode="none" initialRouteName={ROUTE_LOGIN}>
        <Stack.Screen name={NAVIGATION_TO_PRODUCT_SCREEN} component={ProductScreen} options={{ gestureEnabled: false }} />
      </Stack.Navigator>
);
}

export default ProductsScreenStackNavigator;


//// screenOptions={({navigation}) => ({
//         //   headerLeft: () => <HeaderLeft navigation={navigation} />,
//         //   headerRight: () => <HeaderRight />,
//         //   headerTitle: <HeaderTitle />,
//         //   headerStyle: {height: 150, backgroundColor:'green'},
//         //   headerTitleAlign: 'center'
//         // })}
