import {MOBILE_FLAG, SERVER_FLAG} from '../../resources/constants/storeConstants';
import {receivedSeverPushNotification} from '../../store/Message/messageAction';
import store from '../../store';

export const parseNotficationData = (remotePush) =>{
    debugger;
    if(true){ //convert to switch case when server side completed for different types of notification
        parseMessageNotificationData(remotePush.data);
    }
}

const parseMessageNotificationData = (messageData) => {
    debugger;
    let messageFromSeverPushNotification ={
        'DateInfo': messageData.DateInfo,
        'MessageSource':SERVER_FLAG,
        'SenderName': messageData.SenderName,
        'MessageText':messageData.MessageText
    };
    console.log('messageFromSeverPushNotification ----->');
    console.log(messageFromSeverPushNotification);
    store.dispatch(receivedSeverPushNotification(messageFromSeverPushNotification));


}



// for testing ----->>>>


// let messageFromSeverPushNotification ={
//     'DateInfo': 'yagust 5 1998',
//     'MessageSource':SERVER_FLAG,
//     'SenderName': 'till',
//     'MessageText':'messageData.MessageText is --->>'
// };
// console.log('messageFromSeverPushNotification ----->');
// console.log(messageFromSeverPushNotification);
// store.dispatch(receivedSeverPushNotification(messageFromSeverPushNotification));
