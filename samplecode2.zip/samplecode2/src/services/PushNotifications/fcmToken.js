
import React, { Component } from 'react';
import messaging from '@react-native-firebase/messaging';
import {FCM_TOKEN} from '../../resources/constants/asyncKeys';
import AppAsyncStorage from '../../api/helper/AppAsyncStorage';

export default class FCMToken extends Component {
  // checks for Permission
  static getFirebasePermission = async () => {
    debugger;
    const authStatus = await messaging().hasPermission();
    console.log('auth status is -----------> '+ authStatus);
    const permissionEnabled =
        authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
        authStatus === messaging.AuthorizationStatus.PROVISIONAL;
    console.log('permissionEnabled bool is -----------> '+ permissionEnabled);
    if (!permissionEnabled) { // if permission not already granted.
      try {
        await messaging().requestPermission(); // request permission from user.
      } catch (error) {
        console.log('ERROR on permission granted for notification'); // user has rejected permissions.
      }
    }
  };

  static async getToken() {
    let fcmToken = await messaging().getToken();
    debugger;
    console.log('messaging().getToken() method returned FCM token ---> '+ fcmToken);
    return fcmToken;
  }

  static async getFcmTokenFromAsync() {
    debugger;
    // fetching the fcm token.
    let token = await AppAsyncStorage.getValue(FCM_TOKEN);
    debugger;
    console.log('token fromasyn storage --->>>>>>>>>>  ' +token);
    return token;
  }

  static async saveFcmTokenInAsync(fcmToken){
    await AppAsyncStorage.setValue(FCM_TOKEN, fcmToken);
    return;
  }

}
