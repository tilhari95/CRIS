import React, { Component } from 'react';
import messaging from '@react-native-firebase/messaging'


import { parseRemoteMessage } from './notificationManager';

export default class NotificationListeners extends Component {
  // Listen to Remote in the foreground
  static registerNotificationListeners(store) {
    this.messageListener = messaging().onMessage(async remoteMessage => {
        console.log('A new FCM message arrived!', JSON.stringify(remoteMessage));
    });

    // this.notificationOpenedListener = firebase.notifications().onNotificationOpened((notificationOpen: NotificationOpen) => {
    //    const notification: Notification = notificationOpen.notification;
    //    const { type } = notification.data;
    //    if (type == ACTION_APP_UPDATE_TYPE){
    //      Utils.openAppOrPlaStoreLink();
    //    }
    // });
  }

  // De Register Notification Listeners
  // static deRegisterNotificationListeners() {
  //   this.messageListener();
  // }
}
