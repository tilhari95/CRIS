import { scale, verticalScale, moderateScale } from 'react-native-size-matters';
import {Dimensions} from 'react-native';

export const SPLASH_LOGO_WIDTH = moderateScale(300, 0.3);
export const SPLASH_LOGO_HEIGHT = moderateScale(300, 0.3);
export const AUTH_STACK_LOGO_WIDTH = moderateScale(150, 0.3);
export const AUTH_STACK_LOGO_HEIGHT = moderateScale(150, 0.3);
export const BRAND_LOGO_WIDTH = moderateScale(80, 0.3);
export const BRAND_LOGO_HEIGHT = moderateScale(80, 0.3);

export const AUTH_STACK_CONTAINER_WIDTH = scale(300);
export const MODAL_CONTAINER_WIDTH = scale(200);

export const TEXT_SIZE_10 = moderateScale(10,0.3);
export const TEXT_SIZE_15 = moderateScale(15,0.3);
export const TEXT_SIZE_12 = moderateScale(12,0.3);
export const TEXT_SIZE_20 = moderateScale(20,0.3);
export const TEXT_SIZE_18 = moderateScale(18,0.3);

export const INPUT_FIELD_HEIGHT =  moderateScale(40, 0.1);
export const SPACING_30 =  moderateScale(30, 0.3);
export const ICON_30 =  moderateScale(30, 0.3);
export const SPACING_10 =  moderateScale(10, 0.3);
export const SPACING_5 =  moderateScale(5, 0.3);
export const SPACING_2 =  moderateScale(2, 0.2);
export const SPACING_1 = moderateScale(1,0.2);
export const SPACING_15 =  moderateScale(15, 0.3);
export const BADGE_TOP =  moderateScale(-4, 0.1);
export const BADGE_TOP_TABLET =  moderateScale(-10, 0.1);

export const BADGE_LEFT =  moderateScale(12, 0.2);
export const BADGE_LEFT_TABLET =  moderateScale(10, 0.1);

export const BADGE_HEIGHT =  moderateScale(15, 0.2);

//export const HEADER_HEIGHT = moderateScale(80, 0.3);
export const HEADER_HEIGHT = '15%';

export const HEIGHT_40 = moderateScale(40, 0.2);
export const HEIGHT_50 = moderateScale(50, 0.3);
export const MINUS25 = moderateScale(-25,0.3);
export const DEVICE_HEIGHT = Dimensions.get('window').height;
export const DEVICE_WIDTH = Dimensions.get('window').width;
export const WIDTH_250 = moderateScale(250, 0.3);
export const HEIGHT_250 = moderateScale(250, 0.3);
export const HEIGHT_100 = moderateScale(100,0.3);
export const HEIGHT_110 = moderateScale(110,0.3);
export const HEIGHT_MAX_130 = moderateScale(130,0.3);

export const MAX_HEIGHT_70 = 70;
export const WIDTH_200 = moderateScale(200, .2);


export const WIDTH_100 = moderateScale(100,0.3);
export const WIDTH_80 = moderateScale(80, 0.3);
export const WIDTH_60 = moderateScale(60, 0.2);


export const IMAGE_MAX_WIDTH = 600;
export const IMAGE_MAX_HEIGHT = 600;
export const CONTAINER_HEIGHT = verticalScale(500);
export const CONTAINER_HEIGHT_300 = verticalScale(300);
export const CONTAINER_HEIGHT_400 = moderateScale(400, 0.3);


//export const HEADERS__TEXT_SIZE = moderateScale(15,0.1);




