export const SESSION_TOKEN = 'sessionToken';
export const USER_BRAND_DATA = 'userBrandData';
export const LOGGED_IN_EMAIL = 'logged_in_email';
export const PRODUCT_LIST = 'product_list';
export const PRODUCT_TAG_LIST ='product_tag_list';
export const CART_LIST = 'cart-List';
export const LAST_PRODUCT_UPDATE_DATE='last_product_update_date';
export const FCM_TOKEN='fcm_token_key';


