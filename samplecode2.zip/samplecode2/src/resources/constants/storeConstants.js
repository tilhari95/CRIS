import {exp} from 'react-native-reanimated';

export const PASSWORD_ENTERED = 'password_entered';
export const PHONE_CHANGED = 'phone_changed';
export const LOGIN_REQUEST_FAIL = 'login_request_fail';
export const LOGIN_REQUEST_SUCCESS = 'login_request_success';
export const LOGOUT_SUCCESS = 'logout_success';
export const LOGOUT_SPIFF_SUCCESS ='LOGOUT_SPIFF_SUCCESS';
export const LOGOUT_COMM_SUCCESS = 'LOGOUT_COMM_SUCCESS';
export const LOGOUT_FAIL = 'logout_fail';
export const SAVE_USER_ID = 'save_user_id';
export const CLEAR_DATA_AFTER_LOGOUT = 'clear_data_after_logout';
export const EMAIL_ENTERED = 'email_entered';
export const LOGIN_REQUEST = 'login_request';
export const LOGIN_REQUEST_LOADING = 'login_request_loading';
export const USER_BRAND_REQUEST = 'user_brand_request';
export const GET_BRAND_SUCCESS = 'get_brand_success';
export const BRAND_REQUEST_FAIL = 'get_brand_fail';
export const SET_LOGIN_INITIAL_STATE = 'set_login_redux_initial_state';
export const SET_INTERMEDDIATE_PAGE_INITIAL_STATE = 'set_intermediate_page_redux_initial_state';

export const SET_LOGIN_INITIAL_STATE_ON_LOGOUT = 'set_login_redux_initial_state_on_logout';
export const RESET_BRAND_SUCCESS_RESPONSE='RESET_BRAND_SUCCESS_RESPONSE';
export const HTTP_API_ERROR='http_login_error';
export const RESET_HTTP_API_ERROR='reset_http_login_error';
export const RESET_INTERMEDIATE_PAGE_HTTP_API_ERROR='reset_intermediate_page_http_login_error';

export const SET_USER_BRAND_DATA='set_user_brand_data';
export const PRODUCT_API_REQUEST='product_api_request';
export const SET_PRODUCT_LIST_DATA='set_product_list_data';
export const PRODUCT_FORCE_UPDATE ='product_force_update';
export const PRODUCT_REQUEST_SUCCESS='product_request_success';
export const RESET_PRODUCT_PAGE_REDUCER_ON_LOGOUT='reset_product_page_redux_onlogout';
export const RESET_PRODUCT_PAGE_REDUCER_STATE='reset_product_page_reducer_state';
export const RESET_USER_ASYNC_IN_REDUX ='RESET_USER_ASYNC_IN_REDUX';
export const SET_DATE_STRING = 'set_date_string';
export const RESET_REQUEST_SUCCESS = 'reset_request_success';
export const RESET_REQUEST_FAIL = 'reset_request_fail';
export const SET_PASSWORD_INITIAL_STATE='set_password_redux_initial_state';
export const HTTP_RESET_API_ERROR='http_reset_api_error';
export const HTTP_LOGOUT_API_ERROR='http_logout_api_error';
export const HTTP_LOGOUT_API_ERROR_SPIFF ='HTTP_LOGOUT_API_ERROR_SPIFF';
export const HTTP_LOGOUT_API_ERROR_COMM ='HTTP_LOGOUT_API_ERROR_COMM';

export const HTTP_RESET_API_ERROR_RESET='reset_http_error_initial';
export const RESET_PASSWORD_REQUEST='reset_password_request';
export const SPIFF_TRANSACTION_REQUEST='spiff_transaction_request';
export const ORDER_HISTORY_LIST_REQUEST='ORDER_HISTORY_LIST_REQUEST';
export const LOGOUT_REQUEST ='logout_request';
export const LOGOUT_ON_SESSION_INVALID='LOGOUT_ON_SESSION_INVALID';
export const HTTP_PRODUCT_API_ERROR ='http_product_api_error';

export const RESET_HTTP_PRODUCT_API_ERROR='reset_http_product_api_error';
export const LOGOUT = 'logout';
export const LOGOUT_COMM_CENTER = 'logout_comm_center';
export const LOGOUT_SPIFF = 'logout_spiff'
export const RESET_HTTP_LOGOUT_API_ERROR='reset_http_logout_api_error';
export const RESET_HTTP_LOGOUT_REQUEST='reset_http_logout_request';

export const COMPANY_LIST_SUCCESS = 'company_list_success';
export const TEMPLATE_LIST_SUCCESS = 'tempelate_list_success';
export const INTERMEDIATE_PAGE_HTTP_ERROR = 'intermediate_page_http_error';
export const COMAPANY_REQUEST ='COMAPANY_REQUEST';
export const TEMPLATE_REQUEST = 'TEMPLATE_REQUEST';

export const UPDATE_CART_LIST='update_cart_list';
export const DELETE_ITEM_FROM_CART_LIST='delete_item_from_cart_list';
export const ADD_ITEM_TO_CART_LIST='add_item_to_cart_list';
export const UPDATE_ITEM_TO_CART_LIST = 'update_item_to_cart_list';
export const RESET_CART_LIST='reset_cart_list';
export const UPDATE_CART_LIST_SUCCESS = 'update_cart_list_success';
export const UPDATE_CART_ITEM_DELETE_SUCCESS= 'update_cart_item_delete_success';
export const UPDATE_CART_ITEM_ADD_SUCCESS= 'update_cart_item_add_success';
export const UPDATE_EXISTING_CART_ITEM_UPDATE_SUCCESS= 'update_existing_cart_item_update_success';

export const SET_CART_REDUX_INITIAL_STATE='set_cart_redux_initial_state';
export const SET_LOGOUT_REDUX_INITIAL_STATE='SET_LOGOUT_REDUX_INITIAL_STATE';
export const SET_ORDER_HTTP_INITIAL_STATE='set_order_http_initial_state';
export const TOGGLE_CART_UPDATER='toogle_cart_updater';
export const INITIALIZE_CARTLIST_FROM_ASYNC='initialize_cartlist_from_async';
export const RESET_CART_BADGE_VALUE='reset_cart_badge_value';
export const CHECK_AND_PLACE_ORDER='check_and_place_order';
export const SET_CART_BADGE_VALUE='set_cart_badge_value';
export const PLACE_ORDER_FAIL='place_order_fail';
export const PLACE_ORDER_SUCCESS='place_order_success';
export const RESET_PLACE_ORDER_STATE='reset_place_order_state';
export const PLACE_ORDER_MISMATCH = 'place_order_mismatch';
export const HTTP_ORDER_API_ERROR='http_order_api_error';
export const SEND_MESSAGE_FAIL= 'send_message_fail';
export const SEND_MESSAGE_SUCCESS = 'send_message_success';
export const GET_MESSAGE_FAIL = 'get_message_fail';
export const GET_SPIFF_TRANSACTION_FAIL = 'get_spiff_transaction_fail';
export const GET_MESSAGE_SUCCESS = 'get_message_success';
export const GET_SPIFF_TRANCTION_SUCCESS = 'get_spiff_tranaction_success';
export const GET_INVOICE_PDF_SUCCESS ='GET_INVOICE_PDF_SUCCESS';
export const GET_ORDER_HISTORY_SUCCESS = 'get_order_history_success';
export const RESET_SPIFF_TRANCTION_BALANCE_API = 'reset_spiff_tranaction_balace_api';
export const RESET_HTTP_MESSAGE_API_ERROR = 'reset_http_message_api_error';
export const RESET_HTTP_ORDER_HISTORY_API_ERROR = 'reset_http_order_history_api_error';
export const HTTP_ORDER_HISTORY_API_ERROR = 'http_order_history_api_error';
export const RESET_MESSAGE_INDICATOR= 'reset_message_indicator';
export const HTTP_MESSAGE_API_ERROR = 'http_message_api_error';
export const RESET_MESSAGE_PAGE_REDUCER_STATE = 'reset_message_page_reducer_state';
export const RESET_SPIFF_REDUCER_STATE = 'reset_spiff_reducer_state';
export const RESET_ORDER_HISTORY_REDUCER_STATE = 'reset_order_history_reducer_state';
export const FETCH_ORDER_INVOICE ='FETCH_ORDER_INVOICE';
export const HTTP_SPIFF_LANDING_PAGE_API_ERROR = 'http_spiff_landing_page_api_error';
export const RESET_SPIFF_LANDING_PAGE_API_ERROR = 'reset_http_spiff_landing_page_api_error';
export const RESET_SPIFF_PAYOUT_PAGE_API_ERROR = 'reset_spiff_payout_page_http_error';
export const RESET_SPIFF_PAYOUT_API_RESPONSE = 'RESET_SPIFF_PAYOUT_API_RESPONSE';
export const PAYOUT_FINAL_REQUEST_SUCCESS = 'PAYOUT_FINAL_REQUEST_SUCCESS';
export const HTTP_SPIFF_PAYOUT_PAGE_API_ERROR = 'http_spiff_payout_page_api_error';
export const SPIFF_PAYMENT_MODE_SUCCESS = 'spiff_payment_mode_success';
export const REQUEST_PAYMENT_MODE_API ='request_payment_mode_api';
export const REQUEST_PAYOUT_API ='request_payout_api';


export const GET_MESSAGE_API_REQUEST ='get_message_api_request';
export const SEND_MESSAGE_API_REQUEST ='send_message_api_request';
export const SERVER_PUSH_MESSAGE_RECEIVED = 'server_push_message_received';
export const SERVER_PUSH_MESSAGE_RESET = 'server_push_message_reset';




export const OK ="1";
export const FAIL ="0";
export const SERVER_ISSUE="server_issue";
export const RESPONSE_ISSUE="response_issue";
export const REQUEST_ISSUE="request_issue";
export const EXCEPTION_ISSUE="exception_issue";
export const ASYNC_FAIL = 'async_fail';
export const GENERIC_FAIL = 'generic_fail';
export const PDF_LOAD_FAIL = 'pdf_load_fail';

export const PRODUCT_MISMATCH = 'Product mismatch';
export const RESPONSE_SESSION_EXP ='Session expired';
export const INVALID_TOKEN = 'Invalid Token';
export const ERROR_401=401;
export const ERROR_UNKNOWN =91919;
export const MOBILE_FLAG= 'M';
export const SERVER_FLAG= 'W';
export const REQUEST_ERROR='Unable to request server. Check your network.';
export const SESSION_EXPIRED_MSG ='Session Expired! Please login Again.';
export const INTERNAL_SERVER_MSG ='Internal Server Error! Please try later.';
export const OOPS_WRONG ='Something went wrong! Please try later.';
export const PDF_ERROR ='Unable to load invoice or invoice not present.';
export const UNEXPECTED_ERROR ='Error Occurred! Please try later.';
export const SUCCESS_ORDER_PREFIX ='Your order is successfully placed! Please note following order number for further reference:' + '\n';





