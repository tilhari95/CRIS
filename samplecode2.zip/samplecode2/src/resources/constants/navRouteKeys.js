export const NAVIGATION_TO_PRODUCT_SCREEN = 'Products';
export const NAVIGATION_TO_SPIFF_LANDING_SCREEN = 'Spiff landing';
export const NAVIGATION_TO_SPIFF_PAYOUT_SCREEN = 'Spiff payout';

export const NAVIGATION_TO_MESSAGE_SCREEN = 'Messages';
export const NAVIGATION_TO_SHOPPING_CART_SCREEN = 'Shopping Cart';
export const NAVIGATION_TO_SEARCH_SCREEN = 'Search Products';
export const NAVIGATION_TO_PRODUCT_DETAIL_SCREEN = 'Product detail screen';
export const NAVIGATION_TO_PLACE_ORDER_SCREEN = 'Place order screen';
export const NAVIGATION_TO_ORDER_HISTORY_SCREEN = 'order history screen';

export const ROUTE_STACK_ROOT='RootStack';
export const ROUTE_AUTH='Auth';
export const ROUTE_HOME='Home';
export const ROUTE_SPLASH='Splash';
export const ROUTE_STACK_AUTH='AuthStack';
export const ROUTE_STACK_PRODUCT= 'ProductStack';
export const ROUTE_STACK_SPIFF= 'SpiffStack';
export const ROUTE_STACK_PRODUCT_DETAIL= 'ProductDetailStack';
export const ROUTE_DRAWER= 'drawerStack';
export const ROUTE_BOTTOM_NAV= 'bottomNavStack';



export const ROUTE_LOGIN='Login';
export const ROUTE_FORGET_PASSWORD='ForgetPassword';
export const ROUTE_INTERMEDIATE_LOGIN_PAGE='intermediateLoginPage';




