export const INPUT_FIELD_BORDER_COLOR =  "#ccc";
export const GENERIC_BACKGROUND_COLOR = "#fff";
export const PRODUCT_NAME_COLOR = "#808080";
export const GREY_ICON_COLOR = 'grey';
export const BLACK_COLOR = 'black';
export const PRODUCT_HEADER_BG_COLOR = '#f4f2f2';
export const APP_BLUE_COLOR ='#1e87e4';
export const PRODUCT_BORDER_COLOR = "#cfcfcf";
export const LOADER_COLOR = 'black';
export const ERROR_COLOR = 'red';
export const SERVER_MSG_BG_COLOR='#0979ba';
export const MOBILE_MSG_BG_COLOR='#eceef1';

export const HEADER_FONT_WEIGHT =  "500";
export const TEXT_FONT_WEIGHT =  "300";
export const BOLD_FONT_WEIGHT =  "bold";

export const FIELD_BORDER_WIDTH = 2;
export const BORDER_WIDTH_1 = 1;
export const FIELD_BORDER_RADIUS = 3;
export const MODAL_BACKDROP_OPACITY = 0.8;

