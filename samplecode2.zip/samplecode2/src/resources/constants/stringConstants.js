
export const FORGET_PASSWORD = 'Forget Password';
export const RESET_PASSWORD = 'Reset Password';
export const SELECT_COMAPANY ='Select Company and Department:'
export const RESET_PASSWORD_LINK = 'Send Reset Password Link';
export const PROCEED_TO_HOME = 'PROCEED TO HOME PAGE';

export const BACK_TO_LOGIN= 'Back to login';
export const LOGIN= 'Login';
export const ORDER='Order';
export const PAYOUT_REQ='Payout Request';
export const ITEMS='Items';
export const TOTAL='Total';
export const PAYOUT_AMOUNT = 'Payout Amount'
export const ORDER_TOTAL='Order total';
export const PAY_VIA='Pay Via';
export const BACK = 'BACK';

export const SEND_BTN_TITLE ='Send';
export const SYNC_REPLY ='Sync Messages';
export const MESSAGES ='Messages';
export const NO_MESSAGE='No active message thread, Message for any support.';
export const AT = 'at';
export const MOBILE_SEND ='Send by You at';
export const SERVER_SEND ='Send by';
export const DASH = '-';
export const COLON = ':';
export const DOT ='.';
export const SINGLE_SPACE = ' ';
export const FORWARD_SLASH = '/';



export const OKAY= 'OKAY';
export const YES= 'YES';
export const NO= 'NO';
export const CANCEL ='CANCEL';
export const NO_MATCHING_PRODUCTS='No matching products found.';
export const NO_COMPANY_LIST='No company list.';
export const CART_EMPTY='Cart is empty.';
export const SPIFF_EMPTY='No Spiff Transactions.';
export const ORDER_HISTORY_EMPTY='No orders histoy found.';
export const REFRESH_CART_ALERT ='Refreshing product will clear your cart. Do you want to proceed?'

export const PROCEED_TEXT='PROCEED TO PLACE ORDER';
export const PAYOUT_TEXT='REQUEST PAYOUT';
export const REFRESH_TEXT='REFRESH';
export const TOTAL_AMOUNT='TOTAL AMOUNT';
export const BALANCE_AMOUNT='BALANCE';
export const DOLLAR_SYMBOL='$';
export const TAX_STRING='*Taxes may apply.';
export const BALANCE_STRING='Should be less than your balance amount.';
export const MISMATCH_WARNING_MSG = 'Following products are no longer available or have been updated hence removed from you cart. Please review your cart and add updated products or you can place order without them. '
export const PRODUCT_MISMATCH = 'PRODUCT_MISMATCH';
export const TYPE_PRODUCT_HERE='Type product name here...';
export const NAV_PRODUCT_TITLE='Products';
export const SPIFF_PRODUCT_TITLE='Spiff Home';
export const NAV_SEARCH_TITLE='Search Products';
export const NAV_CART_TITLE='Cart';
export const NAV_MESSAGE_TITLE='Messages';

export const EMAIL_PLACEHOLDER = 'Enter Registered Email';
export const PAYOUT_AMOUNT_PLACEHOLDER = ' Enter amount.';
export const PASSWORD_PLACEHOLDER = 'Enter Password';
export const INVALID_CREDENTIALS = 'Invalid Credentials!';
export const INVALID_REG_EMAIL = 'This email address is invalid!'
export const RESET_EMAIL_SUCCESS_MSG = 'Password reset link successfully send on your email address.';
export const QUNATITY ='Quantity :';
export const DATA_VALID = "Data is valid";

export const NOTES ='Notes :';
export const NOTES_PLACEHOLDER='Add notes if any.';
export const PAYMENT_ID_PLACEHOLDER='Add payment mode Id or else email address.';

export const ADDRESS_PLACEHOLDER='Delivery address required.';
export const DELIVERY_ADDRESS ='Delivery Address';
export const ADDRESS ='Address';
export const ORDER_NOTES ='Order Notes';
export const PAYMENT_ID ='Payment Id';

export const PLACE_ORDER ='PLACE ORDER';
export const SUBMIT_PAYOUT_REQ ='SUMBIT PAYOUT REQUEST';
export const REVIEW_CART ='REVIEW CART';
export const ADD ='ADD';
export const UPDATE ='UPDATE';
export const DELETE ='DELETE';
export const PRICE = 'Price : $'
export const PRODUCT_UPDATE_SUCCESS='Products updated successfully.'
export const SPIFF_DROPDOWN_PLACEHOLDER ="Select payment mode";





// error strings
export const EMPTY_ERROR= 'This field cannot be empty.'
export const EMAIL_ERROR= 'Invalid email address.'


// json keys constants

export const PRODUCT_FOUND = 'productFound';
export const CART_PRODUCT_OBJ = 'cartProductObj';
export const QUANTITY_JSON = 'OrderQty';
export const NOTES_JSON = 'Notes';
export const ITEMNO_JSON = 'ItemNo';
export const PRICE_JSON = 'Price';
export const DESCRIPTION_JSON = 'Description';
export const ITEMID_JSON = 'ItemId';
export const ORDER_LINE_JSON = 'OrderLine';
export const TOTAL_SALES_JSON ='TotalSales';
export const ORDER_ADDRESS_JSON = 'OrderAddress';
export const ORDER_NOTES_JSON ='OrderNote';
export const ORDER_DATE_JSON = 'OrderDate';
export const ORDER_CNF_JSON = 'Confirmed';
export const SPIFF_PAYOUT_ID_JSON= 'emailAddress';
export const SPIFF_PAYOUT_AMOUNT_JSON= 'amount';
export const SPIFF_PAYOUT_NOTES_JSON= 'notes';
export const SPIFF_PAYOUT_TYPE_JSON= 'payoutMethod';

export const LOGOUT_SIDEMENU ='LOGOUT';
export const REFRESH_PRODUCTS_SIDEMENU ='REFRESH PRODUCTS';
export const ORDER_HISTORY_SIDEMENU ='ORDER HISTORY';

export const SPIFF_SUCCESS_STRING ='Spiff payout request has been submitted successfully!';



export const CART_BADGE_VALUE='cartBadgeValue';
export const CART_TOTAL_AMOUNT='cartTotalAmount';


export const LOGOUT_FROM_HOME = 'home_logout';
export const LOGOUT_FROM_SPIFF = 'logout_spiff';
export const LOGOUT_FROM_COMM = 'logout_comm';
