
export const mcni_go_icon = require('./mcniGO_logo_blue.png');

export const demo_paint_bucket = require('./paint-bucket.jpg');

export const image_placeholder = require('./imageplaceholder.png');

//export const mcni_company_icon = require('./mcni360-logo_lt-blue.png');
