import {
    SPIFF_PAYOUT_AMOUNT_JSON,
    SPIFF_PAYOUT_ID_JSON,
    SPIFF_PAYOUT_NOTES_JSON,
    SPIFF_PAYOUT_TYPE_JSON,
} from '../resources/constants/stringConstants';


//{payoutId: '', payoutAmount: '', payoutNotes: '', payoutMethod:''})
export const getSpiffPayoutAPIObj = (spiffPayoutObj) => {
    let finalSpiffPayoutObj = {};
    // payout id/email-->
    finalSpiffPayoutObj[SPIFF_PAYOUT_ID_JSON]= spiffPayoutObj.payoutId;
    // payout amount-->
    finalSpiffPayoutObj[SPIFF_PAYOUT_AMOUNT_JSON]= spiffPayoutObj.payoutAmount;
    // payout notes-->
    finalSpiffPayoutObj[SPIFF_PAYOUT_NOTES_JSON]= spiffPayoutObj.payoutNotes;
    // payout method cash/paypal etc etc-->
    finalSpiffPayoutObj[SPIFF_PAYOUT_TYPE_JSON]= spiffPayoutObj.payoutMethod;
    console.log(finalSpiffPayoutObj);
    return finalSpiffPayoutObj;
}
