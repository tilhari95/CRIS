import {
    DESCRIPTION_JSON,
    ITEMID_JSON, ITEMNO_JSON,
    NOTES_JSON, ORDER_ADDRESS_JSON, ORDER_CNF_JSON, ORDER_DATE_JSON, ORDER_LINE_JSON, ORDER_NOTES, ORDER_NOTES_JSON,
    PRICE_JSON,
    QUANTITY_JSON, TOTAL_SALES_JSON,
} from '../resources/constants/stringConstants';

// round price figure to two necessary digits.
export const roundToTwo = (numberString) => {
    debugger;
    return (Number(Math.round(parseFloat(numberString + 'e' + '2')) + 'e-' + '2').toFixed(2));
    //return +(Math.round(num + "e+2")  + "e-2");
}

// fetch product from cart if already added.
export const getProductFromCart = (productObj, cartList) =>{
    debugger;
    // default object-->
    let returnObj = {productFoundInCart: false, productObj: productObj, index: -1 }
    let objIndex;
    let cartProductObj;
    if( cartList.length > 0){
        objIndex = cartList.findIndex((eachCartObj => eachCartObj.ItemId === productObj.ItemId));
        //cartProductObj = cartList.find(eachCartObj => eachCartObj.ItemId === productObj.ItemId);
    }
    console.log(objIndex);
    if(objIndex!== undefined && objIndex >=0){
        cartProductObj= cartList[objIndex];
        return({productFoundInCart: true, productObj: cartProductObj, index: objIndex });
    }
    else{
        return(returnObj);
    }
};

// complete cart calcultion on asunc fetch/ application refresh/restart. Time Complexity O(n).
export const cartCalculationsOnAsyncFetch = (cartList) =>{
    let cartCalculation={badgeCount: 0, cartTotalAmount: 0};
    try{
    debugger;
        let badgeC=0, cartTotalA=0;
        for(let item=0; item< cartList.length; item++){
            if(cartList[item].OrderQty && Number(cartList[item].Price) >=0)
            {
                let quantity =Number(cartList[item].OrderQty);
                let price =Number(cartList[item].Price);
                badgeC+=quantity;
                cartTotalA+=(quantity*price);
            }
        }
        cartCalculation.badgeCount=badgeC;
        cartCalculation.cartTotalAmount=roundToTwo(cartTotalA);
        return(cartCalculation)
    }
    catch (e) {
        console.log('error on cartCalculations() ');
        return(cartCalculation);
    }
}

// Function for deleting product from cart. Time complexity: O(1)
export const cartCalculationsOnDelete = (cartState, quantityDelete, priceDelete ) =>{
    // initial object
    let cartCalculation={badgeCount: cartState.cartBadgeValue, cartTotalAmount: Number(cartState.cartTotalAmount) };
    let quantity =Number(quantityDelete);
    let price =Number(priceDelete);
    // reduce cartBadge counter and cartTotalAmount
    try{
    debugger;
        cartCalculation.badgeCount-=quantity;
        cartCalculation.cartTotalAmount = roundToTwo(cartCalculation.cartTotalAmount-(quantity*price));
        return(cartCalculation)
    }
    catch (e) {
        console.log('error on cartCalculationsOnDelete() ');
        return(cartCalculation);
    }
}

// Function for adding product from cart. Time complexity: O(1)
export const cartCalculationsOnAddition = (cartState, quantityAdd, priceAdd ) =>{
    // initial object
    let cartCalculation={badgeCount: cartState.cartBadgeValue, cartTotalAmount: Number(cartState.cartTotalAmount) };
    let quantity =Number(quantityAdd);
    let price =Number(priceAdd);
    // add to cartBadge counter and cartTotalAmount
    try{
    debugger;
        cartCalculation.badgeCount+=quantity;
        cartCalculation.cartTotalAmount = roundToTwo(cartCalculation.cartTotalAmount+(quantity*price));
        return(cartCalculation)
    }
    catch (e) {
        console.log('error on cartCalculationsOnAddition() ');
        return(cartCalculation);
    }
}


// Function for updating product from cart. Time complexity: O(1)
export const cartCalculationsOnUpdation = (cartState, quantityRemove, quantityAdd, priceAdd ) =>{
    // initial object
    let cartCalculation={badgeCount: cartState.cartBadgeValue, cartTotalAmount: Number(cartState.cartTotalAmount) };
    let quantityR= Number(quantityRemove);
    let quantityA =Number(quantityAdd);
    let price =Number(priceAdd);
    // add to update cartBadge counter and cartTotalAmount
    try{
    debugger;
        cartCalculation.badgeCount=cartCalculation.badgeCount - quantityR + quantityA;
        cartCalculation.cartTotalAmount=roundToTwo(cartCalculation.cartTotalAmount - (quantityR * price) + (quantityA * price));
        return(cartCalculation)
    }
    catch (e) {
        console.log('error on cartCalculationsOnUpdation() ');
        return(cartCalculation);
    }
}

// get cart products array in format as required by place order API.
export const getOrderlineObj = (cartList) => {
    let orderLine=[];
    for(let i=0; i < cartList.length; i++){
        let cartProductObj={};
        cartProductObj[DESCRIPTION_JSON]= cartList[i].ItemDescription;
       // cartProductObj[ITEMID_JSON]="28d06700-d2e6-4214-8099-e0bc320ba878";
        cartProductObj[ITEMID_JSON]=cartList[i].ItemId; //"28d06700-d2e6-4214-8099-e0bc320ba888"
        cartProductObj[QUANTITY_JSON]=cartList[i].OrderQty;
        cartProductObj[PRICE_JSON]=(cartList[i].Price)+'';
        cartProductObj[NOTES_JSON]=cartList[i].Notes;
        cartProductObj[ITEMNO_JSON]=cartList[i].ItemNo;

        orderLine.push(cartProductObj);
    }
    console.log(orderLine);
    return orderLine;
}

// complete place order Object creation.
export const getPlaceOrderAPIObj = (orderLine, deliveryDetails, date, totalAmount) => {
    let finalOrder = {};
    // order status-->
    finalOrder[ORDER_CNF_JSON]= true;
    // order date/time-->
    finalOrder[ORDER_DATE_JSON]= date;
    // order notes input-->
    finalOrder[ORDER_NOTES_JSON]= deliveryDetails.orderNotes;
    // order delivery address-->
    finalOrder[ORDER_ADDRESS_JSON]= deliveryDetails.address;
    //finalOrder['AppOrderNo']= '2'; // to be fetched form check orderdetails PI
    // order total amount -->
    finalOrder[TOTAL_SALES_JSON]= totalAmount;
    // order object -->
    finalOrder[ORDER_LINE_JSON]= orderLine;
    console.log(finalOrder);
    return finalOrder;
}

// remove mis-matched from from cart.
export const removeUpdatedProductsFromCart = (mismatchProdutsArray, cartList) => {
    let updatedCartArray = JSON.parse(JSON.stringify(cartList));
    for(let i =0; i < mismatchProdutsArray.length; i++){
        debugger;
     let objIndex = updatedCartArray.findIndex(eachCartObj => eachCartObj.ItemId === mismatchProdutsArray[i].ItemId); //f6ad0420-b2c4-4902-86dc-30a8d678ca28
        if(objIndex > -1)
            updatedCartArray.splice(objIndex, 1);
    }
return updatedCartArray;
}

// function to get primary image of product from image array/ any image related changes.
export const getPrimaryImage = (itemImageArray) =>{
    let primaryImgObj={}
    for(let i=0; i<itemImageArray.length; i++) {
        if (itemImageArray[i].PrimaryImage == true) {
            primaryImgObj = JSON.parse(JSON.stringify(itemImageArray[i]));
            break;
        }
    }
    return primaryImgObj;
}

// console.log('ROUNDING LOGIC EXAMPLES ------->>>>>');
// console.log(roundToTwo(121));
// console.log(roundToTwo(121.101));
// console.log(roundToTwo(121.105));
// console.log(roundToTwo(121.115));
// console.log(roundToTwo(121.106));
// console.log(roundToTwo(121.10689));
