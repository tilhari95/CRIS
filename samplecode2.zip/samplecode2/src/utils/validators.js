// function to validate email.
export const validateEmail =(emailField) => {
    emailField = emailField.trim();
    const reEmail = /^(?:[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+\.)*[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+@(?:(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!\.)){0,61}[a-zA-Z0-9]?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!$)){0,61}[a-zA-Z0-9]?)|(?:\[(?:(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\.){3}(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\]))$/;
    if (!emailField.match(reEmail)) {
        return false;
    }
    return true;
}
// null and other white space check for any variable.
export const validateRequiredField =(input) => {
    if(input === '' || input === null || input === undefined){
        return false;
    }
    return true;
}

// function for password format and rules.
export const passwordFormatter =(password) => {
    return password.trim();
}


// session token validator
export const tokenValidator = (token) =>{
    if(token && token !== null && token !== '' && token !== undefined){
        return true;
    }
    return false;
}

// input quantity and notes validator.
export const cartScreenInputValidator =(notes,number, isFromCart, prodDetails) => {
    // to check if cart value is updated or not
    let quantityUpdateBool = (isFromCart)? (!(number === prodDetails.Quantity)): true;
    let noteUpdateBool =(isFromCart)? (!(notes === prodDetails.Notes)): true;
    let num=Number(number)
    let isnum = /^\d+$/.test(number);
        if(isnum && num > 0 && (quantityUpdateBool || noteUpdateBool))
            return true;
        else
            return false;
}


export const spiffAmountValidator = (amount, currentBalance) => {
    if(amount === '')
        return true;
    if(amount.isNaN){
        return false;
    }
    let lastChar = amount.slice(-1);
    if(lastChar === '.' || lastChar === ' '){// check numbers like 100. , 123.2 , 5.
        return false;
    }
    let num = Number(amount);
    if(num > 0 && num <=currentBalance){
        let decimalDigits = countDecimalsDigit(num);
        if(decimalDigits >=0 && decimalDigits <= 2)
            return true;
        else
            return false;
    }
    else
        return false;
};

const  countDecimalsDigit = function (value) {


    if(Math.floor(value) === value) return 0;

    return value.toString().split(".")[1].length || 0;
}
