import React from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {Input} from 'react-native-elements';


const TextInput = (
    {
        placeholder,
        leftIconType,
        leftIconSize=25,
        leftIconColor='black',
        rightIconType,
        rightIconSize=25,
        rightIconColor='black',
        onChangeText,
        errorMessage,
        errorStyle,
        secureTextEntry=false,
        containerStyle,
        inputContainerStyle,
        rightIconOnPress,
        keyboardType='default',
        value,
        multiline=false,
        numberOfLines,
        inputStyle,
        returnKeyType,
    }
) => {
    return(
        <Input placeholder={placeholder}
            leftIcon={
                <Icon
                    name={leftIconType}
                    size={leftIconSize}
                    color={leftIconColor}
                />
            }
            rightIcon={
                <Icon
                    name={rightIconType}
                    size={rightIconSize}
                    color={rightIconColor}
                    onPress={rightIconOnPress}
                />
            }
            onChangeText={onChangeText}
            secureTextEntry={secureTextEntry}
            errorMessage={errorMessage}
            errorStyle={errorStyle}
            containerStyle={containerStyle}
            inputContainerStyle={inputContainerStyle}
            keyboardType={keyboardType}
            //returnKeyType='enter'
            value={value}
            inputStyle={inputStyle}
            multiline={multiline}
            numberOfLines={numberOfLines}

        />
    );
};

export default TextInput;
