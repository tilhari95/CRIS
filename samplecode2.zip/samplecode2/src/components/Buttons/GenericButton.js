import React from 'react';
import { Button } from 'react-native-elements';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const GenericButton = (
    {
        title,
        type="solid",
        onPress,
        color='transparent',
        size,
        icon,
        loading=false,
        iconColor="white",
        titleStyle,
        containerStyle,
        buttonStyle,
        disabled=false
    }
) => {
    return (
        <Button
            title={title}
            type={type}
            onPress={onPress}
            color={color}
            icon={
                <Icon
                    name={icon}
                    size={size}
                    color={iconColor}
                />
            }
            loading={loading}
            titleStyle={titleStyle}
            containerStyle={containerStyle}
            buttonStyle={buttonStyle}
            disabled={disabled}
        />
    );
};

export default GenericButton;
