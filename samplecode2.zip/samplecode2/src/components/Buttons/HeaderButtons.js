import React from 'react';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {
  HeaderButton as HB,
  HeaderButtons as HBS,
} from 'react-navigation-header-buttons';

// TODO: extract color and icon size into theme module
const HeaderButton = props => {
  return (
    <HB IconComponent={MaterialIcons} color="black" iconSize={40} {...props} />
  );
};

const HeaderButtons = props => {
  return (
    <HBS
      HeaderButtonComponent={HeaderButton}
      OverflowIcon={<MaterialIcons name="more-vert" size={30} color="black" />}
      {...props}
    />
  );
};

export {Item} from 'react-navigation-header-buttons';
export {HeaderButtons};
