import {StyleSheet, View} from 'react-native';
import {connect} from 'react-redux';
import React, {useEffect, useState} from 'react';
import FastImage from 'react-native-fast-image'
import {Icon, Text} from 'react-native-elements';
import {
    HEIGHT_100, HEIGHT_110, HEIGHT_MAX_130, SPACING_10, SPACING_15, SPACING_5, TEXT_SIZE_10,
    TEXT_SIZE_15,
    WIDTH_100, WIDTH_80,
} from '../../resources/constants/dimensions';
import {
    BOLD_FONT_WEIGHT,
    HEADER_FONT_WEIGHT, INPUT_FIELD_BORDER_COLOR, PRODUCT_NAME_COLOR, TEXT_FONT_WEIGHT,
} from '../../resources/constants/themeConstant';
import {genericImageURL} from '../../api/helper/ApiEndpoints';
import {DELETE, PRICE, QUNATITY, UPDATE} from '../../resources/constants/stringConstants';
import {GenericButton} from '../index';
import {roundToTwo} from '../../utils/cartHelpers';
import {parseSpiffDate} from '../../utils/date';
const OrderHistoryListTemplate =({
   itemData,
   onPdfIconPress,
   }) => {
    let totalAmountWithDeimalCorrection = roundToTwo(itemData.TotalSales);
    let parsedDateInFormat = parseSpiffDate(itemData.OrderDate);
    return(
        <View style={styles.viewStyle}>
            <View style={{flexDirection:'row'}}>
                <View style={{width:'80%'}}>
                    <Text style={[styles.textStyle,{textAlign:'left', fontWeight:'bold',}]}>Invoice {itemData.AppOrderNo}</Text>
                </View>
                <View style={{width:'20%'}}>
                    <Text style={[styles.textStyle, {textAlign:'center'}]}>$ {totalAmountWithDeimalCorrection}</Text>
                </View>
            </View>
            <View style={{flexDirection:'row'}}>
                <View style={[styles.viewElementsStyle, {width:'80%'}]}>
                    <Text style={styles.textStyle}>{itemData.CustomerName}</Text>
                    <Text style={styles.textStyle}>{itemData.OrderNote}</Text>
                    <Text style={styles.textStyle}>{parsedDateInFormat}</Text>
                </View>
                <View style={{width:'20%', justifyContent:'center', alignItems:'center'}}>
                        <GenericButton
                            type='clear'
                            onPress={onPdfIconPress}
                            icon='file-pdf'
                            size={25}
                            iconColor='red'
                        />
                </View>
            </View>
        </View>
    );
}
const styles = StyleSheet.create({
    textStyle:{
        fontSize:TEXT_SIZE_15
    },
    viewStyle:{
        width:"100%",
        maxHeight:HEIGHT_MAX_130,
        borderBottomWidth:1,
        borderColor:INPUT_FIELD_BORDER_COLOR,
        paddingLeft:SPACING_5,
        paddingRight:SPACING_5,
        paddingBottom:SPACING_5,
        paddingTop:SPACING_5,
    },
    viewElementsStyle:{
        justifyContent:'center',
        alignItems: 'flex-start',
        // height:HEADER_HEIGHT,
    },
});

export default OrderHistoryListTemplate;
