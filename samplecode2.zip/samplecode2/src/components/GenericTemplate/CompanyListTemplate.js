import {StyleSheet, View} from 'react-native';
import {connect} from 'react-redux';
import React, {useEffect, useState} from 'react';
import FastImage from 'react-native-fast-image'
import {Icon, Text} from 'react-native-elements';
import {
    HEIGHT_100, HEIGHT_110, HEIGHT_MAX_130, SPACING_10, SPACING_15, SPACING_5, TEXT_SIZE_10,
    TEXT_SIZE_15,
    WIDTH_100, WIDTH_80,
} from '../../resources/constants/dimensions';
import {
    BOLD_FONT_WEIGHT,
    HEADER_FONT_WEIGHT, INPUT_FIELD_BORDER_COLOR, PRODUCT_NAME_COLOR, TEXT_FONT_WEIGHT,
} from '../../resources/constants/themeConstant';
import {companyListImageURL} from '../../api/helper/ApiEndpoints';
const ComapanyListTemplate =({
       itemData,
   }) => {
    let imageCompletePath=companyListImageURL+itemData.Logo;
    return(
        <View style={styles.viewStyle}>
            <View style={[styles.viewElementsStyle,{width:'30%'}]}>
                <FastImage
                    style={styles.imageStyle}
                    source={{uri:imageCompletePath}}
                    resizeMode = 'stretch'
                />
            </View>
            <View style={[styles.viewElementsStyle,{width:'50%',marginLeft:SPACING_5}]}>
                <Text style={styles.itemDescriptionStyle}>{itemData.CompanyName}</Text>
            </View>
            <View style={[styles.viewElementsStyle,{width:'20%',marginLeft:SPACING_5, alignItems:'center'}]}>
                {
                    (itemData.isSelected) ?
                        <Icon
                            name='checkbox-marked-circle-outline'
                            type='material-community'
                        />
                        :
                        <Icon
                            name='checkbox-blank-circle-outline'
                            type='material-community'
                        />
                }
            </View>
        </View>


    );
}
const styles = StyleSheet.create({
    viewStyle:{
        width:"100%",
        flexDirection:"row",
        //  minHeight:HEIGHT_110,
        maxHeight:HEIGHT_MAX_130,
        alignItems:'center',
        borderBottomWidth:1,
        borderColor:INPUT_FIELD_BORDER_COLOR,
        paddingLeft:SPACING_5,
        paddingRight:SPACING_10,
        paddingBottom:SPACING_5,
        paddingTop:SPACING_5
    },
    itemDescriptionStyle:{
        fontWeight:HEADER_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
        //textAlign: 'right'
    },
    itemValueStyle:{
        color:PRODUCT_NAME_COLOR,
        textAlign:'left',
        width:'50%',
        fontWeight:BOLD_FONT_WEIGHT,
        fontSize:TEXT_SIZE_15,
    },
    viewElementsStyle:{
        justifyContent:'center',
        alignItems: 'flex-start',
        // height:HEADER_HEIGHT,
    },
    imageStyle:{
        //backgroundColor:'red',
        width:80,
        height:80,
    },
    buttonStyle:{
        width:"50%",
        paddingRight: SPACING_5}
});

export default ComapanyListTemplate;
