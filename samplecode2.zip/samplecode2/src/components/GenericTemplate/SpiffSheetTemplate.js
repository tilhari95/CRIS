import {StyleSheet, View} from 'react-native';
import React, {useEffect, useState} from 'react';
import {Icon, Text} from 'react-native-elements';
import {
    HEIGHT_MAX_130, SPACING_10,
    TEXT_SIZE_15,
} from '../../resources/constants/dimensions';
import {
    HEADER_FONT_WEIGHT, INPUT_FIELD_BORDER_COLOR, PRODUCT_NAME_COLOR,
} from '../../resources/constants/themeConstant';
import {parseSpiffDate} from '../../utils/date';
import {roundToTwo} from '../../utils/cartHelpers';
const SpiffSheetTemplate =({
   itemData,
   }) => {
        let parsedDateInFormat = parseSpiffDate(itemData.SpiffCreationDate);
        let formattedAmount = roundToTwo(itemData.Amount);
    return(
        <View style={styles.viewStyle}>
            <View style={{width:'40%'}}>
                <Text style={styles.itemDescriptionStyle}>{parsedDateInFormat}</Text>
            </View>
            <View style={{width:'30%'}}>
                <Text h4 h4Style={styles.itemDescriptionStyle}> {itemData.SpiffType} </Text>
            </View>
            <View style={{width:'30%'}}>
                <Text h4 h4Style={[styles.itemDescriptionStyle, {textAlign: 'right', color: PRODUCT_NAME_COLOR}]}>{formattedAmount}</Text>
            </View>
        </View>

    );
}
const styles = StyleSheet.create({
    viewStyle: {
        width: "100%",
        flexDirection: "row",
        maxHeight: HEIGHT_MAX_130,
        alignItems: 'center',
        borderBottomWidth: 1,
        borderColor: INPUT_FIELD_BORDER_COLOR,
        paddingLeft: SPACING_10,
        paddingRight: SPACING_10,
        paddingBottom: SPACING_10,
        paddingTop: SPACING_10
    },
    itemDescriptionStyle: {
        fontWeight: HEADER_FONT_WEIGHT,
        fontSize: TEXT_SIZE_15,
    },
});

export default SpiffSheetTemplate;
