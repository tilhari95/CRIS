/*
 * @Author: Chandan Makhija
 * @Date: 2018-11-05 10:54:59
 */

import React, {Component, Fragment, useEffect, useState} from 'react';
import {ActivityIndicator, SafeAreaView, StyleSheet, View} from 'react-native';
import { Container } from "native-base";
import {GENERIC_BACKGROUND_COLOR, LOADER_COLOR, MODAL_BACKDROP_OPACITY} from '../../resources/constants/themeConstant';
import {Overlay, Text} from 'react-native-elements';
import {connect} from 'react-redux';
import {
    productListRequest, resetHttpProductApiError,
    setDateStringFromAsync, setIsForceUpdate,
    setProductListFromAsync, setUserDataFromAsync,
} from '../../store/ProductPage/productPageAction';
import {resetCartReduxInitialState, updateCartListAsync} from '../../store/Cart/cartAction';
import {resetHttpLogoutApiError, triggerLogoutRequest} from '../../store/Logout/logoutAction';
import {GenericButton} from '../index';
import {OKAY} from '../../resources/constants/stringConstants';

const mapStateToProps = (reduxStore) => {
    return {
        logoutRequested: reduxStore.logout.logoutRequested,
    };
};
// const WithApiErrorHandling = () => (WrappedComponent) =>{
//     return( connect(
//         mapStateToProps,
//         {},
//      )
//     (
//         ({
//           logoutRequested
//         }) => {
//             const [modalVisibility, setModalVisibility] = useState(false);
//             useEffect(() => {
//             debugger;
//                 if(logoutRequested === true) {
//                     setModalVisibility(true);
//                 }
//
//             }, [logoutRequested]);
//
//             return (
//                 <Fragment>
//                     <WrappedComponent />
//                     <Overlay
//                         backdropStyle={styles.overlay}
//                         isVisible={true}
//                         overlayStyle={styles.overlayLoaderStyle}
//                     >
//                         <View style={{width:100, height:100}}>
//                             <Text
//                                 h3 h3Style={styles.modalErrorStyle}>OK</Text>
//                             <GenericButton title={OKAY} ></GenericButton>
//                         </View>
//                     </Overlay>
//                 </Fragment>
//             );
//          }));
// }

const WithApiErrorHandling = () => (WrappedComponent) => (props) => (
    <Fragment>

        <WrappedComponent {...props} />
        <Overlay
            backdropStyle={styles.overlay}
            isVisible={true}
            overlayStyle={styles.overlayLoaderStyle}
        >
            <ActivityIndicator size="large" color={LOADER_COLOR} />
        </Overlay>
    </Fragment>
);


export default (WithApiErrorHandling);


const styles = StyleSheet.create({
    container: {
        flex: 1,
       // height:200,
        //width:200,
        backgroundColor: GENERIC_BACKGROUND_COLOR,
    },
    content: {
        flex: 1,
    },
    overlay:{
        backgroundColor: GENERIC_BACKGROUND_COLOR,
        opacity: 0.8
    },
    overlayLoaderStyle:{
        width:0,height:0,
        padding:0,
        backgroundColor: GENERIC_BACKGROUND_COLOR,
        opacity: MODAL_BACKDROP_OPACITY
    }
});


