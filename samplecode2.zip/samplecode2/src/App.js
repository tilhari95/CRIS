/* eslint-disable prettier/prettier */
import 'react-native-gesture-handler';
import React, {useEffect} from 'react';
import RootStackNavigator from './navigation';
import {Provider as StoreProvider} from 'react-redux';
import store from './store';
import messaging from '@react-native-firebase/messaging';
import fcmToken from './services/PushNotifications/fcmToken';
import {parseNotficationData} from './services/PushNotifications/parseNotificationData';
import {navigationHook} from './navigation/navigatorHook';
import {
    NAVIGATION_TO_MESSAGE_SCREEN,
    ROUTE_BOTTOM_NAV,
    ROUTE_DRAWER,
    ROUTE_HOME,
} from './resources/constants/navRouteKeys';

const App = () => {
    // getting FCM token and Push notfication user permission.
    useEffect(() => {
        handleFCMToken();
        // Listen to whether the token changes
        return messaging().onTokenRefresh(refreshedToken => {
            console.log('messaging().onTokenRefresh() listener returned refreshedToken FCM token ---> '+ refreshedToken);
            fcmToken.saveFcmTokenInAsync(refreshedToken);
        });
    }, []);

    useEffect(() => {
        const unsubscribe = messaging().onMessage(async remoteMessage => {
            // debugger;
            // console.log('A new FCM message arrived! foreground--> '+ JSON.stringify(remoteMessage));
            parseNotficationData(remoteMessage);
        });

        return unsubscribe;
    }, []);

    useEffect(() => {
        messaging().onNotificationOpenedApp(remoteMessage => {
            // console.log(
            //     'Notification caused app to open from background state:',
            //     JSON.stringify(remoteMessage.notification)
            // );
        //    parseNotficationData(remoteMessage);
            navigationHook(ROUTE_HOME, {
             screen: ROUTE_DRAWER,
                params: {
                    screen: ROUTE_BOTTOM_NAV,
                    params:{
                    screen: NAVIGATION_TO_MESSAGE_SCREEN
                    }
             }
             });
        });

        // Check whether an initial notification is available
        messaging()
            .getInitialNotification()
            .then(remoteMessage => {
                if (remoteMessage) {
                    // console.log(
                    //     'Notification caused app to open from quit state:',
                    //     JSON.stringify(remoteMessage.notification)
                    // );
                    parseNotficationData(remoteMessage);


                    //TODO ---> on quit state direct navigatiton to message redirects to homepage after some seconds.

                    // navigationHook(ROUTE_HOME, {
                    //     screen: ROUTE_DRAWER,
                    //     params: {
                    //         screen: ROUTE_BOTTOM_NAV,
                    //         params:{
                    //             screen: NAVIGATION_TO_MESSAGE_SCREEN
                    //         }
                    //     }
                    // });
                }

            });
    }, []);

    const handleFCMToken = async () => {
        await fcmToken.getFirebasePermission();
        let fcmTokenFromAsync = await fcmToken.getFcmTokenFromAsync();
        debugger;
        if(fcmTokenFromAsync === null || fcmTokenFromAsync === undefined || fcmTokenFromAsync === ''){
            let FCMToken = await fcmToken.getToken();
            debugger;
            await fcmToken.saveFcmTokenInAsync(FCMToken);
            //testing -->>
            let fcmTokenFromAsync2 = await fcmToken.getFcmTokenFromAsync();
            console.log(' put fcm token in redux IST time-->>  ' + fcmTokenFromAsync2 );
        }
        else{
           // console.log(' put fcm token in redux already present -->>  ' + fcmTokenFromAsync );
            //set it in
        }
    }

  return (
      <StoreProvider store={store}>
        <RootStackNavigator />
      </StoreProvider>  );
};

export default App;
