/* eslint-disable prettier/prettier */

import {
    PASSWORD_ENTERED,
    LOGIN_REQUEST_SUCCESS,
    LOGIN_REQUEST_FAIL,
    EMAIL_ENTERED,
    LOGIN_REQUEST_LOADING,
    GET_BRAND_SUCCESS,
    BRAND_REQUEST_FAIL,
    SET_LOGIN_INITIAL_STATE,
    HTTP_API_ERROR, RESET_HTTP_API_ERROR, SET_LOGIN_INITIAL_STATE_ON_LOGOUT, RESET_BRAND_SUCCESS_RESPONSE,
} from '../../resources/constants/storeConstants';
import { Status } from '../../api';

const initialState = {
    loginSuccessResponse: null,
    loginFailError: null,
    password: null,
    email:null,
    status: Status.DEFAULT,
    brandSuccessResponse: null,
    brandFailError: null,
    httpError:null,
    sessionToken:null,
};

export default (state = initialState, action) => {
    switch (action.type) {
        case EMAIL_ENTERED:
            return {...state, email: action.payload}
        case PASSWORD_ENTERED:
            return { ...state, password: action.payload };
        case LOGIN_REQUEST_SUCCESS: {
            return { ...state, status: Status.SUCCESS, loginSuccessResponse: action.payload };
        }
        case LOGIN_REQUEST_FAIL: {
            return { ...state, status: Status.ERROR, loginFailError: action.payload};
        }
        case LOGIN_REQUEST_LOADING: {
            return {...state, status: Status.LOADING }
        }
        case GET_BRAND_SUCCESS: {
            return { ...state, status: Status.SUCCESS, brandSuccessResponse: action.payload };
        }
        case BRAND_REQUEST_FAIL: {
            return { ...state, status: Status.ERROR, brandFailError: action.payload };
        }
        case HTTP_API_ERROR:{
            return { ...state, status: Status.ERROR, httpError: action.payload }
        }
        case RESET_HTTP_API_ERROR:{
            return { ...state, httpError: null }
        }
        case SET_LOGIN_INITIAL_STATE:{
            return {...state, ...initialState};
        }
        case SET_LOGIN_INITIAL_STATE_ON_LOGOUT:{
            return {...state, loginSuccessResponse: null,
                loginFailError: null,
                password: null,
                email:null,
                status: Status.DEFAULT,
                brandFailError: null,
                httpError:null,
                sessionToken:null};
        }
        case RESET_BRAND_SUCCESS_RESPONSE:{
            return {...state, brandSuccessResponse: null};
        }
        default:
            return state;
    }
};
