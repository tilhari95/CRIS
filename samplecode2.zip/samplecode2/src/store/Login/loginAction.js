/* eslint-disable prettier/prettier */
import {
    PASSWORD_ENTERED,
    EMAIL_ENTERED,
    LOGIN_REQUEST,
    USER_BRAND_REQUEST, SET_LOGIN_INITIAL_STATE, RESET_HTTP_API_ERROR, RESET_BRAND_SUCCESS_RESPONSE,
} from '../../resources/constants/storeConstants';

export const passwordEntered = text => ({
    type: PASSWORD_ENTERED,
    payload: text,
});

export const emailEntered = text => ({
    type: EMAIL_ENTERED,
    payload: text,
});

export const loginRequest = (email, password) => {
    let payload= { email, password};
    return({
    type: LOGIN_REQUEST,
    payload:payload });
};
export const userBrandRequest = (companyId, templateId) => {
    let payload= { companyId, templateId};
    return({
        type: USER_BRAND_REQUEST,
        payload: payload });
};


export const resetHttpApiError = () =>{
    return({
        type: RESET_HTTP_API_ERROR,
        payload: ''
    })
}

export const resetBrandSuccessResponse =() => {
    return({
        type:  RESET_BRAND_SUCCESS_RESPONSE,
        payload: ''
    })
}

export const setLoginReduxInitialState = () => {
    return({
        type: SET_LOGIN_INITIAL_STATE,
        payload:'' });
};
