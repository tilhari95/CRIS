/* eslint-disable prettier/prettier */

import {
    COMPANY_LIST_SUCCESS,
    TEMPLATE_LIST_SUCCESS,
    INTERMEDIATE_PAGE_HTTP_ERROR,
    RESET_INTERMEDIATE_PAGE_HTTP_API_ERROR,
    SET_INTERMEDDIATE_PAGE_INITIAL_STATE,
} from '../../resources/constants/storeConstants';
import { Status } from '../../api';

const initialState = {
    comapanyListSuccessResponse: null,
    templateListSuccessResponse: null,
    intermediatePageHttpError:null,

};

export default (state = initialState, action) => {
    switch (action.type) {
        case COMPANY_LIST_SUCCESS:
            return {...state, comapanyListSuccessResponse: action.payload}
        case TEMPLATE_LIST_SUCCESS:
            return { ...state, templateListSuccessResponse: action.payload };
        case INTERMEDIATE_PAGE_HTTP_ERROR:{
            return { ...state, intermediatePageHttpError: action.payload }
        }
        case RESET_INTERMEDIATE_PAGE_HTTP_API_ERROR:{
            return { ...state, intermediatePageHttpError: null }
        }
        case SET_INTERMEDDIATE_PAGE_INITIAL_STATE:{
            return {...state, ...initialState};
        }
        default:
            return state;
    }
};
