import {
    COMAPANY_REQUEST,
    RESET_INTERMEDIATE_PAGE_HTTP_API_ERROR, SET_INTERMEDDIATE_PAGE_INITIAL_STATE, TEMPLATE_REQUEST,
} from '../../resources/constants/storeConstants';

export const resetIntermediatePageHttpError = () =>{
    return({
        type: RESET_INTERMEDIATE_PAGE_HTTP_API_ERROR,
        payload: ''
    })
}
export const getTemplateCompanyData = () =>{
    return({
        type: COMAPANY_REQUEST,
        payload: ''
    })
}

export const callTemplateApi = (companyId) =>{
    return({
        type: TEMPLATE_REQUEST,
        payload: companyId
    })
}


export const resetIntermediatePageRedux = () =>{
    return({
        type: SET_INTERMEDDIATE_PAGE_INITIAL_STATE,
        payload: ''
    })
}
