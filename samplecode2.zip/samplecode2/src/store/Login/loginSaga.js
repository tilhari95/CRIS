/* eslint-disable prettier/prettier */
import { takeLatest, takeEvery, call, put } from 'redux-saga/effects';
import { api } from '../../api';
import {
    LOGIN_REQUEST_LOADING,
    LOGIN_REQUEST_SUCCESS,
    LOGIN_REQUEST_FAIL,
    LOGIN_REQUEST,
    USER_BRAND_REQUEST,
    GET_BRAND_SUCCESS,
    OK, FAIL,
    HTTP_API_ERROR, ASYNC_FAIL, GENERIC_FAIL, INTERMEDIATE_PAGE_HTTP_ERROR,
} from '../../resources/constants/storeConstants';
import AppAsyncStorage from '../../api/helper/AppAsyncStorage';
import {
    CART_LIST, LAST_PRODUCT_UPDATE_DATE,
    LOGGED_IN_EMAIL,
    PRODUCT_LIST,
    SESSION_TOKEN,
    USER_BRAND_DATA,
} from '../../resources/constants/asyncKeys';
import {validateRequiredField} from '../../utils/validators';



const checkUserAsync = async(email, token) =>{
    try{
         let prevEmail =await AppAsyncStorage.getValue(LOGGED_IN_EMAIL)
                if(prevEmail === null || prevEmail !== email ){
                    //debugger;
                    await AppAsyncStorage.setValue(LOGGED_IN_EMAIL, email);
                    await AppAsyncStorage.setValue(PRODUCT_LIST,'');
                    await AppAsyncStorage.setValue(CART_LIST,'');
                    await AppAsyncStorage.setValue(SESSION_TOKEN, token);
                    await AppAsyncStorage.setValue(LAST_PRODUCT_UPDATE_DATE, '');
                    return true;
                }

       else{
                await AppAsyncStorage.setValue(SESSION_TOKEN, token);
                    return true;
            }

    }
    catch(error){
        console.log(error);
        return false;
    }
}


const saveBrandAsync= async(brandData, companyId, templateId) =>{
    try {
        let prevLoginBrandData = await AppAsyncStorage.getValue(USER_BRAND_DATA);
        debugger;
        if (validateRequiredField(prevLoginBrandData)) {
        debugger;
            // to check if user logged out due to sesionexpire or any way and now again logging with same id company and temp -->
            // dont reset its cart and product list in that case, reset only when new diffrent useror company or template
            let prevBrandData = JSON.parse(prevLoginBrandData);
            debugger;
            if ((prevBrandData.CompanyId && prevBrandData.CompanyId !== companyId) ||
                (prevBrandData.AppTemplateHeaderId && prevBrandData.AppTemplateHeaderId !== templateId)) {
                await AppAsyncStorage.setValue(PRODUCT_LIST, '');
                await AppAsyncStorage.setValue(CART_LIST, '');
                await AppAsyncStorage.setValue(LAST_PRODUCT_UPDATE_DATE, '');
            }
        }
            await AppAsyncStorage.setValue(USER_BRAND_DATA, brandData);
            return true;
    }
    catch{
        console.log(error);
        return false;
    }

}

// worker saga: Fetch Trending repositories when watcher saga sees the action
function* fetchLoginRequest({ payload: { email, password } }) {
    try {
        //debugger;
        yield put({ type: LOGIN_REQUEST_LOADING });
        const response = yield call({ context: api, fn: api.loginApi }, email, password);
         if(response.data.response.reasonCode === OK){
             const setUserAsync= yield call(checkUserAsync, email,response.data.response.token );
              //debugger;
             if(setUserAsync){
                 //console.log("key is BEFORE safe---->>>")
                 //console.log(response.data.response.token);
                 yield put({type: LOGIN_REQUEST_SUCCESS, payload: {responseData: response.data.response}});
            }
             else{
                 yield put({ type: HTTP_API_ERROR, payload:  {errorType: ASYNC_FAIL} });
             }

        }
         else if(response.data.response.reasonCode === FAIL){
             yield put({type: LOGIN_REQUEST_FAIL, payload: {responseData: response.data.response}});
         }
    }
    catch (errorObj) {
        yield put({ type: HTTP_API_ERROR, payload: errorObj });
    }
}

function* fetchUserBrandRequest({ payload: {companyId, templateId} }) {
    try {
        //debugger;
        const response = yield call({ context: api, fn: api.userBrandApi }, companyId, templateId);
        if(response.data.response.reasonCode === OK ){
            // debugger;
            let userBrandData= JSON.parse(response.data.response.userData);
            // this if condition to handle sitution in  case all bottom tabs are disabled from server -->> throw generic error
            if(userBrandData.CommCenter === true || userBrandData.ManageSpiff === true || userBrandData.OrderProducts === true) {
                console.log('userbrand data');
                console.log(userBrandData);
                const setBrandAsync = yield call(saveBrandAsync, response.data.response.userData, companyId, templateId );
              //  debugger;
                if (setBrandAsync) {
                    yield put({type: GET_BRAND_SUCCESS, payload: {responseData: userBrandData}});
                } else {
                    yield put({type: INTERMEDIATE_PAGE_HTTP_ERROR, payload: {errorType: ASYNC_FAIL}});
                }
            }
            else{
                console.log('-------------------error as all bottom tab false from server---------------------');
                yield put({ type: INTERMEDIATE_PAGE_HTTP_ERROR, payload: {errorType: GENERIC_FAIL}  });
            }
        }
        else{
            yield put({ type: INTERMEDIATE_PAGE_HTTP_ERROR, payload: {errorType: GENERIC_FAIL}  });
        }
    }
    catch (errorObj) {
    //debugger;
        yield put({ type: INTERMEDIATE_PAGE_HTTP_ERROR, payload: errorObj });
    }

}

// watcher saga: watches for actions dispatched to the store, starts worker saga
export default function* watcherSaga() {
    yield takeLatest(LOGIN_REQUEST, fetchLoginRequest);
    yield takeLatest(USER_BRAND_REQUEST, fetchUserBrandRequest);

}


// const response = yield call({ context: api, fn: api.loginApi }, date);
