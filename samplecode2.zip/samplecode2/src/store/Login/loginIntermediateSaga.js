import {call, put, takeLatest} from '@redux-saga/core/effects';
import {api} from '../../api';
import {
    ASYNC_FAIL, COMAPANY_REQUEST, COMAPANY_TEMPLATE_REQUEST, COMPANY_LIST_SUCCESS, GENERIC_FAIL,
    GET_BRAND_SUCCESS, HTTP_API_ERROR,
    INTERMEDIATE_PAGE_HTTP_ERROR, LOGIN_REQUEST,
    OK, TEMPLATE_LIST_SUCCESS, TEMPLATE_REQUEST, USER_BRAND_REQUEST,
} from '../../resources/constants/storeConstants';

function* fetchCompanyRequest({ payload: {} }) {
    try {
        //debugger;
        const response = yield call({ context: api, fn: api.userCompanyApi });
        if(response.data.response.reasonCode === OK){
            // debugger;
            let userCompanyList= JSON.parse(response.data.response.userData);
           // console.log('user Company data');
           // console.log(userCompanyList);
            yield put({type: COMPANY_LIST_SUCCESS, payload: userCompanyList});
        }
        else{
            yield put({ type: HTTP_API_ERROR, payload: {errorType: GENERIC_FAIL}  });
        }
    }
    catch (errorObj) {
        //debugger;
        yield put({ type: HTTP_API_ERROR, payload: errorObj });
    }

}

function* fetchTemplateRequest({ payload: companyId }) {
    try {
        //debugger;
        const response = yield call({ context: api, fn: api.userTemplateApi },companyId );
        if(response.data.response.reasonCode === OK){
            // debugger;
            let userTemplateList= JSON.parse(response.data.response.userData);
            // console.log('user Company data');
            // console.log(userCompanyList);
            yield put({type: TEMPLATE_LIST_SUCCESS, payload: userTemplateList});
        }
        else{
            yield put({ type: INTERMEDIATE_PAGE_HTTP_ERROR, payload: {errorType: GENERIC_FAIL}  });
        }
    }
    catch (errorObj) {
        //debugger;
        yield put({ type: INTERMEDIATE_PAGE_HTTP_ERROR, payload: errorObj });
    }

}

// watcher saga: watches for actions dispatched to the store, starts worker saga
export default function* watcherSaga() {
    yield takeLatest(COMAPANY_REQUEST, fetchCompanyRequest);
    yield takeLatest(TEMPLATE_REQUEST, fetchTemplateRequest);
}

