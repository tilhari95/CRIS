import {
    ADD_ITEM_TO_CART_LIST, CHECK_AND_PLACE_ORDER,
    DELETE_ITEM_FROM_CART_LIST,
    INITIALIZE_CARTLIST_FROM_ASYNC, RESET_CART_BADGE_VALUE,
    RESET_CART_LIST, RESET_PLACE_ORDER_STATE,
    SET_CART_REDUX_INITIAL_STATE, SET_ORDER_HTTP_INITIAL_STATE, TOGGLE_CART_UPDATER,
    UPDATE_CART_LIST, UPDATE_ITEM_TO_CART_LIST,
} from '../../resources/constants/storeConstants';
import AppAsyncStorage from '../../api/helper/AppAsyncStorage';
import {CART_LIST} from '../../resources/constants/asyncKeys';

export const resetCartList = () => ({
    type: RESET_CART_LIST,
    payload: '',
});

export const updateCartListAsync =  (cartList, cartCounter, cartTotalAmount ) => {
    return({type: INITIALIZE_CARTLIST_FROM_ASYNC,
        payload: {cartList: cartList, cartBadgeValue: cartCounter, cartTotalAmount: cartTotalAmount}})
};

export const deleteItemFromCart = (cartList, quantity, price) => {
    return({type: DELETE_ITEM_FROM_CART_LIST, payload: {cartList: cartList, quantityDelete: quantity, priceDelete: price}})
};

export const addItemToCart =(cartList, quantity, price) => {
    return({type: ADD_ITEM_TO_CART_LIST, payload: {cartList: cartList, quantityToAdd: quantity, priceToAdd: price}})
};
export const updateItemInCartList =(cartList, prevQuantity, newQuantity, price) => {
    return({type: UPDATE_ITEM_TO_CART_LIST, payload: {cartList: cartList, quantityToRemove: prevQuantity,
            quantityToAdd: newQuantity,  price: price}})
};

export const toggleCartUpdater = (bool) => {
    return({type: TOGGLE_CART_UPDATER, payload: bool})
};
export const resetCartBadge = () => {
    return({type: RESET_CART_BADGE_VALUE, payload: ''})
};
export const checkAndPlaceOrder = (deliveryDetails) => {
    return({type: CHECK_AND_PLACE_ORDER, payload: deliveryDetails})
};
export const productUpdateOnMismatch = (deliveryDetails) => {
    return({type: CHECK_AND_PLACE_ORDER, payload: deliveryDetails})
};
export const resetCartResponseState = () => {
    return({type: RESET_PLACE_ORDER_STATE, payload: ''})
}

export const resetCartReduxInitialState = () => {
    return({type: SET_CART_REDUX_INITIAL_STATE, payload:'' });
};

export const resetHttpOrderError = () => {
    return({type: SET_ORDER_HTTP_INITIAL_STATE, payload:'' });
};
