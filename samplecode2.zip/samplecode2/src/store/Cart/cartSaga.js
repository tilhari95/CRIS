import { takeLatest, takeEvery, call, put } from 'redux-saga/effects';
import {
    ADD_ITEM_TO_CART_LIST,
    CHECK_AND_PLACE_ORDER,
    DELETE_ITEM_FROM_CART_LIST,
    ERROR_401,
    FAIL,
    GENERIC_FAIL,
    HTTP_ORDER_API_ERROR,
    HTTP_PRODUCT_API_ERROR,
    INVALID_TOKEN,
    OK,
    PLACE_ORDER_FAIL,
    PLACE_ORDER_MISMATCH,
    PLACE_ORDER_SUCCESS,
    PRODUCT_API_REQUEST,
    PRODUCT_MISMATCH,
    RESET_CART_LIST,
    RESPONSE_ISSUE,
    RESPONSE_SESSION_EXP,
    SET_CART_REDUX_INITIAL_STATE,
    UPDATE_CART_ITEM_ADD_SUCCESS,
    UPDATE_CART_ITEM_DELETE_SUCCESS,
    UPDATE_EXISTING_CART_ITEM_UPDATE_SUCCESS,
    UPDATE_ITEM_TO_CART_LIST,
} from '../../resources/constants/storeConstants';
import AppAsyncStorage from '../../api/helper/AppAsyncStorage';
import {CART_LIST} from '../../resources/constants/asyncKeys';
import {
    cartCalculationsOnAsyncFetch,
    cartCalculationsOnAddition,
    cartCalculationsOnDelete,
    cartCalculationsOnUpdation, getOrderlineObj, getPlaceOrderAPIObj,
} from '../../utils/cartHelpers';
import {
    CART_BADGE_VALUE,
    CART_TOTAL_AMOUNT,
    DATA_VALID,
    ORDER_LINE_JSON,
} from '../../resources/constants/stringConstants';
import {select} from '@redux-saga/core/effects';
import {api} from '../../api';
import {getOrderDateAndTime} from '../../utils/date';

export const getCartRedux = (reduxStore) => reduxStore.cart;



export const cartListToAsync = async (cartList) => {
    debugger;
    try {
        console.log(cartList);
        let getC = await AppAsyncStorage.getValue(CART_LIST);
        console.log(getC);
        await AppAsyncStorage.setValue(CART_LIST,JSON.stringify(cartList));
        let getC2 = await AppAsyncStorage.getValue(CART_LIST);
        console.log(getC2);
        return true;
    }
    catch(error){
        return false;
    }

}

function* cartItemDelete({ payload: cartListObj }) {
    //debugger;
    console.log(cartListObj);
    const {quantityDelete,priceDelete} =cartListObj;
    let cartState = yield select(getCartRedux);
    try{
        const cartCalculationObj = yield call (cartCalculationsOnDelete, cartState, quantityDelete, priceDelete );
        //debugger;
        cartListObj[CART_BADGE_VALUE]=cartCalculationObj.badgeCount;
        cartListObj[CART_TOTAL_AMOUNT]=cartCalculationObj.cartTotalAmount;
        const isCartAsync= yield call(cartListToAsync, cartListObj.cartList );

        if (isCartAsync){
            yield put({type: UPDATE_CART_ITEM_DELETE_SUCCESS, payload: cartListObj});
        }
    }
    catch(error){
        //debugger;
        console.log('error on cart delete item-->');
        console.log(error);
    }
}

function* cartItemAdd({ payload: cartListObj }) {
    debugger;
    console.log(cartListObj);
    const {quantityToAdd, priceToAdd} =cartListObj;
    let cartState = yield select(getCartRedux);
    try{
        const cartCalculationObj = yield call (cartCalculationsOnAddition, cartState, quantityToAdd, priceToAdd);
        cartListObj[CART_BADGE_VALUE]=cartCalculationObj.badgeCount;
        cartListObj[CART_TOTAL_AMOUNT]=cartCalculationObj.cartTotalAmount;
        const isCartAsync= yield call(cartListToAsync, cartListObj.cartList );

        if (isCartAsync){
            yield put({type: UPDATE_CART_ITEM_ADD_SUCCESS, payload: cartListObj});
        }
    }
    catch(error){
        console.log('error on cart add item-->');
        console.log(error);
    }
}

function* cartItemUpdate({ payload: cartListObj }) {
    const {quantityToRemove, quantityToAdd, price} =cartListObj;
    let cartState = yield select(getCartRedux);
    try{
        const cartCalculationObj = yield call (cartCalculationsOnUpdation, cartState, quantityToRemove, quantityToAdd, price);
    debugger;
        cartListObj[CART_BADGE_VALUE]=cartCalculationObj.badgeCount;
        cartListObj[CART_TOTAL_AMOUNT]=cartCalculationObj.cartTotalAmount;
        const isCartAsync= yield call(cartListToAsync, cartListObj.cartList );

        if (isCartAsync){
            yield put({type: UPDATE_EXISTING_CART_ITEM_UPDATE_SUCCESS, payload: cartListObj});
        }
    }
    catch(error){
        console.log('error on cart update item-->');
        console.log(error);
    }
}

function* placeOrder({payload: deliveryDetails}) {
    debugger;
    let cartState = yield select(getCartRedux);
    try{
        //get date and time in required format form for API body
        let dateAndTime =yield call (getOrderDateAndTime);
        // get cartList in required format for API body
        const orderLineArray = yield call (getOrderlineObj, cartState.cartList);
        // create checkOrderDetail API body->
        let CheckOrderDetailsBody = {};
        CheckOrderDetailsBody[ORDER_LINE_JSON] = orderLineArray;
        //request CheckOrderDetails api
        const checkOrderDetailsResponse = yield call({ context: api, fn: api.checkOrderDetailsApi }, CheckOrderDetailsBody);
        console.log(checkOrderDetailsResponse);
        const {reasonCode, reasonText, itemList, error} = checkOrderDetailsResponse.data.response;
        let mismatchOrder=true;// for background product api trigger, this will not clear cart.
        if(reasonCode === OK && reasonText === DATA_VALID && itemList ==='' ){ // if no product mismatch, request final place order API
            //get object for place order API body
            const placeOrderAPIBody = yield call (getPlaceOrderAPIObj,
                orderLineArray,deliveryDetails, dateAndTime, cartState.cartTotalAmount );
            // request the API->
            const placeOrderResponse = yield call({ context: api, fn: api.placeOrderApi }, placeOrderAPIBody);
            console.log(placeOrderResponse);
            if(placeOrderResponse.data.response.reasonCode  === OK){ // if order placed successfully
                mismatchOrder=false; // update procducts in background and also clear cart.
                yield put({type: PLACE_ORDER_SUCCESS, payload: placeOrderResponse.data.response});
                //refresh productList
                yield put({type: PRODUCT_API_REQUEST, payload: mismatchOrder});
            }
            else if((placeOrderResponse.data.response.reasonCode === FAIL) && (placeOrderResponse.data.response.error === RESPONSE_SESSION_EXP
            || placeOrderResponse.data.response.error === INVALID_TOKEN) ){
                let errorObj={errorType:RESPONSE_ISSUE, errorBody:placeOrderResponse.data.response.error , ErrorStatus: ERROR_401}
                yield put({ type: HTTP_ORDER_API_ERROR, payload:  errorObj });
            }
            else if(placeOrderResponse.data.response.reasonCode === FAIL){
                yield put({ type: HTTP_ORDER_API_ERROR, payload:  { errorType: GENERIC_FAIL, errorBody:placeOrderResponse.data.response.error } });
            }
        }
        else if (reasonCode === OK && reasonText === PRODUCT_MISMATCH && itemList !==''){
            let mismatchOrderItems = JSON.parse(itemList);
            console.log(mismatchOrderItems);
            yield put({type: PLACE_ORDER_MISMATCH, payload: mismatchOrderItems});
            // refresh product list
            yield put({type: PRODUCT_API_REQUEST, payload: mismatchOrder});
        }
        else if((reasonCode === FAIL) && (error === RESPONSE_SESSION_EXP|| error === INVALID_TOKEN) ){
            let errorObj={errorType:RESPONSE_ISSUE, errorBody:error , ErrorStatus: ERROR_401};
            yield put({ type: HTTP_ORDER_API_ERROR, payload:  errorObj });
        }
        else if(reasonCode === FAIL){
            yield put({ type: HTTP_ORDER_API_ERROR, payload:  { errorType: GENERIC_FAIL, errorBody:error } });
        }
    }
    catch(errorObj){
        yield put({ type: HTTP_ORDER_API_ERROR, payload: errorObj });
    }
}

export default function* watcherSaga() {
    yield takeEvery(ADD_ITEM_TO_CART_LIST, cartItemAdd);
    yield takeEvery(DELETE_ITEM_FROM_CART_LIST, cartItemDelete);
    yield takeEvery(UPDATE_ITEM_TO_CART_LIST, cartItemUpdate);
    yield takeEvery(CHECK_AND_PLACE_ORDER, placeOrder);


}

