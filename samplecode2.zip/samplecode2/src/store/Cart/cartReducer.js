
import {
    UPDATE_CART_LIST,
    RESET_CART_LIST,
    SET_CART_REDUX_INITIAL_STATE,
    TOGGLE_CART_UPDATER,
    INITIALIZE_CARTLIST_FROM_ASYNC,
    UPDATE_CART_LIST_SUCCESS,
    SET_CART_BADGE_VALUE,
    RESET_CART_BADGE_VALUE,
    UPDATE_CART_ITEM_DELETE_SUCCESS,
    UPDATE_CART_ITEM_ADD_SUCCESS,
    UPDATE_EXISTING_CART_ITEM_UPDATE_SUCCESS,
    PLACE_ORDER_SUCCESS,
    PLACE_ORDER_FAIL,
    RESET_PLACE_ORDER_STATE,
    PLACE_ORDER_MISMATCH, HTTP_ORDER_API_ERROR, SET_ORDER_HTTP_INITIAL_STATE,
} from '../../resources/constants/storeConstants';

const initialState = {
    cartList: null,
    triggerCartUpdate: false,
    cartBadgeValue: 0,
    cartTotalAmount: '0', //intial is string zero other time is is string with 2 decimal places, on saving as number type decimal zeros get removed
    placeOrderSuccess: null,
    placeOrderFail: null,
    orderMismatch: null,
    httpOrderError: null
};

export default (state = initialState, action) => {
    switch (action.type) {
        case INITIALIZE_CARTLIST_FROM_ASYNC:
            return {...state,
                cartList: action.payload.cartList,
                cartBadgeValue: action.payload.cartBadgeValue,
                cartTotalAmount: action.payload.cartTotalAmount
            }
        case UPDATE_CART_ITEM_ADD_SUCCESS:
            return {...state,
                cartList: action.payload.cartList,
                triggerCartUpdate: true,
                cartBadgeValue: action.payload.cartBadgeValue,
                cartTotalAmount: action.payload.cartTotalAmount
            }
        case UPDATE_EXISTING_CART_ITEM_UPDATE_SUCCESS:
            return {...state,
                cartList: action.payload.cartList,
                triggerCartUpdate: true,
                cartBadgeValue: action.payload.cartBadgeValue,
                cartTotalAmount: action.payload.cartTotalAmount
            }

        case UPDATE_CART_ITEM_DELETE_SUCCESS:
            return {...state,
                cartList: action.payload.cartList,
                triggerCartUpdate: true,
                cartBadgeValue: action.payload.cartBadgeValue,
                cartTotalAmount: action.payload.cartTotalAmount
            }
        case TOGGLE_CART_UPDATER:
            return {...state, triggerCartUpdate: action.payload }
        case RESET_CART_LIST:
            return {...state, cartList: []}
        case SET_CART_REDUX_INITIAL_STATE:
            return {...state, ...initialState, cartList:[] };
        case SET_CART_BADGE_VALUE:
            return{...state, cartBadgeValue: action.payload }
        case RESET_CART_BADGE_VALUE:
            return{...state, cartBadgeValue: 0 }
        case PLACE_ORDER_SUCCESS:
            return{...state, placeOrderSuccess: action.payload }
        case PLACE_ORDER_FAIL:
            return{...state, placeOrderFail: action.payload }
        case PLACE_ORDER_MISMATCH:
            return{...state, orderMismatch: action.payload }
        case HTTP_ORDER_API_ERROR:
            return{...state, httpOrderError: action.payload }
        case RESET_PLACE_ORDER_STATE:
            return{...state, placeOrderFail: null, placeOrderSuccess: null, orderMismatch:null }
        case SET_ORDER_HTTP_INITIAL_STATE:
            return{...state, httpOrderError: null }

        default:
            return state;
    }
};
