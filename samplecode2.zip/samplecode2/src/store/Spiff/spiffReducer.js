/* eslint-disable prettier/prettier */

import {
    GET_MESSAGE_FAIL,
    GET_MESSAGE_SUCCESS,
    GET_SPIFF_TRANCTION_SUCCESS,
    GET_SPIFF_TRANSACTION_FAIL,
    HTTP_MESSAGE_API_ERROR,
    HTTP_SPIFF_LANDING_PAGE_API_ERROR, HTTP_SPIFF_PAYOUT_PAGE_API_ERROR, PAYOUT_FINAL_REQUEST_SUCCESS,
    RESET_HTTP_MESSAGE_API_ERROR,
    RESET_MESSAGE_INDICATOR,
    RESET_MESSAGE_PAGE_REDUCER_STATE,
    RESET_SPIFF_LANDING_PAGE_API_ERROR, RESET_SPIFF_PAYOUT_API_RESPONSE, RESET_SPIFF_PAYOUT_PAGE_API_ERROR,
    RESET_SPIFF_REDUCER_STATE,
    RESET_SPIFF_TRANCTION_BALANCE_API,
    SEND_MESSAGE_FAIL,
    SEND_MESSAGE_SUCCESS,
    SERVER_PUSH_MESSAGE_RECEIVED,
    SERVER_PUSH_MESSAGE_RESET, SPIFF_PAYMENT_MODE_SUCCESS,
} from '../../resources/constants/storeConstants';

const initialState = {
    getSpiffTranctionSuccessResponse: null,
    getSpiffTranctionFailResponse: null,
    SpiffLandingPageHttpError: null,
    spiffPayoutPageHttpError: null,
    payoutTypesApiSuccess: null,
    payoutFinalRequestSuccess: null,
};

export default (state = initialState, action) => {
    switch(action.type) {
        case GET_SPIFF_TRANCTION_SUCCESS:
            return {...state, getSpiffTranctionSuccessResponse: action.payload}
        case RESET_SPIFF_TRANCTION_BALANCE_API:
            return {...state, getSpiffTranctionSuccessResponse: null, getSpiffTranctionFailResponse: null}
        case GET_SPIFF_TRANSACTION_FAIL:
            return {...state, getSpiffTranctionFailResponse: action.payload}
        case RESET_SPIFF_REDUCER_STATE:
            return{...state, ...initialState}
        case HTTP_SPIFF_LANDING_PAGE_API_ERROR:
            return{...state, SpiffLandingPageHttpError: action.payload}
        case RESET_SPIFF_LANDING_PAGE_API_ERROR:
            return{...state, SpiffLandingPageHttpError: null }
        case HTTP_SPIFF_PAYOUT_PAGE_API_ERROR:
            return{...state, spiffPayoutPageHttpError: action.payload}
        case RESET_SPIFF_PAYOUT_PAGE_API_ERROR:
            return{...state, spiffPayoutPageHttpError: null }
        case SPIFF_PAYMENT_MODE_SUCCESS:
            return{...state, payoutTypesApiSuccess: action.payload }
        case RESET_SPIFF_PAYOUT_API_RESPONSE:
            return{...state, payoutTypesApiSuccess: null}
        case PAYOUT_FINAL_REQUEST_SUCCESS:
            return{...state, payoutFinalRequestSuccess: action.payload}


        default:
            return state;
    }
};
