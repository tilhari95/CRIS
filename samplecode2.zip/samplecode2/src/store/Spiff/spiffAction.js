import {
    PRODUCT_API_REQUEST,
    REQUEST_PAYMENT_MODE_API, REQUEST_PAYOUT_API,
    RESET_HTTP_PRODUCT_API_ERROR,
    RESET_SPIFF_LANDING_PAGE_API_ERROR, RESET_SPIFF_PAYOUT_API_RESPONSE,
    RESET_SPIFF_PAYOUT_PAGE_API_ERROR, RESET_SPIFF_REDUCER_STATE,
    RESET_SPIFF_TRANCTION_BALANCE_API,
    SPIFF_TRANSACTION_REQUEST,
} from '../../resources/constants/storeConstants';

export const spiffTransactionRequest = () => {
    return({
        type: SPIFF_TRANSACTION_REQUEST,
        payload: '' });
};
export const resetHttpSpiffLandingApiError = () => {
    return({
        type: RESET_SPIFF_LANDING_PAGE_API_ERROR,
        payload:'' });
};
export const refreshSpiffBalanceAndTranaction = () => {
    return({
        type: RESET_SPIFF_TRANCTION_BALANCE_API,
        payload:'' });
};

export const requestPaymentMode = () => {
    return({
        type: REQUEST_PAYMENT_MODE_API,
        payload:'' });
};

export const requestFinalSpiffPayout = (payoutRequestObj) => {
    return({
        type: REQUEST_PAYOUT_API,
        payload:payoutRequestObj });
};
export const resetHttpSpiffPayoutApiError = () => {
    return({
        type: RESET_SPIFF_PAYOUT_PAGE_API_ERROR,
        payload:'' });
};

export const resetPayoutSuccess = () => {
    return({
        type: RESET_SPIFF_PAYOUT_API_RESPONSE,
        payload:'' });
};

export const resetSpiffCompleteRedux = () => {
    return({
        type: RESET_SPIFF_REDUCER_STATE,
        payload:'' });
}
