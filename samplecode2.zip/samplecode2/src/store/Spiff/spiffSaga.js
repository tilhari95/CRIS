
import { takeLatest, takeEvery, call, put } from 'redux-saga/effects';
import { api } from '../../api';
import {
    OK,
    FAIL,
    RESET_PASSWORD_REQUEST,
    RESET_REQUEST_SUCCESS,
    RESET_REQUEST_FAIL,
    HTTP_RESET_API_ERROR,
    SPIFF_TRANSACTION_REQUEST,
    SEND_MESSAGE_SUCCESS,
    RESPONSE_SESSION_EXP,
    INVALID_TOKEN,
    RESPONSE_ISSUE,
    ERROR_401,
    HTTP_MESSAGE_API_ERROR,
    GENERIC_FAIL,
    GET_SPIFF_TRANCTION_SUCCESS,
    HTTP_SPIFF_LANDING_PAGE_API_ERROR,
    REQUEST_PAYMENT_MODE_API,
    MOBILE_FLAG,
    HTTP_SPIFF_PAYOUT_PAGE_API_ERROR,
    SPIFF_PAYMENT_MODE_SUCCESS, REQUEST_PAYOUT_API, PAYOUT_FINAL_REQUEST_SUCCESS,
} from '../../resources/constants/storeConstants';
import {getOrderDateAndTime} from '../../utils/date';
import {getPlaceOrderAPIObj} from '../../utils/cartHelpers';
import {getSpiffPayoutAPIObj} from '../../utils/spiffHelpers';

function* fetchSpiffTranactionAndBalanceRequest() {
    try {
        const responseTranactionApi = yield call({ context: api, fn: api.spiffTranactionApi });
        if(responseTranactionApi.data.response.reasonCode === OK){
            // proceed to fetch balance after getting success status form transaction api
            const responseBalanceAPI = yield call({ context: api, fn: api.spiffBalanceApi });
            if(responseBalanceAPI.data.response.reasonCode === OK) {
                debugger;
                // parse both API response when both ok else return error
                let parserSpiffTransactionList = [];
                const spiffTransactionList = responseTranactionApi.data.response.dataList;
                if (spiffTransactionList !== '') {
                    debugger;
                    parserSpiffTransactionList = JSON.parse(spiffTransactionList);
                    console.log(parserSpiffTransactionList);
                }
                let spiffBalance = responseBalanceAPI.data.response.dataList;
                let payloadObj = {parserSpiffTransactionList: parserSpiffTransactionList, spiffBalance: spiffBalance}
                console.log(payloadObj);
                yield put({type: GET_SPIFF_TRANCTION_SUCCESS, payload: payloadObj})
            }
            else if((responseBalanceAPI.data.response.reasonCode === FAIL) && (responseBalanceAPI.data.response.error === RESPONSE_SESSION_EXP
                || responseBalanceAPI.data.response.error === INVALID_TOKEN)){
                let errorObj={errorType:RESPONSE_ISSUE, errorBody:responseTranactionApi.data.response.error , ErrorStatus: ERROR_401}
                yield put({ type: HTTP_SPIFF_LANDING_PAGE_API_ERROR, payload:  errorObj });
            }
            else if(responseBalanceAPI.data.response.reasonCode === FAIL){
                yield put({ type: HTTP_SPIFF_LANDING_PAGE_API_ERROR, payload:  { errorType: GENERIC_FAIL, errorBody:responseBalanceAPI.data.response.error } });
            }
        }
        else if((responseTranactionApi.data.response.reasonCode === FAIL) && (responseTranactionApi.data.response.error === RESPONSE_SESSION_EXP
            || responseTranactionApi.data.response.error === INVALID_TOKEN)){
            let errorObj={errorType:RESPONSE_ISSUE, errorBody:responseTranactionApi.data.response.error , ErrorStatus: ERROR_401}
            yield put({ type: HTTP_SPIFF_LANDING_PAGE_API_ERROR, payload:  errorObj });
        }
        else if(responseTranactionApi.data.response.reasonCode === FAIL){
            yield put({ type: HTTP_SPIFF_LANDING_PAGE_API_ERROR, payload:  { errorType: GENERIC_FAIL, errorBody:responseTranactionApi.data.response.error } });
        }
    }
    catch (errorObj){
        yield put({ type: HTTP_SPIFF_LANDING_PAGE_API_ERROR, payload: errorObj });
    }
}

function* fetchSpiffPaymentModeRequest() {
    try {
        const payoutTypesResponse = yield call({ context: api, fn: api.sendPayoutTypesApi });
        console.log(payoutTypesResponse);
        if(payoutTypesResponse.data.response.reasonCode === OK){
            let parserSpiffPayoutList = [];
            const spiffPayoutList = payoutTypesResponse.data.response.dataList;
            if (spiffPayoutList !== '') {
            debugger;
                parserSpiffPayoutList = JSON.parse(spiffPayoutList);
                console.log(parserSpiffPayoutList);
            }
            yield put({type: SPIFF_PAYMENT_MODE_SUCCESS, payload: parserSpiffPayoutList})
        }
        else if((payoutTypesResponse.data.response.reasonCode === FAIL) && (payoutTypesResponse.data.response.error === RESPONSE_SESSION_EXP
            || payoutTypesResponse.data.response.error === INVALID_TOKEN)){
            let errorObj={errorType:RESPONSE_ISSUE, errorBody:payoutTypesResponse.data.response.error , ErrorStatus: ERROR_401}
            yield put({ type: HTTP_SPIFF_PAYOUT_PAGE_API_ERROR, payload:  errorObj });
        }
        else if(payoutTypesResponse.data.response.reasonCode === FAIL){
            yield put({ type: HTTP_SPIFF_PAYOUT_PAGE_API_ERROR, payload:  { errorType: GENERIC_FAIL, errorBody:payoutTypesResponse.data.response.error } });
        }
    }
    catch (errorObj){
        yield put({ type: HTTP_SPIFF_PAYOUT_PAGE_API_ERROR, payload: errorObj });
    }
}

function* fetchSpiffPayoutRequest({ payload: spiffPayoutObj }) {
    try {
        const spiffPayoutAPIBody = yield call (getSpiffPayoutAPIObj, spiffPayoutObj);
        const payoutApiResponse = yield call({ context: api, fn: api.spiffPayoutRequestApi }, spiffPayoutAPIBody);
        console.log(payoutApiResponse);
        if(payoutApiResponse.data.response.reasonCode === OK){
            yield put({type: PAYOUT_FINAL_REQUEST_SUCCESS, payload: payoutApiResponse})
        }
        else if((payoutApiResponse.data.response.reasonCode === FAIL) && (payoutApiResponse.data.response.error === RESPONSE_SESSION_EXP
            || payoutApiResponse.data.response.error === INVALID_TOKEN)){
            let errorObj={errorType:RESPONSE_ISSUE, errorBody:payoutApiResponse.data.response.error , ErrorStatus: ERROR_401}
            yield put({ type: HTTP_SPIFF_PAYOUT_PAGE_API_ERROR, payload:  errorObj });
        }
        else if(payoutApiResponse.data.response.reasonCode === FAIL){
            yield put({ type: HTTP_SPIFF_PAYOUT_PAGE_API_ERROR, payload:  { errorType: GENERIC_FAIL, errorBody:payoutApiResponse.data.response.error } });
        }
    }
    catch (errorObj){
        yield put({ type: HTTP_SPIFF_PAYOUT_PAGE_API_ERROR, payload: errorObj });
    }
}





export default function* watcherSaga() {
    yield takeLatest(SPIFF_TRANSACTION_REQUEST, fetchSpiffTranactionAndBalanceRequest);
    yield takeLatest(REQUEST_PAYMENT_MODE_API, fetchSpiffPaymentModeRequest);
    yield takeLatest(REQUEST_PAYOUT_API, fetchSpiffPayoutRequest);


}

