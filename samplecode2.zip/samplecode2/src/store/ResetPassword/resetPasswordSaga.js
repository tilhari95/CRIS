/* eslint-disable prettier/prettier */
import { takeLatest, takeEvery, call, put } from 'redux-saga/effects';
import { api } from '../../api';
import {
    OK,
    FAIL,
    RESET_PASSWORD_REQUEST,
    RESET_REQUEST_SUCCESS,
    RESET_REQUEST_FAIL,
    HTTP_RESET_API_ERROR,
} from '../../resources/constants/storeConstants';

function* fetchResetPasswordRequest({ payload: email }) {
    try {
        const response = yield call({ context: api, fn: api.resetPasswordApi }, email);
        if(response.data.response.reasonCode === OK){
                yield put({type: RESET_REQUEST_SUCCESS, payload: response.data.response});
            }
        else if(response.data.response.reasonCode === FAIL){
            yield put({type: RESET_REQUEST_FAIL, payload: response.data.response});
        }
    }
    catch (errorObj){
        yield put({ type: HTTP_RESET_API_ERROR, payload: errorObj });
    }
}

export default function* watcherSaga() {
    yield takeLatest(RESET_PASSWORD_REQUEST, fetchResetPasswordRequest);

}

