import { fork } from 'redux-saga/effects';
import loginSaga from './Login/loginSaga';
import productScreenSaga from './ProductPage/ProductPageSaga';
import resetPasswordSaga from './ResetPassword/resetPasswordSaga';
import cartSaga from './Cart/cartSaga';
import messageSaga from './Message/messageSaga';
import logoutSaga from './Logout/logoutSaga';
import spiffSaga from './Spiff/spiffSaga';
import loginIntermediateSaga from './Login/loginIntermediateSaga';
import orderHistorySaga from './OrderHistory/orderHistorySaga';
// import someOtherSagas from './someOther/sagas';

/**
 * rootSaga
 */
export default function* rootSaga() {
    yield fork(loginSaga);
    yield fork(productScreenSaga);
    yield fork(resetPasswordSaga);
    yield fork(cartSaga);
    yield fork(messageSaga);
    yield fork(logoutSaga);
    yield fork(spiffSaga);
    yield fork(loginIntermediateSaga);
    yield fork(orderHistorySaga);
    // yield fork(someOtherSagas)
}
