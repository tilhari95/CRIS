/* eslint-disable prettier/prettier */
import { takeLatest, takeEvery, call, put } from 'redux-saga/effects';
import { api } from '../../api';
import {
    OK,
    FAIL,
    RESET_PASSWORD_REQUEST,
    RESET_REQUEST_SUCCESS,
    RESET_REQUEST_FAIL,
    HTTP_RESET_API_ERROR,
    HTTP_LOGOUT_API_ERROR,
    LOGOUT_REQUEST,
    GENERIC_FAIL,
    LOGIN_REQUEST_SUCCESS,
    LOGOUT_SUCCESS,
    LOGOUT_ON_SESSION_INVALID,
    LOGOUT_SPIFF,
    LOGOUT_SPIFF_SUCCESS,
    HTTP_LOGOUT_API_ERROR_SPIFF,
    LOGOUT_COMM_SUCCESS,
    HTTP_LOGOUT_API_ERROR_COMM,
} from '../../resources/constants/storeConstants';
import {LOGOUT_FROM_COMM, LOGOUT_FROM_HOME, LOGOUT_FROM_SPIFF} from '../../resources/constants/stringConstants';

function* fetchLogoutRequest({ payload: screenName }) {
    try {
        const response = yield call({ context: api, fn: api.logoutApi });
        if(response.data.response.reasonCode === OK){
            if(screenName === LOGOUT_FROM_HOME)
                yield put({type: LOGOUT_SUCCESS, payload: {responseData: response.data.response}});
            else if (screenName === LOGOUT_FROM_SPIFF){
                yield put({type: LOGOUT_SPIFF_SUCCESS, payload: {responseData: response.data.response}});
            }
            else if (screenName === LOGOUT_FROM_COMM){
                yield put({type: LOGOUT_COMM_SUCCESS, payload: {responseData: response.data.response}});
            }
        }
        else if(response.data.response.reasonCode === FAIL){
            if(screenName === LOGOUT_FROM_HOME)
                yield put({ type: HTTP_LOGOUT_API_ERROR, payload:  { errorType: GENERIC_FAIL, errorBody:response.data.response.error } });
            if(screenName === LOGOUT_FROM_SPIFF)
                yield put({ type: HTTP_LOGOUT_API_ERROR_SPIFF, payload:  { errorType: GENERIC_FAIL, errorBody:response.data.response.error } });
            else if (screenName === LOGOUT_FROM_COMM)
                yield put({ type: HTTP_LOGOUT_API_ERROR_COMM, payload:  { errorType: GENERIC_FAIL, errorBody:response.data.response.error } });
        }
    }
    catch (errorObj){
        if(screenName === LOGOUT_FROM_HOME)
            yield put({ type: HTTP_LOGOUT_API_ERROR, payload: errorObj  });
        if(screenName === LOGOUT_FROM_SPIFF)
            yield put({ type: HTTP_LOGOUT_API_ERROR_SPIFF,  payload: errorObj });
        else if (screenName === LOGOUT_FROM_COMM)
            yield put({ type: HTTP_LOGOUT_API_ERROR_COMM,  payload: errorObj });
    }
}
function* fetchLogoutOnSessionInvalid({ payload: email }) {
    try {
        const response = yield call({ context: api, fn: api.logoutApi });
        if(response.data.response.reasonCode === OK){
          console.log('logged out on session invalid success!!');
        }
        else if(response.data.response.reasonCode === FAIL){
            console.log('logged out on session invalid failed onserver side!!');
        }
    }
    catch (errorObj){
        console.log('logged out on session invalid failed error obj --->> ' + errorObj);
    }
}


export default function* watcherSaga() {
    yield takeLatest(LOGOUT_REQUEST, fetchLogoutRequest);
    yield takeLatest(LOGOUT_ON_SESSION_INVALID, fetchLogoutOnSessionInvalid);


}

