
import {
    HTTP_LOGOUT_API_ERROR,
    RESET_HTTP_LOGOUT_API_ERROR,
    LOGOUT_REQUEST,
    LOGOUT,
    LOGOUT_SUCCESS,
    SET_LOGOUT_REDUX_INITIAL_STATE,
    RESET_HTTP_LOGOUT_REQUEST,
    LOGOUT_COMM_CENTER,
    LOGOUT_SPIFF,
    LOGOUT_COMM_SUCCESS,
    LOGOUT_SPIFF_SUCCESS, HTTP_LOGOUT_API_ERROR_COMM, HTTP_LOGOUT_API_ERROR_SPIFF,
} from '../../resources/constants/storeConstants';
import { Status } from '../../api';

const initialState = {
    logoutHttpError:null,
    logoutHttpErrorSpiff:null,
    logoutHttpErrorComm:null,

    logoutRequested: false,
    logoutRequestedFromSpiff: false,
    logoutRequestedFromComm:false,

    logoutSuccessResponse:null,
    logoutSuccessResponseFromComm:null,
    logoutSuccessResponseFromSpiff:null,

};

export default (state = initialState, action) => {
    switch(action.type) {
        case LOGOUT:
            return{...state, logoutRequested: true}
        case LOGOUT_SPIFF:
            return{...state, logoutRequestedFromSpiff: true}
        case LOGOUT_COMM_CENTER:
            return{...state, logoutRequestedFromComm: true}


        case HTTP_LOGOUT_API_ERROR:
            return{...state, logoutHttpError: action.payload}
        case HTTP_LOGOUT_API_ERROR_COMM:
            return{...state, logoutHttpErrorComm: action.payload}
        case HTTP_LOGOUT_API_ERROR_SPIFF:
            return{...state, logoutHttpErrorSpiff: action.payload}


        case RESET_HTTP_LOGOUT_API_ERROR:
            return{...state, logoutHttpError:null,logoutRequested: false  }


        case LOGOUT_SUCCESS:
            return{...state, logoutSuccessResponse: action.payload}
        case LOGOUT_COMM_SUCCESS:
            return{...state, logoutSuccessResponseFromComm: action.payload}
        case LOGOUT_SPIFF_SUCCESS:
            return{...state, logoutSuccessResponseFromSpiff: action.payload}


        case RESET_HTTP_LOGOUT_REQUEST:
            return{...state, logoutRequested: false, logoutRequestedFromSpiff: false, logoutRequestedFromComm:false,}

        case SET_LOGOUT_REDUX_INITIAL_STATE:
            return{...state, ...initialState}
        default:
            return state;
    }
};
