import {
    LOGOUT_REQUEST,
    RESET_HTTP_LOGOUT_API_ERROR,
    RESET_HTTP_LOGOUT_REQUEST, SET_LOGOUT_REDUX_INITIAL_STATE,
} from '../../resources/constants/storeConstants';

export const triggerLogoutRequest = (screenName) => {
    return({
        type: LOGOUT_REQUEST,
        payload: screenName });
}
export const resetHttpLogoutApiError = () => {
    return({
        type: RESET_HTTP_LOGOUT_API_ERROR,
        payload:'' });
};

export const resetLogoutRequest = () => {
    return({
        type: RESET_HTTP_LOGOUT_REQUEST,
        payload:'' });
};

export const resetLogoutReduxState = () => {
    return({
        type: SET_LOGOUT_REDUX_INITIAL_STATE,
        payload:'' });
}

