/* eslint-disable prettier/prettier */

import {combineReducers} from 'redux';
import LoginReducer from './Login/loginReducer';
import productPageReducer from './ProductPage/productPageReducer';
import resetPasswordReducer from './ResetPassword/resetPasswordReducer';
import cartReducer from './Cart/cartReducer';
import messageReducer from './Message/messageReducer';
import logoutReducer from './Logout/logoutReducer';
import spiffReducer from './Spiff/spiffReducer';
import loginIntermediateReducer from './Login/loginIntermediateReducer';
import orderHistoryReducer from './OrderHistory/orderHistoryReducer';
export default combineReducers({
    login: LoginReducer,
    productPage: productPageReducer,
    resetPassword: resetPasswordReducer,
    cart: cartReducer,
    message: messageReducer,
    logout:logoutReducer,
    spiff: spiffReducer,
    loginIntermediate: loginIntermediateReducer,
    orderHistory: orderHistoryReducer
});
