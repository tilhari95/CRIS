/* eslint-disable prettier/prettier */

import {
    GET_MESSAGE_FAIL,
    GET_MESSAGE_SUCCESS,
    HTTP_MESSAGE_API_ERROR,
    RESET_HTTP_MESSAGE_API_ERROR,
    RESET_MESSAGE_INDICATOR,
    RESET_MESSAGE_PAGE_REDUCER_STATE,
    SEND_MESSAGE_FAIL,
    SEND_MESSAGE_SUCCESS,
    SERVER_PUSH_MESSAGE_RECEIVED,
    SERVER_PUSH_MESSAGE_RESET,
} from '../../resources/constants/storeConstants';

const initialState = {
    getMessageSuccessResponse: null,
    getMessageFailResponse: null,
    sendMessageSuccessResponse: null,
    sendMessageFailResponse: null,
    messageHttpError: null,
    messageFromSeverPushNotification: null,
    messageIndicator: false,
};

export default (state = initialState, action) => {
    switch(action.type) {
        case GET_MESSAGE_SUCCESS:
            return {...state, getMessageSuccessResponse: action.payload}
        case GET_MESSAGE_FAIL:
            return {...state, getMessageFailResponse: action.payload}
        case SEND_MESSAGE_SUCCESS:
            return {...state, sendMessageSuccessResponse: action.payload}
        case SEND_MESSAGE_FAIL:
            return {...state, sendMessageFailResponse: action.payload}
        case RESET_MESSAGE_PAGE_REDUCER_STATE:
            return{...state, ...initialState}
        // case PRODUCT_FORCE_UPDATE:
        //     return{...state, isForceUpdate: action.payload}
        case HTTP_MESSAGE_API_ERROR:
            return{...state, messageHttpError: action.payload}
        case RESET_HTTP_MESSAGE_API_ERROR:
            return{...state, messageHttpError:null }
        case SERVER_PUSH_MESSAGE_RECEIVED:
            return {...state, messageFromSeverPushNotification: action.payload, messageIndicator: true }
        case SERVER_PUSH_MESSAGE_RESET:
            return {...state, messageFromSeverPushNotification: null}
        case RESET_MESSAGE_INDICATOR:
            return{...state, messageIndicator: false }
        default:
            return state;
    }
};
