import {
    GET_MESSAGE_API_REQUEST,
    RESET_HTTP_MESSAGE_API_ERROR, RESET_MESSAGE_INDICATOR,
    SEND_MESSAGE_API_REQUEST, SERVER_PUSH_MESSAGE_RECEIVED, SERVER_PUSH_MESSAGE_RESET,
} from '../../resources/constants/storeConstants';

export const getMessageRequest = () => {
    return({
        type: GET_MESSAGE_API_REQUEST,
        payload: '' });
};
export const sendMessageRequest = (msg) => {
    return({
        type: SEND_MESSAGE_API_REQUEST,
        payload: msg });
};

export const receivedSeverPushNotification = (serverMsgObj) => {
    debugger;
    return({
        type: SERVER_PUSH_MESSAGE_RECEIVED,
        payload: serverMsgObj });
}
export const resetReceivedSeverPushNotification = (serverMsgObj) => {
debugger;
    return({
        type: SERVER_PUSH_MESSAGE_RESET,
        payload: '' });
}


export const resetMessageHttpError = () => {
    return({
        type: RESET_HTTP_MESSAGE_API_ERROR,
        payload: '' });
};


export const resetMessageIndicator = () => {
    return({
       type: RESET_MESSAGE_INDICATOR,
       payload: ''
    });
}
