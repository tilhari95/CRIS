import { takeLatest, call, put } from 'redux-saga/effects';
import { api } from '../../api';
import {
    OK,
    FAIL,
    GENERIC_FAIL,
    RESPONSE_SESSION_EXP,
    ERROR_401,
    RESPONSE_ISSUE,
    INVALID_TOKEN,
    GET_MESSAGE_API_REQUEST,
    GET_MESSAGE_SUCCESS,
    SEND_MESSAGE_API_REQUEST,
    SEND_MESSAGE_SUCCESS,
    HTTP_MESSAGE_API_ERROR, MOBILE_FLAG,
} from '../../resources/constants/storeConstants';
import {takeEvery} from '@redux-saga/core/effects';
import {getOrderDateAndTime} from '../../utils/date';


function* fetchMessageListRequest({ payload: mismatchOrder }) {
    try {
        const response = yield call({ context: api, fn: api.getMessageApi });
    debugger;
        console.log(response);
        if(response.data.response.reasonCode === OK){
            let parserMessageList = [];
            const messageList = response.data.response.messageList;
            if(messageList !==''){
                parserMessageList = JSON.parse(messageList);
            }
            yield put({type: GET_MESSAGE_SUCCESS, payload: parserMessageList})
        }
        else if((response.data.response.reasonCode === FAIL) && (response.data.response.error === RESPONSE_SESSION_EXP
            || response.data.response.error === INVALID_TOKEN) ){
            let errorObj={errorType:RESPONSE_ISSUE, errorBody:response.data.response.error , ErrorStatus: ERROR_401}
            yield put({ type: HTTP_MESSAGE_API_ERROR, payload:  errorObj });
        }
        else if(response.data.response.reasonCode === FAIL){
            yield put({ type: HTTP_MESSAGE_API_ERROR, payload:  { errorType: GENERIC_FAIL, errorBody:response.data.response.error } });
        }
    }
    catch (errorObj) {
        //debugger;
        yield put({ type: HTTP_MESSAGE_API_ERROR, payload: errorObj });
    }
}

function* sendMessageRequest({ payload: messageToSend }) {
    try {
        debugger;
        let dateAndTime =yield call (getOrderDateAndTime);
        let sendMessageBody ={ MessageSource:MOBILE_FLAG, MessageText: messageToSend, DateTime: dateAndTime };
        const response = yield call({ context: api, fn: api.sendMessageApi }, sendMessageBody);
        debugger;
        console.log(response);
        if(response.data.response.reasonCode === OK){
            yield put({type: SEND_MESSAGE_SUCCESS, payload: response.data.response})
        }
        else if((response.data.response.reasonCode === FAIL) && (response.data.response.error === RESPONSE_SESSION_EXP
            || response.data.response.error === INVALID_TOKEN)){
            let errorObj={errorType:RESPONSE_ISSUE, errorBody:response.data.response.error , ErrorStatus: ERROR_401}
            yield put({ type: HTTP_MESSAGE_API_ERROR, payload:  errorObj });
        }
        else if(response.data.response.reasonCode === FAIL){
            yield put({ type: HTTP_MESSAGE_API_ERROR, payload:  { errorType: GENERIC_FAIL, errorBody:response.data.response.error } });
        }
    }
    catch (errorObj) {
        //debugger;
        yield put({ type: HTTP_MESSAGE_API_ERROR, payload: errorObj });
    }
}


// watcher saga: watches for actions dispatched to the store, starts worker saga
export default function* watcherSaga() {
    yield takeLatest(GET_MESSAGE_API_REQUEST, fetchMessageListRequest);
    yield takeEvery(SEND_MESSAGE_API_REQUEST, sendMessageRequest);
}

