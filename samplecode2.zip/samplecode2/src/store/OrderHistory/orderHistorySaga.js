
import { takeLatest, takeEvery, call, put } from 'redux-saga/effects';
import { api } from '../../api';
import {
    OK,
    FAIL,

    RESPONSE_SESSION_EXP,
    INVALID_TOKEN,
    RESPONSE_ISSUE,
    ERROR_401,
    GENERIC_FAIL,
    GET_ORDER_HISTORY_SUCCESS,
    HTTP_ORDER_HISTORY_API_ERROR,
    ORDER_HISTORY_LIST_REQUEST,
    FETCH_ORDER_INVOICE,
    GET_INVOICE_PDF_SUCCESS,
    PDF_LOAD_FAIL,
} from '../../resources/constants/storeConstants';
import RNFetchBlob from 'rn-fetch-blob';

function* fetchOrderHistoryListRequest() {
    try {
        const orderHistoryListResponse = yield call({ context: api, fn: api.orderHistoryListApi });
        console.log(orderHistoryListResponse);
        if(orderHistoryListResponse.data.response.reasonCode === OK){
            let parserOrderHistoryList = [];
            const orderHistoryList = orderHistoryListResponse.data.response.orderList;
            if (orderHistoryList !== '') {
            debugger;
                parserOrderHistoryList = JSON.parse(orderHistoryList);
                console.log(parserOrderHistoryList);
            }
            yield put({type: GET_ORDER_HISTORY_SUCCESS, payload: parserOrderHistoryList})
        }
        else if((orderHistoryListResponse.data.response.reasonCode === FAIL) && (orderHistoryListResponse.data.response.error === RESPONSE_SESSION_EXP
            || orderHistoryListResponse.data.response.error === INVALID_TOKEN)){
            let errorObj={errorType:RESPONSE_ISSUE, errorBody:orderHistoryListResponse.data.response.error , ErrorStatus: ERROR_401}
            yield put({ type: HTTP_ORDER_HISTORY_API_ERROR, payload:  errorObj });
        }
        else if(orderHistoryListResponse.data.response.reasonCode === FAIL){
            yield put({ type: HTTP_ORDER_HISTORY_API_ERROR, payload:  { errorType: GENERIC_FAIL, errorBody:orderHistoryListResponse.data.response.error } });
        }
    }
    catch (errorObj){
        yield put({ type: HTTP_ORDER_HISTORY_API_ERROR, payload: errorObj });
    }
}

function* fetchOrderHistoryInvoice({ payload: invoiceData }) {
    try {
        const pdfSuccessResponse = yield call({ context: api, fn: api.orderInvoiceFetchApi }, invoiceData);
      if(pdfSuccessResponse.success){
          yield put({type: GET_INVOICE_PDF_SUCCESS, payload: pdfSuccessResponse.response})
      }
      else{
          yield put({ type: HTTP_ORDER_HISTORY_API_ERROR, payload: {errorType:PDF_LOAD_FAIL, errorBody:pdfSuccessResponse.response} });
      }
    }
    catch (errorObj){
        console.log(errorObj);
       yield put({ type: HTTP_ORDER_HISTORY_API_ERROR, payload: {errorType:PDF_LOAD_FAIL, errorBody: ''} });
    }
}


export default function* watcherSaga() {
    yield takeLatest(ORDER_HISTORY_LIST_REQUEST, fetchOrderHistoryListRequest);
    yield takeLatest(FETCH_ORDER_INVOICE, fetchOrderHistoryInvoice);

}

