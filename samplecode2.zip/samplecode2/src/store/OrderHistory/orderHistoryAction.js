import {
    FETCH_ORDER_INVOICE,
    ORDER_HISTORY_LIST_REQUEST, RESET_HTTP_ORDER_HISTORY_API_ERROR, RESET_ORDER_HISTORY_REDUCER_STATE,
} from '../../resources/constants/storeConstants';

export const orderHistoryListRequest = () => {
    return({
        type: ORDER_HISTORY_LIST_REQUEST,
        payload: '' });
};
export const resetOrderHistoryApiError = () => {
    return({
        type: RESET_HTTP_ORDER_HISTORY_API_ERROR,
        payload:'' });
};

export const resetOrderHistoryRedux = () => {
    return({
        type: RESET_ORDER_HISTORY_REDUCER_STATE,
        payload:'' });
}

export const fetchOrderInvoice = (invoiceData) => {
    return({
        type: FETCH_ORDER_INVOICE,
        payload:invoiceData
    })
}
