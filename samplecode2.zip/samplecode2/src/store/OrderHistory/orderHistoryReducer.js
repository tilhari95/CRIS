import {
    GET_INVOICE_PDF_SUCCESS,
    GET_MESSAGE_FAIL,
    GET_MESSAGE_SUCCESS, GET_ORDER_HISTORY_SUCCESS,
    GET_SPIFF_TRANCTION_SUCCESS,
    GET_SPIFF_TRANSACTION_FAIL,
    HTTP_MESSAGE_API_ERROR, HTTP_ORDER_HISTORY_API_ERROR,
    HTTP_SPIFF_LANDING_PAGE_API_ERROR, HTTP_SPIFF_PAYOUT_PAGE_API_ERROR, PAYOUT_FINAL_REQUEST_SUCCESS,
    RESET_HTTP_MESSAGE_API_ERROR, RESET_HTTP_ORDER_HISTORY_API_ERROR,
    RESET_MESSAGE_INDICATOR,
    RESET_MESSAGE_PAGE_REDUCER_STATE, RESET_ORDER_HISTORY_REDUCER_STATE,
    RESET_SPIFF_LANDING_PAGE_API_ERROR, RESET_SPIFF_PAYOUT_API_RESPONSE, RESET_SPIFF_PAYOUT_PAGE_API_ERROR,
    RESET_SPIFF_REDUCER_STATE,
    RESET_SPIFF_TRANCTION_BALANCE_API,
    SEND_MESSAGE_FAIL,
    SEND_MESSAGE_SUCCESS,
    SERVER_PUSH_MESSAGE_RECEIVED,
    SERVER_PUSH_MESSAGE_RESET, SPIFF_PAYMENT_MODE_SUCCESS,
} from '../../resources/constants/storeConstants';

const initialState = {
    orderHistoryListSuccessResponse: null,
    orderHistoryPageHttpError: null,
    invoicePdfSuccessResponse: null
};

export default (state = initialState, action) => {
    switch(action.type) {
        case GET_ORDER_HISTORY_SUCCESS:
            return {...state, orderHistoryListSuccessResponse: action.payload}
        case RESET_HTTP_ORDER_HISTORY_API_ERROR:
            return {...state, orderHistoryPageHttpError: null}
        case HTTP_ORDER_HISTORY_API_ERROR:
            return {...state, orderHistoryPageHttpError: action.payload}
        case RESET_ORDER_HISTORY_REDUCER_STATE:
            return{...state, ...initialState}
        case GET_INVOICE_PDF_SUCCESS:
            return {...state, invoicePdfSuccessResponse: action.payload}
        default:
            return state;
    }
};
