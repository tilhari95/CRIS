/* eslint-disable prettier/prettier */

import {
    PRODUCT_REQUEST_SUCCESS,
    SET_DATE_STRING,
    SET_PRODUCT_LIST_DATA,
    SET_USER_BRAND_DATA,
    RESET_PRODUCT_PAGE_REDUCER_STATE,
    PRODUCT_FORCE_UPDATE,
    HTTP_PRODUCT_API_ERROR,
    RESET_HTTP_PRODUCT_API_ERROR,
    RESET_PRODUCT_PAGE_REDUCER_ON_LOGOUT, RESET_USER_ASYNC_IN_REDUX,
} from '../../resources/constants/storeConstants';
import { Status } from '../../api';

const initialState = {
    userBrandDataFromAsync: null,
    productSuccessResponse: null,
    status: Status.DEFAULT,
    productFailError: null,
    dateString: null,
    isForceUpdate: false,
    productHttpError: null,
    tagList: null,
};

export default (state = initialState, action) => {
    switch(action.type) {
        case SET_USER_BRAND_DATA:
            return {...state, userBrandDataFromAsync: action.payload}
        case SET_PRODUCT_LIST_DATA:
            return {...state, productSuccessResponse: action.payload.productList, tagList: action.payload.tagList }
        case PRODUCT_REQUEST_SUCCESS:
            return{...state, productSuccessResponse: action.payload.productList , dateString: action.payload.date, tagList: action.payload.tagList }
        case SET_DATE_STRING:
        return {...state,dateString: action.payload}
        case RESET_PRODUCT_PAGE_REDUCER_ON_LOGOUT:
            return{...state,
                productSuccessResponse: null,
                status: Status.DEFAULT,
                productFailError: null,
                dateString: null,
                isForceUpdate: false,
                productHttpError: null,
                tagList: null,
            }
        case RESET_USER_ASYNC_IN_REDUX:
            return{...state, userBrandDataFromAsync: null,}
        case RESET_PRODUCT_PAGE_REDUCER_STATE:
            return{...state, ...initialState}
        case PRODUCT_FORCE_UPDATE:
            debugger;
            return{...state, isForceUpdate: action.payload}
        case HTTP_PRODUCT_API_ERROR:
            return{...state, productHttpError: action.payload}
        case RESET_HTTP_PRODUCT_API_ERROR:
            return{...state, productHttpError:null}
        default:
            return state;
    }
};
