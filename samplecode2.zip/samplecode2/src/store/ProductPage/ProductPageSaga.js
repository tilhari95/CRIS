/* eslint-disable prettier/prettier */
import { takeLatest, call, put } from 'redux-saga/effects';
import { api } from '../../api';
import {
    OK,
    FAIL,
    PRODUCT_API_REQUEST,
    PRODUCT_REQUEST_SUCCESS,
    HTTP_PRODUCT_API_ERROR,
    ASYNC_FAIL,
    GENERIC_FAIL, RESET_CART_LIST, RESPONSE_SESSION_EXP, ERROR_401, RESPONSE_ISSUE, INVALID_TOKEN,
} from '../../resources/constants/storeConstants';
import {
    CART_LIST, LAST_PRODUCT_UPDATE_DATE,
    LOGGED_IN_EMAIL,
    PRODUCT_LIST, PRODUCT_TAG_LIST,
} from '../../resources/constants/asyncKeys';
import AppAsyncStorage from '../../api/helper/AppAsyncStorage';


const productListToAsync= async(productData, tagData, dateString, mismatchOrder) =>{
    try{
    debugger;
        await AppAsyncStorage.setValue(PRODUCT_LIST, productData);
        await AppAsyncStorage.setValue(PRODUCT_TAG_LIST, tagData);
        await AppAsyncStorage.setValue(LAST_PRODUCT_UPDATE_DATE, dateString);
        if(!mismatchOrder){
            await AppAsyncStorage.setValue(CART_LIST,'');
        }
    debugger;
        return true;
    }
    catch{
    debugger;
        console.log(error);
        return false;
    }

}

function* fetchProductListRequest({ payload: mismatchOrder }) {
    try {
        debugger;
       const response = yield call({ context: api, fn: api.productApi });
        if(response.data.response.reasonCode === OK){
            // setting as empty array rather than string--> TODO at server end
            if(response.data.response.itemList === ''){
                response.data.response.itemList='[]';
            }
            if(response.data.response.tags === ''){
                response.data.response.tags='[]';
            }
            let productListData= JSON.parse(response.data.response.itemList);
            let tagListData= JSON.parse(response.data.response.tags);
            // console.log('product list --->>>');
            console.log(tagListData);
            console.log(productListData);
            const date = new Date();
            let dateString =JSON.stringify(date);
            const setProductAsync= yield call(productListToAsync, response.data.response.itemList, response.data.response.tags,
                dateString, mismatchOrder );
            debugger;
            if(setProductAsync){
                yield put({type: PRODUCT_REQUEST_SUCCESS, payload: {productList: productListData, date: dateString, tagList:tagListData }});
                if(!mismatchOrder)
                    yield put({type: RESET_CART_LIST, payload: []});
            }
            else{
                yield put({ type: HTTP_PRODUCT_API_ERROR, payload:  {errorType: ASYNC_FAIL} });
            }
        }
        else if((response.data.response.reasonCode === FAIL) && (response.data.response.error === RESPONSE_SESSION_EXP
            || response.data.response.error === INVALID_TOKEN) ){
            let errorObj={errorType:RESPONSE_ISSUE, errorBody:response.data.response.error , ErrorStatus: ERROR_401}
            yield put({ type: HTTP_PRODUCT_API_ERROR, payload:  errorObj });
        }
        else if(response.data.response.reasonCode === FAIL){
            yield put({ type: HTTP_PRODUCT_API_ERROR, payload:  { errorType: GENERIC_FAIL, errorBody:response.data.response.error } });
        }
    }
    catch (errorObj) {
        //debugger;
        yield put({ type: HTTP_PRODUCT_API_ERROR, payload: errorObj });
    }
}

// watcher saga: watches for actions dispatched to the store, starts worker saga
export default function* watcherSaga() {
    yield takeLatest(PRODUCT_API_REQUEST, fetchProductListRequest);
}
