import {
    SET_USER_BRAND_DATA,
    PRODUCT_API_REQUEST,
    SET_PRODUCT_LIST_DATA,
    SET_DATE_STRING, PRODUCT_FORCE_UPDATE, RESET_HTTP_PRODUCT_API_ERROR, RESET_USER_ASYNC_IN_REDUX,
} from '../../resources/constants/storeConstants';

export const setUserDataFromAsync = data => ({
    type: SET_USER_BRAND_DATA,
    payload: data,
});

export const setProductListFromAsync = (productList, tagList) => ({
    type: SET_PRODUCT_LIST_DATA,
    payload: { productList: productList, tagList: tagList },
});

export const productListRequest = () => {
    const mismatchOrder= false;
    return({
        type: PRODUCT_API_REQUEST,
        payload: mismatchOrder });
};
export const resetHttpProductApiError = () => {
    return({
        type: RESET_HTTP_PRODUCT_API_ERROR,
        payload:'' });
};


export const resetBrandAsyncFromRedux = () =>{
    return({
        type: RESET_USER_ASYNC_IN_REDUX,
        payload:'' });
}


export const setDateStringFromAsync = (data)=>{
    return({
        type: SET_DATE_STRING,
        payload:data
    })
}
export const setIsForceUpdate = (bool)=>{
    return({
        type: PRODUCT_FORCE_UPDATE,
        payload:bool
    })
}


