import axios from 'axios';
import Logger from './helper/apiLogger';
import {baseUrl, basePath} from './helper/ApiEndpoints'
import AppAsyncStorage from './helper/AppAsyncStorage';
import {
  ERROR_UNKNOWN,
  EXCEPTION_ISSUE,
  REQUEST_ISSUE,
  RESPONSE_ISSUE,
} from '../resources/constants/storeConstants';
const defaultOptions = {
  baseUrl: baseUrl,
  basePath: basePath,
}





const getHeaders = async (setAuthHeader) => {
  debugger;
  let requestheaders={};
  if(setAuthHeader) {
    let token = await AppAsyncStorage.getValue('sessionToken');
    console.log(token);
    requestheaders = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    debugger;
    console.log(requestheaders);
    return requestheaders;
  }
  else
  {
    requestheaders = {
      'Content-Type': 'application/json'
    };
    return requestheaders;
  }


};


/**
 * Provide a layer over the axios library, to
 * configure request parameters before making a HTTP call.
 *
 * NOTE: This class shouln't be used directly,
 * use api object from api.js
 */
class Request {
  constructor() {
    this.configuration = { ...defaultOptions };
  }

  post(endpoint, params, data, setAuthenticationHeader = false) {
    return this.send(endpoint, 'POST', params, data, setAuthenticationHeader);
  }

  put(endpoint, params, data, setAuthenticationHeader = false) {
    return this.send(endpoint, 'PUT', params, data, setAuthenticationHeader);
  }

  get(endpoint, params, data, setAuthenticationHeader = false) {
    return this.send(endpoint, 'GET', params, data, setAuthenticationHeader);
  }

  delete(endpoint, params, data, setAuthenticationHeader = false) {
    return this.send(endpoint, 'DELETE', params, data, setAuthenticationHeader);
  }

  async send(
    /**
     * Api endpoint that will be appended
     * with base_url + root_path, to form complete url
     */
    endpoint,
    /**
     * `method` is the HTTP request method to indicate
     * the desired action to be performed for a given resource
     *
     * https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods
     */
    method,
    /**
     * `params` are the URL GET parameters to be appended with the url.
     * Must be a plain object or a URLSearchParams object
     */
    params,
    /**
     * `data` is the data to be sent as the request body
     * Only applicable for request methods 'PUT', 'POST', and 'PATCH'
     * When no `transformRequest` is set, must be of one of the following types:
     * - string, plain object, ArrayBuffer, ArrayBufferView, URLSearchParams
     * - Browser only: FormData, File, Blob
     * - Node only: Stream, Buffer
     */
    data,
    /**
     * to include Authentication in request header
     */
    setAuthenticationHeader

  ){
    debugger;
    let url = `${this.configuration.baseUrl}${this.configuration.basePath}${endpoint}`;
    console.log(url);
    const headers = await getHeaders(setAuthenticationHeader);
    debugger;
    return new Promise((resolve, reject) => {
      debugger;
      Logger.describeRequest({ url, method, headers, params ,data });

      axios({
        url,
        method,
        headers,
        params,
        data,
        timeout: 10000
      })
        .then(response => {
          debugger;
          Logger.describeSuccessResponse(response);
          resolve(response.data);
          console.log(response.data);
        })
        .catch(error => {
          debugger;
          Logger.describeErrorResponse(error);
          console.log(error);
          if (error.response) { // internal server error
            debugger;
            console.log(error.response);
            let errorObj={errorType:RESPONSE_ISSUE, errorBody: error, ErrorStatus: error.response.status}
            console.log(errorObj)
            reject(errorObj);
            // The request was made and the server responded with a status code
            // that falls out of the range of 2xx
            // handle error here
          } else if (error.request) { ///request time out network error
            debugger;
            console.log(error.request);
            let errorObj={errorType:REQUEST_ISSUE, errorBody: error, ErrorStatus:error.request.status}
            console.log(errorObj)
            reject(errorObj);
            // The request was made but no response was received
            // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
          } else {
            let errorObj={errorType:EXCEPTION_ISSUE, errorBody: error, ErrorStatus: ERROR_UNKNOWN}
            console.log(errorObj)
            reject(errorObj);
            // Something happened in setting up the request that triggered an Error
          }
        });
    });
  }
}

export default Request;

