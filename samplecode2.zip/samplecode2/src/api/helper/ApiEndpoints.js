export const loginAPIEndpoint = '/Login/Login';
export const userBrandAPIEndpoint = '/Login/GetUserData';
export const productListAPIEndpoint = '/Item/GetClientAppItems';
export const resetPasswordAPIEndpoint = '/Login/ForgotPassword';
export const logoutAPIEndpoint = '/login/Logout';
export const checkOrderDetilAPIEndpoint = '/Item/CheckOrderDetails';
export const placeOrderAPIEndpoint = '/Item/AddAppOrder';
export const getMessageAPIEndpoint = '/Messages/GetMessagesData';
export const sendMessageAPIEndpoint = '/Messages/AddMessages';
export const userTemplateAPIEndpoint = '/Login/GetTemplateData';
export const userCompanyAPIEndpoint = '/Login/GetCompanyData';

export const spiffPayoutTypesAPIEndpoint = '/Spiff/GetPayoutTypes';
export const spiffPayoutReqAPIEndpoint = '/Spiff/RequestPayout';
export const spiffTranactionAPIEndpoint = '/Spiff/GetSpiffTransactions';
export const spiffBalanceAPIEndpoint = '/Spiff/GetSpiffBalance';

export const orderHistoryListAPIEndpoint ='/Item/GetOrderList';
export const pdfDownloadEndpoint = '/download/download';

export const companyListImageURL = 'https://mcni-logos.s3.us-east-2.amazonaws.com/';
export const genericImageURL = 'https://mcni-itemimages.s3.us-east-2.amazonaws.com/'; // for dev staging --> http://166.62.46.170:8089/ItemImages/
//for live server -->> https://www.mcni360clientapp.com
// for development server IONOS-->> http://198.71.61.66:8087
// for staging server IONOS -->> http://198.71.61.66:8083
export const baseUrl = 'http://198.71.61.66:8083';
export const basePath = '/api';



//go daddy urls
//dev server  -->>http://166.62.46.170:8087'; //dev staging url ip-->>http://166.62.46.170:8191'
// for dev staging --> http://166.62.46.170:8089/ItemImages/
