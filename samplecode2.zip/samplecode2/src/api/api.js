import Request from './Request';
import {
  basePath, baseUrl,
  checkOrderDetilAPIEndpoint,
  getMessageAPIEndpoint,
  loginAPIEndpoint,
  logoutAPIEndpoint, orderHistoryListAPIEndpoint, pdfDownloadEndpoint,
  placeOrderAPIEndpoint,
  productListAPIEndpoint,
  resetPasswordAPIEndpoint,
  sendMessageAPIEndpoint,
  spiffBalanceAPIEndpoint, spiffPayoutReqAPIEndpoint,
  spiffPayoutTypesAPIEndpoint,
  spiffTranactionAPIEndpoint,
  userBrandAPIEndpoint, userCompanyAPIEndpoint, userCompanyTemplateAPIEndpoint, userTemplateAPIEndpoint,
} from './helper/ApiEndpoints';
import fcmToken from '../services/PushNotifications/fcmToken';
import AppAsyncStorage from './helper/AppAsyncStorage';
import {FCM_TOKEN} from '../resources/constants/asyncKeys';
import {Platform} from 'react-native';
import store from '../store';
import {validateRequiredField} from '../utils/validators';
import RNFetchBlob from 'rn-fetch-blob';


const getCompanyAndTemplateId = () => {
  let brandSuccessResponse = store.getState().login.brandSuccessResponse;
  let userBrandDataFromAsync = store.getState().productPage.userBrandDataFromAsync;

  if(validateRequiredField(brandSuccessResponse)){
    return ({companyId: brandSuccessResponse.responseData.CompanyId, templateId: brandSuccessResponse.responseData.AppTemplateHeaderId})
  }
  else if(validateRequiredField(userBrandDataFromAsync)){
    return ({companyId: userBrandDataFromAsync.CompanyId, templateId: userBrandDataFromAsync.AppTemplateHeaderId})
  }
  else
    return null
}



/**
 * Class that exposes REST API endpoints
 */
class Api {
  constructor() {
    this.request = new Request();
  }

  /**
   * Get list of trending repositories for a given date
   */
  getTrendingRepo(date) {
    const params = {
      q: `created:${date}`,
      sort: 'stars',
      order: 'desc',
    };

    return this.request.post('/search/repositories', params, undefined);
  }

  loginApi(email, password) {
    const params = undefined;
    const data={
      "EmailAddress": email,
      "Password":password
    };
    return this.request.post(loginAPIEndpoint, params, data);
  }

  checkOrderDetailsApi(bodyObj) {
    //debugger;
    const params = undefined;
    let requiredIds = getCompanyAndTemplateId();
    const data={...bodyObj, 'CompanyId': requiredIds.companyId, 'AppTemplateHeaderId': requiredIds.templateId};
    return this.request.post(checkOrderDetilAPIEndpoint, params, data, true);
  }

  placeOrderApi(bodyObj) {
    //debugger;
    const params = undefined;
    let requiredIds = getCompanyAndTemplateId();
    const data={...bodyObj, 'CompanyId': requiredIds.companyId, 'AppTemplateHeaderId': requiredIds.templateId};
    return this.request.post(placeOrderAPIEndpoint, params, data, true);
  }


  async userBrandApi(companyId, templateId) {
    let fcmToken = await AppAsyncStorage.getValue(FCM_TOKEN);
    const data={
      "FCMToken": fcmToken,
      "DeviceType": Platform.OS,
      "CompanyId":companyId,
      "AppTemplateHeaderId":templateId
    };
    // debugger;
    // console.log(data);
    return this.request.post(userBrandAPIEndpoint, undefined, data, true);
  }

  async userCompanyApi() {
    return this.request.post(userCompanyAPIEndpoint, undefined, undefined, true);
  }

  async userTemplateApi(CompanyId) {
    const data ={
      'CompanyId': CompanyId
    }
    return this.request.post(userTemplateAPIEndpoint, undefined, data, true);
  }

  productApi(){
    let requiredIds = getCompanyAndTemplateId();
    const data ={ 'CompanyId': requiredIds.companyId, 'Id': requiredIds.templateId}
    return this.request.post(productListAPIEndpoint, undefined, data, true);

  }
  resetPasswordApi(email){
    const data={
      "EmailAddress": email
    };
    return this.request.post(resetPasswordAPIEndpoint, undefined, data, false);
  }
  getMessageApi(){
    return this.request.post(getMessageAPIEndpoint, undefined, undefined, true);

  }
  sendMessageApi(sendMessageBody){
    return this.request.post(sendMessageAPIEndpoint, undefined, sendMessageBody, true);

  }

  sendPayoutTypesApi(){
    return this.request.post(spiffPayoutTypesAPIEndpoint, undefined, undefined, true);

  }

  spiffPayoutRequestApi(spiffPayoutData){
    let requiredIds = getCompanyAndTemplateId();
    let data ={...spiffPayoutData, 'CompanyId': requiredIds.companyId}
    return this.request.post(spiffPayoutReqAPIEndpoint, undefined, data, true);

  }

 orderHistoryListApi(){
    let requiredIds = getCompanyAndTemplateId();
    let data ={ "FromDate": "2019-12-17", "ToDate": "2020-08-19", "CompanyId": requiredIds.companyId} //"62CEF7CF-2F69-4DB2-B6B9-34E06ED849AE"} //requiredIds.companyId
    return this.request.post(orderHistoryListAPIEndpoint, undefined, data, true);

  }

  orderInvoiceFetchApi(invoiceData){
    let requiredIds = getCompanyAndTemplateId();
    let dirs = RNFetchBlob.fs.dirs;
    //const constructedAPIendpoint= 'http://166.62.46.170:8191/api/download/download?invoiceNo=107292&companyId=d7c5244c-8f25-4408-9ed6-d3256e625a94'
    const constructedAPIendpoint = baseUrl + basePath + pdfDownloadEndpoint + '?invoiceNo=' + invoiceData.AppOrderNo + '&companyId=' + requiredIds.companyId;
    console.log('calling api-->');
    console.log(constructedAPIendpoint);
    //debugger;
    return RNFetchBlob.config({
      fileCache : true,
      //appendExt : 'pdf',
      path : dirs.DocumentDir + '/'+ invoiceData.AppOrderNo +'_invoice.pdf',
      addAndroidDownloads : {
        useDownloadManager : true,
        title : 'Fetching Order invoice',
        description : 'pdf is downloading',
        mime : 'application/pdf',
        mediaScannable : true,
        notification : true,
        path : dirs.DownloadDir + '/'+ invoiceData.AppOrderNo +'_invoice.pdf',
      }
    }).fetch('GET', constructedAPIendpoint)
        .then((resp) => {
          console.log('yeah downloaded ----->>>>>');
          console.log(resp);
          return ({response:resp, success: true});
        })
        .catch((error) => {
          console.log('error while downloading pdf');
          return({response:error, success: false});
        })
  }

  spiffTranactionApi(){
    let requiredIds = getCompanyAndTemplateId();
    const data={ 'CompanyId': requiredIds.companyId};
    return this.request.post(spiffTranactionAPIEndpoint, undefined, data, true);
  }

  spiffBalanceApi(){
    let requiredIds = getCompanyAndTemplateId();
    const data={ 'CompanyId': requiredIds.companyId};
    return this.request.post(spiffBalanceAPIEndpoint, undefined, data, true);
  }

  async logoutApi(){
    let fcmToken = await AppAsyncStorage.getValue(FCM_TOKEN);
    const data={
      "FCMToken": fcmToken
    };
    return this.request.post(logoutAPIEndpoint, undefined, data, false);
  }


}
let api = new Api();

export default api;
