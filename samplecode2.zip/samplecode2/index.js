import {AppRegistry} from 'react-native';
import App from './src/App';
import {name as appName} from './app.json';
import messaging from '@react-native-firebase/messaging';
import {parseNotficationData} from './src/services/PushNotifications/parseNotificationData';

// Register background handler, can be used for making changes in async and doing network related work.
// No changes in DOM as app is still not mounted.
messaging().setBackgroundMessageHandler(async remoteMessage => {
    console.log('Notification handled in the background!-->>' + JSON.stringify(remoteMessage));
    parseNotficationData(remoteMessage);

});

AppRegistry.registerComponent(appName, () => App);
